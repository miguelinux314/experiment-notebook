#if ! defined( VTM_VERSION )
#define VTM_VERSION "15.0"
#endif
