package List;

public class SpihtVector {
	protected int[] elementDataX;
	protected int[] elementDataY;
	protected int[] elementDataZ;
	protected boolean[] type;
	
	protected boolean typed;
	protected int dimension;
	
	
	protected int elementCount;
	
	protected int initialCapacity;
	protected int capacityIncrement;
	
	public SpihtVector(int initialCapacity, int capacityIncrement, int dimension, boolean typed) {
		//super();
		if (initialCapacity <= 0) throw new IllegalArgumentException("Illegal Capacity: " + initialCapacity);
		if (capacityIncrement <= 0) throw new IllegalArgumentException("Illegal Capacity Increment: " + capacityIncrement);
		if ( (dimension < 1) || (dimension > 3) ) throw new IllegalArgumentException("Dimension Illegal: " + dimension);
		
		elementDataY = null;
		elementDataZ = null;
		type = null;
		elementCount = 0;
		
		this.elementDataX = new int[initialCapacity];
		
		if(dimension > 1) this.elementDataY = new int[initialCapacity];
		if(dimension > 2) this.elementDataZ = new int[initialCapacity];
		if(typed) this.type = new boolean[initialCapacity];
		
		this.typed = typed;
		this.initialCapacity = initialCapacity;
		this.capacityIncrement = capacityIncrement;
		this.dimension = dimension;
	}
	
	public int capacity() {
		return elementDataX.length;
	}
	
	public int size() {
		return elementCount;
	}
	public void ensureCapacity() {
		int [] newElementData;
		
		newElementData = new int[initialCapacity + capacityIncrement];
		
		System.arraycopy(elementDataX, 0, newElementData, 0, elementCount);
		elementDataX = newElementData;
		newElementData = null;
		
		if(dimension > 1) {
			newElementData = new int[initialCapacity + capacityIncrement];
			
			System.arraycopy(elementDataY, 0, newElementData, 0, elementCount);
			elementDataY = newElementData;
			newElementData = null;
		}
		if(dimension > 2) {
			newElementData = new int[initialCapacity + capacityIncrement];
			
			System.arraycopy(elementDataZ, 0, newElementData, 0, elementCount);
			elementDataZ = newElementData;
			newElementData = null;
		}
		if(typed) {
			boolean[] newTypeData;
			newTypeData = new boolean[initialCapacity + capacityIncrement];
			
			System.arraycopy(type, 0, newTypeData, 0, elementCount);
			type = newTypeData;
			newTypeData = null;
		}
		initialCapacity += capacityIncrement;
	}
	
	public boolean isEmpty() {
		return (elementCount == 0);
	}
	public int getX(int index) {
		if (index >= elementDataX.length) throw new ArrayIndexOutOfBoundsException("getX: " + index + " > " + elementCount);
		
		return elementDataX[index];
	}
	public int getY(int index) throws Exception {
		if (index >= elementDataX.length) throw new ArrayIndexOutOfBoundsException(index + " > " + elementCount);
		if(dimension < 2) throw new Exception("Second Dimension not defined");
		
		return elementDataY[index];
	}
	public int getZ(int index) throws Exception {
		if (index >= elementDataX.length) throw new ArrayIndexOutOfBoundsException(index + " > " + elementCount);
		if(dimension < 3) throw new Exception ("Third Dimension not defined");
		
		return elementDataZ[index];
	}
	public boolean getType(int index) throws Exception {
		if (index >= type.length) throw new ArrayIndexOutOfBoundsException(index + " > " + elementCount);
		if(!typed) throw new Exception ("Type Not Defined");
		
		return type[index];
	}
	public void setType(int index, boolean type) throws Exception {
		if (index >= elementCount) throw new ArrayIndexOutOfBoundsException(index + " > " + elementCount);
		if(!typed) throw new Exception ("The list has no type");
		
		this.type[index] = type;
	}
	
	public void removeCollectionOfElements(int[] index, int indexLength) throws Exception {
		int numberOfElements;
		
		if(index == null) throw new Exception("Index Vector is null");
		if(indexLength == 0) return;
		
		indexLength--;
		
		for(int i=indexLength;i>= 0;i--) {
			numberOfElements = elementCount - index[i] - 1;
			if(numberOfElements > 0) {
				
				System.arraycopy(elementDataX, index[i] + 1, elementDataX, index[i], numberOfElements);
				elementDataX[elementCount] = 0;
				
				if(typed) {
					System.arraycopy(type, index[i] + 1, type, index[i], numberOfElements);
					type[elementCount] = false;
				}
				
				if(dimension > 1) {
					System.arraycopy(elementDataY, index[i] + 1, elementDataY, index[i], numberOfElements);
					elementDataY[elementCount] = 0;
				}
				if(dimension > 2) {
					System.arraycopy(elementDataZ, index[i] + 1, elementDataZ, index[i], numberOfElements);
					elementDataZ[elementCount] = 0;
				}
			}
			elementDataX[elementCount] = 0;
			if(typed) type[elementCount] = false;
			if(dimension > 1) elementDataY[elementCount] = 0;
			if(dimension > 2) elementDataZ[elementCount] = 0;
			
			elementCount--;
		} // for
	}
	public void removeElement(int index) {
		int numberOfElements;
		
		if (index < 0) throw new IllegalArgumentException("Illegal Index: " + index);
		if (index >= elementCount) throw new ArrayIndexOutOfBoundsException(index + " >= " + elementCount);
		
		numberOfElements = elementCount - index - 1;
		
		if(numberOfElements > 0) {
			System.arraycopy(elementDataX, index + 1, elementDataX, index, numberOfElements);
			
			if(typed) System.arraycopy(type, index + 1, type, index, numberOfElements);
			
			if(dimension > 1) {
				System.arraycopy(elementDataY, index + 1, elementDataY, index, numberOfElements);
			}
			if(dimension > 2) {
				System.arraycopy(elementDataZ, index + 1, elementDataZ, index, numberOfElements);
			}
		}
		elementDataX[elementCount] = 0;
		if(typed) type[elementCount] = false;
		if(dimension > 1) elementDataY[elementCount] = 0;
		if(dimension > 2) elementDataZ[elementCount] = 0;
		
		elementCount--;
	}
	
	public void addElement(int elementX) {
		if( (elementCount + 1) >= elementDataX.length ) ensureCapacity();
		
		if(typed) throw new IllegalArgumentException("The list is typed. Each component of the list has an associated type.");
		
		elementDataX[elementCount] = elementX;
		
		elementCount++;
	}
	public void addElement(int elementX, boolean type) {
		if( (elementCount + 1) >= elementDataX.length ) ensureCapacity();
		
		elementDataX[elementCount] = elementX;
		
		if(!typed) throw new IllegalArgumentException("The list is not typed");
		
		this.type[elementCount] = type;
		
		elementCount++;
	}
	public void addElement(int elementX, int elementY) {
		if( (elementCount + 1) >= elementDataX.length ) ensureCapacity();
		
		if(typed) throw new IllegalArgumentException("The list is typed. Each component of the list has an associated type.");
		
		elementDataX[elementCount] = elementX;
		elementDataY[elementCount] = elementY;
		
		elementCount++;
	}
	public void addElement(int elementX, int elementY, boolean type) {
		if( (elementCount + 1) >= elementDataX.length ) ensureCapacity();
		
		elementDataX[elementCount] = elementX;
		elementDataY[elementCount] = elementY;
		
		if(!typed) throw new IllegalArgumentException("The list is not typed");
		this.type[elementCount] = type;
		
		elementCount++;
	}
	public void addElement(int elementX, int elementY, int elementZ) {
		if( (elementCount + 1) >= elementDataX.length ) ensureCapacity();
		
		if(typed) throw new IllegalArgumentException("The list is typed. Each component of the list has an associated type.");
		
		elementDataX[elementCount] = elementX;
		elementDataY[elementCount] = elementY;
		elementDataZ[elementCount] = elementZ;
		
		elementCount++;
	}
	public void addElement(int elementX, int elementY, int elementZ, boolean type) {
		if( (elementCount + 1) >= elementDataX.length ) ensureCapacity();
		
		elementDataX[elementCount] = elementX;
		elementDataY[elementCount] = elementY;
		elementDataZ[elementCount] = elementZ;
		
		if(!typed) throw new IllegalArgumentException("The list is not typed");
		this.type[elementCount] = type;
		
		elementCount++;
	}
	public void copyInto(int[] anArray, int length) {
		if(anArray.length < length) throw new IllegalArgumentException("The length " + length + " >= array length.");
		
		while( (elementCount + length) >= elementDataX.length) ensureCapacity();
		
		System.arraycopy(anArray, 0, elementDataX, elementCount, length);
		
		elementCount += length;
	}
	public void copyInto(int[] anXArray,int[] anYArray, int length) {
		if(anXArray.length < length) 
			throw new IllegalArgumentException("The length of X array " + length + " >= array length.");
		if(anYArray.length < length)
			throw new IllegalArgumentException("The length of Y array " + length + " >= array length.");
		
		//Aqui hay un bug, hay que contemplar el caso de que hallamos reservado mas memoria.
		if(initialCapacity <= (elementCount + length))
			throw new IllegalArgumentException("The length " + length + " >= elementData length.");
		
		System.arraycopy(anXArray, 0, elementDataX, elementCount, length);
		System.arraycopy(anYArray, 0, elementDataY, elementCount, length);
		
		elementCount += length;
	}
	public void copyInto(int[] anXArray, int[] anYArray, int[] anZArray, int length) {
		if(anXArray.length < length)
			throw new IllegalArgumentException("The length of X array " + length + " >= array length.");
		if(anYArray.length < length)
			throw new IllegalArgumentException("The length of Y array " + length + " >= array length.");
		if(anZArray.length < length)
			throw new IllegalArgumentException("The length of Z array " + length + " >= array length.");
		
		//Aqui hay un bug, hay que contemplar el caso de que hallamos reservado mas memoria.
		if(initialCapacity <= (elementCount + length))
			throw new IllegalArgumentException("The length " + length + " >= elementData length.");
		
		System.arraycopy(anXArray, 0, elementDataX, elementCount, length);
		System.arraycopy(anYArray, 0, elementDataY, elementCount, length);
		System.arraycopy(anZArray, 0, elementDataZ, elementCount, length);
		
		elementCount += length;
	}
	public int[] getElementDataX() {
		int[] elementData;
		
		elementData = new int[elementCount];
		for(int i=0;i<elementCount;i++) elementData[i] = elementDataX[i];
		
		return elementData;
	}
	public int[] getElementDataY() {
		int[] elementData;
		
		if(dimension < 2) throw new IllegalArgumentException("The second dimension is not defined");
		
		elementData = new int[elementCount];
		for(int i=0;i<elementCount;i++) elementData[i] = elementDataY[i];
		
		return elementData;
	}
	public int[] getElementDataZ() {
		int[] elementData;
		
		if(dimension < 3) throw new IllegalArgumentException("The third dimension is not defined");
		
		elementData = new int[elementCount];
		for(int i=0;i<elementCount;i++) elementData[i] = elementDataY[i];
		
		return elementData;
	}
	public boolean[] getElementType() {
		if(!typed) throw new IllegalArgumentException("The types are not defined");
		return type;
	}

	public SpihtVector cloneObject() {
		SpihtVector spv;
		
		spv = new SpihtVector(initialCapacity, capacityIncrement, dimension, typed);
		
		if(dimension == 1) spv.copyInto(elementDataX, elementCount);
		else if(dimension == 2) spv.copyInto(elementDataX, elementDataY, elementCount);
		else if(dimension == 3) spv.copyInto(elementDataX, elementDataY, elementDataZ, elementCount);
		
		return spv;
	}

}
