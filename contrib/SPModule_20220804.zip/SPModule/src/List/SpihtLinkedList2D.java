package List;

/**
 * An implementation of LinkedList class adapted for the 2D SPIHT algorithm
 * Using a linked list to define the LIC, LIS and LSC lists in the SPIHT algorithm.
 * <p>
 * @author González-Conejero, Jorge
 * @version 1.0 04/02/2004
 */

public class SpihtLinkedList2D {
	/**
	 * A reference to the head of the list.
	 * <p>
	 * 
	 */
	private transient Entry head;
	/**
	 * A reference to the last node of the list.
	 * <p>
	 * 
	 */
	public transient Entry lastEntry;
	/**
	 * A reference to the current position in the list.
	 * <p>
	 * 
	 */
	private transient Entry currentPosition;
	/**
	 * The size of the list.
	 * <p>
	 * Negative values are not allowed.
	 */
	private transient int size;
	
	/**
	 * Sets all the references to the linked list in the initial position
	 *
	 */
	public SpihtLinkedList2D() {
		head = new Entry(0,0,null);
		head.next = head;
		lastEntry = head;
		currentPosition = head;
		size = 0;
	}
	
	public void cloneList(SpihtLinkedList2D list) {
		int lengthList;
		
		clearList();
		if( !(list.isEmpty()) ) {
			lengthList = list.size();
			list.initialNode();
			for (int i=0;i<lengthList;i++) {
				addElement(list.getX(),list.getY());
				list.nextValue();
			}
		}
	}
	public void cloneListTyped(SpihtLinkedList2D list) {
		int lengthList;
		
		clearList();
		if( !(list.isEmpty()) ) {
			lengthList = list.size();
			list.initialNode();
			for (int i=0;i<lengthList;i++) {
				addElement(list.getX(),list.getY(),list.getType());
				list.nextValue();
			}
		}
	}
	
	/**
	  * Appends the given element to the end of the LIS list. One dimensional version.
	  * @param x the x coordinate from the input image
	  * @param type the type in the LIS list
	  * @return void
	*/
	public void addElement(int x, boolean type) {
		Entry newEntry = new Entry(x, 0, type, head.next);
		
		lastEntry.next = newEntry;
		lastEntry = newEntry;
		
		size++;
	}
	/**
	  * Appends the given element to the end of the LSC or LIC lists. One dimensional version
	  * @param x the x coordinate from the input image
	  * @return void
	*/
	public void addElement(int x) {
		Entry newEntry = new Entry(x, 0, head.next);
		
		lastEntry.next = newEntry;
		lastEntry = newEntry;
		
		size++;
	}
	/**
	  * Appends the given element to the end of the LIS list. One dimensional version.
	  * @param x the x coordinate from the input image
	  * @param y the y coordinate from the input image
	  * @param type the type in the LIS list
	  * @return void
	*/
	public void addElement(int x,int y, boolean type) {
		Entry newEntry = new Entry(x, y, type, head.next);
		
		lastEntry.next = newEntry;
		lastEntry = newEntry;
		
		size++;
	}
	/**
	  * Appends the given element to the end of the LSC or LIC lists. One dimensional version
	  * @param x the x coordinate from the input image
	  * @param y the y coordinate from the input image
	  * @return void
	*/
	public void addElement(int x, int y) {
		Entry newEntry = new Entry(x, y, head.next);
		
		lastEntry.next = newEntry;
		lastEntry = newEntry;
		
		size++;
	}
	/**
	  * Checks if the list is empty.
	  * @return true if the list is empty, otherwise returns false
	*/
	public boolean isEmpty() {
		if(size == 0) return true;
		
		return false;
	}
	/**
	  * Checks if the current position in the list is the last element.
	  * @return true if the current position is the last element in the list, otherwise returns false
	*/
	public boolean isLast() {
		if(currentPosition.next == lastEntry) return true;
		
		return false;
	}
	/**
	  * Removes the current element and decrements the size of the list.
	  * @return void
	*/	
	public void remove() {
		if(size == 1) {
			head.next = head;
			lastEntry = head;
			currentPosition = head;
			size = 0;
		}
		else {
			if(currentPosition.next == lastEntry)
				lastEntry = currentPosition;
			currentPosition.next = currentPosition.next.next;
			size--;
		}
	}
	/**
	  * Sets the current element reference to the next position in the list.
	  * @return void
	*/
	public void nextValue() {
		currentPosition = currentPosition.next;
	}
	/**
	  * Returns the size of the list.
	  * @return the size of the list
	*/	
	public int size() {
		return size;
	}
	/**
	  * Sets the current element preference to the head of the list.
	  * @return void
	*/
	public void initialNode() {
		currentPosition = head;
	}
	/**
	  * Clears the linked list and initializes the list size.
	  * @return void
	*/
	public void clearList() {
		head.next = head;
		lastEntry = head;
		currentPosition = head;
		size = 0;
		System.gc();
	}
	/**
	  * Moves the element pointered by currentPosition to the end of the parameter list.
	  * @param list a linked list
	  * @return void
	*/
	public void moveElementAtLast(SpihtLinkedList2D list) {
		list.addElement(currentPosition.next.x,currentPosition.next.y,currentPosition.next.type);
		remove();
	}
	/**
	  * Returns the x value coordinate from the current position in the list.
	  * @return the value of x
	*/
	public int getX() {
		return currentPosition.next.x;
	}
	/**
	  * Returns the y value coordinate from the current position in the list.
	  * @return the y coordinate
	*/
	public int getY() {
		return currentPosition.next.y;
	}
	/**
	  * Returns the type from the current position of the LIS.
	  * @return the type
	*/
	public boolean getType() {
		return currentPosition.next.type;
	}
	/**
	  * Sets the type from the current position in the LIS.
	  * @return void
	*/
	public void setType(boolean type) {
		currentPosition.next.type = type;
	}
	/**
	  * Shows the list in the standard output.
	  * @param type specifies if the type will show
	  * @return void
	*/
	public void showList(boolean type) {
		Entry ptr;
		
		System.out.println("Longitut: " + size);
		System.out.print("{");
		ptr = head.next;
		for(int i=0;i<size;i++) {
			if(type) System.out.print("["+ ptr.x + "," + ptr.y + "]"+ptr.type+" ,");
			else System.out.print("["+ ptr.x + "," + ptr.y + "]");
			ptr=ptr.next;
		}
		System.out.println("}");
	}
	/**
	 * Data structure used to store the list three dimensional.
	 */
	private static class Entry {
		/**
		 * The x coordinate.
		 * <p>
		 * Negative values are not allowed.
		 */
		int x;
		/**
		 * The y coordinate.
		 * <p>
		 * Negative values are not allowed.
		 */
		int y;
		/**
		 * The type of the node.
		 * <p>
		 * Not boolean value is not allowed
		 */
		boolean type;
		/**
		 * A reference to the next node in the linked list
		 * <p>
		 * Only a reference to the next node is allowed
		 */
		Entry next;
		/**
		* Initializes the node of the list with the specified type for the LIS
		*/
		Entry(int x, int y, boolean type, Entry next) {
			this.x = x;
			this.y = y;
			this.type = type;
			this.next = next;
		}
		/**
		* Initializes the node of the list for the LSC and LIC
		*/
		Entry(int x, int y, Entry next) {
			this.x = x;
			this.y = y;
			this.next = next;
		}
	}
}
