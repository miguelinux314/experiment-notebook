package BitAllocation;

import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import GiciBitStream.BitRandomAccessFile;
import GiciBitStream.BitInputStream;
import List.SpihtVector;
import GiciBitStream.BitOutputStream;

/** An implementation of one dimensional SPIHT Rate Distortion algorithms.
  * @author Jorge Gonzalez-Conejero
  * @version 1.0 08/03/2004
  */ 
public class SpihtBitAllocation {
	protected static final int xBits = 16,
			yBits = 16,
			zBits = 16,
			levelsBits = 4,
			methodBits = 1,
			thresholdBits = 5;
	/**
	 * The rated output stream.
	 * <p>
	 * Only a SPIHT output stream are allowed.
	*/
	protected BitOutputStream bos = null;
	/**
	 * The input stream of the coded image, with this field we can make a random acces in the coded stream.
	 * <p>
	 * Only a SPIHT input stream are allowed.
	*/
	protected BitRandomAccessFile bis = null;
	/**
	 * The distortions calculed for each line are stored.
	 * <p>
	 * Negative values are not allowed.
	*/
	protected long[][] table = null;
	/**
	 * The realtion between the distortion and the length for each truncation point.
	 * <p>
	 * Negative values are not allowed for this field.
	*/
	protected double[][] rateTable = null;
	/**
	 * The position of the beginning and the end of each truncation point in the original coded bit stream.
	 * <p>
	 * Negative values are not allowed for this field.
	*/
	protected long[][] accessPoints = null;
	/**
	 * The optimal order of the lines to send. 
	 * <p>
	 * Negative values are not allowed for this field. The maximum value is the number of lines of the input image.
	*/
	protected int[] order = null;
	/**
	 * The optimal truncation points for each line according to the Convex Hull Rate Distortion algorithm. 
	 * <p>
	 * Negative values are not allowed for this field. The maximum value is the number of truncation points in the line.
	*/
	protected int[][] feasiblePoints = null;
	/**
	 * The name of the original coded bit stream file.
	 * <p>
	 * Only a valid file name are allowed.
	*/
	//protected String fname;
	/** The list of the valid rate distortion methods.
	  *        <ul>
	  *          <li> rd1tp - Rate Distortion with one truncation point
	  *          <li> rd2tp - Rate Distortion with two truncation points
	  *          <li> rdch - Rate Distortion with two truncation points and the Convex-Hull algorithm
	  *        </ul>
	  * <p>
	  * Only one of these three versions are allowed.
	*/
	protected String[] ratedList = {"rd1tp","rd2tp","rdch"};
	/**
	 * The rate distortion algorithm to apply.
	 * <p>
	 * Only a valid rate distortion algorithm are allowed. <br>
	 *        <ul>
	 *          <li> 0 - One truncation point for each SPIHT step
	 *          <li> 1 - Two truncation points for each SPIHT step
	 *          <li> 2 - Convex Hull with two truncation points for each SPIHT step
	 *        </ul>
	*/
	protected int rateMode;
	/**
	 * This field specifies if we have a rate target to accomplish.
	 * <p>
	 * Only a boolean value is allowed.
	*/
	//protected boolean rateTarget = false;
	/**
	 * The number of bytes for the rate target.
	 * <p>
	 * Only a valid coded file dimension is allowed.
	*/
	//protected long target = 0;
	/**
	 * The dimension of the coding process.
	 * <p>
	 * Only a valid dimension is allowed.
	*/
	protected int dimension = 0;
	
	/** Creates an instance of the algorithm and initialize the attributes from the object.
	  * @param fname the input stream of the original coded image
	  * @param rateVersion the rate distortion algorithm to apply
	  */
	public SpihtBitAllocation(String rateVersion) throws Exception {
		//this.fname = fname;
		
		order = null;
		feasiblePoints = null;
		rateTable = null;
		//this.dimension = dimension;
		
		rateMode = -1;
		for(int i=0;i<ratedList.length;i++) {
			if(ratedList[i].equals(rateVersion)) {
				rateMode = i;
				break;
			}
		}
		if(rateMode == -1) throw new Exception("The specified Rate Distortion algorithm " + rateVersion + " are not avaible.");
	}// Constructor
	
	/** Calculates the rate value with the quotient (distortion / length) for each truncation point and stores it
	  * in the <code>rateTable</code> field.
	  * <p>
	  * This method is for one and two truncation points algorithms only.
	  * @return void
	*/
	protected void generateRateTable() throws Exception {
		int maxThresholdPow = 0;
		int bitsHeader = 0;
		int acum = 0;
		int numberOfUnits = table.length;
		int indexRate = 0;
		int indexAccessPoints = 0;
		double rateValue = 0f;
		double distortion = 0f;
		double length = 0f;
		long[] accessPointsAux = null;
		
		System.out.println("Rate Table Begin");
		
		if(table == null) throw new Exception("The Distortion table is null.");
		if(accessPoints == null) throw new Exception("The Access Points table is null.");
		if(dimension <= 0 || dimension >= 3) throw new Exception("The dimension attribute is not correct.");
		
		bitsHeader = (int) Math.ceil(( Math.log(numberOfUnits) / Math.log(2)));
		rateTable = new double[table.length][];
		
		for(int i = 0 ; i < numberOfUnits ; i++) {
			indexRate = 0;
			indexAccessPoints = 1;
			maxThresholdPow = table[i].length;
			
			if(rateMode == 0) { 
				rateTable[i] = new double[((maxThresholdPow - 1) >> 1) + 1];
				accessPointsAux = new long[((maxThresholdPow - 1) >> 1) + 2];
				accessPointsAux[0] = accessPoints[i][0];
			}
			else rateTable[i] = new double[maxThresholdPow];
			
			for(int step = 0 ; step < maxThresholdPow ; step++) {
				if((rateMode == 1) || (step == 0)) {
					distortion = table[i][step];
					length = accessPoints[i][step + 1] - accessPoints[i][step];
					rateValue = distortion / length;
					if(rateMode == 0) {
						accessPointsAux[indexAccessPoints] = accessPoints[i][step + 1];
						indexAccessPoints++;
					}
				}
				else {
					distortion = table[i][step] + table[i][step + 1];
					length = accessPoints[i][step + 1] - accessPoints[i][step];
					step++;
					length += accessPoints[i][step + 1] - accessPoints[i][step];
					accessPointsAux[indexAccessPoints] = accessPoints[i][step + 1];
					indexAccessPoints++;
					rateValue = distortion / length;
				}
				
				// If one truncation point has 0 distortion value, we join it with the next truncation point
				// the -1 value is a mark to indicate this event
				if(rateValue <= 0) {
					if(rateMode == 0) {
						rateTable[i][indexRate] = -1.0;
						indexRate++;
						step++;
						distortion = table[i][step] + table[i][step + 1];
						length += accessPoints[i][step + 1] - accessPoints[i][step];
						step++;
						length += accessPoints[i][step + 1] - accessPoints[i][step];
						accessPointsAux[indexAccessPoints] = accessPoints[i][step + 1];
						indexAccessPoints++;
						rateValue = distortion / length;
					}
					else {
						rateTable[i][indexRate] = -1.0;
						indexRate++;
						//rateTable[i][step] = -1.0;
						step++;
						distortion = table[i][step];
						length += accessPoints[i][step + 1] - accessPoints[i][step];
						rateValue = distortion / length;
					}
					acum++;
				}
				rateTable[i][indexRate] = rateValue;
				acum++;
				indexRate++;
			} //for step
				if(rateMode == 0) accessPoints[i] = accessPointsAux;
		} //for i
		System.out.println("Rate Table Ends: " + acum);
	}
	/** Generates the optimal order of the lines to be send and stores it in the <code>order</code> field.
	  * @return void
	  */
	protected void generateOrder() throws Exception {
		int numberOfTruncationPoints = 0;
		int maximUnit = 0;
		int numberOfUnits = rateTable.length;
		double maximRateValue = 0.0;
		double rateValue = 0f;
		int[] positionInVector = new int[numberOfUnits];
		
		System.out.println("Generate Order Begin");
		if(rateTable == null) throw new Exception("The rate table is null");
		
		for(int comp = 0 ; comp < numberOfUnits ; comp++) {
			numberOfTruncationPoints += rateTable[comp].length;
			positionInVector[comp] = 0;
		}
		
		order = new int[numberOfTruncationPoints];
		
		for(int i = 0 ; i < numberOfTruncationPoints ; i++) {
			
			for(int j = 0; j < numberOfUnits; j++) {
				int steps = rateTable[j].length;
				if(steps > positionInVector[j]) {
					maximRateValue = rateTable[j][positionInVector[j]];
					maximUnit = j;
					break;
				}
			}
			
			for(int unit = 0 ; unit < numberOfUnits ; unit++) {
				try {
					int steps = rateTable[unit].length;
					
					if(steps > positionInVector[unit]) {
						rateValue = rateTable[unit][positionInVector[unit]];
						
						// If we find a mark that indicates the distortion value is 0 we force the next
						// position in the order attribute to be the same line
						if(rateValue == -1) {
							rateValue = rateTable[unit][positionInVector[unit] + 1];
						}
						if(maximRateValue < rateValue) {
							maximRateValue = rateValue;
							maximUnit = unit;
						}
					}
				} catch (ArrayIndexOutOfBoundsException e) {
					System.out.print(" Final de linea: " + positionInVector[unit] + " Size: " + i);
					System.exit(0);
				}
			}
			// If we find a mark that indicates the distortion value is 0 we force the next
			// position in the order attribute to be the same line
			if((rateTable[maximUnit][positionInVector[maximUnit]]) == -1) {
				(positionInVector[maximUnit])++;
				order[i] = maximUnit;
				i++;
			}
			positionInVector[maximUnit]++;
			order[i] = maximUnit;
		} //for numberOfTruncationPoints
		System.out.println("Generate Order Ends");
	}
	/** Calculates the rate value with the optimal trucantion points provided for the Convex Hull algorithm and stores it
	  * in the <code>rateTable</code> field. The rate values will be the slopes from each point in the CH algorithm.
	  * In this version of the rate algorithm we need a recalculation of the acces points to the original coded bit stream.
	  * @return void
	  *
	*/
	protected void generateConvexHullRateTable() throws Exception {
		int lineThresholds, numPoints, ySize;
		long[] lengths, errors;
		long[] newAccesPoints;
		double[] newRateLine;
		
		ConvexHull ch;
		
		numPoints = 0;
		newAccesPoints = null;
		newRateLine = null;
		ySize = table.length;
		
		if(table == null) throw new Exception("The distortions table is null");
		if(accessPoints == null) throw new Exception("The access points array is null");
		
		feasiblePoints = new int[ySize][];
		rateTable = new double[ySize][];
		
		for(int y = 0 ; y < ySize ; y++) { //ySize
			lineThresholds = table[y].length;
			
			// The error measurement
			errors = new long[lineThresholds];
			// The length of each error
			lengths = new long[lineThresholds];
			//System.out.println("Line: " + y);
			for(int i = 0 ; i < lineThresholds ; i++) {
				errors[i] = table[y][i];
				lengths[i] = accessPoints[y][i + 1] - accessPoints[y][i];
				//System.out.println("errors " + i + ": " + errors[i]);
				//System.out.println("lengths " + i + ": "+ lengths[i]);
			} // for i
			
			ch = new ConvexHull(lengths, errors);
			ch.run();
			
			// The optimal trucation points
			feasiblePoints[y] = ch.getFeasiblePoints();
			// The slopes of the Convex Hull points
			newRateLine = ch.getSlopes();
			
			int totalPasses = (lineThresholds - 1);
			
			//System.out.println("Feasible Points: " + feasiblePoints[y].length);
			/*if(y == 1) {
				for(int i = 0 ; i < lineThresholds ; i++) {
					System.out.println("D: " + errors[i]);
					System.out.println("L: " + lengths[i]);
					System.out.println(" ");
				} // for i
			}*/
			
			/*if(feasiblePoints[y][feasiblePoints[y].length - 1] != totalPasses) {
				//System.out.println("No hay final");
				rateTable[y] = new double[newRateLine.length + 1];
				for(int i = 0 ; i < newRateLine.length ; i++) rateTable[y][i] = newRateLine[i];
				rateTable[y][rateTable[y].length-1] = 0f;
				newAccesPoints = new long[(feasiblePoints[y].length + 2)];
				int[] newFeasiblePoints = new int[feasiblePoints[y].length + 1];
				for(int i=0;i<feasiblePoints[y].length;i++) newFeasiblePoints[i] = feasiblePoints[y][i];
				newFeasiblePoints[newFeasiblePoints.length - 1] = totalPasses;
				feasiblePoints[y] = newFeasiblePoints;
			}
			else {
				//System.out.println("Hay final");
				rateTable[y] = newRateLine;
				newAccesPoints = new long[(feasiblePoints[y].length + 1)];
			}*/
			
			rateTable[y] = newRateLine;
			newAccesPoints = new long[(feasiblePoints[y].length + 1)];
			
			//rateTable[y] = new double[newRateLine.length];
			//for(int i=0;i<newRateLine.length;i++) rateTable[y][i] = newRateLine[i];
			
			//newAccesPoints = new long[(feasiblePoints[y].length + 1)];
			
			// The new acces points in the original coded bit stream
			for(int i=0;i<feasiblePoints[y].length;i++) newAccesPoints[i + 1] = accessPoints[y][feasiblePoints[y][i] + 1];
			
			newAccesPoints[0] = accessPoints[y][0];
			//newAccesPoints[newAccesPoints.length - 1] = accessPoints[y][accessPoints[y].length - 1];
			
			//System.out.println("Old accessPoints: " + accessPoints[y].length);
			//for(int i=0;i<accessPoints[y].length;i++) System.out.print(" " + accessPoints[y][i]);
			//System.out.println("");
			accessPoints[y] = newAccesPoints;
			
			/*System.out.println("RT: " + rateTable[y].length);
			for(int i=0;i<rateTable[y].length;i++) System.out.print(" " + rateTable[y][i]);
			System.out.println("");
			System.out.println("FeasiblePoints: ");
			for(int i=0;i<feasiblePoints[y].length;i++) System.out.print(" " + feasiblePoints[y][i]);
			System.out.println("");
			System.out.println("New AP: ");
			for(int i=0;i<accessPoints[y].length;i++) System.out.print(" " + accessPoints[y][i]);
			System.out.println(" ");*/
		} //for y
		for(int y=0; y < ySize; y++) {
			for(int x=0; x < rateTable[y].length; x++) {
				if (rateTable[y][x] <= 0) {
					System.out.println("Line: " + y + " Threshold: " + x);
					System.exit(0);
				}
			}
		} //for
	}
	
	/** Generates the appropiate rated output stream for the selected algorithm and calls the methods to run
	  * all the rated process.
	  * @param outputFileName the name of the file for output rated bit stream
	  * @return void
	*/
	public void generateRatedOutputStream(String inFile, long target) throws Exception {
		int numberOfTruncationPoints, numPoints, bitsHeader, unit, numberOfUnits, fileHeader;
		int[] positionInUnit;
		long start, finish;
		boolean convexHull;
		String outFile;
		
		outFile = inFile + "_" + ratedList[rateMode];
		unit = 0;
		fileHeader = 0;
		
		convexHull = false;
		if(rateMode == 2) {
			convexHull = true;
			rateMode = 1;
		}
		
		//Generates the rate table
		if(convexHull) generateConvexHullRateTable();
		else generateRateTable();
		
		//Generates the optimal order for the image units
		generateOrder();
		
		//Header Data read
		FileInputStream fism = new FileInputStream(inFile);
		BitInputStream mis = new BitInputStream(fism);
		
		// We initialize the rated output stream
		FileOutputStream fos = new FileOutputStream(outFile);
		if(target != 0) bos = new BitOutputStream(fos, target);
		else bos = new BitOutputStream(fos);
		
		// Header data write
		int xSize = (int) mis.readUBits(16);
		bos.writeUBits(xSize, 16);
		if(dimension == 1) {
			numberOfUnits = (int) mis.readUBits(16);
			bos.writeUBits(numberOfUnits,16);
			fileHeader = 37;
		}
		else {
			int numberOfLines = (int) mis.readUBits(16);
			bos.writeUBits(numberOfLines,16);
			numberOfUnits = (int) mis.readUBits(16);
			bos.writeUBits(numberOfUnits, 16);
			fileHeader = 53;
		}
		int levels = (int) mis.readUBits(4);
		bos.writeUBits(levels, 4);
		int method = (int) mis.readUBits(1);
		bos.writeUBits(method, 1);
		
		//We close the input bitstreams
		fism.close();
		mis.close();
		
		// Open the input random acces
		File fis = new File(inFile);
		bis = new BitRandomAccessFile(fis,"r");
		
		//The total truncation points
		numberOfTruncationPoints = order.length;
		//The number of bits needed to specify the unit number
		bitsHeader = (int)Math.ceil((Math.log(numberOfUnits) / Math.log(2)));
		
		//The current position in each component from the image
		positionInUnit = new int[numberOfUnits];
		
		System.out.println("Comienza la escritura del fichero rated: " + numberOfTruncationPoints);
		for(int i = 0 ; i < numberOfTruncationPoints ; i++) {
			unit = order[i];
			
			// We plus the header and the thresholds in the other components
			start = (accessPoints[unit][positionInUnit[unit]]) + fileHeader + ( (unit + 1) * 5);
			finish = (accessPoints[unit][positionInUnit[unit] + 1]) + fileHeader + ((unit + 1) * 5);
			if(positionInUnit[unit] == 0) start -= 5;
			
			bos.writeUBits(unit, bitsHeader);
			
			if(convexHull) {
				if(positionInUnit[unit] == 0) numPoints = feasiblePoints[unit][0] + 1;
				else numPoints = feasiblePoints[unit][positionInUnit[unit]] - feasiblePoints[unit][positionInUnit[unit] - 1];
				
				numPoints--;
				while(numPoints != 0) {
					bos.writeUBits(0,1);
					numPoints--;
				}
				bos.writeUBits(1,1);
			}
			copyStream(start, finish);
			
			positionInUnit[unit]++;
		}
		bos.close();
		bis.close();
	}
	/** Copies the original coded bit stream to the rated output stream, from the start position to the final.
	  * @param start the start position in the original coded bit stream
	  * @param finish the final position in the original coded bit stream
	  * @return void
	*/
	protected void copyStream(long start, long finish) throws IOException {
		int readBit;
		
		bis.positionInBits(start);
		for(long i = start ; i < finish ; i++) {
			   readBit = (int) bis.readUBits(1);
			   bos.writeUBits(readBit,1);
		}
	}
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               GET METHODS                                  /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	/** Returns the field <code>table</code>.
	  * @return the distortions table
	*/
	public long[][] getDistortionTable() {
		return table;
	}
	/** Returns the field <code>rateTable</code>.
	  * @return the rate measures
	*/
	public double[][] getRateTable() {
		return rateTable;
	}
	/** Returns the field <code>order</code>, it is the optimal order to send the truncation points from the different lines.
	  * @return the optimal order of the truncation points for each line of the image
	*/
	public int[] getLineOrder() {
		return order;
	}
	/** Returns the field <code>accessPoints</code>, it is the beginning and the end of the truncation points in the bit stream.
	  * @return the beginning and the end for all the truncation points from the SPIHT coding algorithm
	*/
	public long[][] getAccessPoints() {
		return accessPoints;
	}
	/** Returns the field <code>feasiblePoints</code>, it is the optimal truncation points given by the Convex Hull algorithm.
	  * @return the optimal truncation points by Convex Hull algorithm
	*/
	public int[][] getFeasiblePoints() {
		return feasiblePoints;
	}
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               SET METHODS                                  /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	
	/** Sets an specific dimension.
	 * @param the dimension
	*/
	public void setDimension(int dimension) {
		this.dimension = dimension;
	}
	/** Sets an specific table of distortions.
	 * @param the table of the distortions calculed
	*/
	public void setDistortionTable(long[][] table) {
		this.table = table;
	}
	/** Sets an specific table of distortions.
	 * @param the table of the distortions calculed
	*/
	public void setAccessPoints(long[][] accessPoints) {
		this.accessPoints = accessPoints;
	}
	/** Sets the rate target attribute.
	 * @param the rate target value
	*/
/*	public void setRateTarget(boolean rateTarget) {
		this.rateTarget = rateTarget;
	}*/
	/** Sets the target value.
	 * @param the target value
	*/
/*	public void setTarget(long target) {
		this.target = target;
	}*/
} //Spiht1DBitAllocation
