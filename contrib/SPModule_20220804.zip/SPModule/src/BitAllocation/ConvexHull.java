package BitAllocation;

/**
 * This class performs incremental computation algorithm of convex hull and slopes to find out feasible truncation points.
 * Usage example:<br>
 * &nbsp; construct<br>
 * &nbsp; [setParameters]<br>
 * &nbsp; run<br>
 * &nbsp; [get functions]<br>
 *
 * @author WaveGis Project
 * @version 1.0
 */
public class ConvexHull{

	/**
	 * Length of each truncation point (not incremental!) -index 0 is the first truncation point-.
	 * <p>
	 * Negative values are not allowed for this field.
	 */
	long[] lengths = null;

	/**
	 * Error saved for each truncation point (not incremental!) -index 0 is the first truncation point-.
	 * <p>
	 * Negative values are not allowed for this field.
	 */
	long[] errors = null;

	/**
	 * First point of the array to consider by convex hull algorithm.
	 * <p>
	 * The number must be equal or greater than 0 and less than lastPoint.
	 */
	int firstPoint;

	/**
	 * Number of points to consider by convex hull algorithm.
	 * <p>
	 * The number must be equal or greater than 0 and less than array length - firstPoint.
	 */
	int numPoints;

	/**
	 * Array that will contain the points that convex hull algorithm finds out.
	 * <p>
	 * Each point must be equal or greater than firstPoint and less than firstPoint+numPoints.
	 */
	int[] CHFeasiblePoints = null;

	/**
	 * Array that will contain the slopes that convex hull algorithm finds out.
	 * <p>
	 * Negative values are not coherent.
	 */
	double[] CHSlopes = null;


	 /**
	 * Constructor that receives the lengths and errors saved by each truncation point, checks it and run the incremental computation algorithm to find out feasible truncation points.
	 *
	 * @param lengths length of each truncation point (non incremental array -only the length of each truncation point-)
	 * @param errors error saved by each truncation point (non incremental array -only the error saved by each truncation point-)
	 */
	public ConvexHull(long[] lengths, long[] errors){
		//Data copy
		this.lengths = lengths;
		this.errors = errors;
		this.numPoints = numPoints;

		//Default parameters
		firstPoint = 0;
		if(lengths.length <= errors.length){
			numPoints = lengths.length;
		}else{
			numPoints = errors.length;
		}
	}

	/**
	 * Set and check the parameters to do the convex hull algorithm.
	 *
	 * @param firstPoint an integer that indicates first point of the array to consider
	 * @param numPoints an integer that indicates number of points to consider
	 */
	public void setParameters(int firstPoint, int numPoints) throws Exception{
		//Parameters copy
		this.firstPoint = firstPoint;
		this.numPoints = numPoints;

		//CHECKS
		//Array length check
		if((firstPoint < 0) || (firstPoint >= lengths.length) || (firstPoint >= errors.length)){
			throw new Exception("First point to consider in convex hull algorithm must be greater than 0 and less than array lengths.");
		}
		if(numPoints <= 1){
			throw new Exception("Number of points to consider in convell hull algorithm is too smaller.");
		}
		if((firstPoint + numPoints > lengths.length) || (firstPoint + numPoints > errors.length)){
			throw new Exception("Number of points to consider in convell hull algorithm is too much bigger.");
		}
	}

	/**
	 * Performs the algorithm.
	 */
	public void run(){
		int[] feasiblePoints = new int[numPoints+1];
		double[] slopes = new double[numPoints+1];
		//Points of slope
		long[] incLengths = new long[numPoints+1]; //length --> X
		long[] incErrors = new long[numPoints+1]; //error --> Y

		//Slope construction (incremental array construction)
		incLengths[0] = 0;
		incErrors[0] = 0;
		for(int i = firstPoint; i < firstPoint+numPoints; i++){
			incErrors[0] += errors[i];
		}
		for(int i = firstPoint; i < firstPoint+numPoints; i++){
			incLengths[i-firstPoint+1] = incLengths[i-firstPoint] + lengths[i];
			incErrors[i-firstPoint+1] = incErrors[i-firstPoint] - errors[i];
		}

		
		//OPTIMIZED ALGORITHM (incremental computation)
		//First feasible point is always the first (length == 0 -- not valid point, it will be dismissed)
		int numFeasiblePoints = 0;
		slopes[numFeasiblePoints] = Float.MAX_VALUE;
		feasiblePoints[numFeasiblePoints++] = 0;
		//Find out next feasible points
		for(int point = 1; point <= numPoints; point++){
			double incDistortion = incErrors[feasiblePoints[numFeasiblePoints-1]] - incErrors[point];
			double incLength = incLengths[point] - incLengths[feasiblePoints[numFeasiblePoints-1]];
			if(incDistortion > 0){
				while(incDistortion >= slopes[numFeasiblePoints-1]*incLength){
					numFeasiblePoints--;
					incDistortion = incErrors[feasiblePoints[numFeasiblePoints-1]] - incErrors[point];
					incLength = incLengths[point] - incLengths[feasiblePoints[numFeasiblePoints-1]];
				}
				slopes[numFeasiblePoints] = incDistortion / incLength;
				feasiblePoints[numFeasiblePoints++] = point;
			}
		}
		

		/*
		//NOT OPTIMIZED ALGORITHM
		//First feasible point is always the first  (length == 0 -- not valid point, it will be dismissed)
		int numFeasiblePoints = 0;
		double minSlope = Float.MAX_VALUE;
		int nextFeasiblePoint = 0;
		//Find out next feasible points
		do{
			slopes[numFeasiblePoints] = minSlope;
			feasiblePoints[numFeasiblePoints++] = nextFeasiblePoint;
			minSlope = Float.MIN_VALUE;
			nextFeasiblePoint = -1;
			for(int i = feasiblePoints[numFeasiblePoints-1]+1; i <= numPoints; i++){
				double incDistortion = incErrors[feasiblePoints[numFeasiblePoints-1]] - incErrors[i];
				double incLength = incLengths[i] - incLengths[feasiblePoints[numFeasiblePoints-1]];
				double slope = incDistortion / incLength;
				if(slope >= minSlope){
					minSlope = slope;
					nextFeasiblePoint = i;
				}
			}
		}while(nextFeasiblePoint != -1);
		*/

		//Array copy
		CHFeasiblePoints = new int[numFeasiblePoints-1];
		CHSlopes = new double[numFeasiblePoints-1];
		for(int i = 1; i < numFeasiblePoints; i++){
			CHFeasiblePoints[i-1] = feasiblePoints[i] + firstPoint - 1;
			CHSlopes[i-1] = slopes[i];
		}
	}

	/**
	 * Returns the feasible points that convex hull algorithm finds out.
	 *
	 * @return an array of integers that contains the feasible points (array length is the number of points that algorithm finds out and the values are the indexes of feasible points in the array passed)
	 */
	public int[] getFeasiblePoints(){
		return(CHFeasiblePoints);
	}

	/**
	 * Returns the slope of each feasible point of convex hull.
	 *
	 * @return an array of doubles that contains the slopes of each feasible point (array length is the number of points that algorithm finds out and values are the slopes of feasible points)
	 */
	public double[] getSlopes(){
		return(CHSlopes);
	}

}
