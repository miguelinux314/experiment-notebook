package Spiht;

import GiciTransform.*;
import GiciFile.*;
import GiciImageExtension.*;
import GiciAnalysis.*;
import java.io.IOException;
import Spiht.SpihtDecoding.*;

/**
 * Main class of the SpihtDecode application.
 *
 * @author WaveGIS project
 * @version 0.1
 */
public class SpihtDecode {
	/**
	 * Main method of SpihtDecode application. It takes program arguments, loads image and runs Spiht decoder.
	 *
	 * @param args an array of strings that contains program parameters
	 */
	public static void main(String[] args){
		ArgsParser arguments = null;
		
		try {
			arguments = new ArgsParser(args);
		} catch (Exception e) {
			System.out.println("ARGUMENTS ERROR: " + e.getMessage());
			System.exit(1);
		}
		
		//Get arguments
		int dimension = arguments.getDimension();
		int[] WTLevels = arguments.getWTLevels();
		int[] WTTypes = arguments.getWTTypes();
		
		float[][][] imageSamples = null;
		try {
			int[][][] imageSamplesInt = null;
			try {
				//DECODER
				Spiht spd;
				
				if(dimension == 1) spd = new SpihtDecoding1D(arguments.getFileName());
				else if(dimension == 2) spd = new SpihtDecoding2D(arguments.getFileName());
				else if (dimension == 3) spd = new SpihtDecoding3D(arguments.getFileName());
				else throw new Exception("The dimension specified is not avaible");
				
				if(arguments.getBuilding()) spd.decodeBuilding();
				else if(arguments.getInterleaved()) spd.decodeInterleaved();
				else if(arguments.getRateDistortion() != null) spd.decodeRated(arguments.getRateDistortion());
				else spd.decode();
				
				imageSamplesInt = spd.getImage();
			} catch (IOException e) {
				System.out.println("An Input/Output exception ocurred in the " + dimension + "D decode process: " + e.getMessage());
				System.exit(2);
			} catch (Exception e) {
				System.out.println("An exception ocurred in the " + dimension +"D decode process: " + e.getMessage());
				System.exit(3);
			}
			
			//DISCRETE WAVELET TRANSFORM
			try {
				int[] WTOrder = new int[1];
				int zSize = imageSamplesInt.length;
				
				WTOrder[0] = 2;
				InverseWaveletTransform wt = new InverseWaveletTransform(integerToFloat(imageSamplesInt));
				if(dimension == 1) wt.setParameters(WTTypes, WTLevels, WTOrder);
				else {
					if(zSize > 1) {
						int Type = WTTypes[0];
						int NumberOfLevels = WTLevels[0];
						WTLevels = new int[zSize];
						WTTypes = new int[zSize];
						for(int i=0; i< zSize; i++) {
							WTTypes[i] = Type;
							WTLevels[i] = NumberOfLevels;
						}
					}
					wt.setParameters(WTTypes, WTLevels);
				}
				imageSamples = wt.run();
			} catch (Exception e) {
				System.out.println("DISCRETE WAVELET TRANSFORM ERROR: " + e.getMessage());
				System.exit(4);
			}
		} catch (Exception e) {
			System.out.println("DECODER PROCESS ERROR: " + e.getMessage());
			System.exit(5);
		}

		for(int z = 0; z < imageSamples.length; z++){
			for(int y = 0; y < imageSamples[z].length; y++){
				for(int x = 0; x < imageSamples[z][y].length; x++){
					if(imageSamples[z][y][x] < 0){
						imageSamples[z][y][x] = 0f;
					}
					if(imageSamples[z][y][x] > 255){
						imageSamples[z][y][x] = 255;
					}
				}
			}
		}
						
		//IMAGE COMPARE
		float[][][] imageSamplesCompare;
		String compareFile = arguments.getCompareImage();
		if(compareFile != null){
			try{
				LoadFile imageCompare = null;
				//Loads image to compare with recovered samples
				if(compareFile.endsWith(".raw")){
					int[] imageGeometry = arguments.getImageGeometry();
					
					//Check parameters of image geometry
					if((imageGeometry[0] <= 0) || (imageGeometry[1] <= 0) || (imageGeometry[2] <= 0)){
						throw new Exception("Image dimensions in \".raw\" data files must be positive (\"-h\" displays help).");
					}
					if((imageGeometry[3] < 0) || (imageGeometry[3] > 7)){
						throw new Exception("Image type in \".raw\" data must be between 0 to 7 (\"-h\" displays help).");
					}
					if((imageGeometry[4] != 0) && (imageGeometry[4] != 1)){
						throw new Exception("Image Endian specification in \".raw\" data must be between 0 or 1 (\"-h\" displays help).");
					}
					if((imageGeometry[5] != 0) && (imageGeometry[5] != 1)){
						throw new Exception("Image RGB specification in \".raw\" data must be between 0 or 1 (\"-h\" displays help).");
					}
					imageCompare = new LoadFile(compareFile, imageGeometry[0], imageGeometry[1], imageGeometry[2], imageGeometry[3], imageGeometry[4], imageGeometry[5] == 0 ? false: true);
				}else{
					imageCompare = new LoadFile(compareFile);
				}

				imageSamplesCompare = imageCompare.getImage();

				//IMAGE DEEXTENSION
				try{
					ImageDeExtension ide = new ImageDeExtension(imageSamples);
					ide.setParameters(imageSamplesCompare[0][0].length, imageSamplesCompare[0].length, imageSamplesCompare.length);
					imageSamples = ide.run();
				}catch(Exception e){
						System.out.println("IMAGE DEEXTENSION ERROR: " + e.getMessage());
						System.exit(4);
				}

				//Compare samples and extracts MSE and PSNR
				Class[] sampleTypes = imageCompare.getTypes();
				//All image components must use same sample type
				boolean equalTypes = true;
				for(int z = 1; z < imageSamples.length;z++){
					if(sampleTypes[z-1] != sampleTypes[z]){
						equalTypes = false;
					}
				}
				if(equalTypes){
					int[] type = new int[imageSamples.length];
					type[0] = 16;
					if(sampleTypes[0] == Byte.TYPE){
						type[0] = 8;
					}else{
						if(sampleTypes[0] == Integer.TYPE){
							type[0] = 32;
						}else{
							if(sampleTypes[0] == Character.TYPE || sampleTypes[0] == Short.TYPE){
								type[0] = 16;
							}else{
								System.out.println("Wrong image type");
								System.exit(1);
							}
						}
					}
					for(int z = 1; z < imageSamples.length; z++){
						type[z] = type[0];
					}
					ImageCompare ic = new ImageCompare(imageSamplesCompare, imageSamples, type);
					float totalMSE = ic.getTotalMSE();
					float totalPSNR = ic.getTotalPSNR();
					float totalSNR = ic.getTotalSNR();
					System.out.print(totalPSNR + " " + totalMSE + "\n");
				}else{
					System.err.println("IMAGE COMPARE ERROR: Sample type of all image components must be the same.");
				}
			}catch(Exception e){
				System.err.println("IMAGE COMPARE ERROR: " + e.getMessage());
				e.printStackTrace();
			}
		}
		
		//RANGE CHECK (Only for 8-bit depth images)
		for(int z =  0; z < imageSamples.length; z++){
			for(int y = 0; y < imageSamples[z].length; y++){
				for(int x = 0; x < imageSamples[z][y].length; x++){
					if(imageSamples[z][y][x] < 0){
						imageSamples[z][y][x] = 0f;
					}
					if(imageSamples[z][y][x] > 255){
						imageSamples[z][y][x] = 255f;
					}
				}
			}
		}

		//RECOVERED SAMPLES SAVE IN RAW FILE
		String outFile = arguments.getOutFile();
		if(outFile != null){
			try{
				if(compareFile.endsWith(".raw")) {
					SaveFile.SaveFileRaw(imageSamples, outFile,1,0);
				}
				else if (compareFile.endsWith(".pgm")) {
					SaveFile.SaveFileFormat(imageSamples, outFile, 0);
				}
				else {
					System.out.println("The image type is not avaible to save.");
				}
			} catch(Exception e){
				System.err.println("IMAGE SAVING ERROR: " + e.getMessage());
			}
		}
		
	}
	/**
	 * Auxiliar method from the Spiht decode main class to chage the coefficients type. The discrete wavelet transform uses
	 * float coefficients and the Spiht provides integer values, this method makes the necessary changes to send the decoded
	 * bitstream result to the inverse discrete wavelet transform.
	 *
	 * @param src the image with integer coefficients
	 * @return the input image with the new type
	 */
	private static float[][][] integerToFloat(int[][][] src){
		int zSize = src.length;
		int ySize = src[0].length;
		int xSize = src[0][0].length;
		
		float dst[][][] = new float[zSize][ySize][xSize];
		
		for (int z = 0; z < zSize; z++) {
			for (int y=0; y < ySize; y++) {
				for (int x=0; x < xSize; x++) {
					dst[z][y][x]=((float) (src[z][y][x]));
					}
			}
		}
		return dst;
	}

}
