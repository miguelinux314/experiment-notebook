package Spiht.SpihtCoding;

import java.io.FileOutputStream;
import java.io.IOException;
import GiciBitStream.BitOutputStream;
import Building.PlaneBuilding;
import List.SpihtLinkedList2D;
import Spiht.Spiht;

/** An implementation of two dimensional SPIHT Coding algorithm. This class also calculates the distortion reduced by each
    sorting or refinement step in the coding process to perform an accurate postcompression rate process. <p>
  * @see Spiht.Spiht
  * @see Building.LineBuilding
  * @see HyperStream.BitOutputStream
  * @author Jorge González-Conejero
  * @version 1.0 11/12/2003
  * @version 2.0 14/12/2003
  */ 
public class SpihtCoding2D extends Spiht {
	/**
	 * List of insignificant coefficients.
	 * <p>
	 * This list must contains the insignificant coefficients of the input image.
	 */
	protected SpihtLinkedList2D LIC = null;
	/**
	 * List of significant coefficients.
	 * <p>
	 * This list must contains the significant coefficients of the input image.
	 */
	protected SpihtLinkedList2D LSC = null;
	/**
	 * List of the roots that constains the subsets in the hierarchical trees.
	 * <p>
	 * This list must contains the significant coefficients of the input image.
	 */
	protected SpihtLinkedList2D LIS = null;
	/**
	 * Current band in the algorithm.
	 * <p>
	 * Negative values are not allowed. It has values between 0 and zSize.
	 */
	protected int z = 0;
	/**
	 * The coded output stream.
	 * <p>
	 * Only a SPIHT output stream is allowed.
	 */
	protected BitOutputStream bos = null;
	/** 
	  * The distortions calculed for each line are stored. 
	  * <p>
	  * Negative values are not allowed.
	  */
	protected long[][] table = null;
	/** 
	  * The mean errors in the recovered process. 
	  * <p>
	  * Only integer values are allowed.
	  */
	protected long errors[][] = null;
	/** 
	  * The position of the beginning and the end of each truncation point in the original coded bitstream. 
	  * <p>
	  * Negative values are not allowed for this field.
	  */
	protected long[][] accessPoints = null;
	/** 
	  * The recovered image at nth step to calculate the distortion.
	  * <p>
	  * Negative values are not allowed for this field.
	  */
	protected int[][] imageRecovered = null;
	/** 
	  * Specifies if the rate values will be calculated.
	  * <p>
	  * Only a boolean value is allowed.
	  */
	protected boolean rate = false;

	/** Creates an instance of the algorithm. Initialize the attributes from the object.
	  * @param image array that contains the values to code
	  * @param levels number of levels of the Discrete Wavelet Transform
	  * @param method the variant of SPITH coding algorithm to apply
	  *        <ul>
	  *          <li> 0 - Original method
	  *          <li> 1 - JPEG2K method
	  *        </ul>
	  */
	public SpihtCoding2D() {
		image = null;
		z = 0;
		size = 0;
	}

	public SpihtCoding2D(int[][][] image, int levels, String fname, boolean rateTarget, long target) throws IOException {
		
		// We instance the object
		FileOutputStream fos = new FileOutputStream(fname);
		bos = new BitOutputStream(fos, target);
		
		// Image attributes
		zSize = image.length;
		ySize = image[0].length;
		xSize = image[0][0].length;
		
		this.levels = levels;
		z = 0;
		size = 0;
		
		// We write the initial header to the final bitstream
		bos.writeUBits(xSize,16);
		bos.writeUBits(ySize,16);
		bos.writeUBits(zSize,16);
		bos.writeUBits(levels,4);
		bos.writeUBits(method,1);
		
		this.image = image;
		image = null;
		
		// We calculte the subband limits
		limitResidualBandX = xSize / (int) Math.pow(2, (levels));
		limitResidualBandY = ySize / (int) Math.pow(2, (levels));
		limitParentX = xSize / 2;
		limitParentY = ySize / 2;
		limitGrandParentX = xSize / 4;
		limitGrandParentY = ySize / 4;
		
	}//Constructor
	
	public void openOutputBitstream(String outFileName, long target) throws IOException {
		FileOutputStream fos = new FileOutputStream(outFileName);
		bos = new BitOutputStream(fos, target);
	}
	public void writeInitialHeader() throws IOException {
		
		if(bos == null) throw new IOException("The output bitstream is closed. Initial header is not written.");
		
		bos.writeUBits(xSize,16);
		bos.writeUBits(ySize,16);
		bos.writeUBits(zSize,16);
		bos.writeUBits(levels,4);
		bos.writeUBits(method,1);
	}
	public void calculateSubbandLimits() throws Exception {
		
		if(xSize == 0) throw new Exception("The size of the image is not correct");
		if(levels == 0) throw new Exception("The number of levels of the image is not correct");
		
		limitResidualBandX = xSize / (int) Math.pow(2, levels);
		limitResidualBandY = ySize / (int) Math.pow(2, levels);
		limitParentX = xSize / 2;
		limitParentY = ySize / 2;
		limitGrandParentX = xSize / 4;
		limitGrandParentY = ySize / 4;
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	///////                              SPIHT CODE METHODS                            /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Applies the SPIHT two dimensional coding algorithm, doing the output to the <code>BitOutputStream</code>.
	 * @param minThreshold the minimum threshold to code.
	 * @return void
	 */
	public void code(int minThreshold) throws IOException {
		int positionInLSC, maxThresholdPow;
		
		rate = false;
		for(z = 0 ; z < zSize ; z++) {
			// We initialize the LIC and the LIS
			LIC = new SpihtLinkedList2D();
			LSC = new SpihtLinkedList2D();
			LIS = new SpihtLinkedList2D();
			
			maxThreshold = initialTh();
			
			System.out.println("Max BitPlane: " + maxThreshold);
			//We output the maximum threshold for the current component
			maxThresholdPow = (int) (Math.log(maxThreshold)/Math.log(2));
			bos.writeUBits(maxThresholdPow, 5);
			//System.out.println("MaxThreshold: " + maxThreshold + " Pow: " + maxThresholdPow);
			
			// List initialization
			listInitialize();
			
			while(maxThreshold > minThreshold) {
				// Sorting step
				positionInLSC = LSC.size();
				try {
					sort(maxThreshold);
					// Refinement step
					if(positionInLSC != 0)
						refinement(maxThreshold, positionInLSC);
					maxThreshold >>= 1;
				} catch (IOException e) {
					bos.close();
					System.out.println(e.getMessage());
					System.exit(1);
				}
				
			} //while
		}
		
		//Close the output stream
		bos.close();
	} //code
	/**
	 * Applies the SPIHT two dimensional coding algorithm, doing the output to the <code>MultiOutputStream</code>.
	 * @param minThreshold the minimum threshold to code.
	 * @return void
	 */
	public void codeRated(int minThreshold) throws IOException {
		int positionInLSC, maxThresholdPow, index;
		int[][] imageAux = null;
		
		this.rate = true;
		
		table = new long[zSize][];
		accessPoints = new long[zSize][];
		errors = new long[zSize][];
		
		for(z = 0 ; z < zSize ; z++) {
			// We initialize the LIC and the LIS
			LIC = new SpihtLinkedList2D();
			LSC = new SpihtLinkedList2D();
			LIS = new SpihtLinkedList2D();
			
			index = 0;
			maxThreshold = initialTh();
			
			//We output the maximum threshold for the current component
			maxThresholdPow = (int) (Math.log(maxThreshold)/Math.log(2));
			bos.writeUBits(maxThresholdPow, 5);
			
			imageAux = new int[ySize][xSize];
			imageRecovered = new int[ySize][xSize];
			
			for(int j=0;j<ySize;j++) { 
				for(int i=0;i<xSize;i++) { 
					imageAux[j][i] = image[z][j][i];
					imageRecovered[j][i] = 0;
				}
			}
			
			table[z] = new long[(maxThresholdPow * 2) + 1];
			accessPoints[z] = new long[(maxThresholdPow * 2) + 2];
			errors[z] = new long[(maxThresholdPow * 2) + 2];
			
			accessPoints[z][index] = size;
			
			// List initialization
			listInitialize();
			
			//Total distortion for the z component
			errors[z][0] = computeSquareError(imageAux, imageRecovered);
			//System.out.println("Errors: " + errors[z][0]);
			while(maxThreshold > minThreshold) {
				// Sorting step
				positionInLSC = LSC.size();
				try {
					sort(maxThreshold);
				} catch (IOException e) {
					bos.close();
					throw new IOException(e.getMessage());
				}
				//Calculates the distortion reduction from the sorting pass and store it.
				errors[z][index + 1] = computeSquareError(imageAux, imageRecovered);
				//System.out.println("Errors: " + errors[z][index + 1]);
				table[z][index] = errors[z][index] - errors[z][index + 1];
				index++;
				//Stores the length of the sortin pass
				accessPoints[z][index] = size;
				
				// Refinement step
				if(positionInLSC != 0) {
					try {
						refinement(maxThreshold, positionInLSC);
					} catch (IOException e) {
						bos.close();
						throw new IOException(e.getMessage());
					}
					errors[z][index + 1] = computeSquareError(imageAux, imageRecovered);
					//System.out.println("Errors: " + errors[z][index + 1]);
					table[z][index] = errors[z][index] - errors[z][index + 1];
					index++;
					//Stores the length of the sortin pass
					accessPoints[z][index] = size;
				}
				maxThreshold >>= 1;
			} //while
			//Ensures the distortion values
			if(errors[z][errors[z].length - 1] != 0) {
				System.out.println("The distortion operation fails.");
				System.exit(0);
			}
			long acum = 0;
			for(int i=0; i < table[z].length; i++) {
				acum += table[z][i];
				//System.out.println("Table: " + table[z][i]);
			}
			//System.out.println("Acum: " + acum);
			if(acum != errors[z][0]) {
				System.out.println("The distortion operation fails in the total distortion in the " + z + " component.");
				System.out.println("Acum: " + acum + " Errors: " + errors[z][0]);
				System.exit(0);
			}
		} //For components
		//Close the output stream
		bos.close();
	} //codeRated
	/** 
	  * Applies the SPIHT two dimensional coding algorithm with the rate distortion PlaneBuilding version,
	  * doing output to the <code>MultiOutputStream</code>.
	  * @param minThreshold the minimum threshold to code
	  * @return void
	  */
	public void codeBuilding(int minThreshold) throws IOException{
		// We calculte the new subband limits
		limitResidualBandX = (xSize / (int) Math.pow(2, (levels))) * zSize;
		limitParentX = (xSize / 2) * zSize;
		limitGrandParentX =(xSize / 4) * zSize;
		
		try {
			PlaneBuilding pb = new PlaneBuilding(levels);
			
			// The image reorganization
			image = pb.obtainReorganizedImage(image);
		} catch (Exception e) {
			System.out.println("Image reorganization failed");
			System.exit(2);
		}
		
		// The new one row image dimensions
		xSize = xSize * zSize;
		zSize = 1;
		
		code(minThreshold);
		
		image = null;
	} //code
	/** 
	  * Applies the SPIHT two dimensional coding algorithm with the rate distortion Interleaved version,
	  * doing output to the <code>MultiOutputStream</code>.
	  * @param minThreshold the minimum threshold to code
	  * @return void
	  */
	public void codeInterleaved(int minThreshold) throws Exception {
		int positionInLSC, minBPE, maxBPE, acum;
		int[] maxThresholdVector, maxThresholdPows;
		//int[] positionInLSCVector;
		
		// Creates an instance of the LIS, LIC and LSC
		SpihtLinkedList2D[] LISVector;
		SpihtLinkedList2D[] LSCVector;
		SpihtLinkedList2D[] LICVector;
		
		//Initializations
		minBPE = Integer.MAX_VALUE;
		maxBPE = Integer.MIN_VALUE;
		positionInLSC = 0;
		acum = 0;
		
		maxThresholdVector = null;
		maxThresholdPows = null;
		
		maxThresholdVector = new int[zSize];
		maxThresholdPows = new int[zSize];
		
		// We store the BPE for each band
		for(z = 0 ; z < zSize ; z++) {
			maxThresholdVector[z] = initialTh();
			maxThresholdPows[z] = (int) (Math.log(maxThresholdVector[z])/Math.log(2));
			if(maxBPE < maxThresholdPows[z]) maxBPE = maxThresholdPows[z];
			if(minBPE > maxThresholdPows[z]) minBPE = maxThresholdPows[z];
		}
		z = 0;
		
		//The lists for each component in the algorithm
		LISVector = new SpihtLinkedList2D[zSize];
		LICVector = new SpihtLinkedList2D[zSize];
		LSCVector = new SpihtLinkedList2D[zSize];
		
		LIC = new SpihtLinkedList2D();
		LIS = new SpihtLinkedList2D();
		LSC = new SpihtLinkedList2D();
		
		listInitialize();
		
		System.out.println("maxBPE: " + maxBPE);
		System.out.println("minBPE: " + minBPE);
		bos.writeUBits(maxBPE,5);
		bos.writeUBits(minBPE,5);
		
		//Here the index variable z is NOT the attribute
		for(int z = 0 ; z < zSize ; z++) {
			//BPE Header
			if(maxBPE != minBPE) bos.writeUBits(maxThresholdPows[z] - minBPE,bos.minBits(maxBPE - minBPE));
			
			//The initialization of lists
			LISVector[z] = new SpihtLinkedList2D();
			
			//System.out.println("Initializations");
			LISVector[z].cloneListTyped(LIS);
			LICVector[z] = new SpihtLinkedList2D();
			LICVector[z].cloneList(LIC);
			LSCVector[z] = new SpihtLinkedList2D();
		}
		LIS = null;
		LIC = null;
		
		while(maxBPE != minBPE) {
			//acum = 0;
			for(z = 0 ; z < zSize ; z++) {
				if(maxThresholdPows[z] > minBPE) {
					//Step initialization
					LIS = LISVector[z];
					LIC = LICVector[z];
					LSC = LSCVector[z];
					maxThreshold = maxThresholdVector[z];
					
					// Sorting step
					positionInLSC = LSC.size();
					sort(maxThreshold);
					
					// Refinement step
					if(positionInLSC != 0) refinement(maxThreshold, positionInLSC);
					
					//New parameters store
					maxThresholdVector[z] = maxThreshold >> 1;
					maxThresholdPows[z]--;
					LISVector[z] = LIS;
					LICVector[z] = LIC;
					LSCVector[z] = LSC;
					LIS = null;
					LSC = null;
					LIC = null;
				}
				//else if(maxThresholdPows[z] == minBPE) acum++;
			}//for
			maxBPE--;
		}//while
		
		maxThresholdPows = null;
		maxThreshold = 1;
		
		while(maxThreshold != 0) {
			for(z = 0; z < zSize ; z++) {
				//Step initialization
				LIS = LISVector[z];
				LIC = LICVector[z];
				LSC = LSCVector[z];
				maxThreshold = maxThresholdVector[z];
				
				// Sorting step
				positionInLSC = LSC.size();
				sort(maxThreshold);
				
				// Refinement step
				if(positionInLSC != 0) refinement(maxThreshold, positionInLSC);
				
				maxThreshold >>= 1;
				//New parameters store
				maxThresholdVector[z] = maxThreshold;
				LISVector[z] = LIS;
				LICVector[z] = LIC;
				LSCVector[z] = LSC;
				LIS = null;
				LSC = null;
				LIC = null;
			}//for
		}//while
		bos.close();
	} // Code
	
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               SPIHT STEPS METHODS                          /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * It realizes the sorting step of the SPIHT two dimensional coding algorithm
	 * @param actualThreshold the current threshold
	 * @return void
	 */
	protected void sort(int actualThreshold) throws IOException {
		int value, size, write;
		boolean end;
		
		write = 0;
		//System.out.println("Sorting Stage: " + actualThreshold);
		//System.out.println("Rate: " + rate);
		LIC.initialNode();
		
		size = LIC.size();
		for(int i=0;i<size;i++){
			value = getSample(LIC.getX(),LIC.getY(),z);
			write++;
			// Asks for a significant sample
			if (Math.abs(value) >= actualThreshold) {
				// Outputs ONE
				bos.writeMulti(ONE);
				write++;
				int x = LIC.getX();
				int y = LIC.getY();
				LIC.moveElementAtLast(LSC);
				
				// Outputs the sign
				if(value < 0) {
					bos.writeMulti(NEG);
					if(rate) {
						imageRecovered[y][x] = - (actualThreshold + (actualThreshold >> 1));
						//System.out.println("Recovered: " + imageRecovered[y][x]); 
					}
				}
				else {
					bos.writeMulti(POS);
					if(rate) {
						imageRecovered[y][x] = actualThreshold + (actualThreshold >> 1);
						//System.out.println("Recovered: " + imageRecovered[y][x]);
					}
				}
			}//if value
			else {
				LIC.nextValue();
				bos.writeMulti(ZERO);
			} //if-else
		} //for
		
		// For each (i,j) LIS
		LIS.initialNode();
		
		end = LIS.isEmpty();
		while((!end) && (LIS.size()!=0)) {
			end = LIS.isLast();
			// TYPE_A
			if (LIS.getType() == TYPE_A) {
				if (significativeDescendent(LIS.getX(),LIS.getY(),true)){
					bos.writeMulti(ONE);
					write++;
					int []childCoordinate = new int[2];
					
					int x = LIS.getX();
					int y = LIS.getY();
					for (int j=1;j<=4;j++) {
						childCoordinate = children(x,y,j);
						value = getSample(childCoordinate[0],childCoordinate[1],z);
						if (Math.abs(value) >= actualThreshold) {
							//outputs ONE
							bos.writeMulti(ONE);
							write++;
							LSC.addElement(childCoordinate[0],childCoordinate[1]);
							//outputs the sign
							if(value < 0) {
								bos.writeMulti(NEG);
								if(rate) {
									imageRecovered[childCoordinate[1]][childCoordinate[0]] = - (actualThreshold + (actualThreshold >> 1));
									//System.out.println("Recovered: " + imageRecovered[childCoordinate[1]][childCoordinate[0]]);
								}
								//System.out.println("Recovered: " + imageRecovered[childCoordinate[1]][childCoordinate[0]]);
							}
							else {
								bos.writeMulti(POS);
								if(rate) {
									imageRecovered[childCoordinate[1]][childCoordinate[0]] = actualThreshold + (actualThreshold >> 1);
									//System.out.println("Recovered: " + imageRecovered[childCoordinate[1]][childCoordinate[0]]);
								}
								//System.out.println("Recovered: " + imageRecovered[childCoordinate[1]][childCoordinate[0]]);
							}
							write++;
						} else {
							LIC.addElement(childCoordinate[0],childCoordinate[1]);
							bos.writeMulti(ZERO);
							write++;
						} //if-else
					}//for j
					if (isGrandParent(LIS.getX(),LIS.getY())) {
						// method 1 JPEG2000
						if (method == 1) {
							LIS.setType(TYPE_B);
							LIS.moveElementAtLast(LIS);
							end = false;
						}
						else if (method == 0) {
							// method 0 Orginal
							LIS.setType(TYPE_B);
							end = false;
						}
					}//if GrandParent
					else {
						LIS.remove();
					}
				}//if significativeDescendents
				else {
					bos.writeMulti(ZERO);
					write++;
					LIS.nextValue();
				}
			}
			// TYPE_B
			else {
				if (significativeDescendent(LIS.getX(),LIS.getY(),false)){
					bos.writeMulti(ONE);
					write++;
					int [] childCoordinate = new int[2];
					int x,y;
					
					x = LIS.getX();
					y = LIS.getY();
					for (int j=1;j<=4;j++) {
						childCoordinate = children(x,y,j);
						LIS.addElement(childCoordinate[0],childCoordinate[1],TYPE_A);
						end = false;
					}
					LIS.remove();
				}
				else {
					bos.writeMulti(ZERO);
					write++;
					LIS.nextValue();
				}
			}
		} //while
		this.size += write;
		//System.out.println("Simbolos escritos: " + write);
	} //sort
	/**
	 * Outputs finer detail to which interval belong already sent samples.
	 * @param actualThreshold the current threshold
	 * @param positionInLSC marks the top position in LSC for the refinement stage
	 * @return void
	 */
	protected void refinement(int actualThreshold, int positionInLSC) throws IOException{
		int value, precissionPoint, write;
		
		write = 0;
		LSC.initialNode();
		for(int i=0;i<positionInLSC;i++) {
			value = Math.abs(getSample(LSC.getX(),LSC.getY(),z));
			if( (actualThreshold & value) != 0) {
				precissionPoint = ONE;
				if(rate) {
					int coef = imageRecovered[LSC.getY()][LSC.getX()];
					boolean sign = false;
					if(coef < 0) {
						sign = true;
						coef = - coef;
					}
					coef += (actualThreshold >> 1);
					if(sign) coef = -coef;
					imageRecovered[LSC.getY()][LSC.getX()] = coef;
				}
			}
			else {
				precissionPoint = ZERO;
				if(rate) {
					int coef = imageRecovered[LSC.getY()][LSC.getX()];
					boolean sign = false;
					if(coef < 0) {
						sign = true;
						coef = -coef;
					}
					if(actualThreshold == 1) coef -= 1;
					else coef -= (actualThreshold >> 1);
					if(sign) coef = -coef;
					imageRecovered[LSC.getY()][LSC.getX()] = coef;
				}
			}
			write++;
			bos.writeMulti(precissionPoint);
			LSC.nextValue();
		} //for
		this.size += write;
		//System.out.println("Simbolos escritos de refinamiento: " + write);
	} //refinement
	
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               SPIHT AUXILIAR METHODS                       /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Outputs if any descendents of a specified postion are significative
	 * @param x x coordinate in the image
	 * @param y y coordinate in the image
	 * @param childs it determines if we have to scan the childs to determine if it has significative descendents.
	 * @return true if the position has significative descendents, false otherwise
	 */
	protected boolean significativeDescendent(int x, int y, boolean childs) {
		 int[] childCoordinate1,childCoordinate2,childCoordinate3,childCoordinate4;
		 
		 childCoordinate1 = new int[2];
		 childCoordinate2 = new int[2];
		 childCoordinate3 = new int[2];
		 childCoordinate4 = new int[2];
		 
		 if (isParent(x,y)) {
			childCoordinate1=children(x,y,1);
			childCoordinate2=children(x,y,2);
			childCoordinate3=children(x,y,3);
			childCoordinate4=children(x,y,4);
			if (childs) {
				if (Math.abs(getSample(childCoordinate1[0],childCoordinate1[1],z))>=maxThreshold) {
					return true;
				}
				
				if (Math.abs(getSample(childCoordinate2[0],childCoordinate2[1],z))>=maxThreshold) {
					return true;
				}
				
				if (Math.abs(getSample(childCoordinate3[0],childCoordinate3[1],z))>=maxThreshold) {
					return true;
				}
				
				if (Math.abs(getSample(childCoordinate4[0],childCoordinate4[1],z))>=maxThreshold) {
					return true;
				}
			}
			if (significativeDescendent(childCoordinate1[0],childCoordinate1[1],true)) return true;
			if (significativeDescendent(childCoordinate2[0],childCoordinate2[1],true)) return true;
			if (significativeDescendent(childCoordinate3[0],childCoordinate3[1],true)) return true;
			if (significativeDescendent(childCoordinate4[0],childCoordinate4[1],true)) return true;
		 }
		 return false;
	}
	/**
	 * Finds the maximum threshold for the component of the input image specified by the field <code>z</code>.
	 * @return the maximum threshold in the component
	 */
	protected int initialTh() {
		int maxim = Math.abs(image[z][0][0]);
		int value = 0;
		for (int y = 0; y < ySize; y++) {
			for (int x = 0; x < xSize; x++) {
				value = Math.abs(image[z][y][x]);
				if (value > maxim ) maxim = value;
			}
		}
		return ((int)Math.pow(2,(int)(Math.log(maxim)/Math.log(2))));
	}
	/**
	 * Initializes the lists LIS and LIC for the three dimensional SPIHT algorithm.
	 * @return void
	 */
	protected void listInitialize() {
		for (int x = 0; x < limitResidualBandX; x++) {
			for (int y = 0; y < limitResidualBandY; y++) {
				LIC.addElement(x,y);
				if (isParent(x,y)) LIS.addElement(x, y, TYPE_A);
			}
		}
	}
	/**
	 * Calculates the Square Error distortion metric from an integer three dimensional vector image.
	 * @param source the original vector
	 * @param recovered the recovered vector
	 * @return the Square Error
	 */
	public long computeSquareError(int[][] source, int[][] recovered) {
		int xSize, ySize;
		long value, squareError;
		
		ySize = source.length;
		xSize = source[0].length;
		squareError = 0;
		for(int y=0;y<ySize; y++) {
			for(int x=0;x<xSize;x++) {
				value = source[y][x] - recovered[y][x];
				squareError += value * value;
			}
		}
		return squareError;
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               GET METHODS                                  /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	public long[][] getTable() {
		return table;
	}
	public long[][] getAccessPoints() {
		return accessPoints;
	}


}//SPIHT2D Coding
