package Spiht.SpihtCoding;

import java.io.IOException;
import java.io.FileOutputStream;
import Building.LineBuilding;
import Spiht.Spiht;
import List.SpihtVector;
import GiciBitStream.BitOutputStream;


/** An implementation of one dimensional SPIHT Coding algorithm. This class also calculates the distortion reduced by each
    sorting or refinement step in the coding process to perform an accurate postcompression rate process. <p>
  * @see Spiht.Spiht
  * @see Building.LineBuilding
  * @see HyperStream.BitOutputStream
  * @author Jorge González-Conejero
  * @version 1.0 11/12/2003
  * @version 2.0 14/12/2003
  */ 

public class SpihtCoding1D extends Spiht {
	/**
	 * Current line of the image in the algorithm.
	 * <p>
	 * Only an integer line number are allowed. If the line is greater than the image heigth it will throw an exception.
	 */
	protected int line = 0;
	/**
	 * List of insignificant coefficients.
	 * <p>
	 * This list must contains the insignificant coefficients of the input image. Only an integer coordinates are allowed.
	 */
	protected SpihtVector LIC = null;
	/**
	 * List of insignificant sets.
	 * <p>
	 * This list must contains the insignificant sets of the input image. Only an integer coordinates are allowed.
	 */
	protected SpihtVector LIS = null;
	/**
	 * List of significant coefficients.
	 * <p>
	 * This list must contains the significant coefficients of the input image. Only an integer coordinates are allowed.
	 */
	protected SpihtVector LSC = null;
	/** 
	  * The coded output stream. 
	  * <p>
	  * Only a SPIHT output bit stream is allowed.
	  */
	protected BitOutputStream bos = null;
	/** 
	  * The distortions calculed for each line are stored. 
	  * <p>
	  * Negative values are not allowed.
	  */
	protected long[][] table = null;
	
	protected long[][] errors = null;
	/** 
	  * The position of the beginning and the end of each truncation point in the original coded bitstream. 
	  * <p>
	  * Negative values are not allowed for this field.
	  */
	protected long[][] accessPoints = null;
	/** 
	  * The recovered image at nth step to calculate the distortion.
	  * <p>
	  * Negative values are not allowed for this field.
	  */
	protected int[] imageRecovered = null;
	/** 
	  * Specifies if the rate values will be calculated.
	  * <p>
	  * Only a boolean value is allowed.
	  */
	protected boolean rate = false;

	/** The object constructor. It initializes the attributes with the default values.
	  */
	public SpihtCoding1D() {
		image = null;
		size = 0;
		line = 0;
	}
	/** The object constructor, It initializes the attributes with the default values and
	  * open the output stream, writes the initial headers and calculates the subbands limits
	  * needed by the coding algorithm.
	  * @param image the input image
	  * @param levels the levels used in the discrete wavelet transform
	  * @param fname the name of the file to write the output stream
	  * @param target specifies if the final bitstream has a rate target
	  */
	public SpihtCoding1D(int[][][] image, int levels, String fname, boolean rateTarget, long target) throws IOException {
		
		//DEFAULT VALUES FOR THE ATTRIBUTES
		this.image = image;
		image = null;
		size = 0;
		line = 0;
		
		//OPENS THE OUTPUT STREAM
		FileOutputStream fos = new FileOutputStream(fname);
		bos = new BitOutputStream(fos, target);
		
		//IMAGES DIMENSIONS
		zSize = this.image.length;
		ySize = this.image[0].length;
		xSize = this.image[0][0].length;
		
		this.levels = levels;
		this.method = 0;
		
		//WRITES INITIAL HEADER
		bos.writeUBits(xSize,16);
		bos.writeUBits(ySize,16);
		bos.writeUBits(levels,4);
		bos.writeUBits(method,1);
		
		//SUBBAND LIMITS
		limitResidualBandX = xSize / (int) Math.pow(2, levels);
		limitParentX = xSize / 2;
		limitGrandParentX = xSize / 4;
	}
	/** Opens the output bitstream for the coding algorithm.
	  * @param outFileName the name of the file to write the output stream
	  * @param target specifies if the final bitstream has a rate target
	  */
	public void openOutputBitstream(String outFileName, long target) throws IOException {
		
		if(bos != null) throw new IOException("ERROR: The output bitstream is already open.");
		
		FileOutputStream fos = new FileOutputStream(outFileName);
		bos = new BitOutputStream(fos, target);
	}
	/** Writes the initial header in the output bitstream that constains the image dimensions, the levels of the discrete
	  * wavelet transform levels and the method used by the coder.
	  */
	public void writeInitialHeader() throws IOException {
		
		if(bos == null) throw new IOException("ERROR: The output bitstream is closed. Initial header is not written.");
		
		bos.writeUBits(xSize,16);
		bos.writeUBits(ySize,16);
		bos.writeUBits(levels,4);
		bos.writeUBits(method,1);
	}
	/** Calculates the limits of the offspring in the input image, this limits are used by the coding algorithm to know
	  * the position of a coefficient in the hierarchical structure.
	  */
	public void calculateSubbandLimits() throws Exception {
		
		if(xSize == 0) throw new Exception("ERROR: The size of the image is not correct");
		if(levels == 0) throw new Exception("ERROR: The number of levels of the image is not correct");
		
		limitResidualBandX = xSize / (int) Math.pow(2, levels);
		limitParentX = xSize / 2;
		limitGrandParentX = xSize / 4;
	}
	
	
	////////////////////////////////////////////////////////////////////////////////
	///////                  SPIHT CODE METHODS                            /////////
	///////////////////////////////////////////////////////////////////////////////
	
	/** 
	  * Applies the SPIHT one dimensional coding algorithm, doing output to the <code>BitOutputStream</code>.
	  * @param minThreshold the minimum threshold to code
	  */
	public void code(int minThreshold) throws Exception {
		int positionInLSC = 0, maxThresholdPow = 0;
		
		this.rate = false;
		System.out.println("YSize: " + ySize + " XSize: " + xSize);
		//APPLY THE SPIHT 1D TO EACH LINE IN THE IMAGE
		for(line = 0 ; line < ySize ; line++) {
			positionInLSC = 0;
			maxThresholdPow = 0;
			
			//LIST INSTANCES
			LIC = new SpihtVector(xSize, 10, 1, false);
			LSC = new SpihtVector(xSize + (xSize / 2), 10, 1, false);
			LIS = new SpihtVector(xSize, 10, 1, true);
			
			//CALCULATES THE INITIAL THRESHOLD IN THE INPUT IMAGE
			maxThreshold = initialTh();
			maxThresholdPow = (int) (Math.log(maxThreshold)/Math.log(2));
			bos.writeUBits(maxThresholdPow,5);
			
			//LIST INITIALIZATIONS
			listInitialize();
			
			while(maxThreshold > minThreshold) {
				positionInLSC = LSC.size();
				//SORTING STEP
				try {
					sort(maxThreshold);
				} catch (IOException e) {
					bos.close();
					throw new IOException(e.getMessage());
				}
				//REFINEMENT STEP
				if(positionInLSC != 0) {
					try {
						refinement(maxThreshold, positionInLSC);
					} catch (IOException e) {
						bos.close();
						System.out.println("Exception in code process: " + e.getMessage());
						e.printStackTrace();
						System.exit(0);
					}
				}
				maxThreshold >>= 1;
			} //while
		} // for lines
		//CLOSE THE OUTPUT BITSTREAM
		bos.close();
	} // Code
	
	/** 
	  * Applies the SPIHT one dimensional coding algorithm with the distortion reduction calculation,
	  * doing output to the <code>BitOutputStream</code>.
	  * @param minThreshold the minimum threshold to code
	  * @return void
	  */
	public void codeRated(int minThreshold) throws Exception {
		int positionInLSC = 0;
		int maxThresholdPow = 0, index = 0;
		int[] imageAux = null;
		size = 0;
		
		//TO STORE THE DISTORTION REDUCTION PROVIDED FOR EACH STEP
		rate = true;
		table = new long[ySize][];
		errors = new long[ySize][];
		accessPoints = new long[ySize][];
		
		//APPLY THE SPIHT 1D TO EACH LINE IN THE IMAGE
		for(line = 0 ; line < ySize ; line++) { 
			index = 0;
			positionInLSC = 0;
			maxThresholdPow = 0;
			
			//LIST INSTANCES
			LIC = new SpihtVector(xSize + (xSize/4), 10, 1, false);
			LSC = new SpihtVector(xSize + (xSize/4), 10, 1, false);
			LIS = new SpihtVector(xSize + (xSize/4), 10, 1, true);
			
			//CALCULATES THE INITIAL THRESHOLD IN THE INPUT IMAGE
			maxThreshold = initialTh();
			maxThresholdPow = (int) (Math.log(maxThreshold)/Math.log(2));
			bos.writeUBits(maxThresholdPow, 5);
			
			//AUXILIAR ARRAYS TO CALCULATE THE DISTORTION REDUCTION PROVIDED FOR EACH SPIHT STEP
			imageAux = new int[xSize];
			imageRecovered = new int[xSize];
			
			for(int i = 0 ; i < xSize ; i++) {
				imageAux[i] = image[0][line][i];
				imageRecovered[i] = 0;
			}
			
			//INSTANCE THE TABLES TO STORE THE DISTORTION REDUCTION
			table[line] = new long[(maxThresholdPow * 2) + 1];
			errors[line] = new long[(maxThresholdPow * 2) + 2];
			accessPoints[line] = new long[(maxThresholdPow * 2) + 2];
			
			accessPoints[line][index] = size;
			
			//LIST INITIALIZATIONS
			listInitialize();
			
			//Total distortion
			errors[line][0] = computeSquareError(imageAux, imageRecovered);
			while(maxThreshold > minThreshold) {
				positionInLSC = LSC.size();
				//SORTING STEP
				try {
					sort(maxThreshold);
				} catch (IOException e) {
					bos.close();
					throw new IOException(e.getMessage());
				}
				
				//CALCULATES THE DISTORTION REDUCTION FOR THE SORTING STEP AND STORES IT
				errors[line][index + 1] = computeSquareError(imageAux, imageRecovered);
				table[line][index] = errors[line][index] - errors[line][index + 1];
				//table[line][index] = computeSquareError(imageAux, imageRecovered);
				index++;
				
				//for(int i=0;i<xSize;i++) imageAux[i] = imageRecovered[i];
				accessPoints[line][index] = size;
				
				//REFINEMENT STEP
				if(positionInLSC != 0) {
					try {
						refinement(maxThreshold, positionInLSC);
					} catch (IOException e) {
						bos.close();
						throw new IOException(e.getMessage());
					}
					//CALCULATES THE DISTORTION REDUCTION FOR THE REFINEMENT STEP AND STORES IT
					errors[line][index + 1] = computeSquareError(imageAux, imageRecovered);
					table[line][index] = errors[line][index] - errors[line][index + 1];
					//table[line][index] = computeSquareError(imageAux, imageRecovered);
					index++;
					
					//for(int i=0;i<xSize;i++) imageAux[i] = imageRecovered[i];
					
					accessPoints[line][index] = size;
				}
				maxThreshold >>= 1;
			} //WHILE
			//System.out.println("Size: " + size);
			//Check the distortion measures
			if(errors[line][errors[line].length - 1] != 0) {
				System.out.println("No se ha recuperado bien");
				System.exit(0);
			}
			int acum = 0;
			for(int i=0;i<table[line].length;i++) {
				acum += table[line][i];
			}
			if(acum != errors[line][0]) {
				System.out.println("Suma: " + errors[line][0] + " Total: " + acum);
				System.exit(0);
			}
		} //FOR LINES
		//CLOSES THE OUTPUT BITSTREAM
		bos.close();
	}
	/** 
	  * Applies the SPIHT one dimensional coding algorithm with the rate distortion LineBuilding version,
	  * doing output to the <code>BitOutputStream</code>.
	  * @param minThreshold the minimum threshold to code
	  */
	public void codeBuilding(int minThreshold) throws Exception {
		int positionInLSC = 0;
		
		//RECALCULATES THE NEW SUBBAND LIMITS
		limitResidualBandX = (xSize / (int) Math.pow(2, (levels))) * ySize;
		limitParentX = (xSize / 2) * ySize;
		limitGrandParentX = (xSize / 4) * ySize;
		
		try {
			//THIS CLASS MAKES THE IMAGE REORGANIZATION
			LineBuilding lb = new LineBuilding(image, levels);
			
			//RUN THE METHOD TO MAKE THE IMAGE REORGANIZATION
			image = lb.obtainReorganizedImage();
		} catch (Exception e) {
			System.out.println("Reorganization LB error: " + e.getMessage());
			e.printStackTrace();
			System.exit(0);
		}
		
		//NEW IMAGE DIMENSIONS
		xSize = xSize * ySize;
		ySize = 1;
		
		//CODES THE NEW ONE ROW IMAGE
		code(minThreshold);
		
		image = null;
	}
	
	/** 
	  * Applies the SPIHT one dimensional coding algorithm with the rate distortion Interleaved version,
	  * doing output to the <code>BitOutputStream</code>.
	  * @param minThreshold the minimum threshold to code
	  */
	public void codeInterleaved(int minThreshold) throws Exception {
		int positionInLSC = 0;
		int positionInLine = 0;
		int minBPE = Integer.MAX_VALUE;
		int maxBPE = Integer.MIN_VALUE;
		int acum = 0;
		int[] maxThresholdVector = null;
		int[] maxThresholdPows = null;
		int[] positionInLineVector = null;
		SpihtVector[] LISVector;
		SpihtVector[] LSCVector;
		SpihtVector[] LICVector;
		
		maxThresholdVector = new int[ySize];
		maxThresholdPows = new int[ySize];
		
		//STORES THE MAXIMUM BPE FOR EACH LINE FROM THE INPUT IMAGE
		for(line = 0 ; line < ySize ; line++) {
			maxThresholdVector[line] = initialTh();
			maxThresholdPows[line] = (int) (Math.log(maxThresholdVector[line])/Math.log(2));
			if(maxBPE < maxThresholdPows[line]) maxBPE = maxThresholdPows[line];
			if(minBPE > maxThresholdPows[line]) minBPE = maxThresholdPows[line];
		}
		line = 0;
		
		//INSTANCES THE LISTS FOR EACH LINE OF THE INPUT IMAGE
		LISVector = new SpihtVector[ySize];
		LICVector = new SpihtVector[ySize];
		LSCVector = new SpihtVector[ySize];
		
		//AUXILIAR LISTS INSTANCES
		LIC = new SpihtVector(xSize + (xSize/4), 10, 1, false);
		LIS = new SpihtVector(xSize + (xSize/4), 10, 1, true);
		
		//AUXILIAR LISTS INITIALIZATIONS
		listInitialize();
		
		System.out.println("maxBPE: " + maxBPE);
		System.out.println("minBPE: " + minBPE);
		//WRITES THE MAXIMUM AND THE MINIMUM BPE IN THE INPUT IMAGE TO THE BITSTREAM
		bos.writeUBits(maxBPE, 5);
		bos.writeUBits(minBPE, 5);
		
		for(int line = 0 ; line < ySize ; line++) {
			//WRITES IN WHICH BPE EVERY LINE BEGINS TO BE SIGNIFICANT
			if(maxBPE != minBPE) {
				//THE BPE IS CODED BY THE DIFFERENCE TO THE MINIMUM BPE
				bos.writeUBits(maxThresholdPows[line] - minBPE,bos.minBits(maxBPE - minBPE));
				size += bos.minBits(maxBPE - minBPE);
			}
			
			//INITIALIZES ALL THE LISTS FOR EACH LINE IN THE IMAGE
			LISVector[line] = LIS.cloneObject();
			LICVector[line] = LIC.cloneObject();
			LSCVector[line] = new SpihtVector(xSize + (xSize/4), 10, 1, false);
		}
		LIS = null;
		LIC = null;
		
		//CODING FIRST THE HIGHER BP IN DESCENDANT ORDER
		while(maxBPE != minBPE) {
			for(line = 0 ; line < ySize ; line++) {
				if(maxThresholdPows[line] > minBPE) {
					//LOADS THE VARIABLES FOR THE CURRENT STEP
					LIS = LISVector[line];
					LIC = LICVector[line];
					LSC = LSCVector[line];
					maxThreshold = maxThresholdVector[line];
					
					try {
						positionInLSC = LSC.size();
						
						//SORTING STEP
						sort(maxThreshold);
						
						//REFINEMENT STEP
						if(positionInLSC != 0)
							refinement(maxThreshold, positionInLSC);
					} catch (IOException e) {
						bos.close();
						throw new Exception(e.getMessage());
					}
					
					//STORES THE VARIABLES AT THE END OF THE STEP
					maxThresholdVector[line] = maxThreshold >> 1;
					maxThresholdPows[line]--;
					LISVector[line] = LIS;
					LICVector[line] = LIC;
					LSCVector[line] = LSC;
					LIS = null;
					LSC = null;
					LIC = null;
				}
			}//FOR LINES
			maxBPE--;
		}//WHILE MAXBPE
		
		maxThresholdPows = null;
		maxThreshold = 1;
		
		//CODING THE BP IN DESCENDANT ORDER
		while(maxThreshold != 0) {
			for(line = 0 ; line < ySize ; line++) {
				//LOADS THE VARIABLES FOR THE CURRENT STEP
				LIS = LISVector[line];
				LIC = LICVector[line];
				LSC = LSCVector[line];
				maxThreshold = maxThresholdVector[line];
				
				try {
					//SORTING STEP
					positionInLSC = LSC.size();
					sort(maxThreshold);
					
					//REFINEMENT STEP
					if(positionInLSC != 0)
						refinement(maxThreshold, positionInLSC);
				} catch (IOException e) {
						bos.close();
						throw new Exception(e.getMessage());
				}
				maxThreshold >>= 1;
				
				//STORES THE VARIABLES AT THE END OF THE STEP
				maxThresholdVector[line] = maxThreshold;
				LISVector[line] = LIS;
				LICVector[line] = LIC;
				LSCVector[line] = LSC;
				LIS = null;
				LSC = null;
				LIC = null;
			}//FOR LINES
		}//WHILE MAXTHRESHOLD != 0
		//CLOSES THE OUTPUT BITSTREAM
		bos.close();
	} // Code
	
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               SPIHT STEPS METHODS                          /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	
	/** It realizes the sorting stage of the SPIHT one dimensional algorithm.
	  * @param actualThreshold current threshold
	  * @return void
	  */
	protected void sort(int actualThreshold) throws Exception {
		int value,size,index;
		boolean end;
		int write;
		int[] removeIndex;
		
		write = 0;
		
		size = LIC.size();
		removeIndex = new int[size];
		index = 0;
		for(int i = 0 ; i < size ; i++){
			value = getSample(LIC.getX(i), line, 0);
			// Asks for a significant sample
			if (Math.abs(value) >= actualThreshold) {
				// Outputs ONE
				bos.writeMulti(ONE);
				write++;
				
				LSC.addElement(LIC.getX(i));
				removeIndex[index] = i;
				//System.out.println("REMOVE: " + removeIndex[index]);
				index++;
				
				// Outputs the sign
				if(value < 0) { 
					bos.writeMulti(NEG);
					if(rate) { 
						imageRecovered[LIC.getX(i)] = - (actualThreshold + (actualThreshold >> 1));
					}
				}
				else {
					bos.writeMulti(POS);
					if(rate) {
						imageRecovered[LIC.getX(i)] = actualThreshold + (actualThreshold >> 1);
					}
				}
				
				write++;
			}//if value
			else {
				bos.writeMulti(ZERO);
				write++;
			} //if-else
		} //for
		
		//System.out.println("FINAL PROCESO LIC");
		//Remove the coordinates that the algorithm has considered significatives
		LIC.removeCollectionOfElements(removeIndex, index);
		//System.out.println("INICIO PROCESO LIS");
		
		for(index=0;index<LIS.size();index++) {
			// TYPE_A
			if (LIS.getType(index) == TYPE_A) {
				if (significativeDescendent(LIS.getX(index),true)){
					bos.writeMulti(ONE);
					write++;
					int child;
					
					for (int j=1;j<=2;j++) {
						child = children(LIS.getX(index),j);
						value = getSample(child, line, 0);
						if (Math.abs(value) >= actualThreshold) {
							// Outputs ONE
							bos.writeMulti(ONE);
							write++;
							LSC.addElement(child);
							// Outputs the sign
							if(value < 0) {
								if(rate) imageRecovered[child] = - (actualThreshold + (actualThreshold >> 1));
								bos.writeMulti(NEG);
								write++;
							}
							else {
								if(rate) imageRecovered[child] = actualThreshold + (actualThreshold >> 1);
								bos.writeMulti(POS);
								write++;
							}
						} else {
							LIC.addElement(child);
							bos.writeMulti(ZERO);
							write++;
						} //if-else
					}//for j  
					if (isGrandParent(LIS.getX(index))) {
						// Method 1 JPEG2000
						if (method == 1) {
							LIS.addElement(LIS.getX(index), TYPE_B);
							LIS.removeElement(index);
							index--;
						}
						else if ( method == 0 ) {
							// method 2 Orginal
							if (significativeDescendent(LIS.getX(index),false)){
								bos.writeMulti(ONE);
								write++;
								for (int j=1;j<=2;j++) {
									child = children(LIS.getX(index),j);
									LIS.addElement(child, TYPE_A);
								}
								LIS.removeElement(index);
								index--;
							}
							else {
								bos.writeMulti(ZERO);
								write++;
								//LIS.addElement(LIS.getX(index), TYPE_B);
								//LIS.removeElement(index);
								//index--;
								LIS.setType(index, TYPE_B);
							}
						}
					}//if GrandParent 
					else {
						LIS.removeElement(index);
						index--;
					} 
				}//if significativeDescendents
				else {
					bos.writeMulti(ZERO);
					write++;
				}
			}
			// TYPE_B
			else {
				if (significativeDescendent(LIS.getX(index),false)){
					bos.writeMulti(ONE);
					write++;
					int child;
					
					for (int j=1;j<=2;j++) {
						child = children(LIS.getX(index),j);
						LIS.addElement(child, TYPE_A);
					}
					LIS.removeElement(index);
					index--;
				}
				else {
					bos.writeMulti(ZERO);
					write++;
				}
			}
		} //while 
		this.size += write;
	} //sort
	/** Outputs finer detail to which interval belong already sent samples.
	  * @param actualThreshold the current threshold
	  * @param positionInLSC marks the top position in LSC for the refinement stage
	  * @return void
	  */
	protected void refinement(int actualThreshold, int positionInLSC) throws Exception{
		int value;
		int precissionPoint;
		int write;
		
		write = 0;
		// Sets the pointer at the begin of the list
		//LSC.initialNode();
		for(int i=0;i<positionInLSC;i++) {
			value = Math.abs(getSample(LSC.getX(i),line,0));
			if( (actualThreshold & value) != 0) { 
				precissionPoint = ONE;
				if(rate) {
					int coef = imageRecovered[LSC.getX(i)];
					boolean sign = false;
					if(coef < 0) {
						sign = true;
						coef = - coef;
					}
					coef += (actualThreshold >> 1);
					if(sign) coef = -coef;
					imageRecovered[LSC.getX(i)] = coef;
				}
			}
			else {
				precissionPoint = ZERO;
				if(rate) {
					int coef = imageRecovered[LSC.getX(i)];
					boolean sign = false;
					if(coef < 0) {
						sign = true;
						coef = - coef;
					}
					if(actualThreshold == 1) coef -= 1;
					else coef -= (actualThreshold >> 1);
					if(sign) coef = - coef;
					imageRecovered[LSC.getX(i)] = coef;
				}
			}
			bos.writeMulti(precissionPoint);
			write++;
		} //for
		//System.out.println("Numero de simbolos escritos en refinement: " + write);
		this.size += write;
	} // refinement
	
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               SPIHT AUXILIAR METHODS                       /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	
	/** Outputs if any descendent of a specified postion are significative or not.
	  * @param x the position in the vector
	  * @param childs it determines if we have to scan the childs to determine if <code>x</code> it has significative descendents
	  * @return true if the specific position has significative descendents, false otherwise
	  */
	protected boolean significativeDescendent(int x,boolean childs) {
		 int child1,child2;
		 
		 if (isParent(x)) {
			child1 = children(x,1);
			child2 = children(x,2);
			if (childs) {
				if (Math.abs(getSample(child1,line,0))>=maxThreshold) {
					return true;
				}
				
				if (Math.abs(getSample(child2,line,0))>=maxThreshold) {
					return true;
				}
			}
			if (significativeDescendent(child1,true)) return true;
			if (significativeDescendent(child2,true)) return true;
		 }
		 return false;
	}
	/**
	 * Finds the maximum threshold for the current line specified by the field <code>line</code>.
	 * @return the maximum threshold in the current line
	 */
	protected int initialTh() {
		int maxim;
		int value;
		
		maxim = Math.abs(image[0][line][0]);
		for (int x = 0; x < xSize; x++) {
			value = Math.abs(image[0][line][x]);
			if (value > maxim ) maxim = value;
		}
		return ((int)Math.pow(2,(int)(Math.log(maxim)/Math.log(2))));
	}
	/**
	 * Initializes the lists LIS and LIC for the three dimensional SPIHT algorithm.
	 * @return void
	 */
	protected void listInitialize() {
		for (int x = 0; x < limitResidualBandX; x++) {
			LIC.addElement(x);
			if (isParent(x)) LIS.addElement(x, TYPE_A);
		}
	}
	/**
	 * Calculates the Square Error distortion metric from an integer one dimensional vector image.
	 * @param source the original vector
	 * @param recovered the recovered vector
	 * @return the Square Error
	 */
	protected long computeSquareError(int[] source, int[] recovered) {
		int xSize = source.length;
		
		long squareError, value;
		
		squareError = 0;
		for (int x = 0; x < xSize; x++) {
			value = source[x] - recovered[x];
			squareError += value * value;
		}
		return squareError;
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               GET METHODS                                  /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * Returns the square errors calculated by the rate distortion methods.
	 * @return the square errors for each step in the spiht coding algorithm
	 */
	public long[][] getTable() {
		return table;
	}
	/**
	 * Returns the point in the bit stream where each sorting or refinement step begins and ends.
	 * @return a long vector with the beginning and the end in the bit stream for each step in the spiht coding process
	 */
	public long[][] getAccessPoints() {
		return accessPoints;
	}
}//SPIHT 1D Coding algorithm
