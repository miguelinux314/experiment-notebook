package Spiht.SpihtCoding;

import java.io.*;
import Spiht.Spiht;
import List.SpihtLinkedList;
import GiciBitStream.BitOutputStream;

/** An implementation of 3D SPIHT coding algorithm. <p>
  * @author González-Conejero, Jorge
  * @version 1.0 04/02/2004
  */ 
public class SpihtCoding3D extends Spiht {
	/**
	 * The coded output stream.
	 * <p>
	 * Only an output stream is allowed.
	 */
	protected BitOutputStream bos = null;
	
	/** Creates an instance of the algorithm, dummy constructor.
	  */
	public SpihtCoding3D () {}
	
	/** Creates an instance of the algorithm. Initialize the attributes from the object.
	  * @param image array that contains the values to code.
	  * @param imagePerformance the image attributes.
	  * @param bos the output stream.
	  * @param method the current method.<br>
	  *        <ul>
	  *          <li> 0 - Original method
	  *          <li> 1 - JPEG2K method
	  *        </ul>
	  */
	
	public SpihtCoding3D(int[][][] image, int levels, String fname, boolean rateTarget, long target) throws IOException{
		// We instance the object
		
		FileOutputStream fos = new FileOutputStream(fname);
		bos = new BitOutputStream(fos);
		
		method = 0;
		
		// Image attributes
		this.zSize = image.length;
		this.ySize = image[0].length;
		this.xSize = image[0][0].length;
		
		this.levels = levels;
		//this.maxThreshold = initialTh(image);
		
		bos.writeUBits(xSize,16);
		bos.writeUBits(ySize,16);
		bos.writeUBits(zSize,16);
		bos.writeUBits(levels,4);
		bos.writeUBits(method,1);
		
		
		// We calculte the subband limits
		limitResidualBandX = xSize / (int) Math.pow(2, (levels));
		limitResidualBandY = ySize / (int) Math.pow(2, (levels));
		limitResidualBandZ = zSize / (int) Math.pow(2, (levels));
		limitParentX = xSize / 2;
		limitParentY = ySize / 2;
		limitParentZ = zSize / 2;
		limitGrandParentX = xSize / 4;
		limitGrandParentY = ySize / 4;
		limitGrandParentZ = zSize / 4;
		
		this.image = image;
	}
	
	public void openOutputBitstream(String outFileName, long target) throws IOException {
		FileOutputStream fos = new FileOutputStream(outFileName);
		bos = new BitOutputStream(fos, target);
	}
	public void writeInitialHeader() throws IOException {
		
		if(bos == null) throw new IOException("The output bitstream is closed. Initial header is not written.");
		
		bos.writeUBits(xSize,16);
		bos.writeUBits(ySize,16);
		bos.writeUBits(zSize,16);
		bos.writeUBits(levels,4);
		bos.writeUBits(method,1);
	}
	public void calculateSubbandLimits() throws Exception {
		
		if(xSize == 0 || ySize == 0 || zSize == 0) throw new Exception("The sizes of the image is not correct");
		if(levels == 0) throw new Exception("The number of levels of the image is not correct");
		
		limitResidualBandX = xSize / (int) Math.pow(2, levels);
		limitResidualBandY = ySize / (int) Math.pow(2, levels);
		limitResidualBandZ = zSize / (int) Math.pow(2, levels);
		limitParentX = xSize / 2;
		limitParentY = ySize / 2;
		limitParentZ = zSize / 2;
		limitGrandParentX = xSize / 4;
		limitGrandParentY = ySize / 4;
		limitGrandParentZ = zSize / 4;
	}

	/**
	 * Applies the SPIHT 3D coding algorithm, doing the output to the <code>MultiOutputStream</code>.
	 * @param minThreshold the minimum threshold to code.
	 * @return void
	 */
	public void codeRated(int minThreshold) throws IOException{
		int positionInLSC = 0;
		
		// We initialize the LIC and the LIS
		LIC = new SpihtLinkedList();
		LSC = new SpihtLinkedList();
		LIS = new SpihtLinkedList(); 
		
		listInitialize();
		
		maxThreshold = initialTh(image);
		bos.writeUBits((int) (Math.log(maxThreshold)/Math.log(2)),4);
		
		while(maxThreshold > minThreshold) {
			// Sorting step
			positionInLSC = LSC.size();
			try {
				sort(maxThreshold);
				// Refinement step
				if(positionInLSC != 0)
					refinement(maxThreshold, positionInLSC);
				maxThreshold >>= 1;
			} catch (IOException e) {
				bos.close();
				System.out.println(e.getMessage());
				System.exit(1);
			}
		} //while

		/*while(maxThreshold > minThreshold) {
			System.out.println("Coding: " + maxThreshold);
			
			// Refinement step
			refinement(maxThreshold << 1,positionInLSC);
			
			// Sorting step
			positionInLSC = LSC.size();
			sort(maxThreshold);
			
			maxThreshold >>= 1;
		} //while
		
		//the last refinement stage in the algorithm
		if (maxThreshold == 0) refinement(1,positionInLSC);*/
		
		//Close the output stream
		bos.close();
	} //code
	
	/**
	 * It realizes the sorting step of the SPIHT 3D coding algorithm
	 * @param actualThreshold the current threshold
	 * @return void
	 */
	protected void sort(int actualThreshold) throws IOException {
		int value,size;
		boolean end;
		int write;
		
		write = 0;
		// For each (i,j) LIC
		System.out.println("Sorting Stage: " + actualThreshold);
		
		LIC.initialNode();
		
		size = LIC.size();
		for(int i=0;i<size;i++){
			value = getSample(LIC.getX(),LIC.getY(),LIC.getZ());
			// Asks for a significant sample
			write++;
			if (Math.abs(value) >= actualThreshold) {
				// Outputs ONE
				bos.writeMulti(ONE);
				write++;
				LIC.moveElementAtLast(LSC);
				// Outputs the sign
				if(value < 0) {
					bos.writeMulti(NEG);
				}
				else {
					bos.writeMulti(POS);
				}
			}//if value
			else {
				LIC.nextValue();
				bos.writeMulti(ZERO);
			} //if-else
		} //for
		
		// For each (i,j) LIS
		LIS.initialNode();
		
		end = LIS.isEmpty();
		while((!end) && (LIS.size()!=0)) {
			end = LIS.isLast();
			// TYPE_A
			if (LIS.getType() == TYPE_A) {
				if (significativeDescendentXYZ(LIS.getX(),LIS.getY(),LIS.getZ(),true)){
					bos.writeMulti(ONE);
					write++;
					int []childCoordinate = new int[3];
					
					int x = LIS.getX();
					int y = LIS.getY();
					int z = LIS.getZ();
					for (int j=1;j<=8;j++) {
						childCoordinate = children(x,y,z,j);
						value = getSample(childCoordinate[0],childCoordinate[1],childCoordinate[2]);
						if (Math.abs(value) >= actualThreshold) {
							//outputs ONE
							bos.writeMulti(ONE);
							write++;
							LSC.addElement(childCoordinate[0],childCoordinate[1],childCoordinate[2]);
							//outputs the sign
							if(value < 0) {
								bos.writeMulti(NEG);
							}
							else {
								bos.writeMulti(POS);
							}
							write++;
						} else {
							LIC.addElement(childCoordinate[0],childCoordinate[1],childCoordinate[2]);
							bos.writeMulti(ZERO);
							write++;
						} //if-else
					}//for j
					if (isGrandParent(LIS.getX(),LIS.getY(),LIS.getZ())) {
						// method 1 JPEG2000
						if (method == 1) {
							LIS.setType(TYPE_B);
							LIS.moveElementAtLast(LIS);
							end = false;
						}
						else if (method == 0) {
							// method 0 Orginal
							if (significativeDescendentXYZ(LIS.getX(),LIS.getY(),LIS.getZ(),false)){
								bos.writeMulti(ONE);
								write++;
								x = LIS.getX();
								y = LIS.getY();
								z = LIS.getZ();
								for (int j=1;j<=8;j++) {
									childCoordinate = children(x,y,z,j);
									LIS.addElement(childCoordinate[0],childCoordinate[1],childCoordinate[2],TYPE_A);
									end = false;
								}
								LIS.remove();
							}
							else {
								bos.writeMulti(ZERO);
								write++;
								LIS.setType(TYPE_B);
								LIS.moveElementAtLast(LIS);
								end = false;
								
							}
						}
					}//if GrandParent
					else {
						LIS.remove();
					}
				}//if significativeDescendents
				else {
					bos.writeMulti(ZERO);
					write++;
					LIS.nextValue();
				}
			}
			// TYPE_B
			else {
				if (significativeDescendentXYZ(LIS.getX(),LIS.getY(),LIS.getZ(),false)){
					bos.writeMulti(ONE);
					write++;
					int [] childCoordinate = new int[3];
					int x,y,z;
					
					x = LIS.getX();
					y = LIS.getY();
					z = LIS.getZ();
					for (int j=1;j<=8;j++) {
						childCoordinate = children(x,y,z,j);
						LIS.addElement(childCoordinate[0],childCoordinate[1],childCoordinate[2],TYPE_A);
						end = false;
					}
					LIS.remove();
				}
				else {
					bos.writeMulti(ZERO);
					write++;
					LIS.nextValue();
				}
			}
		} //while
		System.out.println("Simbolos escritos: " + write);
	} //sort
	/**
	 * Refinement stage. Outputs finer detail to which interval belong already sent samples.
	 * @param actualThreshold the current threshold
	 * @param positionInLSC marks the top position in LSC for the refinement stage
	 * @return void
	 */
	protected void refinement(int actualThreshold, int positionInLSC) throws IOException{
		int value;
		int precissionPoint;
		int write;
		
		write = 0;
		LSC.initialNode();
		for(int i=0;i<positionInLSC;i++) {
			if(i==0) System.out.println("Refinement Stage: " + actualThreshold);
			value = Math.abs(getSample(LSC.getX(),LSC.getY(),LSC.getZ()));
			if( (actualThreshold & value) != 0) precissionPoint = ONE;
			else precissionPoint = ZERO;
			write++;
			bos.writeMulti(precissionPoint);
			LSC.nextValue();
		} //for
		System.out.println("Simbolos escritos de refinamiento: " + write);
	} //refinement
	
	/**
	 * Outputs if any descendents of a specified postion are significative
	 * @param x the x coordinate.
	 * @param y the y coordinate.
	 * @param z the z coordinate
	 * @param childs it determines if we have to scan the childs to determine if it has significative descendents.
	 * @return true if the specific position (x,y,z) has significative descendents, false otherwise
	 */
	protected boolean significativeDescendentXYZ(int x, int y, int z, boolean childs) {
		 int[] childCoordinate1,childCoordinate2,childCoordinate3,childCoordinate4;
		 int[] childCoordinate5,childCoordinate6,childCoordinate7,childCoordinate8;
		 childCoordinate1 = new int[3];
		 childCoordinate2 = new int[3];
		 childCoordinate3 = new int[3];
		 childCoordinate4 = new int[3];
		 childCoordinate5 = new int[3];
		 childCoordinate6 = new int[3];
		 childCoordinate7 = new int[3];
		 childCoordinate8 = new int[3];
		 
		 if (isParent(x,y,z)) {
			childCoordinate1=children(x,y,z,1);
			childCoordinate2=children(x,y,z,2);
			childCoordinate3=children(x,y,z,3);
			childCoordinate4=children(x,y,z,4);
			childCoordinate5=children(x,y,z,5);
			childCoordinate6=children(x,y,z,6);
			childCoordinate7=children(x,y,z,7);
			childCoordinate8=children(x,y,z,8);
			if (childs) {
				if (Math.abs(getSample(childCoordinate1[0],childCoordinate1[1],childCoordinate1[2]))>=maxThreshold) {
					return true;
				}
				
				if (Math.abs(getSample(childCoordinate2[0],childCoordinate2[1],childCoordinate2[2]))>=maxThreshold) {
					return true;
				}
				
				if (Math.abs(getSample(childCoordinate3[0],childCoordinate3[1],childCoordinate3[2]))>=maxThreshold) {
					return true;
				}
				
				if (Math.abs(getSample(childCoordinate4[0],childCoordinate4[1],childCoordinate4[2]))>=maxThreshold) {
					return true;
				}
				if (Math.abs(getSample(childCoordinate5[0],childCoordinate5[1],childCoordinate5[2]))>=maxThreshold) {
					return true;
				}
				
				if (Math.abs(getSample(childCoordinate6[0],childCoordinate6[1],childCoordinate6[2]))>=maxThreshold) {
					return true;
				}
				
				if (Math.abs(getSample(childCoordinate7[0],childCoordinate7[1],childCoordinate7[2]))>=maxThreshold) {
					return true;
				}
				
				if (Math.abs(getSample(childCoordinate8[0],childCoordinate8[1],childCoordinate8[2]))>=maxThreshold) {
					return true;
				}
			}
			if (significativeDescendentXYZ(childCoordinate1[0],childCoordinate1[1],childCoordinate1[2],true)) return true;
			if (significativeDescendentXYZ(childCoordinate2[0],childCoordinate2[1],childCoordinate2[2],true)) return true;
			if (significativeDescendentXYZ(childCoordinate3[0],childCoordinate3[1],childCoordinate3[2],true)) return true;
			if (significativeDescendentXYZ(childCoordinate4[0],childCoordinate4[1],childCoordinate4[2],true)) return true;
			if (significativeDescendentXYZ(childCoordinate5[0],childCoordinate5[1],childCoordinate5[2],true)) return true;
			if (significativeDescendentXYZ(childCoordinate6[0],childCoordinate6[1],childCoordinate6[2],true)) return true;
			if (significativeDescendentXYZ(childCoordinate7[0],childCoordinate7[1],childCoordinate7[2],true)) return true;
			if (significativeDescendentXYZ(childCoordinate8[0],childCoordinate8[1],childCoordinate8[2],true)) return true;
		 }
		 return false;
	}
	/**
	 * Finds the maximum threshold from the input image.
	 * @param image the input image
	 * @return the maximum threshold
	 */
	protected int initialTh(int[][][] image) {
		int maxim = Math.abs(image[0][0][0]);
		int value = 0;
		for (int z = 0; z < zSize; z++) {
			for (int y = 0; y < ySize; y++) {
				for (int x = 0; x < xSize; x++) {
					value = Math.abs(image[z][y][x]);
					if (value > maxim ) maxim = value;
				}
			}
		}
		return ((int)Math.pow(2,(int)(Math.log(maxim)/Math.log(2))));
	}
	/**
	 * Initializes the lists LIS and LIC for the three dimensional SPIHT algorithm.
	 * @return void
	 */
	protected void listInitialize() {
		for (int x = 0; x < limitResidualBandX; x++) {
			for (int y = 0; y < limitResidualBandY; y++) {
				for (int z = 0; z < limitResidualBandZ; z++) {
						LIC.addElement(x,0,0);
						if (isParent(x,y,z)) LIS.addElement(x, y, z, TYPE_A);
					}
				}
			}
	}
}//SPIHT 3D Coding
