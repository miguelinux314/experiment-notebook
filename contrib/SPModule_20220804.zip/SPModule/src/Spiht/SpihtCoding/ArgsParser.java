package Spiht.SpihtCoding;


/**
 * Arguments parser for Spiht coder. This class analyses a string of arguments and extract and check its validity.
 * Usage example:<br>
 * &nbsp; construct<br>
 * &nbsp; [showArgsInfo]<br>
 * &nbsp; [get functions]<br>
 *
 * @author WaveGis Project
 * @version 1.0
 */
public class ArgsParser{

	/**
	 * Arguments specificiation. The array describes argument, explain what is used and its default parameters. First index of array is argument; second specifies:<br>
	 *   <ul>
	 *     <li> 0 - short argument specification (i.e. "-b")
	 *     <li> 1 - long argument specification (i.e. "--blockSize")
	 *     <li> 2 - parsing specification of argument ({} indicates mandatority, [] optionality)
	 *     <li> 3 - default values
	 *     <li> 4 - mandatory argument ("1") or non mandatory argument ("0")
	 *     <li> 5 - explanation
	 *   </ul>
	 * <p>
	 * String arguments.
	 */
	String[][] argsSpecification = {
		{"-h", "--help", "", "", "0",
			"Displays this help and exits program."
		},
		{"-i", "--inputImage", "{string}", "", "1",
			"Input image. Valid formats are: pgm, ppm, pbm, jpg, tiff, png, bmp, gif, fpx. If image is raw data file extension must be \".raw\" and \"-g\" parameter is mandatory."
		},
		{"-g", "--imageGeometry", "{int int int int boolean}", "", "0",
			"Geometry of raw image data. Parameters are:\n    1- zSize (number of image components)\n    2- ySize (image height)\n    3- xSize (image width)\n    4- data type. Possible values are:\n      0- boolean (1 byte)\n      1- unsigned int (1 byte)\n      2- unsigned int (2 bytes)\n      3- signed int (2 bytes)\n      4- signed int (4 bytes)\n      5- signed int (8 bytes)\n      6- float (4 bytes)\n      7- double (8 bytes)\n    5- Byte order (0 if BIG ENDIAN, 1 if LITTLE ENDIAN)\n    6- 1 if 3 first components are RGB, 0 otherwise\nLoading process can be checked by \"-v 0 1 0\" parameter (see detailed explanation above)."
		},
		{"-w", "--WTType", "{int[ int[ int[ ...]]]}", "3", "0",
			"Discrete wavelet transform type for each image component. First value is for the first component, second value for the second component and so on. If only one value is specified, wavelete transform type will be the same for all components. Valid values are:\n 0 -  No wavelet transform \n 1 - Integer (Reversible) 5/3 DWT \n 2 - Real Isorange (irreversible) 9/7 DWT\n 3 - Real Isonorm (irreversible) 9/7 DWT\n 4 - Integer (Reversible) 9/7M DWT (CCSDS-Recommended) \n 5 - Integer 5/3 DWT (classic construction) \n 6 - Integer 9/7 DWT (classic construction)"
		},
		{"-wl", "--waveletTransformLevels", "{int[ int[ int[ ...]]]}", "5", "1",
			"Discrete wavelet transform levels for each image component. First value is for the first component, second value for the second component and so on. If only one value is specified, wavelete transform levels will be the same for all components."
		},
		{"-dim", "--dimension", "{int}", "", "1",
			"Number of dimensions for the SPIHT algorithm. "
		},
		{"-r", "--rateDistortion", "{string}", "", "0",
			"Rate Distortion algorithm. Valid names are: rd1tp, rd2tp, rdch."
		},
		{"-m", "--method", "{int}", "0", "0",
			"The version of the SPIHT algorithm to use. 0 is the original version, 1 is the JPEG2k book version"
		},
		{"-t", "--target", "{long}", "0", "0",
			"The rate target for the output SPIHT bitstream file. If the value is 0 the argument is omited."
		},
		{"-b", "--building", "", "false", "0",
			"Flag for the building rate strategy."
		},
		{"-inter", "--interleaved", "", "false", "0",
			"Flag for the interleaved rate strategy."
		},
		{"-f", "--file", "{string}", "./workDir/default.coded", "0",
			"The input/output file to read/write the SPIHT algorithm bitstream."
		},
		{"-ie", "--imageExtension", "{int}", "1", "0",
			"Extends the input image to the correct dimensions for the SPIHT algorithm. Valid values are:\n    0- Repeats the last pixel\n     1- Symmetric extension\n     2- No extension\n"
		},
		{"-qt", "--quantizationType", "{int}", "1", "0",
			"Quantization type, valid values are:\n    0- Truncation\n    1- Round."
		}

	};

	//ARGUMENTS VARIABLES
	String imageFile;
	String rateDistortion;
	String fileName = "./workDir/default.coded";
	int dimension = 0;
	int method = 0;
	long target = 0;
	int imageExtension = 1;
	int QType = 1;
	boolean finalDistortion = false;
	boolean building = false;
	boolean interleaved = false;
	int[] imageGeometry = null;
	int[] WTTypes = new int[1];
	int[] WTLevels = new int[1];

	/**
	 * Class constructor that receives the arguments string and initializes all the arguments.
	 *
	 * @param args the array of strings passed at the command line
	 */
	public ArgsParser(String[] args) throws Exception{
		int argNum = 0;
		boolean[] argsFound = new boolean[argsSpecification.length];

		//Default values
		WTLevels[0] = 5;
		WTTypes[0] = 3;

		//Arguments parsing
		for(int i = 0; i < argsSpecification.length; i++){
			argsFound[i] = false;
		}
		while(argNum < args.length){
			int argFound = argFind(args[argNum]);
			// The parameter is correct
			if(argFound != -1){
				//The parameter is duplicate
				if(!argsFound[argFound]){
					argsFound[argFound] = true;
					int argOptions = argNum + 1;
					//How many arguments the parameter has
					while(argOptions < args.length){
						if(argFind(args[argOptions]) != -1){
							break;
						}else{
							argOptions++;
						}
					}
					int numOptions = argOptions - argNum;
					String[] options = new String[numOptions];
					System.arraycopy(args, argNum, options, 0, numOptions);
					argNum = argOptions;
					switch(argFound){
					case  0: //-h  --help
						showArgsInfo();
						System.exit(1);
						break;
					case  1: //-i  --inputImage
						imageFile = parseString(options);
						if(imageFile.endsWith(".raw")){
							argsSpecification[2][4] = "1";
						}
						break;
					case  2: //-g  --imageGeometry
						imageGeometry = parseIntegerArray(options, 6);
						break;
					case  3: //-w  --waveletTransformType
						WTTypes = parseIntegerArray(options);
						break;
					case  4: //-wl --waveletTransformLevels
						WTLevels = parseIntegerArray(options);
						break;
					case  5: //-dim --dimension
						dimension = parseIntegerPositive(options);
						break;
					case  6: //-r --rateDistortion
						rateDistortion = parseString(options);
						break;
					case  7: //-m --method
						method = parseIntegerPositive(options);
						break;
					case  8: //-t --target
						target = parseIntegerPositive(options);
						break;
					case  9: //-b --building
						building = true;
						break;
					case  10: //-inter --interleaved
						interleaved = true;
						break;
					case  11: //-f --file
						fileName = parseString(options);
						break;
					case  12: //-ie --imageExtesion
						imageExtension = parseIntegerPositive(options);
						break;
					case  13: //-qt --quantizationType
						QType = parseIntegerPositive(options);
						break;
					default:
					    throw new Exception("OPTION NOT AVAIBLE");
					}
					
				}else{
					throw new Exception("Argument \"" + args[argNum] + "\" repeated.");
				}
			}else{
				throw new Exception("Argument \"" + args[argNum] + "\" unrecognized.");
			}
		}

		//Check mandatory arguments
		for(int i = 0; i < argsSpecification.length; i++){
			if(argsSpecification[i][4].compareTo("1") == 0){
				if(!argsFound[i]){
					throw new Exception("Argument \"" + argsSpecification[i][0] + "\" is mandatory (\"-h\" displays help).");
				}
			}
		}
	}

	/**
	 * Finds the argument string in arguments specification array.
	 *
	 * @param arg argument to find out in argsSpecification
	 * @return the argument index of argsSpecification (-1 if it doesn't exist)
	 */
	int argFind(String arg){
		int argFound = 0;
		boolean found = false;

		while((argFound < argsSpecification.length) && !found){
			if((arg.compareTo(argsSpecification[argFound][0]) == 0) || (arg.compareTo(argsSpecification[argFound][1]) == 0)){
				found = true;
			}else{
				argFound++;
			}
		}
		return(found ? argFound: -1);
	}

	/**
	 * This function shows arguments information to console.
	 */
	public void showArgsInfo(){
		System.out.println("Arguments specification: ");
		for(int numArg = 0; numArg < argsSpecification.length; numArg++){
			char beginMandatory = '{', endMandatory = '}';
			if(argsSpecification[numArg][4].compareTo("0") == 0){
				//No mandatory argument
				beginMandatory = '[';
				endMandatory = ']';
			}
			System.out.print("\n" + beginMandatory + " ");
			System.out.print("{" + argsSpecification[numArg][0] + "|" + argsSpecification[numArg][1] + "} " + argsSpecification[numArg][2]);
			System.out.println(" " + endMandatory);
			System.out.println("  Explanation:\n    " + argsSpecification[numArg][5]);
			System.out.println("  Default value: " + argsSpecification[numArg][3]);
		}
	}


	/////////////////////
	//PARSING FUNCTIONS//
	/////////////////////
	//These functions receives a string array that contains in its first position the argument and then its options//

	int parseIntegerPositive(String[] options) throws Exception{
		int value = 0;

		if(options.length == 2){
			try{
				value = Integer.parseInt(options[1]);
				if(value < 0){
					throw new Exception("\"" + options[1] + "\" of argument \"" + options[0] + "\" is must be a positive integer.");
				}
			}catch(NumberFormatException e){
				throw new Exception("\"" + options[1] + "\" of argument \"" + options[0] + "\" is not a parsable integer.");
			}
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes one option. Try \"-h\" to display help.");
		}
		return(value);
	}

	float parseFloatPositive(String[] options) throws Exception{
		float value = 0F;

		if(options.length == 2){
			try{
				value = Float.parseFloat(options[1]);
				if(value < 0){
					throw new Exception("\"" + options[1] + "\" of argument \"" + options[0] + "\" is must be a positive float.");
				}
			}catch(NumberFormatException e){
				throw new Exception("\"" + options[1] + "\" of argument \"" + options[0] + "\" is not a parsable float.");
			}
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes one option. Try \"-h\" to display help.");
		}
		return(value);
	}

	String parseString(String[] options) throws Exception{
		String value = "";

		if(options.length == 2){
			value = options[1];
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes one option. Try \"-h\" to display help.");
		}
		return(value);
	}

	int[] parseIntegerArray(String[] options) throws Exception{
		int[] value = null;

		if(options.length >= 2){
			value = new int[options.length - 1];
			for(int numOption = 1; numOption < options.length; numOption++){
				try{
						value[numOption - 1] = Integer.parseInt(options[numOption]);
				}catch(NumberFormatException e){
					throw new Exception("\"" + options[numOption] + "\" of argument \"" + options[0] + "\" is not a parsable integer.");
				}
			}
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes one or more options. Try \"-h\" to display help.");
		}
		return(value);
	}

	int[] parseIntegerArray(String[] options, int numOptions) throws Exception{
		int[] value = null;

		if(options.length == numOptions+1){
			value = new int[options.length - 1];
			for(int numOption = 1; numOption < options.length; numOption++){
				try{
						value[numOption - 1] = Integer.parseInt(options[numOption]);
				}catch(NumberFormatException e){
					throw new Exception("\"" + options[numOption] + "\" of argument \"" + options[0] + "\" is not a parsable integer.");
				}
			}
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes " + numOptions +" options. Try \"-h\" to display help.");
		}
		return(value);
	}

	float[] parseFloatArray(String[] options) throws Exception{
		float[] value = null;

		if(options.length >= 2){
			value = new float[options.length - 1];
			for(int numOption = 1; numOption < options.length; numOption++){
				try{
						value[numOption - 1] = Float.parseFloat(options[numOption]);
				}catch(NumberFormatException e){
					throw new Exception("\"" + options[numOption] + "\" of argument \"" + options[0] + "\" is not a parsable float.");
				}
			}
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes one or more options. Try \"-h\" to display help.");
		}
		return(value);
	}

	float[] parseFloatArray(String[] options, int numOptions) throws Exception{
		float[] value = null;

		if(options.length == numOptions+1){
			value = new float[options.length - 1];
			for(int numOption = 1; numOption < options.length; numOption++){
				try{
						value[numOption - 1] = Float.parseFloat(options[numOption]);
				}catch(NumberFormatException e){
					throw new Exception("\"" + options[numOption] + "\" of argument \"" + options[0] + "\" is not a parsable float.");
				}
			}
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes " + numOptions + " options. Try \"-h\" to display help.");
		}
		return(value);
	}


	///////////////////////////
	//ARGUMENTS GET FUNCTIONS//
	///////////////////////////

	public String getImageFile(){
		return(imageFile);
	}
	public int[] getImageGeometry(){
		return(imageGeometry);
	}
	public int[] getWTTypes(){
		return(WTTypes);
	}
	public int[] getWTLevels(){
		return(WTLevels);
	}
	public int getDimension(){
		return(dimension);
	}
	public String getRateDistortion(){
		return(rateDistortion);
	}
	public boolean getFinalDistortion(){
		return(finalDistortion);
	}
	public int getMethod(){
		return(method);
	}
	public long getTarget(){
		return(target);
	}
	public boolean getBuilding(){
		return(building);
	}
	public boolean getInterleaved(){
		return(interleaved);
	}
	public String getFileName(){
		return(fileName);
	}
	public int getImageExtension(){
		return(imageExtension);
	}
	public int getQType(){
		return(QType);
	}

}

