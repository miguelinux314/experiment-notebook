package Spiht;

import Spiht.SpihtCoding.*;
import GiciFile.LoadFile;
import GiciImageExtension.*;
import GiciTransform.*;
import BitAllocation.*;

/**
 * Main class of the SpihtCode application.
 * <p>
 * 
 *
 * @author WaveGIS Project
 * @version 0.1
 */
public class SpihtCode {
	/**
	 * Main method of SpihtCode application. It takes program arguments, loads image and runs Spiht coder.
	 *
	 * @param args an array of strings that contains program parameters
	 */
	public static void main(String[] args){
		ArgsParser arguments = null;
		
		try {
			arguments = new ArgsParser(args);
		} catch (Exception e) {
			System.out.println("ARGUMENTS ERROR: " + e.getMessage());
			System.exit(1);
		}
		
		// Image Load
		String imageFile = arguments.getImageFile();
		LoadFile image = null;
		int zSize = 1;
		try{
			if(imageFile.endsWith(".raw")){
				int[] imageGeometry = arguments.getImageGeometry();
				zSize = imageGeometry[0];
				
				//Check parameters of image geometry
				//Check parameters of image geometry
				if((imageGeometry[0] <= 0) || (imageGeometry[1] <= 0) || (imageGeometry[2] <= 0)){
					throw new Exception("Image dimensions in \".raw\" data files must be positive (\"-h\" displays help).");
				}
				if((imageGeometry[3] < 0) || (imageGeometry[3] > 7)){
					throw new Exception("Image type in \".raw\" data must be between 0 to 7 (\"-h\" displays help).");
				}
				if((imageGeometry[4] != 0) && (imageGeometry[4] != 1)){
					throw new Exception("Image Endian specification in \".raw\" data must be between 0 or 1 (\"-h\" displays help).");
				}
				if((imageGeometry[5] != 0) && (imageGeometry[5] != 1)){
					throw new Exception("Image RGB specification in \".raw\" data must be between 0 or 1 (\"-h\" displays help).");
				}
				image = new LoadFile(imageFile, imageGeometry[0], imageGeometry[1], imageGeometry[2], imageGeometry[3], imageGeometry[4],imageGeometry[5] == 0 ? false: true);
			}else{
				image = new LoadFile(imageFile);
			}
		}catch(Exception e){
			System.err.println("IMAGE LOADING ERROR: " + e.getMessage());
			System.exit(2);
		}
		
		//Get arguments
		int method = arguments.getMethod();
		int dimension = arguments.getDimension();
		int imageExtension = arguments.getImageExtension();
		int QType = arguments.getQType();
		long target = arguments.getTarget();
		String fileName = arguments.getFileName();
		int[] WTTypes = arguments.getWTTypes();
		int[] WTLevels = arguments.getWTLevels();
		int[] WTOrder = new int[1];
		float[][][] imageSamplesFloat = image.getImage();
		
		image = null;
		zSize = imageSamplesFloat.length;

		//IMAGE EXTENSION
		try{
			ImageExtension ie = new ImageExtension(imageSamplesFloat);
			int[] imageExtensionType = new int[zSize];
			int[] WTLevelsExtension = new int[zSize];
			
			for(int z = 0; z < zSize; z++){
				imageExtensionType[z] = imageExtension;
				WTLevelsExtension[z] = WTLevels[0] + 1;
			}
			ie.setParameters(imageExtensionType, WTLevelsExtension);
			imageSamplesFloat = ie.run();
		} catch (Exception e) {
			System.out.println("IMAGE EXTENSION FAILED: " + e.getMessage());
			e.printStackTrace();
			System.exit(3);
		}

		//DISCRETE WAVELET TRANSFORM
		float[][][] imageSamples = null;
		WTOrder[0] = 2;
		
		try {
			ForwardWaveletTransform wt = new ForwardWaveletTransform(imageSamplesFloat);
			if(dimension == 1) wt.setParameters(WTTypes, WTLevels, WTOrder);
			else {
				if(zSize > 1) {
					int Type = WTTypes[0];
					int NumberOfLevels = WTLevels[0];
					WTLevels = new int[zSize];
					WTTypes = new int[zSize];
					for(int i=0; i< zSize; i++) {
						WTTypes[i] = Type;
						WTLevels[i] = NumberOfLevels;
					}
				}
				wt.setParameters(WTTypes, WTLevels);
			}
			imageSamples = wt.run();
		} catch (Exception e) {
			System.out.println("DISCRETE WAVELET TRANSFORM FAILED: " + e.getMessage());
			System.exit(3);
		}
		
		//Coder
		System.out.println(dimension + "D Execution");
		
		Spiht spc = null;
		
		//OBJECT INSTANCE
		try {
			if(dimension == 1) 
				spc = new SpihtCoding1D();
			else if(dimension == 2) 
				spc = new SpihtCoding2D();
			else if(dimension == 3) 
				spc = new SpihtCoding3D();
			else 
				throw new Exception("The dimension specified is not avaible");
		} catch (Exception e) {
			System.out.println("INSTANCE OF THE OBJECT FAILED: " + e.getMessage());
			System.exit(3);
		}
		
		//SPIHT CODING INITIALIZATION
		try {
			spc.setImage(floatToInt(imageSamples, QType));
			spc.setMethod(method);
			spc.setWTLevels(WTLevels[0]);
			spc.calculateSubbandLimits();
			spc.openOutputBitstream(fileName, target);
			spc.writeInitialHeader();
			
		} catch (Exception e) {
			System.out.println("OBJECT INITIALIZATION FAILED: " + e.getMessage());
			System.exit(3);
		}
		
		System.out.println("Codification begins");
		System.gc(); //Free imageSamples
		//CODIFICATION
		try {
			if(arguments.getBuilding()) spc.codeBuilding(0);
			else if(arguments.getInterleaved()) spc.codeInterleaved(0);
			else if(arguments.getRateDistortion() == null) { System.out.println("Code Normal"); spc.code(0);} 
			else {
				System.out.println("CodeRated");
				spc.codeRated(0);
				System.out.println("Rate process");
				SpihtBitAllocation spba = new SpihtBitAllocation(arguments.getRateDistortion());
				spba.setDimension(dimension);
				spba.setAccessPoints(spc.getAccessPoints());
				spba.setDistortionTable(spc.getTable()); 
				/*if(arguments.getTarget() != 0)
					spba.setTarget();*/
				System.out.println("Output Stream process");
				spba.generateRatedOutputStream(arguments.getFileName(), arguments.getTarget());
				spba = null;
			}
		} catch (Exception e) {
			System.out.println("CODIFICATION FAILED: " + e.getMessage());
			e.printStackTrace();
			System.exit(4);
		}
	
	}
	/**
	 * Auxiliar method from the Spiht code main class to quantize the coefficients received from the discrete wavelet transform.
	 *
	 * @param src the image with float coefficients
	 * @return the input image rounded to the nearest integer
	 */
	private static int[][][] floatToInt(float[][][] src, int QType){
		int zSize = src.length;
		int ySize = src[0].length;
		int xSize = src[0][0].length;
		
		int dst[][][] = new int[zSize][ySize][xSize];
		
		for (int z=0; z < zSize; z++) {
			for (int y=0; y < ySize; y++) {
				for (int x=0; x < xSize; x++) {
					dst[z][y][x]= Math.round(src[z][y][x]);
				}
			}
		}
		return dst;
	}
}
