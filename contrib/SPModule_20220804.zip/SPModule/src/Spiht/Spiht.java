package Spiht;

import GiciBitStream.BitOutputStream;
import List.SpihtLinkedList;


/**
 * Abstract class from the SPIHT algorithm. <p>
 * This class contains all the common methods and
 * attributes for decoding and coding algorithms. <p>
 * @see SpihtModule.io.MultiOutputStream
 * @author Jorge Gonzalez-Conejero
 * @version 1.0 04/02/2004
 * @version 1.1 21/10/04
 */
public class Spiht {
	/**
	 * Defines the symbols to write in the output stream.
	  *        <ul>
	  *          <li> ZERO - Insignificant
	  *          <li> ONE - Significant
	  *          <li> POS - Positive coefficient
	  *          <li> NEG - Negative coefficient
	  *        </ul>
	 * <p>
	 * Only the four symbols of the SPIHT algorithm are allowed
	 */
	protected final static byte ZERO = 0,
			ONE = 1,
			POS = 1,
			NEG = 0;

	/**
	 * Defines length of the initial header in the SPIHT bit stream files.
	  *        <ul>
	  *          <li> x - 16 bits
	  *          <li> y - 16 bits
	  *          <li> z - 16 bits
	  *          <li> levels - 4 bits
	  *          <li> method - 1 bit
	  *          <li> initial threshold - 4 bits
	  *        </ul>
	 * <p>
	 * Static attribute
	 */
	protected static final int xBits = 16,
			yBits = 16,
			zBits = 16,
			levelsBits = 4,
			methodBits = 1,
			thresholdBits = 4;
	/**
	 * Defines the type of the subsets in the LIS.
	 *        <ul>
	 *          <li> TYPE_A - Subset of type A in the LIS
	 *          <li> TYPE_B - Subset of type B in the LIS
	 *        </ul>
	 * <p>
	 * Only two types A or B are allowed.
	 */
	protected final static boolean  TYPE_A = false,TYPE_B = true;
	/**
	 * List of insignificant coefficients.
	 * <p>
	 * This list must contains the insignificant coefficients of the input image.
	 */
	protected SpihtLinkedList LIC = null;
	/**
	 * List of significant coefficients.
	 * <p>
	 * This list must contains the significant coefficients of the input image.
	 */
	protected SpihtLinkedList LSC = null;
	/**
	 * List of the roots that constains the subsets in the hierarchical trees.
	 * <p>
	 * This list must contains the significant coefficients of the input image.
	 */
	protected SpihtLinkedList LIS = null;

	/**
	 * Maximum threshold.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int maxThreshold = 0;
	/**
	 * Returns the current <code>threshold</code>
	 * @return current threshold
	 */
	public int getThreshold() {
		return maxThreshold;
	}
	/**
	 * Sets the current <code>threshold</code> in an object <code>.
	 * @param the new current threshold
	 */
	public void setThreshold(int maxThreshold) {
		this.maxThreshold = maxThreshold;
	}

	/**
	 * The size of the input image.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int size = 0;
	/**
	 * The number of levels that we apply in the discrete wavelet transform.
	 * <p>
	 * Negative values are not allowed. The number of levels are restricted by the image dimensions
	 */
	protected int levels = 0;
	/**
	 * Returns the current number of <code>levels</code>
	 * @return current number of levels
	 */
	public int getWTLevels() {
		   return levels;
	}
	/**
	 * Sets the current number of <code>levels</code>
	 * @param the current number of levels
	 */
	public void setWTLevels(int levels) {
		this.levels = levels;
	}

	/**
	 * Stores the method that we use on the algorithm process.
	 *        <ul>
	 *          <li> 0 - Original method
	 *          <li> 1 - JPEG2K method
	 *        </ul>
	 * <p>
	 * Only two methods are allowed.
	 */
	protected int method = 0;
	/**
	 * Returns the current <code>method</code>
	 * @return current method
	 */
	public int getMethod() {
		   return method;
	}
	/**
	 * Sets the current <code>method</code>
	 * @param current method
	 */
	public void setMethod(int method) {
		this.method = method;   
	}

	/**
	 * The image to process.
	 * <p>
	 * Only an array of integers is allowed.
	 */
	protected int[][][] image = null;
	/**
	 * Returns the image.
	 * <p>
	 * @return the image
	 */
	public int[][][] getImage() {
		   return image;
	}
	/**
	 * Sets the image.
	 * @param the new image
	 */
	public void setImage(int[][][] image) {
		this.image = null;
		this.image = image;
		
		zSize = image.length;
		ySize = image[0].length;
		xSize = image[0][0].length;
	}
	/**
	 * The width of the input image.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int xSize = 0;
	/**
	 * Returns the width of the image
	 * <p>
	 * @return the width of the image
	 */
	public int getXSize() {
		   return xSize;
	}
	/**
	 * Sets the width of the image
	 * <p>
	 * @param the width of the image
	 */
	public void setXSize(int xSize) {
		   this.xSize = xSize;
	}

	/**
	 * The height of the input image.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int ySize = 0;
	/**
	 * Returns the height of the image
	 * <p>
	 * @return the height of the image
	 */
	public int getYSize() {
		   return ySize;
	}
	/**
	 * Sets the height of the image
	 * <p>
	 * @return the height of the image
	 */
	public void setYSize(int ySize) {
		   this.ySize = ySize;
	}

	/**
	 * The number of bands of the input image.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int zSize = 0;
	/**
	 * Returns the number of bands of the image
	 * <p>
	 * @return the number of bands of the image
	 */
	public int getZSize() {
		   return zSize;
	}
	/**
	 * Sets the number of bands of the image
	 * <p>
	 * @param the number of bands of the image
	 */
	public void setZSize(int zSize) {
		   this.zSize = zSize;
	}

	/**
	 * Stores the limits of the residual subband in the X axis.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int limitResidualBandX = 1;
	/**
	 * Stores the limits of the residual subband in the Y axis.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int limitResidualBandY = 1;
	/**
	 * Stores the limits of the residual subband in the Z axis.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int limitResidualBandZ = 1;
	/**
	 * Stores the limits of the parents in the X axis
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int limitParentX = 1;
	/**
	 * Stores the limits of the parents in the Y axis
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int limitParentY = 1;
	/**
	 * Stores the limits of the parents in the Z axis
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int limitParentZ = 1;
	/**
	 * Stores the limits of the grandparents in the X axis.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int limitGrandParentX = 0;
	/**
	 * Stores the limits of the grandparents in the Y axis.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int limitGrandParentY = 0;
	/**
	 * Stores the limits of the grandparents in the Z axis.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int limitGrandParentZ = 0;
	/**
	 * This field specifies if we have a rate target to accomplish.
	 * <p>
	 * Only a boolean value is allowed.
	*/
	protected boolean rateTarget = false;
	/**
	 * Sets if the user wants to accomplish an specific rate target specified by target attribute.
	 * <p>
	 * Only a boolean value is allowed.
	*/
	public void setRateTarget(boolean rateTarget) {
		this.rateTarget = rateTarget;
	}
	/**
	 * The number of bytes for the rate target.
	 * <p>
	 * Only an integer value is allowed.
	*/
	protected long target = 0;
	/**
	 * Sets the number of bytes for the rate target.
	 * <p>
	 * Only a valid coded file dimension is allowed.
	*/
	public void setTarget(long target) {
		this.target = target;
	}
	/**
	 * Returns the limit of the lowest frequencies in the X direction
	 * <p>
	 * @return the limit of the lowest frequencies in the X direction
	 */
	public int getLimitResidualBandX() {
		   return limitResidualBandX;
	}
	/**
	 * Returns the limit of the lowest frequencies in the Y direction
	 * <p>
	 * @return the limit of the lowest frequencies in the Y direction
	 */
	public int getLimitResidualBandY() {
		   return limitResidualBandY;
	}
	/**
	 * Returns the limit of the lowest frequencies in the Z direction
	 * <p>
	 * @return the limit of the lowest frequencies in the Z direction
	 */
	public int getLimitResidualBandZ() {
		   return limitResidualBandZ;
	}
	/**
	 * Returns the limit of the parent samples in the X direction
	 * <p>
	 * @return the limit of the parent samples in the X direction
	 */
	public int getLimitParentX() {
		   return limitParentX;
	}
	/**
	 * Returns the limit of the parent samples in the Y direction
	 * <p>
	 * @return the limit of the parent samples in the Y direction
	 */
	public int getLimitParentY() {
		   return limitParentY;
	}
	/**
	 * Returns the limit of the parent samples in the Z direction
	 * <p>
	 * @return the limit of the parent samples in the Z direction
	 */
	public int getLimitParentZ() {
		   return limitParentZ;
	}
	/**
	 * Returns the limit of the grandparent samples in the X direction
	 * <p>
	 * @return the limit of the grandparent samples in the X direction
	 */
	public int getLimitGrandParentX() {
		   return limitGrandParentX;
	}
	/**
	 * Returns the limit of the grandparent samples in the Y direction
	 * <p>
	 * @return the limit of the grandparent samples in the Y direction
	 */
	public int getLimitGrandParentY() {
		   return limitGrandParentY;
	}
	/**
	 * Returns the limit of the grandparent samples in the Z direction
	 * <p>
	 * @return the limit of the grandparent samples in the Z direction
	 */
	public int getLimitGrandParentZ() {
		   return limitGrandParentZ;
	}
	/**
	 * Puts the integer specified for the user into a specific position in the image vector
	 * @param x the x position in the vector
	 * @param y the y position in the vector
	 * @param z the z position in the vector
	 * @param value the new sample
	 * @return void
	 */
	protected void setSample(int x, int y, int z, int value) {
		image[z][y][x] = value;
	}
	/**
	 * Outputs the integer sample for the specified position
	 * @param x the x coordinate.
	 * @param y the y coordinate
	 * @param z the z coordinate
	 * @return the sample in the position (x,y,z).
	 */
	protected int getSample(int x, int y, int z) {
		return (image[z][y][x]);
	}
	/**
	 * This function returns true if the pixel given is grandparent
	 * @param x the x coordinate
	 * @return true if the pixel is grandparent, false otherwise
	 **/
	protected boolean isGrandParent(int x) {
		return (x < limitGrandParentX) ;
	}
	/**
	 * This function returns true if the pixel given is grandparent
	 * @param x the x coordinate
	 * @param y the y coordinate
	 * @return true if the pixel is grandparent, false otherwise
	 **/
	protected boolean isGrandParent(int x, int y) {
		return ((x < limitGrandParentX) && (y < limitGrandParentY));
	}
	/**
	 * This function returns true if the pixel given is grandparent
	 * @param x the x coordinate
	 * @param y the y coordinate
	 * @param z the z coordinate
	 * @return true if the pixel is grandparent, false otherwise
	 **/
	protected boolean isGrandParent(int x, int y, int z) {
		return ((x < limitGrandParentX) && (y < limitGrandParentY) && (z < limitGrandParentZ));
	}
	/**
	 * Returns a specific son of the offspring of a given pixel
	 * @param x the x coordinate
	 * @return the son coordinate of a given pixel
	 */
	 protected int children(int x, int child) {
		 int childCoordinate;
		 
		 childCoordinate = 0;
		 if(x < limitResidualBandX) x = x + (limitResidualBandX - 1);
		 else x = x * 2;
		 
		switch(child) {
			case 1 : 
				childCoordinate = x;
				break;
			case 2 : 
				childCoordinate = x + 1;
				break;
		} //switch
		 return childCoordinate;
	}
	/**
	 * Returns the specified son of the offspring of a given pixel
	 * @param x the x coordinate
	 * @param y the y coordinate
	 * @return the specified son of the offspring
	 */
	protected int[] children(int x, int y, int child) {
		int [] childCoordinates;
		childCoordinates = new int[2];
		
		if((x < limitResidualBandX) && (y < limitResidualBandY)) {
			if( (x % 2) != 0 ) x = x + (limitResidualBandX - 1);
			if( (y % 2) != 0 ) y = y + (limitResidualBandY - 1);
		}
		else {
			x = x * 2;
			y = y * 2;
		}
		switch(child) {
			case 1 : 
				 childCoordinates[0] = x;
				 childCoordinates[1]= y;
				 break;
			case 2 : 
				 childCoordinates[0] = x + 1;
				 childCoordinates[1]= y;
				 break;
			case 3 : 
				 childCoordinates[0] = x;
				 childCoordinates[1]= y + 1;
				 break;
			case 4 : 
				 childCoordinates[0] = x + 1;
				 childCoordinates[1]= y + 1;
				 break;
			default:
				//throw new Exception("No children for the provided coordinates: x: " + x + " y: " + y + " " + child );
				break;
		} //switch
		return (childCoordinates);
	}
	/**
	 * Returns the specified son of the offspring of a given pixel
	 * @param x the x coordinate
	 * @param y the y coordinate
	 * @param z the z coordinate
	 * @return the specified son of the offspring
	 */
	protected int[] children(int x, int y, int z, int child) {
		int [] childCoordinates;
		childCoordinates = new int[3];
		
		if((x < limitResidualBandX) && (y < limitResidualBandY) && (z < limitResidualBandZ)) {
			if( (x % 2) != 0 ) {
				x = x + (limitResidualBandX - 1);
			}
			if( (y % 2) != 0 ) {
				y = y + (limitResidualBandY - 1);
			}
			if( (z % 2) != 0 ) {
				z = z + (limitResidualBandZ - 1);
			}
		}
		else {
			x = x * 2;
			y = y * 2;
			z = z * 2; 
		}
		switch(child) {
			case 1 : 
				 childCoordinates[0] = x;
				 childCoordinates[1]= y;
				 childCoordinates[2]= z;
				 break;
			case 2 : 
				 childCoordinates[0] = x + 1;
				 childCoordinates[1]= y;
				 childCoordinates[2]= z;
				 break;
			case 3 : 
				 childCoordinates[0] = x;
				 childCoordinates[1]= y + 1;
				 childCoordinates[2]= z;
				 break;
			case 4 : 
				 childCoordinates[0] = x + 1;
				 childCoordinates[1]= y + 1;
				 childCoordinates[2]= z;
				 break;
			case 5 :
				 childCoordinates[0] = x;
				 childCoordinates[1]= y;
				 childCoordinates[2]= z + 1;
				 break;
			case 6 : 
				 childCoordinates[0] = x + 1;
				 childCoordinates[1]= y;
				 childCoordinates[2]= z + 1 ;
				 break;
			case 7 : 
				 childCoordinates[0] = x;
				 childCoordinates[1]= y + 1;
				 childCoordinates[2]= z + 1;
				 break;
			case 8 : 
				 childCoordinates[0] = x + 1;
				 childCoordinates[1]= y + 1;
				 childCoordinates[2]= z + 1;
				 break;
		} //switch
		return (childCoordinates);
	}
	/**
	 * This function returns true if the pixel given is parent
	 * @param x the x coordinate
	 * @return true if the pixel is parent, false otherwise
	 **/
	protected boolean isParent(int x) {
		boolean res;
		
		res = true;
		if (x < limitResidualBandX) {
			if( (x % 2) == 0) res = false;
		}
		else {
			res = (x < limitParentX);
		}
		return res;
	}
	/**
	 * This function returns true if the pixel given is parent
	 * @param x the x coordinate
	 * @param y the y coordinate
	 * @return true if the pixel is parent, false otherwise
	 **/
	protected boolean isParent(int x, int y) {
		boolean res;
		
		res = true;
		if ((x < limitResidualBandX) && (y < limitResidualBandY) && ((x % 2) == 0) && ((y % 2) == 0) ) res = false;
		else res = ( (x < limitParentX) && (y < limitParentY) );
		
		return res;
	}
	/**
	 * This function returns true if the pixel given is parent
	 * @param x the x coordinate
	 * @param y the y coordinate
	 * @param z the z coordinate
	 * @return true if the pixel is parent, false otherwise
	 **/
	protected boolean isParent(int x, int y, int z) {
		boolean res;
		
		res = true;
		if ((x < limitResidualBandX) && (y < limitResidualBandY) && (z < limitResidualBandZ)) {
			if( ((x % 2) == 0) && ((y % 2) == 0) && ((z % 2) == 0) ) res = false;
		}
		else {
			res = ((x < limitParentX) && (y < limitParentY) && (z < limitParentZ));
		}
		return res;
	}
	/**
	 * Constructor of the SPIHT class
	 **/
	public Spiht() {
		
	}
	/* Overloaded methods. See method definitions in the SpihtCoding classes */
	public void codeRated(int minThreshold) throws Exception {
		
	}
	public void codeBuilding(int minThreshold) throws Exception {
		
	}
	public void codeInterleaved(int minThreshold) throws Exception {
		
	}
	
	public void code(int minThreshold) throws Exception {
	}
	
	public void decode() throws Exception {
	}
	public void decodeRated(String rateVersion) throws Exception {
	}
	public void decodeBuilding() throws Exception {
	}
	public void decodeInterleaved() throws Exception {
	}
	
	public long[][] getTable() {
		return null;
	}
	public long[][] getAccessPoints() {
		return null;
	}
	public void calculateSubbandLimits() throws Exception {
	}
	public void openOutputBitstream(String name, long target) throws Exception {
	}
	public void writeInitialHeader() throws Exception {
	}
	
}//Spiht
