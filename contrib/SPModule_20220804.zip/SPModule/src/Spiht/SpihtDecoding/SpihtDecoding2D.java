package Spiht.SpihtDecoding;

import java.io.IOException;
import java.io.FileInputStream;
import GiciBitStream.BitOutputStream;
import GiciBitStream.BitInputStream;
import Building.PlaneBuilding;
import Spiht.Spiht;
import List.SpihtLinkedList2D;

/** An implementation of SPIHT two dimensional decoding algorithm.
  * @see SpihtModule.spiht.Spiht
  * @see SpihtModule.spiht.Spiht2D
  * @see SpihtModule.spiht.SpihtCoding2D
  * @author Jorge Gonzalez-Conejero
  * @version 1.0 04/02/2004
  */ 
public class SpihtDecoding2D extends Spiht {
	/**
	 * List of insignificant coefficients.
	 * <p>
	 * This list must contains the insignificant coefficients of the input image.
	 */
	protected SpihtLinkedList2D LIC = null;
	/**
	 * List of significant coefficients.
	 * <p>
	 * This list must contains the significant coefficients of the input image.
	 */
	protected SpihtLinkedList2D LSC = null;
	/**
	 * List of the roots that constains the subsets in the hierarchical trees.
	 * <p>
	 * This list must contains the significant coefficients of the input image.
	 */
	protected SpihtLinkedList2D LIS = null;
	/**
	 * Current band in the algorithm.
	 * <p>
	 * Negative values are not allowed. It has values between 0 and zSize.
	 */
	protected int z;
	/**
	 * The coded input stream.
	 * <p>
	 * Only a binary input stream is allowed.
	 */
	protected BitInputStream bis;
	/** Number of bits that the SPIHT algorithm has read.
	  * <p>
	  * Only an integer values are allowed.
	*/
	//protected int numberReadBits;
	/** The list of the valid rate distortion methods.
	  *        <ul>
	  *          <li> rd1tp - Rate Distortion with one truncation point
	  *          <li> rd2tp - Rate Distortion with two truncation points
	  *          <li> rdch - Rate Distortion with two truncation points and the Convex-Hull algorithm
	  *        </ul>
	  * <p>
	  * Only one of these three versions are allowed.
	*/
	protected String[] ratedList = {"rd1tp","rd2tp","rdch"};
	/** Current position in the LSC list to refine.
	  * <p>
	  * Only an integer values are allowed. Field maxim value is the LSC length.
	*/
	protected int positionInLSC;
	
	/** 
	 * Creates an instance of the algorithm and initializes the object fields.
	 * @param fname the name of the input stream
	 */
	public SpihtDecoding2D(String fname) throws IOException {
		
		FileInputStream fis = new FileInputStream(fname);
		bis = new BitInputStream(fis);
		
		// We read the image performances from the file
		xSize = (int) bis.readUBits(16);
		ySize = (int) bis.readUBits(16);
		zSize = (int) bis.readUBits(16);
		levels = (int) bis.readUBits(4);
		method = (int) bis.readUBits(1);
		
		z = 0;
		size = 0;
		positionInLSC = 0;
		// We define the vector size with the image attributes
		image = new int[zSize][ySize][xSize];
		// The subband limits
		limitResidualBandX = xSize / (int) Math.pow(2, levels);
		limitResidualBandY = ySize / (int) Math.pow(2, levels);
		limitParentX = xSize / 2;
		limitParentY = ySize / 2;
		limitGrandParentX = xSize / 4;
		limitGrandParentY = ySize / 4;
	}//Constructor
	
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                            SPIHT DECODE METHODS                            /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	/** Applies the SPIHT two dimensional Decoding algorithm, doing input from the <code>MultiInputStream</code>.
	 * @return returns the recovered image
	 */
	public void decode() throws IOException {
		int minThreshold;
		int positionInLSC;
		
		minThreshold = 0;
		positionInLSC = 0;
		
		for(z = 0 ; z < zSize ; z++) {
			readThreshold();
			
			LIC = new SpihtLinkedList2D();
			LSC = new SpihtLinkedList2D();
			LIS = new SpihtLinkedList2D();
			positionInLSC = 0;
			listInitialize();
			
			try {
				while(maxThreshold > minThreshold) {
					// Sorting step
					positionInLSC = LSC.size();
					sort(maxThreshold);
					
					// Refinement step
					refinement(maxThreshold, positionInLSC);
					
					maxThreshold >>= 1;
				} //while
			} catch (IOException e) {
				bis.close();
			}
		}//for z
		bis.close();
	}//decode
	/** 
	 * Applies the SPIHT two dimensional decoding algorithm with the specified rate distortion version, 
	 * doing input from the <code>MultiInputStream</code>.
	 * @param rateVersion the version of the rate distortion algorithm to decode
	 * @return returns the recovered image
	 */
	public void decodeRated(String rateVersion) throws Exception {
		int rateMode, minThreshold, bitsBand, numPoints;
		int[] positionInLSCStored, positionInBand, maxThresholdInBand;
		boolean[] firstPositionInBand;
		SpihtLinkedList2D[] LISStored, LICStored, LSCStored;
		
		rateMode = -1;
		numPoints = 0;
		minThreshold = 0;
		
		for(int i=0;i<ratedList.length;i++) {
			if(ratedList[i].equals(rateVersion)) {
				rateMode = i;
				break;
			}
		}
		if(rateMode == -1) throw new Exception("The rate mode " + rateVersion + " is not avaible.");
		
		bitsBand = (int)Math.ceil( (Math.log(zSize) / Math.log(2)) );
		LISStored = new SpihtLinkedList2D[zSize];
		LICStored = new SpihtLinkedList2D[zSize];
		LSCStored = new SpihtLinkedList2D[zSize];
		
		LIC = new SpihtLinkedList2D();
		LSC = new SpihtLinkedList2D();
		LIS = new SpihtLinkedList2D();
		
		positionInBand = new int[zSize];
		
		listInitialize();
		
		for(int i=0;i<zSize;i++) {
			LISStored[i] = new SpihtLinkedList2D();
			LISStored[i].cloneListTyped(LIS);
			LICStored[i] = new SpihtLinkedList2D();
			LICStored[i].cloneList(LIC);
			LSCStored[i] = new SpihtLinkedList2D();
			LSCStored[i].cloneList(LSC);
		}
		positionInLSCStored = new int[zSize];
		firstPositionInBand = new boolean[zSize];
		maxThresholdInBand = new int[zSize];
		
		for(int i=0;i<zSize;i++) {
			   positionInLSCStored[i] = 0;
			   firstPositionInBand[i] = true;
			   maxThresholdInBand[i] = 0;
		}
		positionInLSC = 0;
		
		try {
			for(;;) {
				//Inicio Bucle
				z = (int) bis.readUBits(bitsBand);
				if(rateMode == 2) {
					numPoints = 1;
					while( ((int) bis.readUBits(1)) != 1) numPoints++;
				}
				
				LIS = LISStored[z];
				LIC = LICStored[z];
				LSC = LSCStored[z];
				positionInLSC = positionInLSCStored[z];
				
				if (firstPositionInBand[z]) {
					readThreshold();
					firstPositionInBand[z] = false;
				}
				else maxThreshold = maxThresholdInBand[z];
				
				if(rateMode == 0) {
					// 1 truncation points
					positionInLSC = LSC.size();
					sort(maxThreshold);
					
					if(positionInLSC != 0) refinement(maxThreshold, positionInLSC);
					positionInBand[z]++;
					
					maxThreshold >>= 1;
				} else if(rateMode == 1) {
					// 2 truncation points
					if(positionInBand[z] == 0 || (positionInBand[z] % 2 != 0) ) {
						positionInLSC = LSC.size();
						sort(maxThreshold);
						if(positionInBand[z] == 0) maxThreshold >>= 1;
					}
					else {
						if(positionInLSC != 0) refinement(maxThreshold, positionInLSC);
						maxThreshold >>= 1;
					}
					//if((positionInBand[z]!=0) && ((positionInBand[z] % 2) == 0)) decodeRefinementPass();
					//else decodeSortingPass();
					positionInBand[z]++;
				} else if(rateMode == 2) {
					//Convex Hull 2tp
					for(int i = 0 ; i < numPoints ; i++) {
						if(positionInBand[z] == 0 || (positionInBand[z] % 2 != 0) ) {
							positionInLSC = LSC.size();
							sort(maxThreshold);
							if(positionInBand[z] == 0) maxThreshold >>= 1;
						}
						else {
							if(positionInLSC != 0) refinement(maxThreshold, positionInLSC);
							maxThreshold >>= 1;
						}
						//if((positionInBand[z]!=0) && ((positionInBand[z] % 2) == 0)) decodeRefinementPass();
						//else decodeSortingPass();
						positionInBand[z]++;
					} //for
				}
				maxThresholdInBand[z] = maxThreshold;
				LISStored[z] = LIS;
				LICStored[z] = LIC;
				LSCStored[z] = LSC;
				LIS = null;
				LIC = null;
				LSC = null;
				positionInLSCStored[z] = positionInLSC;
			} //for
		} catch (IOException e) {
			   bis.close();
		}
	} //decodeRatedStream
	
	/** Applies the SPIHT two dimensional decoding algorithm with the <code>PlaneBuilding</code>rate distortion version,
	  * doing input from the <code>MultiInputStream</code>.
	  * @return returns the recovered image
	  */
	public void decodeBuilding() throws IOException {
		int originalXSize;
		int originalZSize;
		PlaneBuilding pb;
		
		// We calculte the new subband limits
		limitResidualBandX = (xSize / (int) Math.pow(2, (levels))) * zSize;
		limitParentX = (xSize / 2) * zSize;
		limitGrandParentX =(xSize / 4) * zSize;
		
		originalXSize = xSize;
		originalZSize = zSize;
		xSize = xSize * zSize;
		zSize = 1;
		
		image = new int[zSize][ySize][xSize];
		
		decode();
		
		pb = new PlaneBuilding(levels);
		image = pb.obtainOriginalImage(image, originalXSize, ySize, originalZSize);
		pb = null;
		
		//return image;
	}
	/** Applies the SPIHT two dimensional decoding algorithm with the <code>Interleaved</code>rate distortion version,
	  * doing input from the <code>MultiInputStream</code>.
	  * @return returns the recovered image
	  */
	public void decodeInterleaved() throws IOException {
		int minBPE, maxBPE, acum;
		int[] maxThresholdVector, maxThresholdPows, positionInLSCVector;
		
		SpihtLinkedList2D[] LISVector, LSCVector, LICVector;
		
		//Initializations
		positionInLSC = 0;
		acum = 0;
		maxThresholdVector = null;
		maxThresholdPows = null;
		positionInLSCVector = null;
		
		maxThresholdVector = new int[zSize];
		maxThresholdPows = new int[zSize];
		positionInLSCVector = new int[zSize];
		
		//The lists for each line in the algorithm
		LISVector = new SpihtLinkedList2D[zSize];
		LICVector = new SpihtLinkedList2D[zSize];
		LSCVector = new SpihtLinkedList2D[zSize];
		
		LIC = new SpihtLinkedList2D();
		LIS = new SpihtLinkedList2D();
		
		listInitialize();
		
		try {
			maxBPE = (int) bis.readUBits(5);
			minBPE = (int) bis.readUBits(5);
			
			for(int z = 0 ; z < zSize ; z++) {
				//BPE Header
				if(maxBPE != minBPE)
					maxThresholdPows[z] = minBPE + (int) bis.readUBits(BitOutputStream.minBits(maxBPE - minBPE));
				else
					maxThresholdPows[z] = maxBPE;
				maxThresholdVector[z] = (int) Math.pow(2,maxThresholdPows[z]);
				
				//The initialization of lists
				LISVector[z] = new SpihtLinkedList2D();
				(LISVector[z]).cloneListTyped(LIS);
				LICVector[z] = new SpihtLinkedList2D();
				(LICVector[z]).cloneList(LIC);
				LSCVector[z] = new SpihtLinkedList2D();
			}//for
			LIS = null;
			LIC = null;
			
			while(maxBPE != minBPE) {
				for(z = 0 ; z < zSize ; z++) {
					if(maxThresholdPows[z] > minBPE) {
						//Step initialization
						LIS = LISVector[z];
						LIC = LICVector[z];
						LSC = LSCVector[z];
						maxThreshold = maxThresholdVector[z];
						positionInLSC = positionInLSCVector[z];
						
						// Sorting step
						positionInLSC = LSC.size();
						sort(maxThreshold);
						
						// Refinement step
						if(positionInLSC != 0) refinement(maxThreshold, positionInLSC);
						
						//New parameters store
						maxThresholdVector[z] = maxThreshold >> 1;
						positionInLSCVector[z] = positionInLSC;
						maxThresholdPows[z]--;
						LISVector[z] = LIS;
						LICVector[z] = LIC;
						LSCVector[z] = LSC;
						LIS = null;
						LSC = null;
						LIC = null;
					}//if
				}//for
				maxBPE--;
			}//while
			
			maxThresholdPows = null;
			maxThreshold = 1;
			
			while(maxThreshold != 0) {
				for(z = 0 ; z < zSize ; z++) {
					//Step initialization
					LIS = LISVector[z];
					LIC = LICVector[z];
					LSC = LSCVector[z];
					maxThreshold = maxThresholdVector[z];
					positionInLSC = positionInLSCVector[z];
					
					// Sorting step
					positionInLSC = LSC.size();
					sort(maxThreshold);
					
					// Refinement step
					if(positionInLSC != 0) refinement(maxThreshold, positionInLSC);
					
					maxThreshold >>= 1;
					
					//New parameters store
					maxThresholdVector[z] = maxThreshold;
					positionInLSCVector[z] = positionInLSC;
					LISVector[z] = LIS;
					LICVector[z] = LIC;
					LSCVector[z] = LSC;
					LIS = null;
					LSC = null;
					LIC = null;
				}//for
			}//while
		} catch (IOException e) {
			bis.close();
			//return image;
		}
		bis.close();
		//return image;
	}
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               SPIHT STEPS METHODS                          /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * It realizes the sorting step of the SPIHT three dimensional algorithm
	 * @param threshold current threshold
	 * @return void
	 */
	protected void sort(int threshold) throws IOException{
		int value,size,symbol,read;
		boolean end;
		
		read = 0;
		// For each (i,j) LIC
		//System.out.println("Sorting Stage: " + threshold);
		LIC.initialNode();
		
		size = LIC.size();
		//System.out.println("Size: " + size);
		for(int i=0;i<size;i++){
			symbol = (int) bis.readUBits(1);
			read++;
			if (symbol == ONE) {
				symbol = (int) bis.readUBits(1);
				read++;
				if (symbol==POS) {
					setSample(LIC.getX(),LIC.getY(),z,threshold+(threshold/2));
				}
				else {
					setSample(LIC.getX(),LIC.getY(),z,-threshold-(threshold/2));
				}
				LIC.moveElementAtLast(LSC);
			} 
			else {
				LIC.nextValue();
			}
		} //for
		
		// For each (i,j) LIS
		LIS.initialNode();
		
		end = LIS.isEmpty();
		while(!end) {
			end = LIS.isLast();
			// TYPE_A
			if (LIS.getType() == TYPE_A) {
				symbol = (int) bis.readUBits(1);
				read++;
				// Asks for significative Descendents
				if (symbol == ONE) {
					int[] childCoordinate = new int[2];
					
					int x = LIS.getX();
					int y = LIS.getY();
					for (int j=1;j<=4;j++) {
						childCoordinate = children(x,y,j);
						symbol = (int) bis.readUBits(1);
						read++;
						if (symbol == ONE) {
							LSC.addElement(childCoordinate[0],childCoordinate[1]);
							symbol = (int) bis.readUBits(1);
							read++;
							if (symbol == POS) {
								setSample(childCoordinate[0],childCoordinate[1],z,threshold+(threshold/2));
							}
							else {
								setSample(childCoordinate[0],childCoordinate[1],z,-threshold-(threshold/2));
							}
						} 
						else {
							LIC.addElement(childCoordinate[0],childCoordinate[1]);
						}
					}//for
					
					if (isGrandParent(LIS.getX(),LIS.getY())) {
						// Method 1 JPEG2000
						if (method == 1) {
							LIS.setType(TYPE_B);
							LIS.moveElementAtLast(LIS);
							end = false;
						}
						else if (method == 0) {
							// Method 0 original
							LIS.setType(TYPE_B);
							end = false;
						}
					}//if GrandParent
					else {
						LIS.remove();
					}
				}//if significativeDescendents
				else {
					LIS.nextValue();
				}
			}
			// TYPE_B
			else {
				symbol = (int) bis.readUBits(1);
				read++;
				// Asks for significative descendents
				if (symbol == ONE) {
					int[] childCoordinate = new int[2];
					int x,y,z;
					
					x = LIS.getX();
					y = LIS.getY();
					for (int j=1;j<=4;j++) {
						childCoordinate = children(x,y,j);
						LIS.addElement(childCoordinate[0],childCoordinate[1],TYPE_A);
						end = false;
					}
					LIS.remove();
				}
				else {
					LIS.nextValue();
				}
			}
		} //while
		size += read;
		//System.out.println("Simbolos leidos "+ read);
	} //sort
	/** Sets in the output image the new value considering the refinement value.
	  * @param actualThreshold the current threshold
	  * @param length determines the last element of the LSC list that we have to refine
	  * @return void
	*/
	protected void refinement(int actualThreshold, int length) throws IOException {
		int value;
		int m;
		boolean sign;
		int read;
		
		if(length == 0) return;
		
		read = 0;
		LSC.initialNode();
		sign = true;
		for(int i=0;i<length;i++) {   
			value = getSample(LSC.getX(),LSC.getY(),z); 
			if(value < 0) {
				sign = false;
				value = Math.abs(value);
			}//if
			m = (int) bis.readUBits(1);
			if (m == ONE) {
				value += actualThreshold/2;
				if(!sign) value = -value;
				setSample(LSC.getX(), LSC.getY(), z, value);
			}
			else {
				if (actualThreshold == 1) value -= 1;
				else value -= actualThreshold/2;
				if(!sign) value = -value;
				setSample(LSC.getX(),LSC.getY(),z,value);
			}
			sign = true;
			LSC.nextValue();
			read++;
		}//for
		size += read;
		//System.out.println("Simbolos leidos de refinamiento: " + read);
	}//refinement
	
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               SPIHT AUXILIAR METHODS                       /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	public void readThreshold() throws IOException {
		maxThreshold = (int) Math.pow(2,(int) bis.readUBits(5));
	}
	/**
	 * Initializes the lists LIS and LIC for the three dimensional SPIHT algorithm.
	 * @return void
	 */
	protected void listInitialize() {
		for (int x = 0; x < limitResidualBandX; x++) {
			for (int y = 0; y < limitResidualBandY; y++) {
				LIC.addElement(x,y);
				if (isParent(x,y)) LIS.addElement(x, y, TYPE_A);
			}
		}
	}
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               GET METHODS                                  /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	/** Returns the current <code>MultiInputStream</code>.
	  * @return the MultiInputStream
	*/
	public BitInputStream getInputStream() {
		   return bis;
	}
} //Spiht2D decoding
