package Spiht.SpihtDecoding;

import GiciBitStream.*;
import java.io.*;
import Building.LineBuilding;
import List.SpihtVector;
import Spiht.Spiht;


/** An implementation of SPIHT one dimensional decoding algorithm. <p>
  * @see SpihtModule.io.BitInputStream
  * @see SpihtModule.building.LineBuilding
  * @author Jorge Gonzalez-Conejero
  * @version 1.0 11/12/2003
  */ 
public class SpihtDecoding1D extends Spiht {
	/**
	 * Current line of the image in the algorithm.
	 * <p>
	 * Only an integer line number are allowed. If the line is greater than the image heigth it will throw an exception.
	 */
	protected int line = 0;
	/**
	 * List of insignificant coefficients.
	 * <p>
	 * This list must contains the insignificant coefficients of the input image. Only an integer coordinates are allowed.
	 */
	protected SpihtVector LIC = null;
	/**
	 * List of insignificant sets.
	 * <p>
	 * This list must contains the insignificant sets of the input image. Only an integer coordinates are allowed.
	 */
	protected SpihtVector LIS = null;
	/**
	 * List of significant coefficients.
	 * <p>
	 * This list must contains the significant coefficients of the input image. Only an integer coordinates are allowed.
	 */
	protected SpihtVector LSC = null;
	/** The coded input stream.
	  * <p>
	  * Only a SPIHT bit stream are allowed.
	*/
	protected BitInputStream bis;
	/** Current position in the LSC list to refine.
	  * <p>
	  * Only an integer values are allowed. Field maxim value is the LSC length.
	*/
	protected int positionInLSC = 0;
	/** Number of bits that the SPIHT algorithm has read.
	  * <p>
	  * Only an integer values are allowed.
	*/
	protected int numberReadBits = 0;
	/** The list of the valid rate distortion methods.
	  *        <ul>
	  *          <li> rd1tp - Rate Distortion with one truncation point
	  *          <li> rd2tp - Rate Distortion with two truncation points
	  *          <li> rdch - Rate Distortion with two truncation points and the Convex-Hull algorithm
	  *        </ul>
	  * <p>
	  * Only one of these three versions are allowed.
	*/
	protected String[] ratedList = {"rd1tp","rd2tp","rdch"};
	/** Creates an instance of the algorithm and initialize the object fields.
	  * @param fname the name of the file that contains the SPIHT bit stream
	  */
	public SpihtDecoding1D(String fname) throws IOException{
		
		FileInputStream fis = new FileInputStream(fname);
		bis = new BitInputStream(fis);
		
		// We instance the object
		
		// Image attributes
		xSize = (int) bis.readUBits(16);
		ySize = (int) bis.readUBits(16);
		levels = (int) bis.readUBits(4);
		method = (int) bis.readUBits(1);
		
		numberReadBits = xBits + yBits + levelsBits + methodBits;
		
		image = new int[1][ySize][xSize];
		
		// The subband limits
		limitResidualBandX = xSize / (int) Math.pow(2, levels);
		limitParentX = xSize / 2;
		limitGrandParentX = xSize / 4;
	} //Constructor
	
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                            SPIHT DECODE METHODS                            /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	/** Applies the SPIHT one dimensional Decoding algorithm, doing input from the <code>MultiInputStream</code>.
	 * @return returns the recovered image
	 */
	public void decode() throws Exception {
		// Variable definitions
		int positionInLSC;
		int minThreshold = 0;
		
		for(line = 0 ; line < ySize ; line++) {
			positionInLSC = 0;
			
			try {
				LIC = new SpihtVector(xSize + (xSize/2), 10, 1, false);
				LSC = new SpihtVector(xSize + (xSize/2), 10, 1, false);
				LIS = new SpihtVector(xSize + (xSize/2), 10, 1, true);
				
				readThreshold();
				
				// Initializes the LIC and LIS
				listInitialize();
				
				while(maxThreshold > minThreshold) {
					//System.out.println("MaxThreshold: " + maxThreshold);
					positionInLSC = LSC.size();
					try {
						// Sorting step
						sort(maxThreshold);
					} catch (IOException e) {
						bis.close();
						throw new IOException(e.getMessage());
					}
					
					if(positionInLSC != 0) {
						try {
							// Refinement step
							refinement(maxThreshold, positionInLSC);
						} catch (IOException e) {
							bis.close();
							throw new IOException(e.getMessage());
						}
					}
					maxThreshold >>= 1;
				} //while
			} catch (IOException e) {
				bis.close();
				//return (image);
			}
		}//for
		bis.close();
		//return (image);
	} //decode
	
	/** Applies the SPIHT one dimensional decoding algorithm with the specified rate distortion version,
	  * doing input from the <code>MultiInputStream</code>.
	  * @param rateVersion the version of the rate distortion algorithm to decode
	  * @return returns the recovered image
	  */
	public void decodeRated(String rateVersion) throws Exception {
		int bitsLine, rateMode, numPoints, minThreshold;
		int[] positionInLSCStored, positionInLine, maxThresholdInLine;
		SpihtVector[] LISStored, LICStored, LSCStored;
		
		minThreshold = 0;
		numPoints = 0;
		rateMode = -1;
		for(int i=0;i<ratedList.length;i++) {
			if(ratedList[i].equals(rateVersion)) {
				rateMode = i;
				break;
			}
		}
		
		if(rateMode == -1) throw new Exception("The rate mode " + rateVersion + " is not avaible");
		
		bitsLine = (int) Math.ceil((Math.log(ySize) / Math.log(2)));
		
		LISStored = new SpihtVector[ySize];
		LICStored = new SpihtVector[ySize];
		LSCStored = new SpihtVector[ySize];
		
		LIC = new SpihtVector(xSize + (xSize / 4), 10, 1, false);
		LIS = new SpihtVector(xSize + (xSize / 4), 10, 1, true);
		
		listInitialize();
		
		for(int i=0;i<ySize;i++) {
			LISStored[i] = LIS.cloneObject();
			LICStored[i] = LIC.cloneObject();
			LSCStored[i] = new SpihtVector(xSize + (xSize / 4), 10, 1, false);
		}
		
		positionInLSCStored = new int[ySize];
		maxThresholdInLine = new int[ySize];
		positionInLine = new int[ySize];
		
		for(int i=0;i<ySize;i++) {
			positionInLSCStored[i] = 0;
			maxThresholdInLine[i] = 0;
			positionInLine[i] = 0;
		}
		positionInLSC = 0;
		
		try {
			for(;;) {
				//Inicio Bucle
				
				line = (int) bis.readUBits(bitsLine);
				
				if(rateMode == 2) {
					numPoints = 1;
					while( ((int) bis.readUBits(1)) != 1) numPoints++;
				}
				
				LIS = LISStored[line];
				LIC = LICStored[line];
				LSC = LSCStored[line];
				positionInLSC = positionInLSCStored[line];
				
				if (positionInLine[line] == 0) readThreshold();
				else maxThreshold = maxThresholdInLine[line];
				
				if(rateMode == 0) {
					// 1 truncation point
					positionInLSC = LSC.size();
					sort(maxThreshold);
					
					if(positionInLSC != 0) refinement(maxThreshold, positionInLSC);
					maxThreshold >>= 1;
					
					(positionInLine[line])++;
					/*decodeRefinementPass();
					decodeSortingPass();
					(positionInLine[line])++;*/
				}
				
				if(rateMode == 1) {
					// 2 truncation points
					if((positionInLine[line]==0) || ((positionInLine[line] % 2) != 0)) {
						positionInLSC = LSC.size();
						sort(maxThreshold);
						if(positionInLine[line]==0) maxThreshold >>= 1;
					}
					else {
						if(positionInLSC != 0) refinement(maxThreshold, positionInLSC);
						maxThreshold >>= 1;
					}
					(positionInLine[line])++;
				}
				
				if(rateMode == 2) {
					// Convex Hull 2tp
					for(int i = 0 ; i < numPoints ; i++) {
						if((positionInLine[line] == 0) || ((positionInLine[line] % 2) != 0)) {
							positionInLSC = LSC.size();
							sort(maxThreshold);
							if(positionInLine[line] == 0) maxThreshold >>= 1;
						}
						else {
							if(positionInLSC != 0) refinement(maxThreshold, positionInLSC);
							maxThreshold >>= 1;
						}
						positionInLine[line]++;
					}//for
				}
				
				maxThresholdInLine[line] = maxThreshold;
				LISStored[line] = LIS;
				LICStored[line] = LIC;
				LSCStored[line] = LSC;
				LIS = null;
				LIC = null;
				LSC = null;
				positionInLSCStored[line] = positionInLSC;
			} //for
		} catch (IOException e) {
			   bis.close();
			   //return image;
		}
		//bis.close();
		//return image;
	} // decodeRatedStream
	
	/** Applies the SPIHT one dimensional decoding algorithm with the <code>LineBuilding</code>rate distortion version,
	  * doing input from the <code>MultiInputStream</code>.
	  * @return returns the recovered image
	  */
	public void decodeBuilding() throws Exception {
		int originalXSize;
		int originalYSize;
		
		//SubBand limits
		limitResidualBandX = (xSize / (int) Math.pow(2, (levels))) * ySize;
		limitParentX = (xSize / 2) * ySize;
		limitGrandParentX = (xSize / 4) * ySize;
		
		originalXSize = xSize;
		originalYSize = ySize;
		xSize = xSize * ySize;
		ySize = 1;
		
		image = new int[1][ySize][xSize];
		
		decode();
		
		LineBuilding lb = new LineBuilding(originalXSize, originalYSize, levels);
		image = lb.obtainOriginalImage(image);
		
		//return image;
	}
	/** Applies the SPIHT one dimensional decoding algorithm with the <code>Interleaved</code>rate distortion version,
	  * doing input from the <code>MultiInputStream</code>.
	  * @return returns the recovered image
	  */
	public void decodeInterleaved() throws Exception {
		//int positionInLSC;
		int minBPE, maxBPE, acum;
		int[] maxThresholdVector,maxThresholdPows, positionInLSCVector;
		
		SpihtVector[] LISVector;
		SpihtVector[] LSCVector;
		SpihtVector[] LICVector;
		
		//Initializations
		positionInLSC = 0;
		acum = 0;
		
		maxThresholdVector = new int[ySize];
		maxThresholdPows = new int[ySize];
		positionInLSCVector = new int[ySize];
		
		//The lists for each line in the algorithm
		LISVector = new SpihtVector[ySize];
		LICVector = new SpihtVector[ySize];
		LSCVector = new SpihtVector[ySize];
		
		LIC = new SpihtVector(xSize + (xSize/4), 10, 1, false);
		LIS = new SpihtVector(xSize + (xSize/4), 10, 1, true);
		
		listInitialize();
		
		try {
			maxBPE = (int) bis.readUBits(5);
			minBPE = (int) bis.readUBits(5);
			
			for(int line=0;line<ySize;line++) {
				//BPE Header
				if(maxBPE != minBPE) maxThresholdPows[line] = minBPE + (int) bis.readUBits(BitOutputStream.minBits(maxBPE - minBPE));
				else maxThresholdPows[line] = minBPE;
				
				//System.out.println("Pow " + maxThresholdPows[line]);
				maxThresholdVector[line] = (int) Math.pow(2,maxThresholdPows[line]);
				
				//The initialization of lists
				LISVector[line] = LIS.cloneObject();
				LICVector[line] = LIC.cloneObject();
				LSCVector[line] = new SpihtVector(xSize + (xSize/4), 10, 1, false);
			}//for
			LIS = null;
			LIC = null;
			
			while(acum < (ySize - 1)) {
				acum = 0;
				for(line=0;line<ySize;line++) {
					if(maxThresholdPows[line] > minBPE) {
						//Step initialization
						LIS = LISVector[line];
						LIC = LICVector[line];
						LSC = LSCVector[line];
						maxThreshold = maxThresholdVector[line];
						positionInLSC = positionInLSCVector[line];
						
						// Sorting step
						positionInLSC = LSC.size();
						sort(maxThreshold);
						
						// Refinement step
						if(positionInLSC != 0) refinement(maxThreshold, positionInLSC);
						
						//New parameters store
						maxThresholdVector[line] = maxThreshold >> 1;
						positionInLSCVector[line] = positionInLSC;
						(maxThresholdPows[line])--;
						LISVector[line] = LIS;
						LICVector[line] = LIC;
						LSCVector[line] = LSC;
						LIS = null;
						LSC = null;
						LIC = null;
					}//if
					else if(maxThresholdPows[line] == minBPE) acum++;
				}//for
			}//while
			
			maxThresholdPows = null;
			maxThreshold = 1;
			
			while(maxThreshold != 0) {
				acum = 0;
				for(line = 0 ; line < ySize ; line++) {
					//Step initialization
					LIS = LISVector[line];
					LIC = LICVector[line];
					LSC = LSCVector[line];
					maxThreshold = maxThresholdVector[line];
					positionInLSC = positionInLSCVector[line];
					
					// Sorting step
					positionInLSC = LSC.size();
					sort(maxThreshold);
					
					// Refinement step
					if(positionInLSC != 0) refinement(maxThreshold, positionInLSC);
					
					maxThreshold >>= 1;
					//New parameters store
					maxThresholdVector[line] = maxThreshold;
					positionInLSCVector[line] = positionInLSC;
					LISVector[line] = LIS;
					LICVector[line] = LIC;
					LSCVector[line] = LSC;
					LIS = null;
					LSC = null;
					LIC = null;
				}//for
			}//while
		} catch (IOException e) {
			bis.close();
			//return image;
		}
		bis.close();
		//return image;
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               SPIHT STEPS METHODS                          /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	/** It calls the refinement step of the SPIHT one dimensional algorithm.
	  * @return void
	  */
	public void decodeRefinementPass() throws IOException{
		// Refinement step
		if(maxThreshold == 0) refinement(1,positionInLSC);
		else refinement(maxThreshold << 1,positionInLSC);
	}
	/** It calls the sorting step of the SPIHT one dimensional algorithm and ensures that the step can be applied.
	  * @return void
	  */
	public void decodeSortingPass() throws Exception {
		// Sorting step
		if(maxThreshold != 0) {
			positionInLSC = LSC.size();
			sort(maxThreshold);
			
			maxThreshold >>= 1;
		}
	}
	
	/** It realizes the sorting decoding step of the SPIHT one dimensional algorithm
	  * @param threshold current threshold
	  * @return void
	  */
	protected void sort(int threshold) throws Exception{
		int value,size,symbol,index;
		boolean end;
		int read;
		int[] removeIndex;
		
		read = 0;
		index = 0;
		
		size = LIC.size();
		removeIndex = new int[size];
		
		for(int i=0;i<size;i++){
			symbol = bis.readMulti();
			read++;
			if (symbol == ONE) {
				symbol = bis.readMulti();
				read++;
				if (symbol == POS) setSample(LIC.getX(i), line, 0, threshold + (threshold / 2));
				else setSample(LIC.getX(i), line, 0, -threshold - (threshold / 2));
				
				LSC.addElement(LIC.getX(i));
				removeIndex[index] = i;
				index++;
			} 
		} //for
		
		//Remove the coordinates that the algorithm has considered significatives
		LIC.removeCollectionOfElements(removeIndex, index);
		
		for(index=0;index<LIS.size();index++) {
			//end = LIS.isLast();
			// TYPE_A
			if (LIS.getType(index) == TYPE_A) {
				symbol = bis.readMulti();
				read++;
				// Asks for significative descendents
				if (symbol == ONE) {
					int child;
					
					for (int j=1;j<=2;j++) {
						child = children(LIS.getX(index),j);
						symbol = bis.readMulti();
						read++;
						if (symbol == ONE) {
							LSC.addElement(child);
							symbol = bis.readMulti();
							read++;
							
							if (symbol == POS) setSample(child, line, 0, threshold+(threshold/2));
							else setSample(child, line, 0, -threshold-(threshold/2));
						} 
						else {
							LIC.addElement(child);
						}
					}//for
					
					if (isGrandParent(LIS.getX(index))) {
						// method JPEG 2000
						if (method == 1) {
							LIS.addElement(LIS.getX(index),TYPE_B);
							LIS.removeElement(index);
							index--;
							//LIS.moveElementAtLast(LIS);
							//end = false;
						}
						else if (method == 0) {
							// method 2 original
							symbol = bis.readMulti();
							read++;
							// Asks for significative descendents
							if (symbol == ONE) {
								for (int j=1;j<=2;j++) {
									child = children(LIS.getX(index),j);
									LIS.addElement(child,TYPE_A);
									//end = false;
								}
								LIS.removeElement(index);
								index--;
							}
							else {
								//LIS.addElement(LIS.getX(index),TYPE_B);
								//LIS.removeElement(index);
								//index--;
								LIS.setType(index, TYPE_B);
							}
						}
					}//if GrandParent
					else {
						LIS.removeElement(index);
						index--;
					}
				}//if significativeDescendents
				else {
					//LIS.nextValue();
				}
			}
			// TYPE_B
			else {
				symbol = bis.readMulti();
				read++;
				// Asks for significative descendents
				if (symbol == ONE) {
					int child;
					
					for (int j=1;j<=2;j++) {
						child = children(LIS.getX(index),j);
						LIS.addElement(child,TYPE_A);
						//end = false;
					}
					LIS.removeElement(index);
					index--;
				}
				else {
					//LIS.nextValue();
				}
			}
		} //while
		//System.out.println("Simbolos leidos en el sorting: " + read);
		numberReadBits += read;
	} //sort
	
	/** Sets in the output image the new value considering the refinement value.
	  * @param actualThreshold the current threshold
	  * @param length determines the last element of the LSC list that we have to refine
	  * @return void
	*/
	protected void refinement(int actualThreshold,int length) throws IOException {
		int value;
		int m;
		boolean sign;
		int read;
		
		read = 0;
		sign = true;
		for(int i=0;i<length;i++) {
			value = getSample(LSC.getX(i), line, 0); 
			if(value < 0) {
				sign = false;
				value = Math.abs(value);
			}//if
			m = bis.readMulti();
			read++;
			if (m == ONE) {
				value += actualThreshold/2;
				if(!sign) value = -value;
				setSample(LSC.getX(i), line, 0, value);
			}
			else {
				if (actualThreshold == 1) value -= 1;
				else value -= actualThreshold/2;
				if(!sign) value = -value;
				setSample(LSC.getX(i), line, 0, value);
			}
			sign = true;
		}//for
		//System.out.println("Simbolos leidos en el refinement: " + read);
		numberReadBits += read;
	}//refinement
	
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               SPIHT AUXILIAR METHODS                       /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * Initializes the lists LIS and LIC for the three dimensional SPIHT algorithm.
	 * @return void
	 */
	protected void listInitialize() {
		for (int x = 0; x < limitResidualBandX; x++) {
			LIC.addElement(x);
			if (isParent(x)) LIS.addElement(x, TYPE_A);
		}
	}
	/** Reads the initial threshold for a line from the input bit stream.
	  * @return void
	*/
	public void readThreshold() throws IOException {
		maxThreshold = (int) Math.pow(2,(int) bis.readUBits(5));
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////
	///////                               GET METHODS                                  /////////
	////////////////////////////////////////////////////////////////////////////////////////////
	/** Returns the current <code>MultiInputStream</code>.
	  * @return the MultiInputStream
	*/
	public BitInputStream getInputStream() {
		   return bis;
	}
	/** Returns number of bits that the SPIHT decoding algorithm has read.
	  * @return the number of bits read
	*/
	public int getNumberReadBits() {
		   return numberReadBits;
	}
}//SPIHT Decoding 1D
