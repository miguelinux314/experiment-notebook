package Spiht.SpihtDecoding;

import GiciBitStream.BitInputStream;
import java.io.*;
import List.SpihtLinkedList;
import Spiht.Spiht;

/** An implementation of 3D SPIHT decoding algorithm. <p>
  * @author Jorge González
  * @version 1.0 04/02/2004
  */ 
public class SpihtDecoding3D extends Spiht {
	/**
	 * The coded input stream.
	 * <p>
	 * Only a binary input stream is allowed.
	 */
	protected BitInputStream bis;
	/** 
	 * Creates an instance of the algorithm. Dummy constructor
	 */
	public SpihtDecoding3D () {}
	
      	/** 
	 * Creates an instance of the algorithm, sets the image attributes, the limits of the different subbands and handle the lists requirements.
	 * @param fname the name of the input stream
	 */
	public SpihtDecoding3D(String fname) throws IOException {
		FileInputStream fis = new FileInputStream(fname);
		bis = new BitInputStream(fis);
		
		/* We read the image performances from the file */
		xSize = (int) bis.readUBits(16);
		ySize = (int) bis.readUBits(16);
		zSize = (int) bis.readUBits(16);
		levels = (int) bis.readUBits(4);
		method = (int) bis.readUBits(1);
		
		// We define the vector size with the image attributes
		image = new int[zSize][ySize][xSize];
		
		// The subband limits
		limitResidualBandX = xSize / (int) Math.pow(2, (levels));
		limitResidualBandY = ySize / (int) Math.pow(2, (levels));
		limitResidualBandZ = zSize / (int) Math.pow(2, (levels));
		limitParentX = xSize / 2;
		limitParentY = ySize / 2;
		limitParentZ = zSize / 2;
		limitGrandParentX = xSize / 4;
		limitGrandParentY = ySize / 4;
		limitGrandParentZ = zSize / 4;
	}
	
	/** 
	 * Applies the 3D SPIHT decoding algorithm, doing input from the <code>MultiInputStream</code>.
	 * @return returns the recovered image in a vector
	 */
	public void decode() throws IOException {
		int positionInLSC = 0;
		int minThreshold = 0, oneStepThreshold;
		
		maxThreshold = (int) Math.pow(2,(int) bis.readUBits(4));
		
		oneStepThreshold = maxThreshold >> 1;
		
		// Lists of the algorithm might be defined
		LIC = new SpihtLinkedList();
		LSC = new SpihtLinkedList();
		LIS = new SpihtLinkedList();
		
		// Initializes the LIC and LIS
		listInitialize();

		while(maxThreshold > minThreshold) {
			// Sorting step
			positionInLSC = LSC.size();
			try {
				sort(maxThreshold);
				// Refinement step
				if(positionInLSC != 0)
					refinement(maxThreshold, positionInLSC);
				maxThreshold >>= 1;
			} catch (IOException e) {
				bis.close();
			}
		    
		} //while

		/*try {
			while(maxThreshold > minThreshold) {
				//System.out.println("Decoding: " + maxThreshold);
				
				// Refinement step
				refinement(maxThreshold << 1, positionInLSC);
				// Sorting step
				positionInLSC = LSC.size();
				sort(maxThreshold);
				
				maxThreshold >>= 1;
			} //while
			// The last refinement stage in the algorithm
			if (maxThreshold == 0) refinement(1,positionInLSC);
			else {
				//if only one step is executed we dont have refinement stage
				if(maxThreshold != oneStepThreshold) refinement(maxThreshold << 1,positionInLSC);
			}
			bis.close();
			//return (image);
		} catch (IOException e) {
			bis.close();
			//System.out.println("An exception ocurred");
			//return (image);
		}*/
	}
	
	/**
	 * It realizes the sorting step of the SPIHT three dimensional algorithm
	 * @param threshold current threshold
	 * @return void
	 */
	protected void sort(int threshold) throws IOException{
		int value,size,symbol,read;
		boolean end;
		
		read = 0;
		// For each (i,j) LIC
		//System.out.println("Sorting Stage: " + threshold);
		LIC.initialNode();
		
		size = LIC.size();
		//System.out.println("Size: " + size);
		for(int i=0;i<size;i++){
			symbol = bis.readMulti();
			read++;
			if (symbol == ONE) {
				symbol=bis.readMulti();
				read++;
				if (symbol==POS) {
					setSample(LIC.getX(),LIC.getY(),LIC.getZ(),threshold+(threshold/2));
				}
				else {
					setSample(LIC.getX(),LIC.getY(),LIC.getZ(),-threshold-(threshold/2));
				}
				LIC.moveElementAtLast(LSC);
			} 
			else {
				LIC.nextValue();
			}
		} //for
		
		// For each (i,j) LIS
		LIS.initialNode();
		
		end = LIS.isEmpty();
		while(!end) {
			end = LIS.isLast();
			// TYPE_A
			if (LIS.getType() == TYPE_A) {
				symbol=bis.readMulti();
				read++;
				// Asks for significative Descendents
				if (symbol == ONE) {
					int[] childCoordinate = new int[3];
					
					int x = LIS.getX();
					int y = LIS.getY();
					int z = LIS.getZ();
					for (int j=1;j<=8;j++) {
						childCoordinate = children(x,y,z,j);
						symbol = bis.readMulti();
						read++;
						if (symbol == ONE) {
							LSC.addElement(childCoordinate[0],childCoordinate[1],childCoordinate[2]);
							symbol = bis.readMulti();
							read++;
							if (symbol == POS) {
								setSample(childCoordinate[0],childCoordinate[1],childCoordinate[2],threshold+(threshold/2));
							}
							else {
								setSample(childCoordinate[0],childCoordinate[1],childCoordinate[2],-threshold-(threshold/2));
							}
						} 
						else {
							LIC.addElement(childCoordinate[0],childCoordinate[1],childCoordinate[2]);
						}
					}//for
					
					if (isGrandParent(LIS.getX(),LIS.getY(),LIS.getZ())) {
						// Method 1 JPEG2000
						if (method == 1) {
							LIS.setType(TYPE_B);
							LIS.moveElementAtLast(LIS);
							end = false;
						}
						else if (method == 0) {
							// Method 0 original
							symbol = bis.readMulti();
							read++;
							// Asks for significative descendents
							if (symbol == ONE) {
								x = LIS.getX();
								y = LIS.getY();
								z = LIS.getZ();
								for (int j=1;j<=8;j++) {
									childCoordinate = children(x,y,z,j);
									LIS.addElement(childCoordinate[0],childCoordinate[1],childCoordinate[2],TYPE_A);
									end = false;
								}
								LIS.remove();
							}
							else {
								LIS.setType(TYPE_B);
								LIS.moveElementAtLast(LIS);
								end = false;
							}
						}
					}//if GrandParent
					else {
						LIS.remove();
					}
				}//if significativeDescendents
				else {
					LIS.nextValue();
				}
			}
			// TYPE_B
			else {
				symbol = bis.readMulti();
				read++;
				// Asks for significative descendents
				if (symbol == ONE) {
					int[] childCoordinate = new int[3];
					int x,y,z;
					
					x = LIS.getX();
					y = LIS.getY();
					z = LIS.getZ();
					for (int j=1;j<=8;j++) {
						childCoordinate = children(x,y,z,j);
						LIS.addElement(childCoordinate[0],childCoordinate[1],childCoordinate[2],TYPE_A);
						end = false;
					}
					LIS.remove();
				}
				else {
					LIS.nextValue();
				}
			}
		} //while
		//System.out.println("Simbolos leidos "+ read);
	} //sort
	/** 
	 * Refinement stage. Sets in the output image the new value considering the refinement value.
	 * @param actualThreshold the current threshold
	 * @param length determines the last element of the LSC list that we have to refine
	 * @return void
	 */
	protected void refinement(int actualThreshold, int length) throws IOException {
		int value;
		int m;
		boolean sign;
		int read;
		
		read = 0;
		LSC.initialNode();
		sign = true;
		for(int i=0;i<length;i++) {   
			value = getSample(LSC.getX(),LSC.getY(),LSC.getZ()); 
			if(value < 0) {
				sign = false;
				value = Math.abs(value);
			}//if
			m = bis.readMulti();
			if (m == ONE) {
				value += actualThreshold/2;
				if(!sign) value = -value;
				setSample(LSC.getX(), LSC.getY(), LSC.getZ(), value);
			}
			else {
				if (actualThreshold == 1) value -= 1;
				else value -= actualThreshold/2;
				if(!sign) value = -value;
				setSample(LSC.getX(),LSC.getY(),LSC.getZ(),value);
			}
			sign = true;
			LSC.nextValue();
			read++;
		}//for
		//System.out.println("Simbolos leidos de refinamiento: " + read);
	}//refinement
	/**
	 * Initializes the lists LIS and LIC for the three dimensional SPIHT algorithm.
	 * @return void
	 */
	protected void listInitialize() {
		for (int x = 0; x < limitResidualBandX; x++) {
			for (int y = 0; y < limitResidualBandY; y++) {
				for (int z = 0; z < limitResidualBandZ; z++) {
						LIC.addElement(x,0,0);
						if (isParent(x,y,z)) LIS.addElement(x, y, z, TYPE_A);
					}
				}
			}
	}

}//Spiht3D decoding
