package Building;


/**
 * 
 *
 * @author Jorge Gonzalez
 * @version 1.0 07/11/2003
 */
public class LineBuilding {
	
	protected int xSize,ySize,levels;
	protected int[][][] image = null;
	
	public LineBuilding(int[][][] image, int levels) {
		this.image = image;
		
		//We store the image attributes in a vector
		xSize = image[0][0].length;
		ySize = image[0].length;
		this.levels = levels;
	}
	
	public LineBuilding(int xSize, int ySize, int levels) {
		image = null;
		
		this.xSize = xSize;
		this.ySize = ySize;
		this.levels = levels;
	}

	public int[][][] obtainReorganizedImage() {
		int initialLimit, finalLimit;
		int positionInLine;
		int [][][] imageReorganized = null;
		
		imageReorganized = new int[1][1][xSize * ySize];
		
		positionInLine = 0;
		initialLimit = 0;
		
		for(int level=levels;level>=0;level--) {
			finalLimit = xSize / (int) Math.pow(2,level);
			for(int y=0;y<ySize;y++) {
				for(int x=initialLimit;x<finalLimit;x++) {
					imageReorganized[0][0][positionInLine] = image[0][y][x];
					positionInLine++;
				}
			}
			initialLimit = finalLimit;
		}
		return imageReorganized;
	}
	
	public int[][][] obtainOriginalImage(int[][][] imageReorganized) {
		
		int initialLimit, finalLimit;
		int positionInLine;
		int[][][] imageOriginal;
		
		positionInLine = 0;
		initialLimit = 0;
		imageOriginal = new int[1][ySize][xSize];
		for(int level=levels;level>=0;level--) {
			finalLimit = xSize / (int) Math.pow(2,level);
			for(int y=0;y<ySize;y++) {
				for(int x=initialLimit;x<finalLimit;x++) {
					imageOriginal[0][y][x] = imageReorganized[0][0][positionInLine];
					positionInLine++;
				}
			}
			initialLimit = finalLimit;
		}
		
		return imageOriginal;
	} //obtainOriginalImage
}//LineBuilding
