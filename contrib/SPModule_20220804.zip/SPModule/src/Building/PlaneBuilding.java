package Building;

/**
 * 
 *
 * @author Jorge Gonzalez
 * @version 1.0 07/11/2003
 */
public class PlaneBuilding {
	
	protected int xSize, ySize, zSize, levels;
	protected int[][][] imageOriginal;
	protected int[][][] imageReorganized;
	
	public PlaneBuilding(int levels) {
		imageOriginal = null;
		imageReorganized = null;
		
		this.levels = levels;
	}
	
	protected void building(boolean forward) {
		
		int initialLimitX, finalLimitX;
		int initialLimitY, finalLimitY;
		int subbandWidth;
		int position;
		int xShift;
		int x,y,z;
		
		x = 0;
		y = 0;
		z = 0;
		xShift = 0;
		position = 0;
		initialLimitX = 0;
		initialLimitY = 0;
		finalLimitX = xSize / (int) Math.pow(2,levels);
		finalLimitY = ySize / (int) Math.pow(2,levels);
		subbandWidth = finalLimitX - initialLimitX;
		
		//Residual Band for each component
		for(z=0;z<zSize;z++) {
			for(y = initialLimitY ; y < finalLimitY ; y++) {
				for(x = initialLimitX ; x < finalLimitX ; x++) {
					if(forward) imageReorganized[0][y][x + position] = imageOriginal[z][y][x];
					else imageOriginal[z][y][x] = imageReorganized[0][y][x + position];
					
				}
			}
			position += subbandWidth;
		}
		
		for(int level=levels;level>0;level--) {
			//try {
			xShift =(xSize / (int) Math.pow(2,level)) * zSize;
			position = 0;
			
			// Bottom left
			initialLimitX = 0;
			initialLimitY = ySize / (int) Math.pow(2,level);
			finalLimitX = xSize / (int) Math.pow(2,level);
			finalLimitY = ySize / (int) Math.pow(2,level - 1);
			subbandWidth = finalLimitX - initialLimitX;
			
			for(z=0;z<zSize;z++) {
				for(y=initialLimitY;y<finalLimitY;y++) {
					for(x=initialLimitX;x<finalLimitX;x++) {
						if(forward) imageReorganized[0][y][x + position] = imageOriginal[z][y][x];
						else imageOriginal[z][y][x] = imageReorganized[0][y][x + position];
					}
				}
				position += subbandWidth;
			}
			// Top Rigth
			initialLimitX = xSize / (int) Math.pow(2,level);
			initialLimitY = 0;
			finalLimitX = xSize / (int) Math.pow(2,level - 1);;
			finalLimitY = ySize / (int) Math.pow(2,level);
			
			for(z=0;z<zSize;z++) {
				for(y=initialLimitY;y<finalLimitY;y++) {
					position = xShift;
					for(x=initialLimitX;x<finalLimitX;x++) {
						if(forward) imageReorganized[0][y][position] = imageOriginal[z][y][x];
						else imageOriginal[z][y][x] = imageReorganized[0][y][position];
						position++;
					}
				}
				xShift += subbandWidth;
			}
			//Bottom Rigth
			xShift =(xSize / (int) Math.pow(2,level)) * zSize;
			initialLimitX = xSize / (int) Math.pow(2,level);;
			initialLimitY = ySize / (int) Math.pow(2,level);;
			finalLimitX = xSize / (int) Math.pow(2,level - 1);
			finalLimitY = ySize / (int) Math.pow(2,level - 1);
			
			for(z=0;z<zSize;z++) {
				for(y=initialLimitY;y<finalLimitY;y++) {
					position = xShift;
					for(x=initialLimitX;x<finalLimitX;x++) {
						if(forward) imageReorganized[0][y][position] = imageOriginal[z][y][x];
						else imageOriginal[z][y][x] = imageReorganized[0][y][position];
						position++;
					}
				}
				xShift += subbandWidth;
			}
		} //level
	} //building
	
	public int[][][] obtainReorganizedImage(int[][][] imageOriginal) {
		this.imageOriginal = imageOriginal;
		
		zSize = imageOriginal.length;
		ySize = imageOriginal[0].length;
		xSize = imageOriginal[0][0].length;
		
		imageReorganized = new int[1][ySize][xSize * zSize];
		
		building(true);
		
		return imageReorganized;
	}
	public int[][][] obtainOriginalImage(int[][][] imageReorganized, int xSize, int ySize, int zSize) {
		this.imageReorganized = imageReorganized;
		this.xSize = xSize;
		this.ySize = ySize;
		this.zSize = zSize;
		
		imageOriginal = new int[zSize][ySize][xSize];
		
		building(false);
		
		return imageOriginal;
	}
/*		public int[][][] obtainReorganizedImage() {
		
		int initialLimitX, finalLimitX;
		int initialLimitY, finalLimitY;
		int subbandWidth;
		int [][][] imageReorganized;
		int position;
		int xShift;
		int x,y,z;
		
		imageReorganized = new int[xSize * zSize][ySize][1];
		
		x = 0;
		y = 0;
		z = 0;
		xShift = 0;
		position = 0;
		initialLimitX = 0;
		initialLimitY = 0;
		finalLimitX = xSize / (int) Math.pow(2,levels);
		finalLimitY = ySize / (int) Math.pow(2,levels);
		subbandWidth = finalLimitX - initialLimitX;
		
		//Residual Band for each component
		for(z=0;z<zSize;z++) {
			for(y=initialLimitY;y<finalLimitY;y++) {
				for(x=initialLimitX;x<finalLimitX;x++) {
					imageReorganized[x + position][y][0] = imageOriginal[x][y][z];
				}
			}
			position += subbandWidth;
		}
		
		for(int level=levels;level>0;level--) {
			//try {
			xShift =(xSize / (int) Math.pow(2,level)) * zSize;
			//xShift--;
			position = 0;
			
			// Bottom left
			initialLimitX = 0;
			initialLimitY = ySize / (int) Math.pow(2,level);
			finalLimitX = xSize / (int) Math.pow(2,level);
			finalLimitY = ySize / (int) Math.pow(2,level - 1);
			subbandWidth = finalLimitX - initialLimitX;
			
			for(z=0;z<zSize;z++) {
				for(y=initialLimitY;y<finalLimitY;y++) {
					for(x=initialLimitX;x<finalLimitX;x++) {
						imageReorganized[x + position][y][0] = imageOriginal[x][y][z];
					}
				}
				position += subbandWidth;
			}
			// Top Rigth
			initialLimitX = xSize / (int) Math.pow(2,level);
			initialLimitY = 0;
			finalLimitX = xSize / (int) Math.pow(2,level - 1);;
			finalLimitY = ySize / (int) Math.pow(2,level);
			
			for(z=0;z<zSize;z++) {
				for(y=initialLimitY;y<finalLimitY;y++) {
					position = xShift;
					for(x=initialLimitX;x<finalLimitX;x++) {
						imageReorganized[position][y][0] = imageOriginal[x][y][z];
						position++;
					}
				}
				xShift += subbandWidth;
			}
			//Bottom Rigth
			xShift =(xSize / (int) Math.pow(2,level)) * zSize;
			initialLimitX = xSize / (int) Math.pow(2,level);;
			initialLimitY = ySize / (int) Math.pow(2,level);;
			finalLimitX = xSize / (int) Math.pow(2,level - 1);
			finalLimitY = ySize / (int) Math.pow(2,level - 1);
			
			for(z=0;z<zSize;z++) {
				for(y=initialLimitY;y<finalLimitY;y++) {
					position = xShift;
					for(x=initialLimitX;x<finalLimitX;x++) {
						imageReorganized[position][y][0] = imageOriginal[x][y][z];
						position++;
					}
				}
				xShift += subbandWidth;
			}
		} //level
		
		return imageReorganized;
	}
	
	public int[][][] obtainOriginalImage(int[][][] imageReorganized, int xSize, int ySize, int zSize) {
		int[][][] imageOriginal;
		int initialLimitX, finalLimitX;
		int initialLimitY, finalLimitY;
		int subbandWidth;
		int position;
		int xShift;
		int x,y,z;
		
		imageOriginal = new int[xSize][ySize][zSize];
		
		x = 0;
		y = 0;
		z = 0;
		xShift = 0;
		position = 0;
		initialLimitX = 0;
		initialLimitY = 0;
		finalLimitX = xSize / (int) Math.pow(2,levels);
		finalLimitY = ySize / (int) Math.pow(2,levels);
		subbandWidth = finalLimitX - initialLimitX;
		
		//Residual Band for each component
		for(z=0;z<zSize;z++) {
			for(y=initialLimitY;y<finalLimitY;y++) {
				for(x=initialLimitX;x<finalLimitX;x++) {
					imageOriginal[x][y][z] = imageReorganized[x + position][y][0];
					//imageReorganized[x + position][y][0] = image[x][y][z];
				}
			}
			position += subbandWidth;
		}
		
		for(int level=levels;level>0;level--) {
			//try {
			xShift =(xSize / (int) Math.pow(2,level)) * zSize;
			position = 0;
			
			// Bottom left
			initialLimitX = 0;
			initialLimitY = ySize / (int) Math.pow(2,level);
			finalLimitX = xSize / (int) Math.pow(2,level);
			finalLimitY = ySize / (int) Math.pow(2,level - 1);
			subbandWidth = finalLimitX - initialLimitX;
			
			for(z=0;z<zSize;z++) {
				for(y=initialLimitY;y<finalLimitY;y++) {
					for(x=initialLimitX;x<finalLimitX;x++) {
						imageOriginal[x][y][z] = imageReorganized[x + position][y][0];
						//imageReorganized[x + position][y][0] = image[x][y][z];
					}
				}
				position += subbandWidth;
			}
			// Top Rigth
			initialLimitX = xSize / (int) Math.pow(2,level);
			initialLimitY = 0;
			finalLimitX = xSize / (int) Math.pow(2,level - 1);;
			finalLimitY = ySize / (int) Math.pow(2,level);
			
			for(z=0;z<zSize;z++) {
				for(y=initialLimitY;y<finalLimitY;y++) {
					position = xShift;
					for(x=initialLimitX;x<finalLimitX;x++) {
						imageOriginal[x][y][z] = imageReorganized[position][y][0];
						//imageReorganized[position][y][0] = image[x][y][z];
						position++;
					}
				}
				xShift += subbandWidth;
			}
			//Bottom Rigth
			xShift =(xSize / (int) Math.pow(2,level)) * zSize;
			initialLimitX = xSize / (int) Math.pow(2,level);;
			initialLimitY = ySize / (int) Math.pow(2,level);;
			finalLimitX = xSize / (int) Math.pow(2,level - 1);
			finalLimitY = ySize / (int) Math.pow(2,level - 1);
			
			for(z=0;z<zSize;z++) {
				for(y=initialLimitY;y<finalLimitY;y++) {
					position = xShift;
					for(x=initialLimitX;x<finalLimitX;x++) {
						imageOriginal[x][y][z] = imageReorganized[position][y][0];
						//imageReorganized[position][y][0] = image[x][y][z];
						position++;
					}
				}
				xShift += subbandWidth;
			}
		} //level
		
		return imageOriginal;
	} //obtainOriginalImage*/
}//PlaneBuilding
