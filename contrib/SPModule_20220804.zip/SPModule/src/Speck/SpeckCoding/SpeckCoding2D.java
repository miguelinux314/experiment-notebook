package Speck.SpeckCoding;

import java.io.FileOutputStream;
import java.io.IOException;
import GiciBitStream.BitOutputStream;
import Speck.Speck;
import Speck.SpeckVector;
import Speck.SpeckVector.SpeckDynamV;
import Speck.SpeckVector.SpeckSet;


/** An implementation of two dimensional SPECK Coding algorithm. 
  * @see Speck.Speck
  * @see Speck.SpeckVector
  * @see HyperStream.BitOutputStream
  * @author Daniel Rodrigo & Jorge Gonzalez-Conejero
  * @version 1.1 13/05/05
  */ 
public class SpeckCoding2D extends Speck {
	
	/** Creates an instance of the algorithm. Initialize the attributes from the object.
	  */
	public SpeckCoding2D() {
		image = null;
	}
	/**
	 * The coded output stream.
	 * <p>
	 * Only a stream is allowed.
	 */
	protected BitOutputStream output = null;
	
	/**
	 * The lowest threshold used by the coder.
	 * <p>
	 * Negative values are not allowed. Default is 0, changed by user in options.
	 */
	protected int minThreshold = 0;
	
	/**
	 * Available levels in the I set, 0 means SetI is empty and its processing unnecesary.
	 * <p>
	 * Value between SetI number of vectors and 0. 
	 */
	protected int SetIlevels = 0;
	/**
	 * Creates an instance of the algorithm. Initialize the attributes from the object.
	 * @param image array that contains the values to code
	 * @return void 
	 */
	 public SpeckCoding2D(int[][][] image)throws IOException {
			
		 this.image = image;
		 //Sets the image dimensions
		 ySize = image[0].length;
		 xSize = image[0][0].length;
		 zSize = image.length;
	 }
	 
	 /**          
	  * Speck attributes and output binary stream inicialization.
	  * @param levels of the WT.
	  * @param name of the output file.
	  * @param quadrisection method.
	  * @param lowest threshold.    
	  * @return void
	  */                            
	public void setParameters(int levels, String fname, int method,int minThreshold)throws IOException{
		this.WTlevels = levels;
		this.method = method;
		this.SetIlevels = levels;
		this.minThreshold = minThreshold;
		
		FileOutputStream foutput = new FileOutputStream(fname); 
		output = new BitOutputStream(foutput);       
		
		// We write the initial header to the final bitstream
		output.writeUBits(xSize,16);
		output.writeUBits(ySize,16);
		output.writeUBits(zSize,16);
		output.writeUBits(levels,4);
		output.writeUBits(method,2);
	}  
	
	/**
	 * Initialites all the sets and applies the Speck algorithm 
	 *@return void
	 */
	public void run()throws IOException{
		int LSPlength = 0;
	
		SpeckSet tempSet= new SpeckSet(0,0);
		SpeckVector Svector = new SpeckVector();
		
		maxThreshold = initialTh();
		SetSizes = (int)(Math.log(ySize)/Math.log(2));
		//LIS creation
		LIS = new SpeckDynamV();
		//LSP creation
		LSP = new SpeckVector();
		//SetI creation
		SetI = new SpeckVector[WTlevels];
		for(int i=0;i<WTlevels;i++){
			SetI[i]= new SpeckVector();	
		}                                                  
		//SetI filled with the image subsets except root
		//Each WT level is quadrisected and stored in different vectors
		//They will become the S sets of future SetI processings
		tempSet.SetSize(xSize,ySize);
		for(int i=0; i<WTlevels; i++){
	
			Svector = QuadriSect(tempSet);
			tempSet = Svector.PopSet();
			for (int j=0; j<3; j++){
				SetI[WTlevels-i-1].AddSet(Svector.PopSet());
			}
		}          
		//root added to the LIS  
		LIS.AddDynSet(tempSet);
		try{
			int maxThresholdPow = (int) (Math.log(maxThreshold)/Math.log(2));
			output.writeUBits(maxThresholdPow, thresholdBits);
			//main loop
			while(maxThreshold > minThreshold){
				LSPlength = LSP.getLength();
				Sorting();
				Refinement(LSPlength);
				maxThreshold >>= 1;
			}
	      		output.close();
		
		} 
		catch (IOException e) {
					output.close();
					System.out.println(e.getMessage());
					System.exit(1);
		}
		
	}
	
	 //***************************************************************//
	 //***************************************************************//    
	 //****		   Speck Article Based Functions	      ****//     
	 //***************************************************************//
	 //***************************************************************//
	 
	/**        
	 * Takes all the sets of the LIS for processing. 
	 *@return void
	 */
	
	public void Sorting()throws IOException{
	
		SpeckSet S;
		
		SpeckVector currentV = LIS.top;
		int k = LIS.GetDynLength();
		for (int i=0; i < k; i++){
			
			int l = currentV.getLength();
			for (int j=0; j<l; j++){
				S = currentV.PopSet();
				ProcessS(S);
			}
			currentV = currentV.next;
		}
		if (SetIlevels > 0) ProcessI();
	}
	
	/**
	 * Checks the significance of a set, sending it for processing if its bigger than a pixel. 
	 *@param original set
	 *@return void
	 */
	public void ProcessS(SpeckSet S)throws IOException{
		
	
		if(Significance(S) == 1){
			if((S.GetSizeX() == 1) && (S.GetSizeY() == 1)){ //significant point
				output.writeMulti(ONE);
				if(image[0][S.GetSetY()][S.GetSetX()] < 0)
					output.writeMulti(NEG);
				else output.writeMulti(POS);
				LSP.AddSet(S);
			}
			else{ //significant set
				
				output.writeMulti(ONE);
				CodeS(S);
			}
		}
		else{	//insignificant
			LIS.AddDynSet(S);
			output.writeMulti(ZERO);
		}
	}
	
	/**
	 * Checks the significance of the 4 subsets of a set, recursive until obtaining pixels.  
	 *@param original set
	 *@return void
	 */
	public void CodeS(SpeckSet S)throws IOException{
		//Variable definitions
		int templength = 0;
		int zeroSet = 0; //nonsignificative set counter for 3/4 method
				
		SpeckVector subsetsVector = null;
		SpeckVector iterativeVector = null;
		SpeckSet subSet = null;
		
		//SpeckVector instances
		subsetsVector = new SpeckVector();
		iterativeVector = new SpeckVector();
		subSet = new SpeckSet();
		
		subsetsVector = QuadriSect(S);
		int k = subsetsVector.getLength();
		
		for(int i=0; i<k; i++){
			subSet = subsetsVector.PopSet();
			if(Significance(subSet) == 1){
				
				if((subSet.GetSizeX() == 1) && (subSet.GetSizeY() == 1)){ //point
					if ((method != 2)||!((i == 3)&&(zeroSet == 3)))output.writeMulti(ONE);
					if(image[0][subSet.GetSetY()][subSet.GetSetX()] < 0)
						output.writeMulti(NEG);
					else    output.writeMulti(POS);
					LSP.AddSet(subSet);
				}
				else{ //set
					
					if (method != 1){ //recursive
						if ((method == 0)||!((i == 3)&&(zeroSet == 3)))output.writeMulti(ONE);
						CodeS(subSet);
					}
					else{ //iterative
						output.writeMulti(ONE);
						iterativeVector.AddSet(subSet);
			
					}
				}	
			}
			else{ //non significative
				output.writeMulti(ZERO);
				zeroSet++;
				LIS.AddDynSet(subSet);
			}
		}
		
		templength =  iterativeVector.getLength();
		if((method == 1)&&(templength > 0)){ //iterative
			for(int i=0; i<templength; i++){
				subSet = iterativeVector.PopSet();
				CodeS(subSet);
			}
		}
		
	}
	/**
	 * Looks for a significative subset in I.
	 * @return void 
	 */
	public void ProcessI()throws IOException{
		
		boolean sign = false;
		int setSizeX = 0;
		int setSizeY = 0;
		
		for(int i=0; i<WTlevels; i++){
			int k = SetI[i].getLength();
			SpeckSet currentSet = SetI[i].top;
			for (int j=0; j<k; j++){
				if(Significance(currentSet)==1){
					sign = true;
					break;
				}
				currentSet = currentSet.NextSet();
			}
			if (sign == true) break;
		}
		
		if (sign == true){ //Some SetI value is significant
			output.writeMulti(ONE);
			CodeI();
		}
		else{
			output.writeMulti(ZERO);
			
		}
		
	}
	
	/**
	 * Takes the 3 minor sets of I for processing.
	 *@return void
	 */
	public void CodeI()throws IOException{
		SpeckSet subSetI;
		int setSizeX = 0;
		int setSizeY = 0;
		int k = 0;
		
		SetIlevels--;
		while(SetI[k].getLength() != 3){
			k++;
		}
		for (int i=0; i<3; i++){
			subSetI = SetI[k].PopSet();
			ProcessS(subSetI);
		}
		ProcessI();
	}
	
	/**
	 * Outputs finer detail to which interval belong already sent samples.
	 * @param number of points in the LSP in the previous loop.
	 * @return void
	 */
	public void Refinement(int LSPlength)throws IOException{
		
		SpeckSet LSPSet = null;
		LSPSet = new SpeckSet();
		int precissionPoint;
		
		LSPSet = LSP.top;
		for(int i=0; i<LSPlength; i++){
		
			int value = Math.abs(image[0][LSPSet.GetSetY()][LSPSet.GetSetX()]);
			if( (maxThreshold & value) != 0) precissionPoint = ONE;
			else precissionPoint = ZERO;
			output.writeMulti(precissionPoint);
			LSPSet = LSPSet.NextSet();
		}
	}
	
	
	//***************************************************************//
	//***************************************************************//
	//****	       End of Speck Article Based Functions	     ****//
	//***************************************************************//
	//***************************************************************//
	
	/**
	 * Look for a significative pixel in a set.
	 *@param the set to check      
	 *@return 1 if the set has a significative pixel, 0 otherwise
	 */
	public int Significance(SpeckSet S){
		int sizeX = S.GetSizeX();
		int sizeY = S.GetSizeY();
		int x = S.GetSetX();
		int y = S.GetSetY();
		
		for (int i = x; i< x+sizeX; i++) {
			for (int j = y; j < y+sizeY; j++){
				int value = Math.abs(image[0][j][i]);
				if (value >= maxThreshold){
					return 1;
				}
			}
		}
		return 0;
	}
	
	/**
	 * Divides a set in 4 new subsets with identical size, or in the points that compose it. 
	 *@param the original set
	 *@return a list with the subsets
	 */
	protected SpeckVector QuadriSect(SpeckSet s){
		SpeckVector setsVector = null;
		setsVector = new SpeckVector();
		int setSizeX = s.GetSizeX();
		int setSizeY = s.GetSizeY();
		int setCoordX = s.GetSetX();
		int setCoordY = s.GetSetY();
		int subsetSizeX = 0;
		int subsetSizeY = 0;
		int k = 0;
	
		if ((setSizeX > 1) && (setSizeY > 1)){ //the set can be quadrisected
			for (int i=0; i<2; i++){
				for(int j=0; j<2; j++){
					
					subsetSizeX = (int) setSizeX/2;
					subsetSizeY = (int) setSizeY/2;
				
					SpeckSet tempSet = new SpeckSet();
					tempSet.SetX(setCoordX + (subsetSizeX * i));
					tempSet.SetY(setCoordY + (subsetSizeY * j));
					if (setSizeX % 2 == 1){	
						if (k > 1) subsetSizeX++;
					}
					if (setSizeY % 2 == 1){
						 if (k == 1 || k == 3) subsetSizeY++;
					}
					tempSet.SetSize(subsetSizeX,subsetSizeY);
					setsVector.AddSet(tempSet);
					k++;
				}
			}
			
		}
		else{ //the set will be divided in points
			if (setSizeX == 1) {
				subsetSizeX = 0;
				subsetSizeY = 1;
			}
			else{
				subsetSizeX = 1;
				subsetSizeY = 0;
			}
			for(int i=0; i < (setSizeX*setSizeY); i++){ //all the set is divided
				SpeckSet tempSet = new SpeckSet();
				tempSet.SetX(setCoordX + (subsetSizeX * i));
				tempSet.SetY(setCoordY + (subsetSizeY * i));
				tempSet.SetSize(1,1);
				setsVector.AddSet(tempSet);
			}
			
		}
		return setsVector;
	}
	
	/**
	 * Finds the maximum threshold for the component of the input image specified by the field <code>z</code>.
	 * @return the maximum threshold in the component
	 */
	protected int initialTh() {
		int maxim;
		int value;
		
		maxim = Math.abs(image[0][0][0]);
		for (int x = 0; x < xSize; x++) {
			for (int y = 0; y < ySize; y++){
				value = Math.abs(image[0][y][x]);
				if (value > maxim ) maxim = value;
			}
		}                                                        
		return ((int)Math.pow(2,(int)(Math.log(maxim)/Math.log(2))));
	}
}
