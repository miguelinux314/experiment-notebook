package Speck;

/**
 * Set and vector of sets attributes class.
 * <p>
 * @author Daniel Rodrigo & Jorge Gonzalez-Conejero
 * @version 1.1 13/05/05
 */
 
public class SpeckVector{
	
         //begin and end of vector pointers   
	 public SpeckSet top;
	 public SpeckSet end;
	 public SpeckVector next;
	 public SpeckVector prev;
	 public int size;
	 
	/**
	 * Default class builder. 
	 */
	public SpeckVector(){
		SpeckSet top = null;
		SpeckSet end = null;
		SpeckVector next = null;
		SpeckVector prev = null;
		size=0;
	}
	
	/**
	 * Function used to take the first set of a vector, removing it.
	 * @return the first set of the list.
	 */
	public SpeckSet PopSet(){
		
		SpeckSet Set = null;
		Set = new SpeckSet();
		
		if (top != null){
			Set.Xcoord = top.Xcoord;
			Set.Ycoord = top.Ycoord;
			Set.SizeX = top.SizeX;
			Set.SizeY = top.SizeY;
			if (top.next != null){
				top.next.prev = null;
				top = top.next;
			}
			else{
				top = null;
				end = null;
			}
			Set.prev = null;
			Set.next = null;
			return Set;
		}
	
		return null;
	}                    
	
	/**
	 * A new set is added at the end of the vector
	 * @param the set to add
	 * @return void
	 */
	public void AddSet(SpeckSet Set){
		
		Set.next = null;
		Set.prev = null;
		
		if (top != null){
			
			end.next = Set;
			Set.prev = end;
		}
		else{ top = Set;size=Set.GetSizeX()*Set.GetSizeY();}
		end = Set;
		
	}
	
	/**
	 * Calculates the total number of elements (length) of the vector.
	 * @return the vector length
	 */
	public int getLength(){
		int length = 0;
		SpeckSet currentSet = top;	
		
		while(currentSet != null){
			length++;
			if (currentSet.next == null) break;
			currentSet = currentSet.next;
		}
		return length;
	}
	
	/**
  	 * Looks for the X coordenate of a set located into the vector. The set
	 * will be looked for from the top or the end depending on its position.  
	 * @param position of the set in the vector.
	 * @param length of the vector.
	 * @return X set attribute value.
	 */
	public int getElementX(int index,int length){
		int currentPosition = 0;
		SpeckSet currentSet = top;
		
		if(index<=length/2){
			while((currentSet != null)&&(currentPosition < index)){
				currentPosition++;
				currentSet = currentSet.next;
			}
		}else{
			currentSet = end;
			while((currentSet != null)&&(currentPosition < length-index)){
				currentPosition++;
				currentSet = currentSet.prev;
			}
		}
		return currentSet.Xcoord;
	}
	
	/**
	* Looks for the Y coordenate of a set located into the vector. The set
	* will be looked for from the top or the end depending on its position.  
	* @param position of the set in the vector.
	* @param length of the vector.
	* @return Y set attribute value.
	*/
	public int getElementY(int index,int length){
		int currentPosition = 0;
		SpeckSet currentSet = top;
		
		if(index<=length/2){
			while((currentSet != null)&&(currentPosition < index)){
				currentPosition++;
				currentSet=currentSet.next;                              
			}
		}else{
			currentSet = end;
			while((currentSet != null)&&(currentPosition < length-index)){
				currentPosition++;
				currentSet=currentSet.prev;
			}
		
		}
		return currentSet.Ycoord;
	}
	
	
	
	//sets class
	static public class SpeckSet{
		//coordenates where the set begins
		protected int Xcoord;
		protected int Ycoord;
		//next and previous set pointers
		protected SpeckSet next;
		protected SpeckSet prev;
		
		protected int SizeX;
		protected int SizeY;
		//default builder
		public SpeckSet(){
			next = null;
			prev = null;
			SizeX = 0;
			SizeY = 0;
		}
		//builder with coordinates
		public SpeckSet(int x, int y){
			Xcoord = x;
			Ycoord = y;
			SizeX = 0;
			SizeY = 0;
			next = null;
			prev = null;
		}
		/**
		 * Returns the X attribute of the set.
		 * @return x coordinate.
		 */
		public int GetSetX(){
			return Xcoord;
		}
		/**
		 * Returns the Y attribute of the set.
		 * @return y coordinate.
		 */
		public int GetSetY(){
			return Ycoord;
		}
		
		/**
		 * Modifies the X attribute of the set.
		 * @param the new X value
		 * @return void.
		 */
		public void SetX(int x){
			this.Xcoord = x;	
		}
		
		/**
		 * Modifies the Y attribute of the set.
		 * @param the new Y value
		 * @return void.
		 */
		public void SetY(int y){
			this.Ycoord = y;
		}
		/**                                                              
		 * Returns the next set from the current one, for sequential vector searchs.
		 * @return the next set
		 */          
		public SpeckSet NextSet(){
			return next;                         
		}  
		
		
		public void SetSize(int x,int y){
			this.SizeX = x;
			this.SizeY = y;
		}
		public int GetSizeX(){
			return SizeX;
		}
		public int GetSizeY(){
			return SizeY;
		}
	}
	
	//dynamic vector class
	static public class SpeckDynamV{
		//vector pointers
		public SpeckVector top;
		public SpeckVector end;
		
		//default builder
		public SpeckDynamV(){
			SpeckVector top = null;
			SpeckVector end = null;
		}
		/**
		* Adds a set to a designated vector of the dynamic list, using the cardinality of the blocks.
		* @param the set to include
		* @return void
		*/
		public void AddDynSet(SpeckSet Set){
			
			if(top == null){ //empty dynamic list
				top = new SpeckVector();
				top.AddSet(Set);
				end = top;
			}else{
				SpeckVector currentV = top;
				while((currentV.size < Set.GetSizeX()*Set.GetSizeY()) && (currentV.next != null)){
					currentV = currentV.next;
				}
				if(currentV.size > Set.GetSizeX()*Set.GetSizeY()){//new set size
					SpeckVector Vec = new SpeckVector();
					Vec.AddSet(Set);
					if (currentV.prev!=null)currentV.prev.next=Vec;
					else top=Vec;
					Vec.prev=currentV.prev;
					Vec.next=currentV;
					currentV.prev=Vec;
						
				}
				else if(currentV.size == Set.GetSizeX()*Set.GetSizeY()){
					currentV.AddSet(Set);  //the size already exists
				}
				else{				//new set size
					SpeckVector Vec = new SpeckVector();
					Vec.AddSet(Set);
					if (currentV.next!=null)currentV.next.prev=Vec;
					Vec.next = currentV.next;
					currentV.next=Vec;
					Vec.prev=currentV;
				}	
			}
			
		}
		
		/**
		* Calculates the total number of elements (length) of the dynamic list.
		* @return the vector length
		*/
		public int GetDynLength(){
			int length = 0;
			SpeckVector currentV = top;
			
			while(currentV != null){
				length++;
				if (currentV.next == null) break;
				currentV = currentV.next;
			}
			return length;
		}
	}
}
