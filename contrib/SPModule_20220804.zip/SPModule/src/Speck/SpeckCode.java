package Speck;

import Speck.SpeckCoding.SpeckCoding2D;
import Speck.SpeckCoding.*;
import GiciFile.LoadFile;
import GiciTransform.*;

/**
 * Main class of the SpeckCode application.
 * <p>
 * @see Speck.SpeckCoding.SpeckCoding2D 
 * @author Daniel Rodrigo & Jorge Gonzalez-Conejero
 * @version 1.0 01/04/05
 */
public class SpeckCode {
	/**
	 * Main method of SpeckCode application. It takes program arguments, loads image and runs Speck coder.
	 *
	 * @param args an array of strings that contains program parameters
	 */
	public static void main(String[] args){
		ArgsParser arguments = null;
		
		try {
			arguments = new ArgsParser(args);
		} catch (Exception e) {
			System.out.println("ARGUMENTS ERROR: " + e.getMessage());
			System.exit(1);
		}
		
		// IMAGE LOAD
		String imageFile = arguments.getImageFile();
		LoadFile image = null;
		try{
			if(imageFile.endsWith(".raw")){
				int[] imageGeometry = arguments.getImageGeometry();

				//Check parameters of image geometry
				if((imageGeometry[0] <= 0) || (imageGeometry[1] <= 0) || (imageGeometry[2] <= 0)){
					throw new Exception("Image dimensions in \".raw\" data files must be positive (\"-h\" displays help).");
				}
				if((imageGeometry[3] < 0) || (imageGeometry[3] > 7)){
					throw new Exception("Image type in \".raw\" data must be between 0 to 7 (\"-h\" displays help).");
				}
				if((imageGeometry[4] != 0) && (imageGeometry[4] != 1)){
					throw new Exception("Image Endian specification in \".raw\" data must be between 0 or 1 (\"-h\" displays help).");
				}
				if((imageGeometry[5] != 0) && (imageGeometry[5] != 1)){
					throw new Exception("Image RGB specification in \".raw\" data must be between 0 or 1 (\"-h\" displays help).");
				}
				image = new LoadFile(imageFile, imageGeometry[0], imageGeometry[1], imageGeometry[2], imageGeometry[3], imageGeometry[4],imageGeometry[5] == 0 ? false: true);
			}else{
				image = new LoadFile(imageFile);
			}
		}catch(Exception e){
			System.err.println("IMAGE LOADING ERROR: " + e.getMessage());
			System.exit(2);
		}
		
		//GET ARGUMENTS
		String fileName = arguments.getFileName();
		int[] WTTypes = arguments.getWTTypes();
		int[] WTLevels = arguments.getWTLevels();
		int method = arguments.getMethod();
		int minThr = arguments.getMinThr();
		int QType = arguments.getQType();
		
		//DISCRETE WAVELET TRANSFORM
		float[][][] imageSamples = null;
				
		try {
			ForwardWaveletTransform wt = new ForwardWaveletTransform(image.getImage());
			wt.setParameters(WTTypes, WTLevels);
			imageSamples = wt.run();
			
		} catch (Exception e) {
			System.out.println("DISCRETE WAVELET TRANSFORM FAILED: " + e.getMessage());
			System.exit(3);
		}
		
		//CODER
		try{
			
			SpeckCoding2D spc = new SpeckCoding2D(floatToInt(imageSamples, QType));
			spc.setParameters(WTLevels[0],fileName,method,minThr);
			spc.run();
		}catch (Exception e){
			System.out.println("CODIFICATION FAILED: " + e.getMessage());
			System.exit(4);
		}
	}
	/**
	 * Auxiliar method from the Spiht code main class to quantize the coefficients received from the discrete wavelet transform.
	 *
	 * @param src the image with float coefficients
	 * @return the input image rounded to the nearest integer
	 */
	private static int[][][] floatToInt(float[][][] src, int QType){
		int zSize = src.length;
		int ySize = src[0].length;
		int xSize = src[0][0].length;
		
		int dst[][][] = new int[zSize][ySize][xSize];
		
		for (int z=0; z < zSize; z++) {
			for (int y=0; y < ySize; y++) {
				for (int x=0; x < xSize; x++) {
					dst[z][y][x]= Math.round(src[z][y][x]);
				}
			}
		}
		return dst;
	}
}
