package Speck.SpeckDecoding;

import java.io.IOException;
import java.io.FileInputStream;
import GiciBitStream.BitInputStream;
import Speck.Speck;
import Speck.SpeckVector;
import Speck.SpeckVector.SpeckDynamV;
import Speck.SpeckVector.SpeckSet;

/** An implementation of SPECK two dimensional decoding algorithm.
  * @see Speck.Speck
  * @see Speck.SpeckVector
  * @see HyperStream.BitInputStream
  * @author Daniel Rodrigo & Jorge Gonzalez-Conejero
  * @version 1.1 13/05/05
  */ 
public class SpeckDecoding2D extends Speck {
	
		
	/**
	 * The lowest threshold used by the decoder.
	 * <p>
	 * Negative values are not allowed. Default is 0, changed by user in options.
	 */
	 protected int minThreshold = 0;
	 
	 /**
	  * Available levels in the I set, 0 means SetI is empty and its processing unnecesary.
	  * <p>
	  * Value between SetI number of vectors and 0. 
	  */
	 protected int SetIlevels = 0;
	
	/**
	 * Potence of the higgest threshold.
	 * <p>
	 * Negative values not allowed.
	 */
	 protected int maxThresholdPow = 0;
	 
	/**
	 * The coded input stream.
	 * <p>
	 * Only a binary input stream is allowed.
	 */
	protected BitInputStream input = null;
	
	/** 
	 * Creates an instance of the algorithm and initializes the input stream.
	 * @return void
	 */
	public SpeckDecoding2D() throws IOException {
		
		
	}
	/**          
	 * Speck attributes reading and inicialization.
	 * @param lowest threshold.
	 * @param input binary stream file.
	 * @return void
	 */                            	       
	public void setParameters(int minThr,String fname)throws IOException{
		this.minThreshold = minThr;
		
		FileInputStream fis = new FileInputStream(fname);
		input = new BitInputStream(fis);
		
		
		// We read the image performances from the file
		xSize = (int) input.readUBits(16);
		ySize = (int) input.readUBits(16);
		zSize = (int) input.readUBits(16);
		WTlevels = (int) input.readUBits(4);
		this.method = (int) input.readUBits(2);
		maxThresholdPow = (int) input.readUBits(5);
		SetIlevels = WTlevels;
		image = new int[zSize][ySize][xSize];		
	}
	
	/** Applies the SPECK decoding algorithm, with the <code>MultiInputStream</code> as input.
	 * @return returns the recovered image
	 */
	public void run() throws IOException {
	
		int setSize = ySize;
		int LSPlength = 0;
		
		SpeckSet tempSet= new SpeckSet(0,0);
		SpeckVector Svector = new SpeckVector();
		SetSizes = (int)(Math.log(ySize)/Math.log(2));
		//LIS creation		
		LIS = new SpeckDynamV();
		
		//LSP creation
		LSP = new SpeckVector();
		//SetI creation
		SetI = new SpeckVector[WTlevels];
		for (int i=0;i<WTlevels;i++){
			SetI[i] = new SpeckVector();
		}
		
		//SetI filled with the image subsets except root 
		//Each WT level is quadrisected and stored in different vectors
		//They will become the S sets of future SetI processings
		tempSet.SetSize(xSize,ySize);
		for(int i=0; i<WTlevels; i++){
			Svector = QuadriSect(tempSet);
			tempSet = Svector.PopSet();
			for (int j=0; j<3; j++){
				SetI[WTlevels-i-1].AddSet(Svector.PopSet());
			}
			
		}
		//root added to the LIS  
		LIS.AddDynSet(tempSet);
	            
		try {
			maxThreshold = (int)Math.pow(2,maxThresholdPow); 
			
			//main loop
			while(maxThreshold > minThreshold) {
				LSPlength = LSP.getLength();
				Sorting();
				Refinement(LSPlength);
				maxThreshold >>= 1;
			} 
			/*for(int i=0;i<xSize;i++){
				for(int j=0;j<ySize;j++){
					System.out.println("punt"+i+" 0 valor "+image[0][j][i]);
				}
			}*/
		} catch (Exception e) {
			input.close();
		}
	}
	        
	 //***************************************************************//
	 //***************************************************************//   
	 //****		   Speck Article Based Functions	      ****//   
	 //***************************************************************//
	 //***************************************************************//
	 
	/**
	 * Takes all the sets of the LIS for processing. 
	 *@return void
	 */
	public void Sorting()throws IOException{
		
		SpeckSet S;
		SpeckVector currentV = LIS.top;
		
		int k = LIS.GetDynLength();
		for (int i=0; i < k; i++){
			int l = currentV.getLength();
			for (int j=0; j<l; j++){
				S = currentV.PopSet();
				ProcessS(S);
			}
			currentV = currentV.next;
		}
		
		if (SetIlevels > 0) ProcessI();
		
	}
	/**
	 * Checks the significance of a set, sending it for processing if its bigger than a pixel. 
	 *@param original set
	 *@return void
	 */
	public void ProcessS(SpeckSet S)throws IOException{
		int read = (int) input.readUBits(1);
		if(read == ONE){
			if((S.GetSizeX() == 1) && (S.GetSizeY() == 1)){ //point
				read = (int) input.readUBits(1);
				if (read==POS)	image[0][S.GetSetY()][S.GetSetX()] = maxThreshold+(maxThreshold/2);
				
				else image[0][S.GetSetY()][S.GetSetX()] = -maxThreshold-(maxThreshold/2);
				LSP.AddSet(S);
			}
			else CodeS(S);
		}
		else LIS.AddDynSet(S);
		
	}
	
	/**
	 * Checks the significance of the 4 subsets of a set, recursive until obtaining pixels.  
	 *@param original set
	 *@return void
	 */
	public void CodeS(SpeckSet S)throws IOException{
		int read = 0; //input
		int zeroSet = 0; //nonsignificative set counter for 3/4 method
		
		SpeckVector subsetsVector = null;
		SpeckVector iterativeVector = null;
		SpeckSet subSet = null;
		
		//SpeckVector instances
		subsetsVector = new SpeckVector();
		iterativeVector = new SpeckVector();
		subSet = new SpeckSet();
		
		subsetsVector = QuadriSect(S);
		int k = subsetsVector.getLength();
		
		for(int i=0; i<k; i++){
			subSet = subsetsVector.PopSet();
			if ((method != 2)||!((i == 3)&&(zeroSet == 3)))read = (int) input.readUBits(1);
			if ((method ==2) && (i==3) && (zeroSet==3)) read = ONE;
			if(read == ONE){ //significative
				if((subSet.GetSizeX() == 1) && (subSet.GetSizeY() == 1)){ //point
					read = (int) input.readUBits(1);
					if(read == POS)	image[0][subSet.GetSetY()][subSet.GetSetX()] = maxThreshold+(maxThreshold/2);
					else image[0][subSet.GetSetY()][subSet.GetSetX()] = -maxThreshold-(maxThreshold/2);
					LSP.AddSet(subSet);
					
				}
				else{ //set
					if (method != 1){ //recursive
						CodeS(subSet);
					}
					else{ //iterative
						iterativeVector.AddSet(subSet);
					}
				}	
			}
			else{ //nonsignificative
				zeroSet++;
				LIS.AddDynSet(subSet);
			}
		}
		if(method == 1){ //iterative
			int l = iterativeVector.getLength(); 
			for(int i=0; i<l; i++){
				subSet = iterativeVector.PopSet();
				CodeS(subSet);
			}
		}
		
	}
	/**
	 * Looks for a significative subset in I.
	 * @return void 
	 */
	public void ProcessI()throws IOException{
	
		int read = (int) input.readUBits(1);
		if (read == ONE){ //Some SetI value is significative
			CodeI();
		}
	}
	
	/**
	 * Takes the 3 minor sets of I for processing.
	 *@return void
	 */
	public void CodeI()throws IOException{
		SpeckSet subSetI;
		int k = 0;
		
		SetIlevels--;
		while(SetI[k].getLength() != 3){
			k++;
		}
		for (int i=0; i<3; i++){
			subSetI = SetI[k].PopSet();
			ProcessS(subSetI);
		}
		ProcessI();
	}
	
	/**
	 * Outputs finer detail to which interval belong already sent samples.
	 * @param number of points in the LSP in the previous loop.
	 * @return void
	 */
	public void Refinement(int LSPlength)throws IOException{
		int read;
		int value=0;
		SpeckSet LSPSet = null;
		LSPSet = new SpeckSet();
		boolean sign;
		
		LSPSet = LSP.top;
		for(int i=0; i<LSPlength; i++){
			sign = true;
			read = (int) input.readUBits(1);
			value = image[0][LSPSet.GetSetY()][LSPSet.GetSetX()];
			if (value<0){
				sign = false;
				value = Math.abs(value);
			}
			if(read == ONE){
				value += (int)maxThreshold/2;
				if(!sign) value = -value;
				image[0][LSPSet.GetSetY()][LSPSet.GetSetX()] = value;
			}	
			else{
				if (maxThreshold == 1) value -= 1;
				else value -= maxThreshold/2;
				if(!sign) value = -value;
				image[0][LSPSet.GetSetY()][LSPSet.GetSetX()] = value;
			}
			LSPSet = LSPSet.NextSet();
		}
	}
	            
	//***************************************************************//
	//***************************************************************//
	//****	       End of Speck Article Based Functions	     ****//
	//***************************************************************//
	//***************************************************************//

	/**
	 * Divides a set in 4 new subsets with identical size, or in the points that compose it.
	 *@param the original set
	 */

	protected SpeckVector QuadriSect(SpeckSet s){
		SpeckVector setsVector = null;
		setsVector = new SpeckVector();
		int setSizeX = s.GetSizeX();
		int setSizeY = s.GetSizeY();
		int setCoordX = s.GetSetX();
		int setCoordY = s.GetSetY();
		int subsetSizeX = 0;
		int subsetSizeY = 0;
		int k = 0;
		
		if ((setSizeX > 1) && (setSizeY > 1)){  //the set can be quadrisected
			
			for (int i=0; i<2; i++){
				for(int j=0; j<2; j++){
					
					subsetSizeX = (int) setSizeX/2;
					subsetSizeY = (int) setSizeY/2;
				
					SpeckSet tempSet = new SpeckSet();
					tempSet.SetX(setCoordX + (subsetSizeX * i));
					tempSet.SetY(setCoordY + (subsetSizeY * j));
					if (setSizeX % 2 == 1){
						 if (k > 1) subsetSizeX++;
					}
					if (setSizeY % 2 == 1){
						if (k == 1 || k == 3) subsetSizeY++;
					}
					tempSet.SetSize(subsetSizeX,subsetSizeY);
					setsVector.AddSet(tempSet);
					k++;
				}
			}
			
		}
		else{ //the set will be divided in points
			if (setSizeX == 1) {
				subsetSizeX = 0;
				subsetSizeY = 1;
			}
			else{
				subsetSizeX = 1;
				subsetSizeY = 0;
			}
			for(int i=0; i < (setSizeX*setSizeY); i++){  //all the set is divided
				SpeckSet tempSet = new SpeckSet();
				tempSet.SetX(setCoordX + (subsetSizeX * i));
				tempSet.SetY(setCoordY + (subsetSizeY * i));
				tempSet.SetSize(1,1);
				setsVector.AddSet(tempSet);
			}
			
		}
		return setsVector;
	}
	                                                     
}
