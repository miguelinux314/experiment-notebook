package Speck.SpeckDecoding;


/**
 * Arguments parser for SPModule decoder. This class analyses a string of arguments and extract and check its validity.
 * Usage example:<br>
 * &nbsp; construct<br>
 * &nbsp; [showArgsInfo]<br>
 * &nbsp; [get functions]<br>
 *
 * @author Daniel Rodrigo & Jorge Gonzalez-Conejero
 * @version 1.0 01/04/05
 */
public class ArgsParser{

	/**
	 * Arguments specificiation. The array describes argument, explain what is used and its default parameters. First index of array is argument; second specifies:<br>
	 *   <ul>
	 *     <li> 0 - short argument specification (i.e. "-b")
	 *     <li> 1 - long argument specification (i.e. "--blockSize")
	 *     <li> 2 - parsing specification of argument ({} indicates mandatority, [] optionality)
	 *     <li> 3 - default values
	 *     <li> 4 - mandatory argument ("1") or non mandatory argument ("0")
	 *     <li> 5 - explanation
	 *   </ul>
	 * <p>
	 * String arguments.
	 */
	String[][] argsSpecification = {
		{"-h", "--help", "", "", "0",
			"Displays this help and exits program."
		},
		{"-c", "--compareImage", "{string}", "", "0",
			"Input image. Valid formats are: pgm, ppm, pbm, jpg, tiff, png, bmp, gif, fpx. If image is raw data file extension must be \".raw\" and \"-g\" parameter is mandatory."
		},
		{"-g", "--imageGeometry", "{int int int int boolean}", "", "0",
			"Geometry of raw image data. Parameters are:\n    1 - zSize (number of image components)\n    2 - ySize (image height)\n    3 - xSize (image width)\n    4 - data type. Possible values are:\n      0- boolean (1 byte)\n      1- byte (1 byte)\n      2- char (2 bytes)\n      3- short (2 bytes)\n      4- int (4 bytes)\n      5- long (8 bytes)\n      6- float (4 bytes)\n      7- double (8 bytes)\n    5- 0 Big-Endian\n 1 Little-Endian\n    6 - 1 if 3 first components are RGB, 0 otherwise"
		},
		{"-o", "--outFile", "{string}", "same as input with new extensions", "0",
			"Output image file name."
		},
		{"-w", "--waveletTransformType", "{int[ int[ int[ ...]]]}", "", "1",
			"Discrete wavelet transform type for each image component. First value is for the first component, second value for the second component and so on. If only one value is specified, wavelete transform type will be the same for all components. Valid values are:\n    0 - No wavelet transform\n    1 - Reversible 5/3 DWT\n    2 - Irreversible 9/7 DWT"
		},
		{"-wl", "--waveletTransformLevels", "{int[ int[ int[ ...]]]}", "", "1",
			"Discrete wavelet transform levels for each image component. First value is for the first component, second value for the second component and so on. If only one value is specified, wavelete transform levels will be the same for all components."
		},
		{"-f", "--file", "{string}", "./workDir/default.coded", "0",
			"The input/output file to read/write the SPECK algorithm bitstream."
		},
		{"-t", "--threshold", "{int}", "0", "0",
			"The lowest threshold used by SPECK for checking significance"
		}
	};

	//ARGUMENTS VARIABLES
	String imageFile;
	String outFile;
	String fileName = "./workDir/default.coded";
	int minThr = 0;
	int[] imageGeometry = null;
	int[] WTTypes = null;
	int[] WTLevels = null;

	/**
	 * Class constructor that receives the arguments string and initializes all the arguments.
	 *
	 * @param args the array of strings passed at the command line
	 */
	public ArgsParser(String[] args) throws Exception{
		int argNum = 0;
		boolean[] argsFound = new boolean[argsSpecification.length];

		//Arguments parsing
		for(int i = 0; i < argsSpecification.length; i++){
			argsFound[i] = false;
		}
		while(argNum < args.length){
			int argFound = argFind(args[argNum]);
			// The parameter is correct
			if(argFound != -1){
				//The parameter is duplicate
				if(!argsFound[argFound]){
					argsFound[argFound] = true;
					int argOptions = argNum + 1;
					//How many arguments the parameter has
					while(argOptions < args.length){
						if(argFind(args[argOptions]) != -1){
							break;
						}else{
							argOptions++;
						}
					}
					int numOptions = argOptions - argNum;
					String[] options = new String[numOptions];
					System.arraycopy(args, argNum, options, 0, numOptions);
					argNum = argOptions;
					switch(argFound){
					case  0: //-h  --help
						showArgsInfo();
						System.exit(1);
						break;
					case  1: //-c  --compareImage
						imageFile = parseString(options);
						if(imageFile.endsWith(".raw")){
							argsSpecification[2][4] = "1";
						}
						break;
					case  2: //-g  --imageGeometry
						imageGeometry = parseIntegerArray(options, 6);
						break;
					case  3: //-o  --outFile
						outFile = parseString(options);
						break;
					case  4: //-w  --waveletTransformType
						WTTypes = parseIntegerArray(options);
						break;
					case  5: //-wl --waveletTransformLevels
						WTLevels = parseIntegerArray(options);
						break;
					case  6: //-f --file
						fileName = parseString(options);
						break;
					case  7: //-t --threshold
						minThr = parseIntegerPositive(options);
						break;
						
					default:
					    throw new Exception("OPTION NOT AVAIBLE");
					}
				}else{
					throw new Exception("Argument \"" + args[argNum] + "\" repeated.");
				}
			}else{
				throw new Exception("Argument \"" + args[argNum] + "\" unrecognized.");
			}
		}

		//Check mandatory arguments
		for(int i = 0; i < argsSpecification.length; i++){
			if(argsSpecification[i][4].compareTo("1") == 0){
				if(!argsFound[i]){
					throw new Exception("Argument \"" + argsSpecification[i][0] + "\" is mandatory (\"-h\" displays help).");
				}
			}
		}
	}

	/**
	 * Finds the argument string in arguments specification array.
	 *
	 * @param arg argument to find out in argsSpecification
	 * @return the argument index of argsSpecification (-1 if it doesn't exist)
	 */
	int argFind(String arg){
		int argFound = 0;
		boolean found = false;

		while((argFound < argsSpecification.length) && !found){
			if((arg.compareTo(argsSpecification[argFound][0]) == 0) || (arg.compareTo(argsSpecification[argFound][1]) == 0)){
				found = true;
			}else{
				argFound++;
			}
		}
		return(found ? argFound: -1);
	}

	/**
	 * This function shows arguments information to console.
	 */
	public void showArgsInfo(){
		System.out.println("Arguments specification: ");
		for(int numArg = 0; numArg < argsSpecification.length; numArg++){
			char beginMandatory = '{', endMandatory = '}';
			if(argsSpecification[numArg][4].compareTo("0") == 0){
				//No mandatory argument
				beginMandatory = '[';
				endMandatory = ']';
			}
			System.out.print("\n" + beginMandatory + " ");
			System.out.print("{" + argsSpecification[numArg][0] + "|" + argsSpecification[numArg][1] + "} " + argsSpecification[numArg][2]);
			System.out.println(" " + endMandatory);
			System.out.println("  Explanation:\n    " + argsSpecification[numArg][5]);
			System.out.println("  Default value: " + argsSpecification[numArg][3]);
		}
	}


	/////////////////////
	//PARSING FUNCTIONS//
	/////////////////////
	//These functions receives a string array that contains in its first position the argument and then its options//

	int parseIntegerPositive(String[] options) throws Exception{
		int value = 0;

		if(options.length == 2){
			try{
				value = Integer.parseInt(options[1]);
				if(value < 0){
					throw new Exception("\"" + options[1] + "\" of argument \"" + options[0] + "\" is must be a positive integer.");
				}
			}catch(NumberFormatException e){
				throw new Exception("\"" + options[1] + "\" of argument \"" + options[0] + "\" is not a parsable integer.");
			}
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes one option. Try \"-h\" to display help.");
		}
		return(value);
	}

	float parseFloatPositive(String[] options) throws Exception{
		float value = 0F;

		if(options.length == 2){
			try{
				value = Float.parseFloat(options[1]);
				if(value < 0){
					throw new Exception("\"" + options[1] + "\" of argument \"" + options[0] + "\" is must be a positive float.");
				}
			}catch(NumberFormatException e){
				throw new Exception("\"" + options[1] + "\" of argument \"" + options[0] + "\" is not a parsable float.");
			}
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes one option. Try \"-h\" to display help.");
		}
		return(value);
	}

	String parseString(String[] options) throws Exception{
		String value = "";

		if(options.length == 2){
			value = options[1];
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes one option. Try \"-h\" to display help.");
		}
		return(value);
	}

	int[] parseIntegerArray(String[] options) throws Exception{
		int[] value = null;

		if(options.length >= 2){
			value = new int[options.length - 1];
			for(int numOption = 1; numOption < options.length; numOption++){
				try{
						value[numOption - 1] = Integer.parseInt(options[numOption]);
				}catch(NumberFormatException e){
					throw new Exception("\"" + options[numOption] + "\" of argument \"" + options[0] + "\" is not a parsable integer.");
				}
			}
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes one or more options. Try \"-h\" to display help.");
		}
		return(value);
	}

	int[] parseIntegerArray(String[] options, int numOptions) throws Exception{
		int[] value = null;

		if(options.length == numOptions+1){
			value = new int[options.length - 1];
			for(int numOption = 1; numOption < options.length; numOption++){
				try{
						value[numOption - 1] = Integer.parseInt(options[numOption]);
				}catch(NumberFormatException e){
					throw new Exception("\"" + options[numOption] + "\" of argument \"" + options[0] + "\" is not a parsable integer.");
				}
			}
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes " + numOptions +" options. Try \"-h\" to display help.");
		}
		return(value);
	}

	float[] parseFloatArray(String[] options) throws Exception{
		float[] value = null;

		if(options.length >= 2){
			value = new float[options.length - 1];
			for(int numOption = 1; numOption < options.length; numOption++){
				try{
						value[numOption - 1] = Float.parseFloat(options[numOption]);
				}catch(NumberFormatException e){
					throw new Exception("\"" + options[numOption] + "\" of argument \"" + options[0] + "\" is not a parsable float.");
				}
			}
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes one or more options. Try \"-h\" to display help.");
		}
		return(value);
	}

	float[] parseFloatArray(String[] options, int numOptions) throws Exception{
		float[] value = null;

		if(options.length == numOptions+1){
			value = new float[options.length - 1];
			for(int numOption = 1; numOption < options.length; numOption++){
				try{
						value[numOption - 1] = Float.parseFloat(options[numOption]);
				}catch(NumberFormatException e){
					throw new Exception("\"" + options[numOption] + "\" of argument \"" + options[0] + "\" is not a parsable float.");
				}
			}
		}else{
			throw new Exception("Argument \"" + options[0] + "\" takes " + numOptions + " options. Try \"-h\" to display help.");
		}
		return(value);
	}


	///////////////////////////
	//ARGUMENTS GET FUNCTIONS//
	///////////////////////////

	public String getCompareImage(){
		return(imageFile);
	}
	public String getOutFile(){
		return(outFile);
	}
	public int[] getImageGeometry(){
		return(imageGeometry);
	}
	public int[] getWTTypes(){
		return(WTTypes);
	}
	public int[] getWTLevels(){
		return(WTLevels);
	}
	public String getFileName(){
		return(fileName);
	}
	public int getMinThr(){
		return(minThr);
	}
}

