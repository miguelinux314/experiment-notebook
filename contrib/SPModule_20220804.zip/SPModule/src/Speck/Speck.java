package Speck;
import Speck.SpeckVector.SpeckDynamV;
import GiciBitStream.BitOutputStream;


/**
 * Class from the SPECK algorithm. <p>
 * This class contains all the common methods and
 * attributes for decoding and coding algorithms. <p>
 * @see HyperFile
 * @author Daniel Rodrigo & Jorge Gonzalez-Conejero
 * @version 1.1 13/05/05
 */
 
 
 
public class Speck {
	
	
	
	/**
	 * Defines the symbols to write in the output stream.
	  *        <ul>
	  *          <li> ZERO - Insignificant
	  *          <li> ONE - Significant
	  *          <li> POS - Positive coefficient
	  *          <li> NEG - Negative coefficient
	  *        </ul>
	 * <p>
	 * Only the four symbols of the SPECK algorithm are allowed
	 */
	protected final static byte ZERO = 0,
			ONE = 1,
			POS = 1,
			NEG = 0;
		
	/**
	 * Defines length of the initial header in the SPECK bit stream files.
	  *        <ul>
	  *          <li> x - 16 bits
	  *          <li> y - 16 bits
	  *          <li> z - 16 bits
	  *          <li> levels - 4 bits
	  *          <li> method - 1 bit
	  *          <li> initial threshold - 4 bits
	  *        </ul>
	 * <p>
	 * Static attribute
	 */
	protected static final int xBits = 16,
			yBits = 16,
			zBits = 16,
			levelsBits = 4,
			thresholdBits = 5;
			
	/**
	 * Number of possible subset sizes.
	 *<p>
	 * Negative values are not allowed. Restricted by image size.
	 */
	protected int SetSizes = 0;
	
	/**
	 * Returns the current <code>SetSizes</code>
	 * @return current SetSizes
	 */		
	public int getSetSizes() {
		   return SetSizes;
	}
	/**
	 * Sets the current number of <code>SetSizes</code>
	 * @param the current number of possible set sizes.
	 */
	public void setSetSizes(int SetSizes) {
		this.SetSizes = SetSizes;
	}
	/**
	 * Stores the method that we use for quadrisecting sets.
	 *        <ul>
	 *          <li> 0 - Recursive method
	 *          <li> 1 - Iterarive method
	 *	    <li> 2 - 3/4 method
	 *        </ul>
	 * <p>
	 * Only three methods are allowed.
	 */
	protected int method = 0;
	
	/**
	 * The number of levels that we apply in the discrete wavelet transform.
	 * <p>
	 * Negative values are not allowed. The number of levels are restricted by the image dimensions
	 */
	protected int WTlevels = 0;
	
	/**
	 * Returns the current number of <code>levels</code>
	 * @return current number of levels
	 */
	public int getWTLevels() {
		   return WTlevels;
	}
	/**
	 * Sets the current number of <code>levels</code>
	 * @param the current number of levels
	 */
	public void setWTLevels(int WTlevels) {
		this.WTlevels = WTlevels;
	}

	/**
	 * Maximum threshold.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int maxThreshold = 0;
	
	/**
	 * Returns the current <code>threshold</code>
	 * @return current threshold
	 */
	public int getMThreshold() {
		return maxThreshold;
	}
	
	/**
	 * Sets the current <code>threshold</code> in an object <code>.
	 * @param the new current threshold
	 */
	public void setMThreshold(int maxThreshold) {
		this.maxThreshold = maxThreshold;
	}
	
	
	/**
	 * The width of the input image.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int xSize = 0;
	
	/**
	 * Returns the width of the image
	 * <p>
	 * @return the width of the image
	 */
	public int getXSize() {
		   return xSize;
	}
	
	/**
	 * Sets the width of the image
	 * <p>
	 * @param the width of the image
	 */
	public void setXSize(int xSize) {
		   this.xSize = xSize;
	}
	
	/**
	 * The height of the input image.
	 * <p>
	 * Negative values are not allowed.
	 */
	protected int ySize = 0;
	
	/**
	 * Returns the height of the image
	 * <p>
	 * @return the height of the image
	 */
	public int getYSize() {
		   return ySize;
	}
	
	/**
	 * Sets the height of the image
	 * <p>
	 * @return the height of the image
	 */
	public void setYSize(int ySize) {
		   this.ySize = ySize;
	}
	/**
	 * The number of bands of the input image.
	 * <p>
	 * Negative values are not allowed.
	 */
	 protected int zSize ;
	 /**
	 * Returns the number of bands of the image
	 * <p>
	 * @return the number of bands of the image
	 */
	public int getZSize() {
		   return zSize;
	}
	
	/**
	 * Sets the number of bands of the image
	 * <p>
	 * @return the number of bands of the image
	 */
	public void setZSize(int zSize) {
		   this.zSize = zSize;
	}
	/**
	 * The image to process.
	 * <p>
	 * Only an array of integers is allowed.
	 */
	protected int[][][] image = null;
	
	/**
	 * Sets the image to code.
	 * @param the new image
	 */
	public void setImage(int[][][] image) {
		this.image = null;
		this.image = image;
				
		ySize = image[0].length;
		xSize = image[0][0].length;
	}
	/**
	 *Outputs the image.
	 * @return the coding image. 
	 */
	public int[][][] getImage() {
		return image;
	}
	
	/**
	 * List of insignificant subsets.
	 * <p>
	 * This dynamic list contains the insignificant subsets of the input image.
	 */
	protected SpeckDynamV LIS ;
	/**
	 * List of significant pixels.
	 * <p>
	 * This list contains the significant pixels of the input image.
	 */
	protected SpeckVector LSP ;
	
	/**
	 * List of subsets.
	 * <p>
	 * This list contains the subsets of the input image except the root.
	 */
	protected SpeckVector[] SetI;
	
	/** 
	  * Constructor for the SPECK class.
	  */
	public Speck() {
		
	}
	
	
}
