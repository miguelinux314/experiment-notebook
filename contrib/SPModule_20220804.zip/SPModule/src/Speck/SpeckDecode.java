package Speck;

import GiciTransform.*;
import GiciFile.*;
import GiciAnalysis.*;
import java.io.IOException;
import Speck.SpeckDecoding.*;

/**
 * Main class of the SpeckDecode application.
 * <p>
 * @see Speck.SpeckCoding.SpeckDecoding2D 
 * @author Daniel Rodrigo, Jorge Gonzalez-Conejero
 * @version 1.0 01/04/05
 */
public class SpeckDecode {
	/**
	 * Main method of SpeckDecode application. It takes program arguments, loads image and runs Speck decoder.
	 *
	 * @param args an array of strings that contains program parameters
	 */
	public static void main(String[] args){
		ArgsParser arguments = null;
		
		try {
			arguments = new ArgsParser(args);
		} catch (Exception e) {
			System.out.println("ARGUMENTS ERROR: " + e.getMessage());
			System.exit(1);
		}
		
		//GET ARGUMENTS
		int[] WTLevels = arguments.getWTLevels();
		int[] WTTypes = arguments.getWTTypes();
		int minThr = arguments.getMinThr();
		//DECODER
		float[][][] imageSamplesFloat = null;
		int[][][] imageSamplesInt = null;
	
		//////////////////////////////////
		//Place for the decoder code//////
		//////////////////////////////////
		try{
			SpeckDecoding2D spk = new SpeckDecoding2D();
			spk.setParameters(minThr,arguments.getFileName());
			spk.run();
			
			imageSamplesInt = spk.getImage();
			
				
		}catch (Exception e) {
			System.out.println("An exception ocurred in the decode process: " + e.getMessage());
			System.exit(1);
		}
		
		//DISCRETE WAVELET TRANSFORM
		float[][][] imageSamples = null;
		try {
			InverseWaveletTransform wt = new InverseWaveletTransform(integerToFloat(imageSamplesInt));
			wt.setParameters(WTTypes, WTLevels);
			
			imageSamples = wt.run();
			wt = null;
		} catch (Exception e) {
			System.out.println("DISCRETE WAVELET TRANSFORM ERROR: " + e.getMessage());
			System.exit(4);
		}
		
		//IMAGE COMPARE
		String compareFile = arguments.getCompareImage();
		if(compareFile != null){
			LoadFile imageCompare = null;
			try{
				//Loads image to compare with recovered samples
				if(compareFile.endsWith(".raw")){
					int[] imageGeometry = arguments.getImageGeometry();

					//Check parameters of image geometry
					if((imageGeometry[0] <= 0) || (imageGeometry[1] <= 0) || (imageGeometry[2] <= 0)){
						throw new Exception("Image dimensions in \".raw\" data files must be positive (\"-h\" displays help).");
					}
					if((imageGeometry[3] < 0) || (imageGeometry[3] > 7)){
						throw new Exception("Image type in \".raw\" data must be between 0 to 7 (\"-h\" displays help).");
					}
					if((imageGeometry[4] != 0) && (imageGeometry[4] != 1)){
						throw new Exception("Image Endian specification in \".raw\" data must be between 0 or 1 (\"-h\" displays help).");
					}
					if((imageGeometry[5] != 0) && (imageGeometry[5] != 1)){
						throw new Exception("Image RGB specification in \".raw\" data must be between 0 or 1 (\"-h\" displays help).");
					}
					imageCompare = new LoadFile(compareFile, imageGeometry[0], imageGeometry[1], imageGeometry[2], imageGeometry[3], imageGeometry[4], imageGeometry[5] == 0 ? false: true);
				}else{
					imageCompare = new LoadFile(compareFile);
				}

				//Compare samples and extracts MSE and PSNR
				Class[] sampleTypes = imageCompare.getTypes();
				//All image components must use same sample type
				boolean equalTypes = true;
				for(int z = 1; z < imageSamples.length;z++){
					if(sampleTypes[z-1] != sampleTypes[z]){
						equalTypes = false;
					}
				}
				if(equalTypes){
					//Before comparison a round will be done in image samples
					int[] type = new int[1];
					type[0] = 16;
					if(sampleTypes[0] == Byte.TYPE){
						type[0] = 8;
					}else{
						if(sampleTypes[0] == Integer.TYPE){
							type[0] = 32;
						}else{
							if(sampleTypes[0] == Character.TYPE || sampleTypes[0] == Short.TYPE){
								type[0] = 16;
							}else{
								System.out.println("Wrong image type");
								System.exit(1);
							}
						}
					}

					ImageCompare ic = new ImageCompare(imageCompare.getImage(), imageSamples, type);
					float totalMSE = ic.getTotalMSE();
					float totalPSNR = ic.getTotalPSNR();
					float totalSNR = ic.getTotalSNR();
					System.out.print(totalPSNR + " " + totalMSE + "\n");
				}else{
					System.err.println("IMAGE COMPARE ERROR: Sample type of all image components must be the same.");
				}
			}catch(Exception e){
				System.err.println("IMAGE COMPARE ERROR: " + e.getMessage());
			}
			}
		
		//RANGE CHECK (Only for 8-bit depth images)
		/*for(int z =  0; z < imageSamples.length; z++){
			for(int y = 0; y < imageSamples[z].length; y++){
				for(int x = 0; x < imageSamples[z][y].length; x++){
					if(imageSamples[z][y][x] < 0){
						imageSamples[z][y][x] = 0f;
						//System.out.println("RangeCheck");
					}
					if(imageSamples[z][y][x] > 255){
						imageSamples[z][y][x] = 255f;
						//System.out.println("RangeCheck");
					}
				}
			}
		}*/

		//RECOVERED SAMPLES SAVE IN RAW FILE
		String outFile = arguments.getOutFile();
		if(outFile != null){
			try{
				if(outFile.endsWith(".raw")) {
					SaveFile.SaveFileRaw(imageSamples, outFile,arguments.getImageGeometry()[3],0);
				}
				else if (outFile.endsWith(".pgm")) {
					SaveFile.SaveFileFormat(imageSamples, outFile, 0);
				}
				else {
					System.out.println("The image type is not avaible to save.");
				}
			}catch(Exception e){
				System.err.println("IMAGE SAVING ERROR: " + e.getMessage());
			}
		}
	}
	/**
	 * Auxiliar method from the Spiht decode main class to chage the coefficients type. The discrete wavelet transform uses
	 * float coefficients and the Spiht provides integer values, this method makes the necessary changes to send the decoded
	 * bitstream result to the inverse discrete wavelet transform.
	 *
	 * @param src the image with integer coefficients
	 * @return the input image with the new type
	 */
	private static float[][][] integerToFloat(int[][][] src){
		int zSize = src.length;
		int ySize = src[0].length;
		int xSize = src[0][0].length;
		
		float dst[][][] = new float[zSize][ySize][xSize];
		
		for (int z=0; z < zSize; z++) {
			for (int y=0; y < ySize; y++) {
				for (int x=0; x < xSize; x++) {
					dst[z][y][x]=((float) (src[z][y][x]));
					}
			}
		}
		return dst;
	}

}
