package GiciBitStream;

import java.io.File;
import java.io.RandomAccessFile;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.EOFException;

/** An implementation of RandomAccesFile class bit oriented.
  * @see java.io.RandomAccesFile
  * @see SpihtModule.io.MultiInputStream
  * @author Jorge Gonzalez-Conejero
  * @version 1.0 11/12/2003
  */ 
public class BitRandomAccessFile extends RandomAccessFile {
	/** 
	  * Mask size for bit operations.
	  */
	final protected static int MASK_SIZE = 8;
	/** 
	  * Mask of zeros for bit operations.
	  */
	final protected static int ZERO = 0;
	/** 
	  * Mask of ones for bit operations.
	  */
	final protected static int ONES = ~0;
	/** 
	  * Array of masks for bit operations.
	  */
	final protected static int[] BIT_MASK = new int[MASK_SIZE];
	/** 
	  * Field of masks for bit operations.
	  */
	final protected static int[] FIELD_MASK = new int[MASK_SIZE];
	
	/** 
	  * Generate the needed masks for various bit fields and for individual bits.
	  */
	static {
		int tempBit = 1;
		int tempField = 1;
		for (int i=0; i<MASK_SIZE; i++) {
			// Set the masks.
			BIT_MASK[i] = tempBit;
			FIELD_MASK[i] = tempField;
			
			// Update the temporary values.
			tempBit <<= 1;
			tempField <<= 1;
			tempField++;
		}
	}
	/**
	* This is a prefetched byte used to construct signed and unsigned
	* numbers with an arbitrary number of significant bits. */
	private int bits;
	
	/**
	* The number of valid bits remaining in the bits field. */
	private int validBits;
	
	/** Creates an instance of the algorithm and initialize the fields.
	  * @param f the file to open
	  * @param mode mode to open the file
	  */
	public BitRandomAccessFile(File f, String mode) throws FileNotFoundException {
		super(f, mode);
		
		bits = 0;
		validBits = 0;
	}
	/**
	  * A utility method to fetch the next byte in preparation for
	  * constructing a bit field.  There is no protection for this
	  * method; ensure that it is only called when a byte must be
	  * fetched.
	  * @return void
	  */
	protected void fetchByte() throws IOException {
		bits = read();
		if (bits < 0) throw new EOFException();
		validBits = MASK_SIZE;
	}
	
	/**
	  * A utility to force the next read to be byte-aligned.
	  * @return void
	  */
	public void byteAlign() {
		validBits = 0;
	}
	
	/**
	  * Read a bit from the input stream and interpret this as a
	  * boolean value,  A 1-bit is true; a 0-bit is false.
	  */
	public boolean readBitFlag() throws IOException {
		if (validBits==0) fetchByte();
		return ((bits & BIT_MASK[--validBits])!=0);
	}
	
	/**
	  * Read a signed value of n-bits from the input stream. */
	public long readSBits(int n) throws IOException {
		if (n == 0) return 0;
		long value = (readBitFlag()) ? ONES : ZERO;
		value <<= (--n);
		return (value | readUBits(n));
	}
	
	/**
	  * Read a float value of n-bits from the stream. */
	public float readFBits(int n) throws IOException {
		if (n == 0) return 0.0f;
		int value = (readBitFlag()) ? ONES : ZERO;
		value <<= (--n);
		return (float)(value | readUBits(n))/(float)0x10000;
	}
	
	public void positionInBits(long newPos) throws IOException {
		int bits;
		validBits = 0;
		bits = (int) (newPos % 8);
		//System.out.println("Pos en el byte: " + bits);
		seek((int) (newPos / 8));
		if(bits != 0) {
			bits = (int) readUBits(bits);
		}
		
	}
	
	/**
	  * Read an unsigned value of n-bits from the input stream. */
	public long readUBits(int n) throws IOException {
		long value = ZERO;
		while (n>0) {
			// Take the needed bits or the number which are valid
			// whichever is less.
			if (validBits==0) fetchByte();
			int nbits = (n>validBits) ? validBits : n;
			
			// Take the bits and update the counters.
			int temp = ((bits>>(validBits-nbits)) & FIELD_MASK[nbits-1]);
			validBits -= nbits;
			n -= nbits;
			
			// Shift the value up to accomodate new bits.
			value <<= nbits;
			value |= temp;
		}
		return value;
	}
}
