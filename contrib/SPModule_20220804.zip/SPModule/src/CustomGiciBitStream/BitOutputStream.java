// Copyright 2001, FreeHEP.
package GiciBitStream;

import java.io.EOFException;
import java.io.FilterOutputStream;
import java.io.OutputStream;
import java.io.IOException;

/**
 * Class to write bits to a Stream, allowing for byte synchronization.
 * Signed, Unsigned, Booleans and Floats can be written.
 *
 * <p>Corrections: David Gavilan
 * <p>Methods added: Jorge Gonzalez
 * @author Mark Donszelmann
 * @author Charles Loomis
 * @version $Id: BitOutputStream.java,v 1.1.1.1 2002/12/13 16:41:05 root Exp $
 */
public class BitOutputStream extends FilterOutputStream implements FinishableOutputStream {

    protected int bits;
    protected int bitPos;
	
	/** Attributes added by Jorge Gonzalez */
	public static final int ZERO=0, ONE=1;
	protected long target = 0;
	protected boolean rateTarget = false;
	protected long streamSize = 0;

    public BitOutputStream(OutputStream out) {
        super(out);
		
        bits = 0;
        bitPos = 0;
		rateTarget = false;
		target = 0;
		streamSize = 0;
    }
	
	/**
	  * Constructor added by Jorge Gonzalez to specify a rate Target for the file.
	  * Class to write bits to a Stream, allowing for byte synchronization.
	  * Signed, Unsigned, Booleans and Floats can be written.
	  *
	  */
    public BitOutputStream(OutputStream out, long target) {
        super(out);
		
        bits = 0;
        bitPos = 0;
		if(target != 0) {
			this.rateTarget = true;
			this.target = target;
		}
		else rateTarget = false;
		
		streamSize = 0;
    }

    public void finish()
        throws IOException {

        flushByte();
    }

    public void close()
        throws IOException {

        finish();
        super.close();
    }

    /**
     * A utility method to flush the next byte */
    protected void flushByte()
        throws IOException {

        if (bitPos == 0) return;

        out.write(bits);
        bits = 0;
        bitPos = 0;
    }

    /**
     * A utility to force the next write to be byte-aligned. */
    public void byteAlign() throws IOException {
        flushByte();
    }

    /**
     * Write a bit to the output stream.
     * A 1-bit is true; a 0-bit is false. */
    public void writeBitFlag(boolean bit)
        throws IOException {

        writeUBits((bit) ? 1 : 0, 1);
    }

    /**
     * Write a signed value of n-bits to the output stream. */
    public void writeSBits(long value, int n)
        throws IOException {

        long tmp = value & 0x7FFFFFFF;

        if (value < 0) {
            tmp |= (1L << (n-1));
        }

        writeUBits(tmp, n);
    }

    /**
     * Write a float value of n-bits to the stream. */
    public void writeFBits(float value, int n)
        throws IOException {

        if (n == 0) return;
        long tmp = (long)(value * (float)0x10000);
        writeUBits(tmp, n);
    }

    /**
     * Write an unsigned value of n-bits to the output stream. */
    public void writeUBits(long value, int n) throws IOException {
		
        if (n == 0) return;
        if (bitPos == 0) bitPos = 8;
		
        int bitNum = n;
		
        while (bitNum > 0) {
            while ((bitPos > 0) && (bitNum > 0)) {
                long or = (value & (1L << (bitNum - 1)));
                int shift = bitPos-bitNum;
                if (shift < 0) {
                    or >>= -shift;
                } else {
                    or <<= shift;
                }
                bits |= or;

                bitNum--;
                bitPos--;
            }
			
			if( bitPos == 0 ) {
                write(bits);
                bits = 0;
                if (bitNum > 0) bitPos = 8;
				
				streamSize++;
				//Conditional structure added by Jorge Gonzalez
				if(rateTarget && (streamSize >= target)) {
					throw new IOException("Target: " + target + " (bytes) Size: " + streamSize + " (bytes)");
				}
            }
        }
    }
	/**
      * Writes just one multi to the output stream (1, 2 or 3 bits).
      * @param multi a number in {0,1,2,3} == {ZERO, ONE, PLUS, MINUS, SEPARATOR}
      */
    public void writeMulti(int multi) throws IOException {
		/* Write the multi using the min number of bits which are necessary to 
		represent the current number of simbols*/
		
		writeUBits(multi,1);
    }
    /**
     * calculates the minumum number of bits necessary to
     * write number.
     *
     * @param number number
     * @return minimum number of bits to store number
     */
    public static int minBits(int number) {
        return minBits((long)number);
    }

    public static int minBits(float number) {
        return minBits((int)(number / 0x10000)) + 16;
    }

    public static int minBits(long number) {
        boolean signed = number < 0;
        number = Math.abs(number);

        long x = 1;
        int i;

        for(i = 1; i <= 64; i++) {
            x <<= 1;
            if (x > number) break;
        }

        return i + ((signed) ? 1 : 0);
    }
}
