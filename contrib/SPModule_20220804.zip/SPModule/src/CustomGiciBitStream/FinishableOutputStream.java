// Copyright 2001, FreeHEP.
package GiciBitStream;

import java.io.*;

/**
 * The FinishableOutputStream allows a generic way of calling finish on an
 * output stream without closing it.
 * 
 * @author Mark Donszelmann
 * @version $Id: FinishableOutputStream.java,v 1.1.1.1 2002/12/13 16:41:05 root Exp $
 */
public interface FinishableOutputStream {
    public void finish() throws IOException;
}
