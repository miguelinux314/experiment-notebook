package GiciImageExtension;


import GiciException.*;

/**
 * This class receives an image and delete the files and columns extended during compression process.<br>
 * Usage example:<br>
 * &nbsp; construct<br>
 * &nbsp; set functions<br>
 * &nbsp; run<br>
 *
 * @author WaveGis Project
 * @version 1.0
 */
public class ImageDeExtension{

	/**
	 * Definition in Coder
	 */
	float[][][] imageSamples = null;

	/**
	 * Definition in Coder
	 */
	int zSize;

	/**
	 * Definition in Coder
	 */
	int ySize;

	/**
	 * Definition in Coder
	 */
	int xSize;

	/**
	 * Definition in Coder
	 */
	int zOriginalSize;

	/**
	 * Definition in Coder
	 */
	int yOriginalSize;

	/**
	 * Definition in Coder
	 */
	int xOriginalSize;
	
	/**
	 * To know if parameters are set.
	 * <p>
	 * True indicates that they are set otherwise false.
	 */
	boolean parametersSet = false;


	/**
	 * Constructor that receives the original image samples.
	 *
	 * @param imageSamples definition in Coder
	 */
	public ImageDeExtension(float[][][] imageSamples){
		//Image data copy
		this.imageSamples = imageSamples;

		//Size set
		zSize = imageSamples.length;
		
		
	
	}

	/**
	 * Set the parameters used to do the normalization operation
	 *
	 * @param  imageExtensionType definition in this class
	 * @param  DWTLevels definition in IDCCoder/Transform/WaveletTransform
	 */
	public void setParameters(int xOriginalSize, 
									  int yOriginalSize, int zOriginalSize){
		parametersSet = true;

		//Parameters copy
		this.xOriginalSize = xOriginalSize;
		this.yOriginalSize = yOriginalSize;
		this.zOriginalSize = zOriginalSize;
	}
  
// 	/**
// 	 * Verify Parameters defined in this class
// 	 *
// 	 * @param  imageExtensionType defined in this class
// 	 *
// 	 * @return a boolean that indicates if the parameters are allowed
// 	 */
// 	public static boolean verifyParameters(
// 		int xOriginalSize, int xSize,
// 		int yOriginalSize, int ySize,
// 		int zOriginalSize, int zSize
// 		){
		
// 		if (xSize - xOriginalSize < 0){
// 			return false;				
// 		}
// 		if (ySize - yOriginalSize < 0){
// 			return false;				
// 		}
// 		if (zSize - zOriginalSize < 0){
// 			return false;				
// 		}
// 		return true;
// 	}
	
	/**
	 * Inversion of the extension 
	 *
	 * @return the deExtended image
	 */
	public float[][][] run() throws Exception{
		//If parameters are not set run cannot be executed
		if(!parametersSet){
			throw new ParameterException("ImageDeExtension cannot run if parameters are not set.");
		}
// 		if( !verifyParameters() ){
// 			throw new ParameterException("Original Sizes are bigger than the extended ones");
// 		}

		float[][][] cropedImage = new float[zOriginalSize][yOriginalSize][xOriginalSize];
		int zSize = imageSamples.length;
		if( zSize < zOriginalSize ){//given sizes are not proper to crop the image
			throw new ParameterException("zOriginalSize parameter was not properly set.");
		}
		for(int z=0; z < zOriginalSize ; z++){
			int ySize = imageSamples[z].length;
			if( ySize < yOriginalSize ){//given sizes are not proper to crop the image
				throw new ParameterException("yOriginalSize parameter was not properly set.");
			}
			for(int y=0; y < yOriginalSize ; y++ ) {
				int xSize = imageSamples[z][y].length;
				if( xSize < xOriginalSize ){//given sizes are not proper to crop the image
					throw new ParameterException("xOriginalSize parameter was not properly set.");
				}
				for (int x=0; x < xOriginalSize ; x++ ){
					cropedImage[z][y][x] = imageSamples[z][y][x];
				}
			}
		}

		//Return the croped image
		return(cropedImage);
	}

}
