package GiciImageExtension;



/**
 * This class receives an image and performs an extension to the specified components.<br>
 * Usage example:<br>
 * &nbsp; construct<br>
 * &nbsp; set functions<br>
 * &nbsp; run<br>
 *
 * @author WaveGis Project
 * @version 1.0
 */
public class ImageExtension{

	/**
	 * Definition in Coder
	 */
	float[][][] imageSamples = null;

	/**
	 * Definition in Coder
	 */
	int zSize;

	/**
	 * Definition in Coder
	 */
	int ySize;

	/**
	 * Definition in Coder
	 */
	int xSize;

	/**
	 * Extension Type.
	 * <p>
	 * Following values are allowed : 0 - Repeat last value (CCSDS Recommended). 1 - Symmetric extension. 2. - No Extension. 
	 */
	int[] imageExtensionType = null;

	/**
	 * Definition in IDCCoder/Transform/WaveletTransform
	 */
	int[] WTLevels = null ;
	
	/**
	 * To know if parameters are set.
	 * <p>
	 * True indicates that they are set otherwise false.
	 */
	boolean parametersSet = false;

	/**
	 * Definition in SegmentCoder/SegmentManager
	 */
	int[] PadRows = null;
	
	/**
	 * Constructor that receives the original image samples.
	 *
	 * @param imageSamples definition in Coder
	 */
	public ImageExtension(float[][][] imageSamples){
		//Image data copy
		this.imageSamples = imageSamples;

		//Size set
		zSize = imageSamples.length;
		ySize = imageSamples[0].length;
		xSize = imageSamples[0][0].length;
	}

	/**
	 * Set the parameters used to do the normalization operation
	 *
	 * @param  imageExtensionType definition in this class
	 * @param  WTLevels definition in IDCCoder/Transform/WaveletTransform
	 */
	public void setParameters(int[] imageExtensionType, int[] WTLevels){
		parametersSet = true;

		//Parameters copy
		this.imageExtensionType = imageExtensionType;
		this.WTLevels = WTLevels;
	}
  

	/**
	 * Indicates whether image extension must be applied 
	 *
	 * @param  imageExtensionType definition in this class
	 * @param  WTLevels definition in IDCCoder/Transform/WaveletTransform
	 * @param  xSize integer containing the width of the original image
	 * @param  ySize integer containing the height of the original image
	 * @param  zSize number of components
	 *
	 * @return a boolean that indicates if extension must be performed
	 */
	public static boolean needImageExtension(int[] imageExtensionType, int[] WTLevels,
														  int xSize, int ySize, int zSize){
		
		for(int z=0 ; z < zSize  ; z++){
			if ( imageExtensionType[z]!=2 && WTLevels[z]!=0){
				int requiredLines = ((int) 1 << WTLevels[z]); //2^(WTLevels[z]) 
				int requiredColumns = ((int) 1 << WTLevels[z]); //2^(WTLevels[z]) 
				if( ySize%requiredLines!=0 || xSize%requiredColumns!=0 ){
					return true ; 
				}
			}
		}
			
		return false;
	}
	
	/**
	 * Finds the index to extend a vector according to the type selected
	 *
	 * @param indexToExtend index of the extended position
	 * @param originalSize size of the original signal
	 * @param extensionType type of extension
	 *
	 * @return an integer corresponding to the index in the original of the position that is located the value of the extended position  
	 */
	public int getExtendedIndex (int indexToExtend, 
										  int originalSize, int extensionType)
		throws Exception {
		if ( indexToExtend >=0 && indexToExtend < originalSize ){
			return indexToExtend;
		} else if(extensionType == 0){
			return originalSize - 1 ;
		} else if (extensionType == 1){
			/*int index = (2*(originalSize - 1) ) - indexToExtend;
			  if ( index<0 || index >= originalSize ){
			  throw new Exception("The size of the image do not allow a symmetric extension.");
			  }*/
			int index = indexToExtend;
			while ( index<0 || index >= originalSize ){
				if ( index<0 ){
					index = -index;
				} else { // index >= originalSize
					index = (2*(originalSize - 1) ) - index;
				}					
			}
			return index;
		} 
		return -1;
	}

	/**
	 * Performs the extension desired to each component
	 *
	 * @return the extended image
	 */
	public float[][][] run() throws Exception{
		//If parameters are not set run cannot be executed
		if(!parametersSet){
			throw new Exception("ImageExtension cannot run if parameters are not set.");
		}
		this.PadRows = new int[zSize];
		float[][][] extendedImage = new float[zSize][][];
		for(int z=0; z < zSize ; z++){
			int linesToAdd = 0;
			int columnsToAdd = 0;
			if (imageExtensionType[z]!=2 && WTLevels[z]!=0 ){ //extension is needed
				int requiredLines = ((int) 1 << WTLevels[z]); //2^(WTLevels[z]) 
				int requiredColumns = ((int) 1 << WTLevels[z]); //2^(WTLevels[z])
				if( ySize%requiredLines!=0){ 
					linesToAdd = requiredLines - ySize%requiredLines;
				}
				if( xSize%requiredColumns!=0 ){
					columnsToAdd = requiredColumns - xSize%requiredColumns;
				}
			}
				
			int extendedySize = ySize + linesToAdd ;
			int extendedxSize = xSize + columnsToAdd ;
			PadRows[z] = linesToAdd; //number of padding rows added to perform the extension
			extendedImage[z] = new float[extendedySize][extendedxSize];
						
			//extension
			for(int y=0; y < ySize ; y++ ) {
				for (int x=0; x < xSize ; x++ ){
					extendedImage[z][y][x] = imageSamples[z][y][x];
				}
	
				//horizontal extension
				
				for(int x=xSize ; x < extendedxSize ; x++ ){
					int index = getExtendedIndex(x, xSize, imageExtensionType[z]);
					extendedImage[z][y][x] = imageSamples[z][y][index];											
				}
			}
					
			//vertical extension
			for(int y=ySize; y < extendedySize ; y++ ) {
				for(int x=0 ; x < extendedxSize ; x++ ){
					int indexX = getExtendedIndex(x, xSize, imageExtensionType[z]);
					int indexY = getExtendedIndex(y, ySize, imageExtensionType[z]);
					extendedImage[z][y][x] = imageSamples[z][indexY][indexX];											
				}
			}
		}
	
		
				
		
/*	for(int z=0; z < zSize ; z++){
	if ( imageExtensionType[z] !=2 ){
					
	int requiredLines = 1 ;
	int requiredColumns = 1 ;
	int index ;
	for( int k=0 ; k < WTLevels[z] ; k++ ){ 
	//Calculation of the minimum number of lines and columns 
	//required to create a block when WTKLevels[z] WT levels 
	//are applied
	requiredLines *=2 ;
	requiredColumns *=2 ;
	}
	//horizontal extension
	if( xSize%requiredColumns != 0 ){//extension is required
	int columnsToAdd = requiredColumns - xSize%requiredColumns;
	int extendedSize = xSize + columnsToAdd ;
							
	for(int y=0; y < ySize ; y++ ) {
	float[] extendedLine = new float[extendedSize] ;
	for (int x=0; x < xSize ; x++ ){
	extendedLine[x] = imageSamples[z][y][x];
	}
	//extension
	for(int x=xSize ; x < extendedSize ; x++ ){
	index = getExtendedIndex(x, xSize, imageExtensionType[z]);
	//extendedLine[x] = imageSamples[z][y][index];											
	}
	imageSamples[z][y] = null;
	imageSamples[z][y] = extendedLine ;
	}
	}
					
	//vertical extension
	if( ySize%requiredLines != 0 ){//extension is required
	int linesToAdd = requiredLines - ySize%requiredColumns;
	int extendedSize = ySize + linesToAdd ;
	float[][] extendedComponent = new float[extendedSize][];
	for(int y=0; y < ySize ; y++ ) {
	extendedComponent[y] = imageSamples[z][y];
	}
	for(int y=ySize; y < extendedSize ; y++){
	index = getExtendedIndex(y, ySize, imageExtensionType[z]);
	extendedComponent[y] = imageSamples[z][index];
	}
	imageSamples[z] = null;
	imageSamples[z] = extendedComponent ;
							
	}
					
	}
					
	}*/
		//Return the extended image
		return(extendedImage);
	}

	public int[] getPadRows(){
		return this.PadRows;
	}	
}
