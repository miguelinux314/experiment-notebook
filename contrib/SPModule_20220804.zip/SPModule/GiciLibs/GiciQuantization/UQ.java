package GiciQuantization;


public class UQ {
	private int quantizationStep;
	private long acumulatedError = 0;
	
	public UQ() {
			
	}

	public void setQuantizerStep(int quantizationStep){
		this.quantizationStep = quantizationStep;
	}
	
	public long quantize(long value) {
		int q_value;
		if(value >= 0){
			q_value = (int) Math.floor(value + quantizationStep) / (2*quantizationStep+1);
		}else{
			q_value = (int) ((int) Math.floor(value - (float)quantizationStep) / (float)(2*quantizationStep+1));
		}
		acumulatedError = acumulatedError + Math.abs((value - q_value));
		return q_value;
	}
	
	public long dequantize(long q_value){	
		long value;
		value = q_value * ( 2 * quantizationStep + 1);
		return value;
	}
	
	public long getAcumulatedError() {
		return acumulatedError;
	}
	
}
