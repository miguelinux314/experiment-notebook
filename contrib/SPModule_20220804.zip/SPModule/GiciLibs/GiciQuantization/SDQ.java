package GiciQuantization;


public class SDQ {
	private int quantizationStep;
	private long acumulatedError = 0;
	
	public SDQ() {
			
	}
	
	public void setQuantizerStep(int quantizationStep){
		this.quantizationStep = quantizationStep;
	}

	public long quantize(long value) {
		int sign = 1;
		int q_value;
		if(value < 0){
			sign = -1;
		}
		q_value=sign*(int)Math.floor(Math.abs(value)/(float)quantizationStep);
		acumulatedError = acumulatedError + Math.abs((value - q_value));	
		return q_value;
	}
	
	public long dequantize(long q_value){
		long value;
		value = q_value * quantizationStep;
		return value;
	}

	public long getAcumulatedError() {
		
		return acumulatedError;
	}
	
}
