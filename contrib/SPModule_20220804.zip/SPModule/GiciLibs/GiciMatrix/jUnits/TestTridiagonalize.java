package GiciMatrix.jUnits;

import java.util.Random;

import GiciMatrix.MatrixAlgebra;
import GiciMatrix.Tridiagonalize;
import junit.framework.TestCase;

public class TestTridiagonalize extends TestCase {
	float[][] buildTestMatrix1() {
		float[][] r = MatrixAlgebra.identityUT(8);

		for (int i = 0; i < r.length; i++) {
			for (int j = 0; j < r[i].length; j++) {
				int v = (i + 1) + (j + i + 1);
				r[i][j] = (float) ((v * v * v * v * v * v * v % 256));
			}
		}

		return r;
	}

	public void testMatrix1() {
		float[][] a = buildTestMatrix1();

		//MatrixAlgebra.printMatrix(a);

		Tridiagonalize tr = new Tridiagonalize(a);

		tr.run();

		float[][] t = tr.getT();
		float[][] u = tr.getU();

		//MatrixAlgebra.printMatrix(t);
		//MatrixAlgebra.printMatrix(u);
		//MatrixAlgebra.printMatrix(MatrixAlgebra.multiplicationCC(MatrixAlgebra.multiplicationCUH(u, t), MatrixAlgebra.transpose(u)));

		assertTrue(MatrixAlgebra.compare(MatrixAlgebra.cutUHUT(MatrixAlgebra.cutCUH(
				MatrixAlgebra.multiplicationCC(MatrixAlgebra.multiplicationCUH(u, t),
						MatrixAlgebra.transposeC(u)))), a, 0.01f));
	}

	float[][] buildRandomMatrix(long seed) {
		Random ra = new Random(seed);

		float[][] r = MatrixAlgebra.zeroUH((int) (ra.nextFloat() * 150 + 1));

		for (int i = 0; i < r.length; i++) {
			for (int j = 0; j < r[i].length; j++) {
				r[i][j] = (ra.nextFloat() - 0.5f) * 256.0f;
			}
		}

		return r;
	}

	public void testHeavyDuty() {
		Random ra = new Random(33);
		long[] tests = new long[20];

		for(int j = 0; j < tests.length; j++) {
			tests[j] = ra.nextLong();
		}

		for(int i = 0; i < tests.length; i++) {
			float[][] a = MatrixAlgebra.cutUHUT(buildRandomMatrix(tests[i]));

			System.out.println("Testing a " + a.length + "x" + a.length + " matrix");

			Tridiagonalize tr = new Tridiagonalize(a);

			tr.run();

			float[][] t = tr.getT();
			float[][] u = tr.getU();

			float[][] rec = MatrixAlgebra.cutUHUT(MatrixAlgebra.cutCUH(
					MatrixAlgebra.multiplicationCC(MatrixAlgebra.multiplicationCUH(u, t),
							MatrixAlgebra.transposeC(u))));

			//MatrixAlgebra.printMatrix(MatrixAlgebra.minus(ac, rec));

			assertTrue(MatrixAlgebra.compare(a, rec, 0.01f));
		}
	}

	public void testIndentity() { 
		float[][] a = MatrixAlgebra.identityUT(5);
		Tridiagonalize tr = new Tridiagonalize(a);

		tr.run();

		float[][] t = tr.getT();
		float[][] u = tr.getU();

		float[][] rec = MatrixAlgebra.cutUHUT(MatrixAlgebra.cutCUH(
				MatrixAlgebra.multiplicationCC(MatrixAlgebra.multiplicationCUH(u, t),
						MatrixAlgebra.transposeC(u))));

//		MatrixAlgebra.printMatrix(MatrixAlgebra.minus(a, rec));

		assertTrue(! Float.isNaN(rec[0][0]));

		assertTrue(MatrixAlgebra.compare(a, rec, 0.01f));
	}

}
