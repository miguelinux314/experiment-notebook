package GiciMatrix.jUnits;

import java.util.Random;

import GiciAnalysis.Epsilon;
import GiciMatrix.*;
import junit.framework.TestCase;

public class TestQR extends TestCase {

	public void testBasic() {
		float[][] a = MatrixAlgebra.identityUH(10);

		QRDecomposition qr = new QRDecomposition(a);

		qr.run();

		float[][] q = qr.getQ();
		float[][] r = qr.getR();

		assertTrue(MatrixAlgebra.compare(a,
				MatrixAlgebra.multiplicationUTUH(r, q),
				Float.MIN_VALUE));
	}

	float[][] buildTestMatrix1() {
		/*
Q:

-0.058428  0.015664  0.008966  0.006233  0.004763  0.003848  0.003226 -0.998085
-0.998292 -0.000917 -0.000525 -0.000365 -0.000279 -0.000225 -0.000189  0.058416
 0.000000  0.999877 -0.000141 -0.000098 -0.000075 -0.000060 -0.000051  0.015689
 0.000000  0.000000  0.999960 -0.000056 -0.000043 -0.000035 -0.000029  0.008982
 0.000000  0.000000  0.000000  0.999981 -0.000030 -0.000024 -0.000020  0.006244
 0.000000  0.000000  0.000000  0.000000  0.999989 -0.000018 -0.000015  0.004772
 0.000000  0.000000  0.000000  0.000000  0.000000  0.999993 -0.000012  0.003856
 0.000000  0.000000  0.000000  0.000000  0.000000  0.000000  0.999995  0.003232


R:

-2190.742568    -16483.791626    -78948.813755   -284022.431955   -838492.105685  -2141687.022549  -4897329.706773 -10262374.209838
    0.000000     78134.618855    280086.552333    824408.719623   2100523.708936   4793357.450438  10027233.569318  19550525.106840
    0.000000         0.000000    823576.223573   2097504.885722   4784558.169766  10005205.699710  19501269.186021  35865251.462741
    0.000000         0.000000         0.000000   4783062.250710  10000775.635821  19490130.442127  35840362.754958  62769536.422206
    0.000000         0.000000         0.000000         0.000000  19487393.866281  35833370.463952  62753805.019501 105427432.103082
    0.000000         0.000000         0.000000         0.000000         0.000000  62748982.428769 105416416.761604 170868390.249441
    0.000000         0.000000         0.000000         0.000000         0.000000         0.000000 170860268.371782 268440545.384679
    0.000000         0.000000         0.000000         0.000000         0.000000         0.000000         0.000000  -1140905.837428

		 */

		float[][] r = MatrixAlgebra.zeroUH(8);

		for (int i = 0; i < r.length; i++) {
			for (int j = 0; j < r[i].length; j++) {
				int v = (i + 1) + Math.max(1, i) + j;
				r[i][j] = (float) (v * v * v * v * v * v * v);
			}
		}

		return r;
	}

	public void testExtended() {
		float[][] a = buildTestMatrix1();

		QRDecomposition qr = new QRDecomposition(a);

		qr.run();

		float[][] q = qr.getQ();
		float[][] r = qr.getR();

		/*MatrixAlgebra.printMatrix(a);
		MatrixAlgebra.printMatrix(q);
		MatrixAlgebra.printMatrix(r);*/


		float[][] qc = MatrixAlgebra.toComplete(q);
		float[][] rc = MatrixAlgebra.toComplete(r);
		float[][] ac = MatrixAlgebra.toComplete(a);

		float[][] rec = MatrixAlgebra.multiplicationCC(qc, rc);

		/*MatrixAlgebra.printMatrix(ac);
		MatrixAlgebra.printMatrix(rec);
		MatrixAlgebra.printMatrix(MatrixAlgebra.minus(ac, rec));
		MatrixAlgebra.printMatrix(MatrixAlgebra.relativeError(rec, ac));*/

		/*oju aqui! que l'error es relatiu*/

		/* No sembla que 0.01 sigui molt demanar no?
		 * Doncs amb un error relatiu < epsilon, l'error absolut es de 16
		 */ 
		assertTrue(MatrixAlgebra.compare(ac, rec, 16));
	}

	public void testOne() {
		float[][] a = {{33.0f}};

		QRDecomposition qr = new QRDecomposition(a);

		qr.run();

		float[][] q = qr.getQ();
		float[][] r = qr.getR();

		float[][] qc = MatrixAlgebra.toComplete(q);
		float[][] rc = MatrixAlgebra.toComplete(r);
		float[][] ac = MatrixAlgebra.toComplete(a);

		float[][] rec = MatrixAlgebra.multiplicationCC(qc, rc);

		assertTrue(MatrixAlgebra.compare(ac, rec, 0.0001f));
	}

	float[][] buildRandomMatrix(long seed) {
		Random ra = new Random(seed);

		float[][] r = MatrixAlgebra.zeroUH((int) (ra.nextFloat() * 550 + 1));

		for (int i = 0; i < r.length; i++) {
			for (int j = 0; j < r[i].length; j++) {
				r[i][j] = (ra.nextFloat() - 0.5f) * 256.0f;
			}
		}

		return r;
	}

	public void testHeavyDuty() {
		Random ra = new Random(33);
		long[] tests = new long[200];

		for(int j = 0; j < tests.length; j++) {
			tests[j] = ra.nextLong();
		}

		for(int i = 0; i < tests.length; i++) {
			float[][] a = buildRandomMatrix(tests[i]);

			System.out.println("Testing a " + a.length + "x" + a.length + " matrix");

			QRDecomposition qr = new QRDecomposition(a);

			qr.run();

			float[][] q = qr.getQ();
			float[][] r = qr.getR();

			float[][] qc = MatrixAlgebra.toComplete(q);
			float[][] rc = MatrixAlgebra.toComplete(r);
			float[][] ac = MatrixAlgebra.toComplete(a);

			float[][] rec = MatrixAlgebra.multiplicationCC(qc, rc);

			//MatrixAlgebra.printMatrix(MatrixAlgebra.minus(ac, rec));

			assertTrue(MatrixAlgebra.compare(ac, rec, Epsilon.getFloatEpsilon() * 1024.0f));
		}
	}

	public void testIndentity() { 
		float[][] a = MatrixAlgebra.identityUH(5);

		QRDecomposition qr = new QRDecomposition(a);

		qr.run();

		float[][] q = qr.getQ();
		float[][] r = qr.getR();

		float[][] qc = MatrixAlgebra.toComplete(q);
		float[][] rc = MatrixAlgebra.toComplete(r);
		float[][] ac = MatrixAlgebra.toComplete(a);

		float[][] rec = MatrixAlgebra.multiplicationCC(qc, rc);

		assertTrue(! Float.isNaN(rec[0][0]));

		assertTrue(MatrixAlgebra.compare(ac, rec, 0.1f));
	}
}
