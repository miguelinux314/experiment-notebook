package GiciMatrix.jUnits;

import java.util.Random;

import GiciMatrix.MatrixAlgebra;
import junit.framework.TestCase;


public class TestMatrixInverse extends TestCase {

	float[][] buildTestMatrix1() {
		float[][] r = MatrixAlgebra.identityC(12);

		for (int i = 0; i < r.length; i++) {
			for (int j = 0; j < r.length; j++) {
				int v = (i + 1) + (j + i + 1);
				r[i][j] = (float) ((v * v * v * v * v * v * v % 256));
			}
		}

		return r;
	}

	public void testMatrix1() {
		float[][] a = buildTestMatrix1();

		//MatrixAlgebra.printMatrix(a);

		//System.out.println(MatrixAlgebra.determinant(a));
		
		float[][] a1 = MatrixAlgebra.inverseC(a);

		//MatrixAlgebra.printMatrix(a1);
		//MatrixAlgebra.printMatrix(MatrixAlgebra.multiplicationCC(a,a1));

		assertTrue(MatrixAlgebra.compare(MatrixAlgebra.multiplicationCC(a,a1), MatrixAlgebra.identityC(a.length), 0.01f));
	}

	float[][] buildRandomMatrix(long seed) {
		Random ra = new Random(seed);

		float[][] r = MatrixAlgebra.identityC((int) (ra.nextFloat() * 1500 + 1));

		for (int i = 0; i < r.length; i++) {
			for (int j = 0; j < r.length; j++) {
				r[i][j] = (ra.nextFloat() - 0.5f) * 256.0f;
			}
		}

		return r;
	}

	public void testHeavyDuty() {
		Random ra = new Random(33);
		long[] tests = new long[200];

		for(int j = 0; j < tests.length; j++) {
			tests[j] = ra.nextLong();
		}

		for(int i = 0; i < tests.length; i++) {
			float[][] a = buildRandomMatrix(tests[i]);

			if (Math.abs(MatrixAlgebra.determinant(a)) < 0.0001) {
				continue;
			}
			
			//MatrixAlgebra.printMatrix(a);

			System.out.println("Testing a " + a.length + "x" + a.length + " matrix");

			float[][] a1 = MatrixAlgebra.inverseC(a);

			//MatrixAlgebra.printMatrix(a1);
			//MatrixAlgebra.printMatrix(MatrixAlgebra.multiplicationCC(a,a1));

			assertTrue(MatrixAlgebra.compare(MatrixAlgebra.multiplicationCC(a,a1), MatrixAlgebra.identityC(a.length), 0.01f));
		}
	}

}
