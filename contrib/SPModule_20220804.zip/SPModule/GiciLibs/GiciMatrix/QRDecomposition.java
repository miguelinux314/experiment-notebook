package GiciMatrix;

/**
 * Computes the QRDecomposition of a matrix. An error of the order of epsilon can be expected.
 *
 * @author Ian Blanes
 *
 */
public class QRDecomposition {
	/**
	 * Input matrix.
	 */
	private float [][] a;

	/**
	 * Orthogonal matrix.
	 */
	private float [][] q;

	/**
	 * Upper triangular matrix.
	 */
	private float [][] r;

	/**
	 * Did we ran the decomposition before we try to get the results?
	 */
	private boolean ran = false;

	/**
	 * Constructor.
	 *
	 * @param b the input matrix. Must be in upper Hessenberg form.
	 */
	public QRDecomposition(final float [][] b) {
		this.a = MatrixAlgebra.copy(b);
		q = MatrixAlgebra.identityUH(b.length);
	}

	/**
	 * Applies a Givens rotation on rows.
	 * Works on any matrix aligned to the right if the missing elements are zeroed.
	 * returns = G * A
	 *
	 * @param m matrix to be manipulated.
	 * @param i first row.
	 * @param k second row.
	 * @param c first parameter of the rotation.
	 * @param s second parameter of the rotation.
	 */
	private void applyGivensRotationRows(final float [][] m, final int i, final int k,
			final double c, final double s) {

		int cols = Math.min(m[i].length, m[k].length);
		int skipI = Math.max(m[i].length - m[k].length, 0);
		int skipK = Math.max(m[k].length - m[i].length, 0);

		for (int j = 0; j < cols; j++) {
			float f, g;

			f = m[i][j + skipI];
			g = m[k][j + skipK];

			/* rowI = c * rowI + s * rowK */
			m[i][j + skipI] = (float) (c * f + s * g);

			/* rowK = -s * rowI + c * rowK */
			m[k][j + skipK]	= (float) (-s * f + c * g);
		}
	}

	/**
	 * Applies a Givens rotation on columns.
	 * Only works on upper Hessenberg matrices, returns = A * Tr(G)
	 *
	 * @param m matrix to be manipulated.
	 * @param i first row.
	 * @param k second row.
	 * @param c first parameter of the rotation.
	 * @param s second parameter of the rotation.
	 */
	private void applyGivensRotationCols(final float [][] m, final int i, final int k,
			final double c, final double s) {

		int rows = Math.min(m.length, Math.min(i, k) + 2);

		for (int j = 0; j < rows; j++) {
			int skip = Math.max(j - 1, 0);

			float f, g;

			f = m[j][i - skip];
			g = m[j][k - skip];

			/* rowI = c * rowI + s * rowK */
			m[j][i - skip] = (float) (c * f + s * g);

			/* rowK = - s * rowI + c * rowK */
			m[j][k - skip]	= (float) (-s * f + c * g);
		}
	}

	/**
	 * Computes the parameters of a Givens rotation that zeros the lower element.
	 *
	 * @param f first parameter
	 * @param g second parameter
	 * @return [c, s].
	 */
	private double[] getCandS(final double f, final double g) {
		double[] result = {0.0 /* C */, 0.0 /* S */};

		/* Anderson, Edward. (2000) Discontinuous Plane
		 * Rotations and the Symmetric Eigenvalue Problem.
		 * LAPACK Working Note 150, University of Tennessee,
		 * UT-CS-00-454, December 4, 2000. */

		if (Math.abs(g) < Float.MIN_VALUE) {
			result[0] = -Math.signum(f);
			result[1] = 0.0f;
		} else if (Math.abs(f) < Float.MIN_VALUE) {
			result[0] = 0.0f;
			result[1] = -Math.signum(g);
		} else if (Math.abs(f) > Math.abs(g)) {
			double t = g / (double) f;
			double u = Math.copySign(Math.sqrt(1.0 + t * t), f);

			result[0] = 1 / u;
			result[1] = t / u;
		} else {
			double t = f / (double) g;
			double u = Math.copySign(Math.sqrt(1.0 + t * t), g);

			result[1] = 1 / u;
			result[0] = t / u;
		}

		return result;
	}

	/**
	 * Decomposes the input matrix.
	 */
	public final void run() {
		ran = true;

		/* Implicit Wilkinson shift */
		double d = (a[a.length - 2][1] - a[a.length - 1][1]) / 2.0; 
		double tnn12 = a[a.length-1][0] * a[a.length-1][0];
		double mu = a[a.length-1][1] - tnn12 / (d + Math.copySign(Math.sqrt(d * d + tnn12), d)); 
		
		double f = a[0][0] - mu, g = a[1][0];
		
		/* Apply givens rotations and put zeros in the lower diagonal */
		for (int i = 0; i < a.length - 1; i++) {
			/* find c and s */
			double[] result = getCandS(f, g);
			double c = result[0], s = result[1];

			/* apply */
			applyGivensRotationRows(a, i, i + 1, c, s);
			applyGivensRotationCols(q, i, i + 1, c, s);

			/* make sure we got a zero */
			a[i + 1][0] = 0.0f;
			
			/* locate the next f and g */
			if (i + 1 < a.length - 1) {
				f = a[i + 1][1];
				g = a[i + 2][0];
			}
		}

		/* A is now R */
		r = MatrixAlgebra.cutUHUT(a);
	}

	/**
	 * @return Q, the orthogonal matrix.
	 */
	public final float[][] getQ() {
		assert (ran);
		return q;
	}

	/**
	 * @return R, the upper triangular matrix.
	 */
	public final float[][] getR() {
		assert (ran);
		return r;
	}
}
