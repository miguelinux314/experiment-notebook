package GiciMatrix;

import GiciAnalysis.Epsilon;

/**
 * @author Ian Blanes
 *
 */
public class Tridiagonalize {
	/**
	 * Input matrix. Here its a complete matrix.
	 */
	private float[][] a;

	/**
	 * Resulting tridiagonal matrix.
	 */
	private float[][] t;

	/**
	 * U * T * Tr(U) = A.
	 */
	private float[][] u;

	/**
	 * Did we ran the decomposition before we try to get the results?
	 */
	private boolean ran = false;

	/**
	 * Constructor.
	 *
	 * @param b Input matrix. b Must be a symmetric matrix (saved as a upper triangular matrix).
	 */
	public Tridiagonalize(final float[][] b) {
		assert (b.length > 0 && b.length == b[0].length);
		assert (b[b.length - 1].length == 1);

		/* Just in case */
		this.a = MatrixAlgebra.toComplete(b);

		/* Fill the symmetry */
		for (int i = 0; i < this.a.length; i++) {
			for (int j = 0; j < i; j++) {
				this.a[i][j] = this.a[j][i];
			}
		}

		t = MatrixAlgebra.identityUH(a.length);
		u = MatrixAlgebra.identityC(a.length);
	}

	/**
	 * Computes p*b*p where p is an orthogonal matrix an b is a upper matrix.
	 *
	 * @param b complete matrix.
	 * @param p complete matrix.
	 * @param skip padding that is need on p.
	 * @return P x B x P.
	 */
	private float[][] pap(final float[][] b, final int skip, final float[][] p) {
		/* This could be improved with a faster computation based directly on v
		 * See: The symmetric Eigenvalue Problem, pag 119.
		 * */
		
		//FIXME: sembla que vindria a ser alguna cosa aixi: P x B x P = B - vw^T - wv^T
		// veure Golub p. 415
		float[][] pp = MatrixAlgebra.padIdentityTL(p, skip);
		return MatrixAlgebra.multiplicationCC(pp, MatrixAlgebra.multiplicationCC(b, pp));
	}

	/**
	 * Computes P = Id - 2 * v * Tr(v).
	 * @param v column vector.
	 * @return P = Id - 2 * v * Tr(v).
	 */
	private float[][] buildP(final float[] v) {
		/* Can be done better but not faster (programming speed), see comment on pap. */
		float[][] vmt = new float[1][v.length];
		float[][] vm = new float[v.length][1];

		for (int i = 0; i < v.length; i++) {
			vmt[0][i] = v[i];
			vm[i][0] = v[i];
		}

		float[][] vv = MatrixAlgebra.multiplicationCC(vm, vmt);

		for (int j = 0; j < v.length; j++) {
			for (int k = 0; k < v.length; k++) {
				vv[j][k] *= 2.0f;
			}
		}

		return MatrixAlgebra.subtract(MatrixAlgebra.identityC(v.length), vv);
	}

	/**
	 * Computes the tridiagonalization.
	 */
	public final void run() {
		ran = true;

		for (int i = 0; i < (a.length - 1); i++) {
			/* x = a[i][1..end] */
			int j;

			/* Compute alpha and fill v */
			float alpha = 0.0f;
			float[] v = new float[a[i].length - 1 - i];

			for (j = i + 1; j < a[i].length; j++) {
				alpha += a[i][j] * a[i][j];
				v[j - (i + 1)] = a[i][j];
			}

			if (Math.abs(alpha) < Float.MIN_VALUE) {
				/* We don't need to do anything here. */
				continue;
			}

			alpha = (float) Math.sqrt(alpha);

			/* Chose the sign properly for numerical stability.
			 * We don't want a cancellation latter. */
			if (Math.signum((v[0] * alpha)) > 0) {
				alpha = -alpha;
			}

			v[0] -= alpha;

			/* Normalize u and get v */
			float uNorm = 0.0f;

			for (j = 0; j < v.length; j++) {
				uNorm += v[j] * v[j];
			}

			/* For faster multiplication later use 1/x */
			// FIXME: Oju amb el cas que uNorm es 0!
			assert(uNorm > Epsilon.getFloatEpsilon());
			uNorm = (float) (1 / Math.sqrt(uNorm));

			for (j = 0; j < v.length; j++) {
				v[j] *= uNorm;
			}

			/* Take care of the rest */
			float [][] p = buildP(v);
			a = pap(a, i + 1 , p);

			/* Save for the inversion latter */
			u = MatrixAlgebra.subMultiplicationCC(p, u);
		}

		u = MatrixAlgebra.transposeC(u);
		t = MatrixAlgebra.cutCUH(a);
	}

	/**
	 * @return T, the tridiagonal matrix.
	 */
	public final float[][] getT() {
		assert (ran);
		return t;
	}

	/**
	 * @return U, the inversion matrix.
	 */
	public final float[][] getU() {
		assert (ran);
		return u;
	}
}
