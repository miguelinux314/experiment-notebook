package GiciFile.RawImage.jUnits;

import GiciFile.RawImage.*;

import java.io.*;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class TestRII {
	private int[] geo;
	private int[][][] BSQImg=null;
	private int[] BSQarray=null;

	@Before
	public void setUp() {
		BSQImg = new int[3][4][5];
		int counter = 0;
		for(int i=0;i<BSQImg.length;i++) {
			for(int j=0;j<BSQImg[0].length;j++) {
				for(int k=0;k<BSQImg[0][0].length;k++) {
					BSQImg[i][j][k] = counter;
					counter++;
				}
			}
		}

		BSQarray = getSimpleArray(BSQImg);

		geo = new int[Geometry.GEO_SIZE];
		geo[Geometry.Z_SIZE] = BSQImg.length;
		geo[Geometry.Y_SIZE] = BSQImg[0].length;
		geo[Geometry.X_SIZE] = BSQImg[0][0].length;
		geo[Geometry.SAMPLE_TYPE] = Geometry.INT;
		geo[Geometry.BYTE_ORDER] = Geometry.BIG_ENDIAN;
	}

	@Test
	public void test() throws Exception {
		File f = new File("testfile");
		testWrite(f, OrderConverter.DIM_TRANSP_BSQ_TO_BIP, OrderConverter.DIM_TRANSP_BIP_TO_BSQ, RawImage.WRITE, false);
		testReadWrite(f, OrderConverter.DIM_TRANSP_BSQ_TO_BIP, OrderConverter.DIM_TRANSP_BIP_TO_BSQ, RawImage.RW, false);
		testReadBand(f, OrderConverter.DIM_TRANSP_BSQ_TO_BIP, OrderConverter.DIM_TRANSP_BIP_TO_BSQ, RawImage.READ, false, 2);
		testExceptions(f, OrderConverter.DIM_TRANSP_BSQ_TO_BIP, OrderConverter.DIM_TRANSP_BIP_TO_BSQ, false);
	}

	public void testWrite(File f, int[] originalPixelOrder, int[] pixelOrderTransformation, int mode, boolean lossless) throws Exception {
		if(f.exists()) {
			f.delete();
		}

		RawImageIterator<int[]> it = new RawImageIterator<int[]>(null, new int[0], f, geo, originalPixelOrder, pixelOrderTransformation, mode, lossless);
		for(int i=0;i<BSQImg.length;i++) {
			for(int j=0;j<BSQImg[0].length;j++) {
				it.next();
				it.set(BSQImg[i][j]);
			}
		}
		it.close();
	}

	public void testReadWrite(File f, int[] originalPixelOrder, int[] pixelOrderTransformation, int mode, boolean lossless) throws IOException {
		RawImageIterator<int[]> it = new RawImageIterator<int[]>(null, new int[0], f, geo, originalPixelOrder, pixelOrderTransformation, mode, lossless);
		int index = 0;
		while(it.hasNext()) {
			int tmp[] = it.next();
			index = it.nextIndex();
			for(int i=0;i<tmp.length;i++) {
				tmp[i] += index;
			}
			it.set(tmp);
		}
		it.close();

		int counter = 0;
		it = new RawImageIterator<int[]>(null, new int[0], f, geo, originalPixelOrder, pixelOrderTransformation, mode, lossless);
		while(it.hasNext()) {
			int tmp[] = it.next();
			for(int i=0;i<tmp.length;i++) {
				assertTrue(tmp[i] == BSQarray[counter]+1+counter/BSQImg[0][0].length);
				counter++;
			}
		}
	}

	public void testReadBand(File f, int[] originalPixelOrder, int[] pixelOrderTransformation, int mode, boolean lossless, int band) throws IOException {
		int pixelsPerLine = geo[pixelOrderTransformation[originalPixelOrder[Geometry.X_SIZE]]];
		int linesPerBand = geo[pixelOrderTransformation[originalPixelOrder[Geometry.Y_SIZE]]];
		int counter = band*linesPerBand*pixelsPerLine;
		RawImageIterator<int[]> it = new RawImageIterator<int[]>(null, new int[0], f, geo, originalPixelOrder, pixelOrderTransformation, mode, lossless, band);
		while(it.hasNext()) {
			int tmp[] = it.next();
			for(int i=0;i<tmp.length;i++) {
				assertTrue(tmp[i] == BSQarray[counter]+1+counter/BSQImg[0][0].length);
				counter++;
			}
		}
	}

	public void testExceptions(File f, int[] originalPixelOrder, int[] pixelOrderTransformation, boolean lossless) throws IOException {
		try {
			RawImageIterator<byte[]> it = new RawImageIterator<byte[]>(null, new byte[0], f, geo, originalPixelOrder, pixelOrderTransformation, RawImage.RW, lossless);
			fail("Missing ClassCastException");
		}catch(ClassCastException e) {}
		
		try {
			int band = geo[pixelOrderTransformation[originalPixelOrder[Geometry.Z_SIZE]]];
			RawImageIterator<int[]> it = new RawImageIterator<int[]>(null, new int[0], f, geo, originalPixelOrder, pixelOrderTransformation, RawImage.RW, lossless, band);
			fail("Missing IndexOutOfBoundsException");
		}catch(IndexOutOfBoundsException e) {}

		try {
			RawImageIterator<int[]> it = new RawImageIterator<int[]>(null, new int[0], f, geo, originalPixelOrder, pixelOrderTransformation, RawImage.RW, lossless, 1, 0);
			fail("Missing IndexOutOfBoundsException");
		}catch(IndexOutOfBoundsException e) {}

		try {
			RawImageIterator<int[]> it = new RawImageIterator<int[]>(null, new int[0], f, geo, originalPixelOrder, pixelOrderTransformation, RawImage.RW, lossless, -1);
			fail("Missing IndexOutOfBoundsException");
		}catch(IndexOutOfBoundsException e) {}

		try {
			RawImageIterator<int[]> it = new RawImageIterator<int[]>(null, new int[0], f, geo, originalPixelOrder, pixelOrderTransformation, RawImage.READ, lossless);
			int[] tmp = new int[geo[pixelOrderTransformation[originalPixelOrder[Geometry.X_SIZE]]]];
			for(int i=0;i<tmp.length;i++) {
				tmp[i] = 0;
			}
			it.next();
			it.set(tmp);
			fail("Missing UnsupportedOperationException");
		}catch(UnsupportedOperationException e) {}

		try {
			RawImageIterator<int[]> it = new RawImageIterator<int[]>(null, new int[0], f, geo, originalPixelOrder, pixelOrderTransformation, RawImage.WRITE, lossless);
			int[] tmp = new int[geo[pixelOrderTransformation[originalPixelOrder[Geometry.X_SIZE]]]];
			for(int i=0;i<tmp.length;i++) {
				tmp[i] = 0;
			}
			it.set(tmp);
			fail("Missing IllegalStateException");
		}catch(IllegalStateException e) {}

		RawImageIterator<int[]> it = new RawImageIterator<int[]>(null, new int[0], f, geo, originalPixelOrder, pixelOrderTransformation, RawImage.WRITE, lossless);
		assertTrue(it.next() == null);
		assertTrue(it.previous() == null);
	}

	public int[] getSimpleArray(int[][][] img) {
		int[] array = new int[img.length * img[0].length * img[0][0].length];
		int counter = 0;
		for(int i=0;i<img.length;i++) {
			for(int j=0;j<img[0].length;j++) {
				for(int k=0;k<img[0][0].length;k++) {
					array[counter] = img[i][j][k];
					counter++;
				}
			}
		}
		return array;
	}
}
