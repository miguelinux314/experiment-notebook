package GiciFile.RawImage.jUnits;

import GiciFile.RawImage.*;

import java.io.*;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class TestRI {
	private int[] geo;

	@Before
	public void setUp() {
		geo = new int[Geometry.GEO_SIZE];
		geo[Geometry.Z_SIZE] = 3;
		geo[Geometry.Y_SIZE] = 4;
		geo[Geometry.X_SIZE] = 5;
		geo[Geometry.SAMPLE_TYPE] = Geometry.INT;
		geo[Geometry.BYTE_ORDER] = Geometry.BIG_ENDIAN;
	}

	@Test
	public void test() throws IOException, UnsupportedOperationException, IndexOutOfBoundsException, ClassCastException {
		File f = new File("testfile2");
		f.delete();
		testRead(f, OrderConverter.DIM_TRANSP_BSQ_TO_BIP, OrderConverter.DIM_TRANSP_BIP_TO_BSQ, false);
		RandomAccessFile file = new RandomAccessFile(f, "rw");
		int[] sizeTable = {1/* boolean */, 1/* byte */, 2/* char */, 2/* short */, 4/* int */, 8/* long */, 4/* float */, 8/* double */};
		int size = sizeTable[geo[Geometry.SAMPLE_TYPE]];
		file.setLength(geo[Geometry.Z_SIZE]*geo[Geometry.Y_SIZE]*geo[Geometry.X_SIZE]*size);
		file.close();
		testWrite(f, OrderConverter.DIM_TRANSP_BSQ_TO_BIP, OrderConverter.DIM_TRANSP_BIP_TO_BSQ, false);
		testRW(f, OrderConverter.DIM_TRANSP_BSQ_TO_BIP, OrderConverter.DIM_TRANSP_BIP_TO_BSQ, false);
	}

	public void testRead(File f, int[] originalPixelOrder, int[] pixelOrderTransformation, boolean lossless) throws IOException, UnsupportedOperationException, IndexOutOfBoundsException, ClassCastException {
		RawImage image = new RawImage(f, geo, originalPixelOrder, RawImage.READ);
		try {
			RawImageIterator <int[]> it = (RawImageIterator<int[]>) image.getIterator(new int[0], pixelOrderTransformation, RawImage.READ, lossless);
			fail("File don't exist and error was not throwed");
		}catch(IOException e) {}
		try {
			image.getIterator(new int[0], pixelOrderTransformation, RawImage.WRITE, lossless);
			fail("Missing UnsupportedOperationException");
		}catch(UnsupportedOperationException e){}
		try {
			image.getIterator(new int[0], pixelOrderTransformation, RawImage.RW, lossless);
			fail("Missing UnsupportedOperationException");
		}catch(UnsupportedOperationException e){}
	}

	public void testWrite(File f, int[] originalPixelOrder, int[] pixelOrderTransformation, boolean lossless) throws IOException, UnsupportedOperationException, IndexOutOfBoundsException, ClassCastException{
		RawImage image = new RawImage(f, geo, originalPixelOrder, RawImage.WRITE);
		try {
			image.getIterator(new int[0], pixelOrderTransformation, RawImage.READ, lossless);
			fail("Missing UnsupportedOperationException");
		}catch(UnsupportedOperationException e){}
		RawImageIterator <int[]> it = (RawImageIterator<int[]>) image.getIterator(new int[0], pixelOrderTransformation, RawImage.WRITE, lossless);
		image.close(it);
		try {
			image.getIterator(new int[0], pixelOrderTransformation, RawImage.RW, lossless);
			fail("Missing UnsupportedOperationException");
		}catch(UnsupportedOperationException e){};
	}

	public void testRW(File f, int[] originalPixelOrder, int[] pixelOrderTransformation, boolean lossless) throws IOException, UnsupportedOperationException, IndexOutOfBoundsException, ClassCastException {
		RawImage image = new RawImage(f, geo, originalPixelOrder, RawImage.RW);
		RawImageIterator <int[]> it;
		it = (RawImageIterator<int[]>) image.getIterator(new int[0], pixelOrderTransformation, RawImage.READ, lossless);
		it.close();
		it = (RawImageIterator<int[]>) image.getIterator(new int[0], pixelOrderTransformation, RawImage.WRITE, lossless);
		it.close();
		it = (RawImageIterator<int[]>) image.getIterator(new int[0], pixelOrderTransformation, RawImage.RW, lossless);
		it.close();
	}
}
