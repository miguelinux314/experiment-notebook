package GiciFile.RawImage.jUnits;

import GiciFile.RawImage.*;
import GiciTransform.Reshape;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class TestOC {

	public final static int BSQ = 0;
	public final static int BIL = 1;
	public final static int BIP = 2;

	private int[] geo;
	private byte[][][] BSQImg=null;

	@Before
	public void setUp() {
		BSQImg = new byte[3][4][5];
		byte counter = 0;
		for(int i=0;i<BSQImg.length;i++) {
			for(int j=0;j<BSQImg[0].length;j++) {
				for(int k=0;k<BSQImg[0][0].length;k++) {
					BSQImg[i][j][k] = counter;
					counter++;
				}
			}
		}

		geo = new int[Geometry.GEO_SIZE];
		geo[Geometry.Z_SIZE] = BSQImg.length;
		geo[Geometry.Y_SIZE] = BSQImg[0].length;
		geo[Geometry.X_SIZE] = BSQImg[0][0].length;
		geo[Geometry.SAMPLE_TYPE] = Geometry.U_BYTE; //Unused
		geo[Geometry.BYTE_ORDER] = Geometry.BIG_ENDIAN; //Unused
	}

	@Test
	public void test() {
		byte[][][] initialImg = null, finalImg=null;
		int[] orPixelOrder;
		int pixelOrder[][][] = {{OrderConverter.DIM_TRANSP_IDENTITY,
					OrderConverter.DIM_TRANSP_BSQ_TO_BIL,
					OrderConverter.DIM_TRANSP_BSQ_TO_BIP},
					{OrderConverter.DIM_TRANSP_BIL_TO_BSQ,
					OrderConverter.DIM_TRANSP_IDENTITY,
					OrderConverter.DIM_TRANSP_BIL_TO_BIP},
					{OrderConverter.DIM_TRANSP_BIP_TO_BSQ,
					OrderConverter.DIM_TRANSP_BIP_TO_BIL,
					OrderConverter.DIM_TRANSP_IDENTITY}};
		for(int i=0;i<3;i++) {
			initialImg = getImage(i);
			byte[] initialImgArray = getSimpleArray(initialImg);
			orPixelOrder = originalPixelOrder(i);
			for(int j=0;j<3;j++) {
				OrderConverter oc = new OrderConverter(geo, orPixelOrder, pixelOrder[i][j]);
				finalImg = getImage(j);
				compare(oc, initialImgArray, getSimpleArray(finalImg));
			}
		}
	}

	public int[] originalPixelOrder(int pixelOrder) {
		switch (pixelOrder) {
			case BSQ:
				return OrderConverter.DIM_TRANSP_IDENTITY;
			case BIL:
				return OrderConverter.DIM_TRANSP_BSQ_TO_BIL;
			case BIP:
				return OrderConverter.DIM_TRANSP_BSQ_TO_BIP;
		}
		return OrderConverter.DIM_TRANSP_IDENTITY;
	}

	public byte[] getSimpleArray(byte[][][] img) {
		byte[] array = new byte[img.length * img[0].length * img[0][0].length];
		int counter = 0;
		for(int i=0;i<img.length;i++) {
			for(int j=0;j<img[0].length;j++) {
				for(int k=0;k<img[0][0].length;k++) {
					array[counter] = img[i][j][k];
					counter++;
				}
			}
		}
		return array;
	}

	public byte[][][] getImage(int pixelOrder) {
		Reshape r = null;
		int[][][] integerImg, tmpImg;
		byte[][][] img;

		if(pixelOrder == BSQ) {
			return BSQImg;
		}

		integerImg = new int[BSQImg.length][BSQImg[0].length][BSQImg[0][0].length];
		for(int i=0;i<BSQImg.length;i++) {
			for(int j=0;j<BSQImg[0].length;j++) {
				for(int k=0;k<BSQImg[0][0].length;k++) {
					integerImg[i][j][k] = BSQImg[i][j][k];
				}
			}
		}
		r = new Reshape(integerImg);
		switch (pixelOrder) {
			case BIL:
				r.dimensionTranspose(Reshape.DIM_TRANSP_BSQ_TO_BIL);
				break;
			case BIP:
				r.dimensionTranspose(Reshape.DIM_TRANSP_BSQ_TO_BIP);
				break;
		}
		tmpImg = r.getImageInteger();
		img = new byte[tmpImg.length][tmpImg[0].length][tmpImg[0][0].length];
		for(int i=0;i<tmpImg.length;i++) {
			for(int j=0;j<tmpImg[0].length;j++) {
				for(int k=0;k<tmpImg[0][0].length;k++) {
					img[i][j][k] = (byte)tmpImg[i][j][k];
				}
			}
		}
		return img;
	}

	public void compare(OrderConverter oc, byte[] initImg, byte[] finalImg) {
		byte value=0;
		for(int i = 0; i < finalImg.length;i++) {
			value = (byte) initImg[oc.getAddress(i)];
			assertFalse(value == -1 || value != finalImg[i]);
		}
	}
}
