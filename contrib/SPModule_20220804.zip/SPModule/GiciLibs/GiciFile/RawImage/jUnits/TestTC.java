package GiciFile.RawImage.jUnits;

import GiciFile.RawImage.*;
import GiciException.LackOfPrecisionError;

import java.nio.*;
import static org.junit.Assert.*;
import java.util.*;
import org.junit.Test;

public class TestTC {

	@Test
	public void test() {
		testBoolean();
		testUByte();
		testUShort();
		testShort();
		testInt();
		testLong();
		testFloat();
		testDouble();
	}

	public void testBoolean() {
		int[] geo = new int[Geometry.GEO_SIZE];
		geo[Geometry.Z_SIZE] = 1; //unused
		geo[Geometry.Y_SIZE] = 1; //unused
		geo[Geometry.X_SIZE] = 6; //unused
		geo[Geometry.SAMPLE_TYPE] = Geometry.BOOLEAN;
		geo[Geometry.BYTE_ORDER] = Geometry.BIG_ENDIAN; //unused
		
		//int[]
		TypeConverter<int[]> intConverter = new TypeConverter<int[]>(new int[0], geo, false);
		int[] intValues = {0, 1, -2, 30, 0, 2};
		byte[] buffer = intConverter.TtoByte(intValues);
		int[] intValues2 = new int[intValues.length];
		for(int i=0;i<intValues.length;i++) {
			intValues2[i] = (intValues[i] == 0) ? 0 : 1;
		}
		compare(buffer, intValues2, Geometry.BOOLEAN);
		int[] intValues3 = intConverter.bytetoT(buffer);
		assertArrayEquals(intValues2, intValues3);

		//long[]
		TypeConverter<long[]> longConverter = new TypeConverter<long[]>(new long[0], geo, false);
		long[] longValues = {0, 1, -2, 30, 0, 2};
		buffer = longConverter.TtoByte(longValues);
		long[] longValues2 = new long[longValues.length];
		for(int i=0;i<longValues.length;i++) {
			longValues2[i] = (longValues[i] == 0) ? 0 : 1;
		}
		compare(buffer, longValues2, Geometry.BOOLEAN);
		long[] longValues3 = longConverter.bytetoT(buffer);
		assertArrayEquals(longValues2, longValues3);

		//float[]
		TypeConverter<float[]> floatConverter = new TypeConverter<float[]>(new float[0], geo, false);
		float[] floatValues = {0, 1, -2, 30, 0, 2};
		buffer = floatConverter.TtoByte(floatValues);
		float[] floatValues2 = new float[floatValues.length];
		for(int i=0;i<floatValues.length;i++) {
			floatValues2[i] = (floatValues[i] == 0.0f) ? 0.0f : 1.0f;
		}
		compare(buffer, floatValues2, Geometry.BOOLEAN);
		float[] floatValues3 = floatConverter.bytetoT(buffer);
		assertTrue(Arrays.equals(floatValues2, floatValues3));
	}

	public void testUByte() {
		testLittleInteger(Geometry.U_BYTE, 0, 255);
	}
	
	public void testUShort() {
		testLittleInteger(Geometry.U_SHORT, Character.MIN_VALUE, Character.MAX_VALUE);
	}
	
	public void testShort() {
		testLittleInteger(Geometry.SHORT, Short.MIN_VALUE, Short.MAX_VALUE);
	}

	public void testLittleInteger(int type, int min, int max) {
		int[] geo = new int[Geometry.GEO_SIZE];
		geo[Geometry.Z_SIZE] = 1; //unused
		geo[Geometry.Y_SIZE] = 1; //unused
		geo[Geometry.X_SIZE] = 6; //unused
		geo[Geometry.SAMPLE_TYPE] = type;
		geo[Geometry.BYTE_ORDER] = Geometry.BIG_ENDIAN; //unused
		
		//int[]
		TypeConverter<int[]> intConverter = new TypeConverter<int[]>(new int[0], geo, false);
		byte[] buffer;
		try {
			int[] intValuesTmp1 = {0, 100, min-1, 40, 5, 34};
			buffer = intConverter.TtoByte(intValuesTmp1);
		}catch(LackOfPrecisionError e) {
			fail("Error about pixel out of range in lossy mode");
		}

		try {
			int[] intValuesTmp2 = {0, 100, 30, 40, 5, max+1};
			buffer = intConverter.TtoByte(intValuesTmp2);
		}catch(LackOfPrecisionError e) {
			fail("Error about pixel out of range in lossy mode");
		}

		int[] intValues = {0, 100, 30, 40, 5, 34};
		buffer = intConverter.TtoByte(intValues);
		compare(buffer, intValues, geo[Geometry.SAMPLE_TYPE]);
		int[] intValues2 = intConverter.bytetoT(buffer);
		assertArrayEquals(intValues, intValues2);

		//long[]
		TypeConverter<long[]> longConverter = new TypeConverter<long[]>(new long[0], geo, false);
		try {
			long[] longValuesTmp1 = {0, 100, min-1, 40, 5, 34};
			buffer = longConverter.TtoByte(longValuesTmp1);
		}catch(LackOfPrecisionError e) {
			fail("Error about pixel out of range in lossy mode");
		}

		try {
			long[] longValuesTmp2 = {0, 100, 30, 40, 5, max+1};
			buffer = longConverter.TtoByte(longValuesTmp2);
		}catch(LackOfPrecisionError e) {
			fail("Error about pixel out of range in lossy mode");
		}

		long[] longValues = {0, 100, 30, 40, 5, 34};
		buffer = longConverter.TtoByte(longValues);
		compare(buffer, longValues, geo[Geometry.SAMPLE_TYPE]);
		long[] longValues2 = longConverter.bytetoT(buffer);
		assertArrayEquals(longValues, longValues2);

		//float[]
		TypeConverter<float[]> floatConverter = new TypeConverter<float[]>(new float[0], geo, false);
		try {
			float[] floatValuesTmp1 = {0, 100, min-1, 40, 5, 34};
			buffer = floatConverter.TtoByte(floatValuesTmp1);
		}catch(LackOfPrecisionError e) {
			fail("Error about pixel out of range in lossy mode");
		}

		try {
			float[] floatValuesTmp2 = {0, 100, 30, 40, 5, max+1};
			buffer = floatConverter.TtoByte(floatValuesTmp2);
		}catch(LackOfPrecisionError e) {
			fail("Error about pixel out of range in lossy mode");
		}

		float[] floatValues = {0, 100, 30.4f, 40, 5, 34};
		buffer = floatConverter.TtoByte(floatValues);
		floatValues[2] = (int) floatValues[2];
		compare(buffer, floatValues, geo[Geometry.SAMPLE_TYPE]);
		float[] floatValues2 = floatConverter.bytetoT(buffer);
		assertTrue(Arrays.equals(floatValues, floatValues2));

		try {
			float[] floatValuesTmp3 = {0, 100, 30.4f, 40, 5, 34};
			TypeConverter<float[]> floatConverter2 = new TypeConverter<float[]>(new float[0], geo, true);
			buffer = floatConverter2.TtoByte(floatValuesTmp3);
			fail("Missing error about lack of precision");
		}catch(LackOfPrecisionError e) {}
		
	}

	public void testInt() {
		int[] geo = new int[Geometry.GEO_SIZE];
		geo[Geometry.Z_SIZE] = 1; //unused
		geo[Geometry.Y_SIZE] = 1; //unused
		geo[Geometry.X_SIZE] = 6; //unused
		geo[Geometry.SAMPLE_TYPE] = Geometry.INT;
		geo[Geometry.BYTE_ORDER] = Geometry.BIG_ENDIAN; //unused
		
		//int[]
		TypeConverter<int[]> intConverter = new TypeConverter<int[]>(new int[0], geo, false);
		byte[] buffer;

		int[] intValues = {0, 100, -30, 40, 5, 34};
		buffer = intConverter.TtoByte(intValues);
		compare(buffer, intValues, geo[Geometry.SAMPLE_TYPE]);
		int[] intValues2 = intConverter.bytetoT(buffer);
		assertArrayEquals(intValues, intValues2);

		//long[]
		TypeConverter<long[]> longConverter = new TypeConverter<long[]>(new long[0], geo, false);

		long[] longValues = {0, 100, 30, 40, 5, 34};
		buffer = longConverter.TtoByte(longValues);
		compare(buffer, longValues, geo[Geometry.SAMPLE_TYPE]);
		long[] longValues2 = longConverter.bytetoT(buffer);
		assertArrayEquals(longValues, longValues2);

		//float[]
		TypeConverter<float[]> floatConverter = new TypeConverter<float[]>(new float[0], geo, false);

		float[] floatValues = {0, 100, 30.4f, 40, 5, 34};
		buffer = floatConverter.TtoByte(floatValues);
		floatValues[2] = (int) floatValues[2];
		compare(buffer, floatValues, geo[Geometry.SAMPLE_TYPE]);
		float[] floatValues2 = floatConverter.bytetoT(buffer);
		assertTrue(Arrays.equals(floatValues, floatValues2));

		try {
			float[] floatValuesTmp3 = {0, 100, 30.4f, 40, 5, 34};
			TypeConverter<float[]> floatConverter2 = new TypeConverter<float[]>(new float[0], geo, true);
			buffer = floatConverter2.TtoByte(floatValuesTmp3);
			fail("Missing error about lack of precision");
		}catch(LackOfPrecisionError e) {}
		
	}

	public void testLong() {
		int[] geo = new int[Geometry.GEO_SIZE];
		geo[Geometry.Z_SIZE] = 1; //unused
		geo[Geometry.Y_SIZE] = 1; //unused
		geo[Geometry.X_SIZE] = 6; //unused
		geo[Geometry.SAMPLE_TYPE] = Geometry.LONG;
		geo[Geometry.BYTE_ORDER] = Geometry.BIG_ENDIAN; //unused
		
		//int[]
		TypeConverter<int[]> intConverter = new TypeConverter<int[]>(new int[0], geo, false);
		byte[] buffer;

		int[] intValues = {0, 100, -30, 40, 5, 34};
		buffer = intConverter.TtoByte(intValues);
		compare(buffer, intValues, geo[Geometry.SAMPLE_TYPE]);
		int[] intValues2 = intConverter.bytetoT(buffer);
		assertArrayEquals(intValues, intValues2);

		//long[]
		TypeConverter<long[]> longConverter = new TypeConverter<long[]>(new long[0], geo, false);

		long[] longValues = {0, 100, 30, 40, 5, 34};
		buffer = longConverter.TtoByte(longValues);
		compare(buffer, longValues, geo[Geometry.SAMPLE_TYPE]);
		long[] longValues2 = longConverter.bytetoT(buffer);
		assertArrayEquals(longValues, longValues2);

		//float[]
		TypeConverter<float[]> floatConverter = new TypeConverter<float[]>(new float[0], geo, false);

		float[] floatValues = {0, 100, 30.4f, 40, 5, 34};
		buffer = floatConverter.TtoByte(floatValues);
		floatValues[2] = (long) floatValues[2];
		compare(buffer, floatValues, geo[Geometry.SAMPLE_TYPE]);
		float[] floatValues2 = floatConverter.bytetoT(buffer);
		assertTrue(Arrays.equals(floatValues, floatValues2));

		try {
			float[] floatValuesTmp3 = {0, 100, 30.4f, 40, 5, 34};
			TypeConverter<float[]> floatConverter2 = new TypeConverter<float[]>(new float[0], geo, true);
			buffer = floatConverter2.TtoByte(floatValuesTmp3);
			fail("Missing error about lack of precision");
		}catch(LackOfPrecisionError e) {}
		
	}

	public void testFloat() {
		int[] geo = new int[Geometry.GEO_SIZE];
		geo[Geometry.Z_SIZE] = 1; //unused
		geo[Geometry.Y_SIZE] = 1; //unused
		geo[Geometry.X_SIZE] = 6; //unused
		geo[Geometry.SAMPLE_TYPE] = Geometry.FLOAT;
		geo[Geometry.BYTE_ORDER] = Geometry.BIG_ENDIAN; //unused
		
		//int[]
		TypeConverter<int[]> intConverter = new TypeConverter<int[]>(new int[0], geo, false);
		TypeConverter<int[]> intConverter2 = new TypeConverter<int[]>(new int[0], geo, true);
		byte[] buffer;

		try {
			int[] intValuesTmp1 = {0, 100, Integer.MIN_VALUE+1, 40, 5, 34};
			buffer = intConverter2.TtoByte(intValuesTmp1);
			fail("Missing error about lack of precision");
		}catch(LackOfPrecisionError e) {}

		try {
			int[] intValuesTmp2 = {0, 100, 30, 40, 5, Integer.MAX_VALUE-1};
			buffer = intConverter2.TtoByte(intValuesTmp2);
			fail("Missing error about lack of precision");
		}catch(LackOfPrecisionError e) {}

		int[] intValues = {0, 100, Integer.MIN_VALUE+1, 40, 5, 34};
		buffer = intConverter.TtoByte(intValues);
		intValues[2] = (int) ((float) intValues[2]);
		compare(buffer, intValues, geo[Geometry.SAMPLE_TYPE]);
		int[] intValues2 = intConverter.bytetoT(buffer);
		assertArrayEquals(intValues, intValues2);

		//long[]
		TypeConverter<long[]> longConverter = new TypeConverter<long[]>(new long[0], geo, false);
		TypeConverter<long[]> longConverter2 = new TypeConverter<long[]>(new long[0], geo, true);

		try {
			long[] longValuesTmp1 = {0, 100, Long.MIN_VALUE+1, 40, 5, 34};
			buffer = longConverter2.TtoByte(longValuesTmp1);
			fail("Missing error about lack of precision");
		}catch(LackOfPrecisionError e) {}

		try {
			long[] longValuesTmp2 = {0, 100, 30, 40, 5, Long.MAX_VALUE-1};
			buffer = longConverter2.TtoByte(longValuesTmp2);
			fail("Missing error about lack of precision");
		}catch(LackOfPrecisionError e) {}

		long[] longValues = {0, 100, Long.MAX_VALUE-1, 40, 5, 34};
		buffer = longConverter.TtoByte(longValues);
		longValues[2] = (long) ((float) longValues[2]);
		compare(buffer, longValues, geo[Geometry.SAMPLE_TYPE]);
		long[] longValues2 = longConverter.bytetoT(buffer);
		assertArrayEquals(longValues, longValues2);

		//float[]
		TypeConverter<float[]> floatConverter = new TypeConverter<float[]>(new float[0], geo, false);

		float[] floatValues = {0, 100, 30.4f, 40, 5, 34};
		buffer = floatConverter.TtoByte(floatValues);
		compare(buffer, floatValues, geo[Geometry.SAMPLE_TYPE]);
		float[] floatValues2 = floatConverter.bytetoT(buffer);
		assertTrue(Arrays.equals(floatValues, floatValues2));
	}

	public void testDouble() {
		int[] geo = new int[Geometry.GEO_SIZE];
		geo[Geometry.Z_SIZE] = 1; //unused
		geo[Geometry.Y_SIZE] = 1; //unused
		geo[Geometry.X_SIZE] = 6; //unused
		geo[Geometry.SAMPLE_TYPE] = Geometry.DOUBLE;
		geo[Geometry.BYTE_ORDER] = Geometry.BIG_ENDIAN; //unused
		
		//int[]
		TypeConverter<int[]> intConverter = new TypeConverter<int[]>(new int[0], geo, true);
		byte[] buffer;

		int[] intValues = {0, 100, Integer.MIN_VALUE+1, 40, 5, 34};
		buffer = intConverter.TtoByte(intValues);
		compare(buffer, intValues, geo[Geometry.SAMPLE_TYPE]);
		int[] intValues2 = intConverter.bytetoT(buffer);
		assertArrayEquals(intValues, intValues2);

		//long[]
		TypeConverter<long[]> longConverter = new TypeConverter<long[]>(new long[0], geo, false);
		TypeConverter<long[]> longConverter2 = new TypeConverter<long[]>(new long[0], geo, true);

		try {
			long[] longValuesTmp1 = {0, 100, Long.MIN_VALUE+1, 40, 5, 34};
			buffer = longConverter2.TtoByte(longValuesTmp1);
			fail("Missing error about lack of precision");
		}catch(LackOfPrecisionError e) {}

		try {
			long[] longValuesTmp2 = {0, 100, 30, 40, 5, Long.MAX_VALUE-1};
			buffer = longConverter2.TtoByte(longValuesTmp2);
			fail("Missing error about lack of precision");
		}catch(LackOfPrecisionError e) {}

		long[] longValues = {0, 100, Long.MAX_VALUE-1, 40, 5, 34};
		buffer = longConverter.TtoByte(longValues);
		longValues[2] = (long) ((double) longValues[2]);
		compare(buffer, longValues, geo[Geometry.SAMPLE_TYPE]);
		long[] longValues2 = longConverter.bytetoT(buffer);
		assertArrayEquals(longValues, longValues2);

		//float[]
		TypeConverter<float[]> floatConverter = new TypeConverter<float[]>(new float[0], geo, false);

		float[] floatValues = {0, 100, 30.4f, 40, 5, 34};
		buffer = floatConverter.TtoByte(floatValues);
		compare(buffer, floatValues, geo[Geometry.SAMPLE_TYPE]);
		float[] floatValues2 = floatConverter.bytetoT(buffer);
		assertTrue(Arrays.equals(floatValues, floatValues2));
	}

	public void compare(byte[] b, int[] values, int type) {
		int[] sizeTable = {1/* boolean */, 1/* byte */, 2/* char */, 2/* short */, 4/* int */, 8/* long */, 4/* float */, 8/* double */};
		int size = sizeTable[type];
		if(b.length != values.length*size) {
			System.out.println("Sizes are inconsistent");
			return;
		}
		ByteBuffer buffer = ByteBuffer.wrap(b);
		switch(type) {
			case Geometry.U_BYTE:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.get()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.U_SHORT:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.getChar()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.SHORT:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.getShort()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.INT:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.getInt()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.LONG:
				for(int i=0;i<values.length;i++) {
					if(values[i] != (int)buffer.getLong()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.FLOAT:
				for(int i=0;i<values.length;i++) {
					if(values[i] != (int)buffer.getFloat()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.DOUBLE:
				for(int i=0;i<values.length;i++) {
					if(values[i] != (int)buffer.getDouble()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
		}
	}

	public void compare(byte[] b, long[] values, int type) {
		int[] sizeTable = {1/* boolean */, 1/* byte */, 2/* char */, 2/* short */, 4/* int */, 8/* long */, 4/* float */, 8/* double */};
		int size = sizeTable[type];
		if(b.length != values.length*size) {
			System.out.println("Sizes are inconsistent");
			return;
		}
		ByteBuffer buffer = ByteBuffer.wrap(b);
		switch(type) {
			case Geometry.U_BYTE:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.get()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.U_SHORT:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.getChar()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.SHORT:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.getShort()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.INT:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.getInt()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.LONG:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.getLong()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.FLOAT:
				for(int i=0;i<values.length;i++) {
					if(values[i] != (long)buffer.getFloat()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.DOUBLE:
				for(int i=0;i<values.length;i++) {
					if(values[i] != (long)buffer.getDouble()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
		}
	}

	public void compare(byte[] b, float[] values, int type) {
		int[] sizeTable = {1/* boolean */, 1/* byte */, 2/* char */, 2/* short */, 4/* int */, 8/* long */, 4/* float */, 8/* double */};
		int size = sizeTable[type];
		if(b.length != values.length*size) {
			System.out.println("Sizes are inconsistent");
			return;
		}
		ByteBuffer buffer = ByteBuffer.wrap(b);
		switch(type) {
			case Geometry.U_BYTE:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.get()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.U_SHORT:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.getChar()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.SHORT:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.getShort()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.INT:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.getInt()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.LONG:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.getLong()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.FLOAT:
				for(int i=0;i<values.length;i++) {
					if(values[i] != buffer.getFloat()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
			case Geometry.DOUBLE:
				for(int i=0;i<values.length;i++) {
					if(values[i] != (float)buffer.getDouble()) {
						System.out.println("Error in pixel "+i);
						return;
					}
				}
				break;
		}
	}

}
