/*
 * GICI Library -
 * Copyright (C) 2007  Group on Interactive Coding of Images (GICI)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Group on Interactive Coding of Images (GICI)
 * Department of Information and Communication Engineering
 * Autonomous University of Barcelona
 * 08193 - Bellaterra - Cerdanyola del Valles (Barcelona)
 * Spain
 *
 * http://gici.uab.es
 * gici-info@deic.uab.es
 */
package GiciFile;

import java.io.*;
import java.nio.*;
import java.util.zip.GZIPInputStream;

import GiciException.WarningException;


/**
 * This class receives a raw image file and loads it.<br>
 *
 * @author Group on Interactive Coding of Images (GICI)
 * @version 1.0
 */
public class LoadRawFile {

	private abstract static class BufferReader {
		public abstract void fillLine (final int z, final int y, final int xSize, ByteBuffer buffer, final int sampleType);
	}
	
	private static class FloatBufferReader extends BufferReader { 
		final float[][][] imageSamples;

		FloatBufferReader(float[][][] imageSamples) {
			this.imageSamples = imageSamples;
		}

		public void fillLine (final int z, final int y, final int xSize, ByteBuffer buffer, final int sampleType) {
			switch(sampleType){
			case 0: //boolean (1 byte)
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = buffer.get(x) == 0 ? 0.0F : 1.0F;
				}
				break;
			case 1: //unsigned int (1 byte)
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = buffer.get(x) & 0xff;
				}
				break;
			case 2: //unsigned int (2 bytes)
				CharBuffer cb = buffer.asCharBuffer();
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = cb.get(x) & 0xffff;
				}
				break;
			case 3: //signed short (2 bytes)
				ShortBuffer sb = buffer.asShortBuffer();
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = sb.get(x);
				}
				break;
			case 4: //signed int (4 bytes)
				IntBuffer ib = buffer.asIntBuffer();
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = ib.get(x);
				}
				break;
			case 5: //signed long (8 bytes)
				LongBuffer lb = buffer.asLongBuffer();
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = lb.get(x);
				}
				break;
			case 6: //float (4 bytes)
				buffer.asFloatBuffer().get(imageSamples[z][y]);
				break;
			case 7: //double (8 bytes) - loss of precision
				DoubleBuffer db = buffer.asDoubleBuffer();
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = (float) db.get(x);
				}
				break;
			}
		}
	};
	
	private static class IntegerBufferReader extends BufferReader { 
		final int[][][] imageSamples;

		IntegerBufferReader(int[][][] imageSamples) {
			this.imageSamples = imageSamples;
		}

		public void fillLine (final int z, final int y, final int xSize, ByteBuffer buffer, final int sampleType) {
			switch(sampleType){
			case 0: //boolean (1 byte)
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = buffer.get(x) == 0 ? 0 : 1;
				}
				break;
			case 1: //unsigned int (1 byte)
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = buffer.get(x) & 0xff;
				}
				break;
			case 2: //unsigned int (2 bytes)
				CharBuffer cb = buffer.asCharBuffer();
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = cb.get(x) & 0xffff;
				}
				break;
			case 3: //signed short (2 bytes)
				ShortBuffer sb = buffer.asShortBuffer();
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = sb.get(x);
				}
				break;
			case 4: //signed int (4 bytes)
				buffer.asIntBuffer().get(imageSamples[z][y]);
				break;
			case 5: //signed long (8 bytes)
				LongBuffer lb = buffer.asLongBuffer();
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = (int)lb.get(x);
				}
				break;
			case 6: //float (4 bytes)
				FloatBuffer fb = buffer.asFloatBuffer();
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = (int) fb.get(x);
				}
				break;
			case 7: //double (8 bytes) - loss of precision
				DoubleBuffer db = buffer.asDoubleBuffer();
				for(int x = 0; x < xSize; x++){
					imageSamples[z][y][x] = (int) db.get(x);
				}
				break;
			}
		}
	};
	
	/**
	 * Loads a raw data image.
	 *
	 * @param imageFile an string that contains the name of the image file
	 * @param zSize an integer of image depth
	 * @param ySize an integer of image height
	 * @param xSize an integer of image width
	 * @param sampleType a Class of image samples type
	 * @param byteOrder 0 if BIG_ENDIAN, 1 if LITTLE_ENDIAN
	 * @param RGBComponents a boolean that indicates if the three first components are RGB (true, otherwise false)
	 *
	 * @throws WarningException when the file cannot be load
	 */
	private static void loadRawData(String imageFile, int zSize, int ySize, int xSize, int sampleType, int byteOrder, BufferReader bufferReader, int zSkip) throws IOException{
		assert (imageFile != null);

		//Test first for .gz
		boolean fileIsAGZ = false;
		int dotPos = imageFile.lastIndexOf(".");
		
		if(dotPos >= 0){
			fileIsAGZ = imageFile.substring(dotPos + 1, imageFile.length()).compareToIgnoreCase("gz") == 0;
		} 
		
		//Open file and loads it
		InputStream fis = null;
		
		if (fileIsAGZ) {
			fis = new GZIPInputStream(new FileInputStream(imageFile), 64*1024);
		} else {
			fis = new BufferedInputStream(new FileInputStream(imageFile), 64*1024);
		}

		DataInputStream dis = new DataInputStream(fis);

		//Buffer to perform data conversion
		ByteBuffer buffer;
		// Line size in bytes
		int byte_xSize;
		//Set correct line size
		int[] byte_xSize_table = {1/* boolean - 1 byte */, 1/* byte */, 2/* char */, 2/* short */, 4/* int */, 8/* long */, 4/* float */, 8/* double */}; 

		if (sampleType < 0 || sampleType >= byte_xSize_table.length) {
			throw new ArrayIndexOutOfBoundsException("Sample type out of range.");
		}

		byte_xSize = xSize * byte_xSize_table[sampleType];

		buffer = ByteBuffer.allocate(byte_xSize);

		switch(byteOrder){
		case 0: //BIG ENDIAN
			buffer = buffer.order(ByteOrder.BIG_ENDIAN);
			break;
		case 1: //LITTLE ENDIAN
			buffer = buffer.order(ByteOrder.LITTLE_ENDIAN);
			break;
		}

		// Skip zSkip components
		if (zSkip != 0) {
			dis.skip((long)zSkip * (long)ySize * (long)byte_xSize);
		}
		
		//Read image
		//Further speed improvements can be achieved in the worst case where image width is little by fixing a min read size and not reading less than it
		
		for(int z = 0; z < zSize; z++){
			for(int y = 0; y < ySize; y++){
				
				int bytes_read = 0;
				int buffer_fill = 0;
				
				// Keep trying till we get enough
				do {
					buffer_fill += bytes_read;
					bytes_read = dis.read(buffer.array(), buffer_fill, byte_xSize - buffer_fill);
				} while (bytes_read >= 0 && bytes_read + buffer_fill < byte_xSize);

				if (bytes_read >= 0) {
					bytes_read += buffer_fill;
				}
				
				if(bytes_read < 0) {
					throw new EOFException("File reading error (end of file reached before the full file has been read).");
				}
				
				if(bytes_read != byte_xSize){
					throw new IOException("File reading error (" + bytes_read + " bytes read, but " + byte_xSize + " needed).");
				}
				
				bufferReader.fillLine(z, y, xSize, buffer, sampleType);
			}
		}

		//Close .raw file
		fis.close();
	}
	
	/**
	 * Loads a raw data image.
	 *
	 * @param imageFile an string that contains the name of the image file
	 * @param zSize an integer of image depth
	 * @param ySize an integer of image height
	 * @param xSize an integer of image width
	 * @param sampleType a Class of image samples type
	 * @param byteOrder 0 if BIG_ENDIAN, 1 if LITTLE_ENDIAN
	 * @param RGBComponents a boolean that indicates if the three first components are RGB (true, otherwise false)
	 *
	 * @throws WarningException when the file cannot be load
	 */
	public static float[][][] loadRawDataToFloat(String imageFile, int zSize, int ySize, int xSize, int sampleType, int byteOrder, boolean RGBComponents) throws IOException{
		//Memory allocation
		float[][][] imageSamples = new float[zSize][ySize][xSize];
		
		loadRawData(imageFile, zSize, ySize, xSize, sampleType, byteOrder, new FloatBufferReader(imageSamples), 0);
		return imageSamples;
	}
	
	/**
	 * Loads a raw data image.
	 *
	 * @param imageFile an string that contains the name of the image file
	 * @param zSize an integer of image depth
	 * @param ySize an integer of image height
	 * @param xSize an integer of image width
	 * @param sampleType a Class of image samples type
	 * @param byteOrder 0 if BIG_ENDIAN, 1 if LITTLE_ENDIAN
	 * @param RGBComponents a boolean that indicates if the three first components are RGB (true, otherwise false)
	 *
	 * @throws WarningException when the file cannot be load
	 */
	public static int[][][] loadRawDataToInteger(String imageFile, int zSize, int ySize, int xSize, int sampleType, int byteOrder, boolean RGBComponents) throws IOException{
		//Memory allocation
		int[][][] imageSamples = new int[zSize][ySize][xSize];
		
		loadRawData(imageFile, zSize, ySize, xSize, sampleType, byteOrder, new IntegerBufferReader(imageSamples), 0);
		return imageSamples;
	}
	
	
	/**
	 * Loads a raw data image.
	 *
	 * @param imageFile an string that contains the name of the image file
	 * @param zSize an integer of image depth
	 * @param ySize an integer of image height
	 * @param xSize an integer of image width
	 * @param sampleType a Class of image samples type
	 * @param byteOrder 0 if BIG_ENDIAN, 1 if LITTLE_ENDIAN
	 * @param RGBComponents a boolean that indicates if the three first components are RGB (true, otherwise false)
	 *
	 * @throws WarningException when the file cannot be load
	 */
	public static int[][][] loadRawComponentDataToInteger(String imageFile, int zSize, int ySize, int xSize, int sampleType, int byteOrder, int zIndex) throws IOException{
		assert(zIndex >= 0 && zIndex < zSize);
		
		//Memory allocation
		int[][][] imageSamples = new int[1][ySize][xSize];
		
		loadRawData(imageFile, 1, ySize, xSize, sampleType, byteOrder, new IntegerBufferReader(imageSamples), zIndex);
		return imageSamples;
	}
}
