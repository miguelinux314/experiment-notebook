
package GiciEntropyCoder.BlockAdaptiveCoder.jUnits;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import GiciEntropyCoder.BlockAdaptiveCoder.BlockAdaptiveCoder;
import GiciEntropyCoder.BlockAdaptiveCoder.BlockAdaptiveDecoder;

@SuppressWarnings({"rawtypes", "unchecked"})
public class TestBlockAdaptiveCoder {

	private final Class cBlockAdaptiveCoder;

	private final Class cCoderBlockCounter;
	private final Field coderBlockCounter;
	private final Method coderIncrement;
	private final Method rOffset;
	private final Method sOffset;

	private final Class cCoderZeroBlock;
	private final Field coderZeroBlock;
	private final Field coderNumZeroBlocks;

	private final Class cCoderSecExt;
	private final Field coderSecExt;
	private final Field coderSecExtBlock;
	private final Method codeSecExtBlock;
	private final Method convertToSecExt;
	private final Method coderTransform;


	private final Class cBlockAdaptiveDecoder;

	private final Class cDecoderBlockCounter;
	private final Field decoderBlockCounter;
	private final Method decoderIncrement;
	private final Method rDistance;
	private final Method sDistance;

	private final Class cDecoderZeroBlock;
	private final Field decoderZeroBlock;
	private final Field decoderNumZeroBlocks;

	private final Class cDecoderSecExt;
	private final Field decoderSecExt;
	private final Field decoderSecExtBlock;
	private final Field b;
	private final Field ms;
	private final Method decodeSecExtBlock;
	private final Method convertFromSecExt;
	private final Method decoderTransform;


	public TestBlockAdaptiveCoder() throws NoSuchFieldException, NoSuchMethodException, SecurityException {

		cBlockAdaptiveCoder = BlockAdaptiveCoder.class;

		cCoderBlockCounter = cBlockAdaptiveCoder.getDeclaredClasses()[3];
		coderBlockCounter = cBlockAdaptiveCoder.getDeclaredField("blockCounter");
		coderBlockCounter.setAccessible(true);

		rOffset = cCoderBlockCounter.getDeclaredMethod("rOffset");
		rOffset.setAccessible(true);

		sOffset = cCoderBlockCounter.getDeclaredMethod("sOffset");
		sOffset.setAccessible(true);

		coderIncrement = cCoderBlockCounter.getDeclaredMethod("increment");
		coderIncrement.setAccessible(true);

		cCoderZeroBlock = cBlockAdaptiveCoder.getDeclaredClasses()[2];
		coderZeroBlock = cBlockAdaptiveCoder.getDeclaredField("zeroBlock");
		coderZeroBlock.setAccessible(true);

		coderNumZeroBlocks = cCoderZeroBlock.getDeclaredField("numZeroBlocks");
		coderNumZeroBlocks.setAccessible(true);

		cCoderSecExt = cBlockAdaptiveCoder.getDeclaredClasses()[1];
		coderSecExt = cBlockAdaptiveCoder.getDeclaredField("secExt");
		coderSecExt.setAccessible(true);

		coderSecExtBlock = cCoderSecExt.getDeclaredField("secExtBlock");
		coderSecExtBlock.setAccessible(true);

		convertToSecExt = cCoderSecExt.getDeclaredMethod("convertToSecExt", int[].class);
		convertToSecExt.setAccessible(true);

		coderTransform = cCoderSecExt.getDeclaredMethod("transform", int.class, int.class);
		coderTransform.setAccessible(true);

		codeSecExtBlock = cCoderSecExt.getDeclaredMethod("codeBlock");
		codeSecExtBlock.setAccessible(true);


		cBlockAdaptiveDecoder = BlockAdaptiveDecoder.class;

		cDecoderBlockCounter = cBlockAdaptiveDecoder.getDeclaredClasses()[3];
		decoderBlockCounter = cBlockAdaptiveDecoder.getDeclaredField("blockCounter");
		decoderBlockCounter.setAccessible(true);

		rDistance = cDecoderBlockCounter.getDeclaredMethod("rDistance");
		rDistance.setAccessible(true);

		sDistance = cDecoderBlockCounter.getDeclaredMethod("sDistance");
		sDistance.setAccessible(true);

		decoderIncrement = cDecoderBlockCounter.getDeclaredMethod("increment");
		decoderIncrement.setAccessible(true);

		cDecoderZeroBlock = cBlockAdaptiveDecoder.getDeclaredClasses()[2];
		decoderZeroBlock = cBlockAdaptiveDecoder.getDeclaredField("zeroBlock");
		decoderZeroBlock.setAccessible(true);

		decoderNumZeroBlocks = cDecoderZeroBlock.getDeclaredField("numZeroBlocks");
		decoderNumZeroBlocks.setAccessible(true);

		cDecoderSecExt = cBlockAdaptiveDecoder.getDeclaredClasses()[1];
		decoderSecExt = cBlockAdaptiveDecoder.getDeclaredField("secExt");
		decoderSecExt.setAccessible(true);

		decoderSecExtBlock = cDecoderSecExt.getDeclaredField("secExtBlock");
		decoderSecExtBlock.setAccessible(true);

		b = cDecoderSecExt.getDeclaredField("b");
		b.setAccessible(true);

		ms = cDecoderSecExt.getDeclaredField("ms");
		ms.setAccessible(true);

		convertFromSecExt = cDecoderSecExt.getDeclaredMethod("convertFromSecExt", int[].class);
		convertFromSecExt.setAccessible(true);

		decoderTransform = cDecoderSecExt.getDeclaredMethod("transform", int.class);
		decoderTransform.setAccessible(true);

		decodeSecExtBlock = cDecoderSecExt.getDeclaredMethod("decodeBlock", int[].class);
		decodeSecExtBlock.setAccessible(true);
	}

/*
	@Test
	public void testBlockCounter() throws IllegalAccessException, InvocationTargetException {

		int r = 256;
		int s = 64;

		// coder
		BlockAdaptiveCoder coder = new BlockAdaptiveCoder(null, 1, 1, false, r, s);
		assertTrue((int) rOffset.invoke(coderBlockCounter.get(coder)) == 0);
		assertTrue((int) sOffset.invoke(coderBlockCounter.get(coder)) == 0);

		coderIncrement.invoke(coderBlockCounter.get(coder));
		assertTrue((int) rOffset.invoke(coderBlockCounter.get(coder)) == 1);
		assertTrue((int) sOffset.invoke(coderBlockCounter.get(coder)) == 1);

		for (int i = 1; i < s; i++) {
			coderIncrement.invoke(coderBlockCounter.get(coder));
		}
		assertTrue((int) rOffset.invoke(coderBlockCounter.get(coder)) == s);
		assertTrue((int) sOffset.invoke(coderBlockCounter.get(coder)) == 0);

		for (int i = s; i < r; i++) {
			coderIncrement.invoke(coderBlockCounter.get(coder));
		}
		assertTrue((int) rOffset.invoke(coderBlockCounter.get(coder)) == 0);

		// decoder
		BlockAdaptiveDecoder decoder = new BlockAdaptiveDecoder(null, 1, 1, false, r, s);
		assertTrue((int) rDistance.invoke(decoderBlockCounter.get(decoder)) == r);
		assertTrue((int) sDistance.invoke(decoderBlockCounter.get(decoder)) == s);

		decoderIncrement.invoke(decoderBlockCounter.get(decoder));
		assertTrue((int) rDistance.invoke(decoderBlockCounter.get(decoder)) == r-1);
		assertTrue((int) sDistance.invoke(decoderBlockCounter.get(decoder)) == s-1);

		for (int i = 1; i < s; i++) {
			decoderIncrement.invoke(decoderBlockCounter.get(decoder));
		}
		assertTrue((int) rDistance.invoke(decoderBlockCounter.get(decoder)) == r-s);
		assertTrue((int) sDistance.invoke(decoderBlockCounter.get(decoder)) == s);

		for (int i = s; i < r; i++) {
			decoderIncrement.invoke(decoderBlockCounter.get(decoder));
		}
		assertTrue((int) rDistance.invoke(decoderBlockCounter.get(decoder)) == r);
	}


	@Test
	public void testSecExtTransform() throws IllegalAccessException, InvocationTargetException {

		// coder
		BlockAdaptiveCoder coder = new BlockAdaptiveCoder(null, 1, 1, false, 1, 1);

		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 0, 0) == 0);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 1, 0) == 1);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 0, 1) == 2);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 2, 0) == 3);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 1, 1) == 4);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 0, 2) == 5);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 3, 0) == 6);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 2, 1) == 7);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 1, 2) == 8);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 0, 3) == 9);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 4, 0) == 10);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 3, 1) == 11);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 2, 2) == 12);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 1, 3) == 13);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 0, 4) == 14);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 5, 0) == 15);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 4, 1) == 16);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 3, 2) == 17);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 2, 3) == 18);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 1, 4) == 19);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 0, 5) == 20);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 6, 0) == 21);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 5, 1) == 22);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 4, 2) == 23);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 3, 3) == 24);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 2, 4) == 25);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 1, 5) == 26);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 0, 6) == 27);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 7, 0) == 28);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 6, 1) == 29);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 5, 2) == 30);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 4, 3) == 31);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 3, 4) == 32);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 2, 5) == 33);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 1, 6) == 34);
		assertTrue((long) coderTransform.invoke(coderSecExt.get(coder), 0, 7) == 35);

		// decoder
		BlockAdaptiveDecoder decoder = new BlockAdaptiveDecoder(null, 1, 1, false, 1, 1);

		decoderTransform.invoke(decoderSecExt.get(decoder), 0);
		assertTrue(b.getInt(decoderSecExt.get(decoder)) == 0 && ms.getInt(decoderSecExt.get(decoder)) == 0);

		for (int i = 1; i <= 2; i++) {
			decoderTransform.invoke(decoderSecExt.get(decoder), i);
			assertTrue(b.getInt(decoderSecExt.get(decoder)) == 1 && ms.getInt(decoderSecExt.get(decoder)) == 1);
		}

		for (int i = 3; i <= 5; i++) {
			decoderTransform.invoke(decoderSecExt.get(decoder), i);
			assertTrue(b.getInt(decoderSecExt.get(decoder)) == 2 && ms.getInt(decoderSecExt.get(decoder)) == 3);
		}

		for (int i = 6; i <= 9; i++) {
			decoderTransform.invoke(decoderSecExt.get(decoder), i);
			assertTrue(b.getInt(decoderSecExt.get(decoder)) == 3 && ms.getInt(decoderSecExt.get(decoder)) == 6);
		}

		for (int i = 10; i <= 14; i++) {
			decoderTransform.invoke(decoderSecExt.get(decoder), i);
			assertTrue(b.getInt(decoderSecExt.get(decoder)) == 4 && ms.getInt(decoderSecExt.get(decoder)) == 10);
		}

		for (int i = 15; i <= 20; i++) {
			decoderTransform.invoke(decoderSecExt.get(decoder), i);
			assertTrue(b.getInt(decoderSecExt.get(decoder)) == 5 && ms.getInt(decoderSecExt.get(decoder)) == 15);
		}

		for (int i = 21; i <= 27; i++) {
			decoderTransform.invoke(decoderSecExt.get(decoder), i);
			assertTrue(b.getInt(decoderSecExt.get(decoder)) == 6 && ms.getInt(decoderSecExt.get(decoder)) == 21);
		}

		for (int i = 28; i <= 35; i++) {
			decoderTransform.invoke(decoderSecExt.get(decoder), i);
			assertTrue(b.getInt(decoderSecExt.get(decoder)) == 7 && ms.getInt(decoderSecExt.get(decoder)) == 28);
		}
	}


	@Test
	public void testSecExtTransformSanity() throws IllegalAccessException, InvocationTargetException {

		int[] inData;
		int[] outData;

		for (int j = 1; j < 64; j++) {
			inData = new int[j];
			outData = new int[j];

			Random rand = new Random();
			for (int i = 0; i < j; i++) {
				inData[i] = rand.nextInt() & 0xff;
				outData[i] = ~inData[i];
			}

			BlockAdaptiveCoder coder = new BlockAdaptiveCoder(null, 1, 1, false, 1, 1);
			convertToSecExt.invoke(coderSecExt.get(coder), inData);

			BlockAdaptiveDecoder decoder = new BlockAdaptiveDecoder(null, 1, 1, false, 1, 1);
			decoderSecExtBlock.set(decoderSecExt.get(decoder), coderSecExtBlock.get(coderSecExt.get(coder)));
			convertFromSecExt.invoke(decoderSecExt.get(decoder), outData);

			assertArrayEquals(inData, outData);
		}
	}


	@Test
	public void testSecExtSanity() throws IOException, IllegalAccessException, InvocationTargetException {

		File file = new File("temp");
		FileInputStream fis;
		FileOutputStream fos;

		int[] inData;
		int[] outData;

		for (int j = 1; j < 64; j++) {
			inData = new int[j];
			outData = new int[j];

			Random rand = new Random();
			for (int i = 0; i < j; i++) {
				inData[i] = rand.nextInt() & 0x0f;
				outData[i] = ~inData[i];
			}

			fos = new FileOutputStream(file);
			BlockAdaptiveCoder coder = new BlockAdaptiveCoder(new BitOutputStream(fos), 1, 1, false, 1, 1);
			convertToSecExt.invoke(coderSecExt.get(coder), inData);
			codeSecExtBlock.invoke(coderSecExt.get(coder));
			coder.finish();
			fos.close();

			fis = new FileInputStream(file);
			BlockAdaptiveDecoder decoder = new BlockAdaptiveDecoder(new BitInputStream(fis), 1, 1, false, 1, 1);
			decodeSecExtBlock.invoke(decoderSecExt.get(decoder), outData);
			fis.close();

			assertArrayEquals(inData, outData);
		}

		file.delete();
	}

/*
	@Test
	public void testZeroBlock() throws IOException, IllegalAccessException, InvocationTargetException {

		File file = new File("temp");
		FileOutputStream fos;

		int r = 200;
		int s = 64;

		int j = 16;
		int[] block = new int[j];
		for (int i = 0; i < j; i++) {
			block[i] = 0;
		}

		fos = new FileOutputStream(file);
		BlockAdaptiveCoder coder = new BlockAdaptiveCoder(new BitOutputStream(fos), 1, 1, false, r, s);
		assertTrue(coderNumZeroBlocks.getInt(coderZeroBlock.get(coder)) == 0);

		coder.codeBlock(block);
		assertTrue(coderNumZeroBlocks.getInt(coderZeroBlock.get(coder)) == 1);
		assertTrue(file.length() == 0);

		while ((int) sOffset.invoke(coderBlockCounter.get(coder)) != 0) {
			coder.codeBlock(block);
		}
		coder.finish();
		fos.close();

		assertTrue(coderNumZeroBlocks.getInt(coderZeroBlock.get(coder)) == 0);
		assertTrue(file.length() == 2);

		fos = new FileOutputStream(file);
		coder = new BlockAdaptiveCoder(new BitOutputStream(fos), 1, 1, false, r, s);

		for (int i = 0; i < r; i++) {
			coder.codeBlock(block);
		}
		coder.finish();
		fos.close();

		assertTrue(file.length() == 5);

		file.delete();
	}

	@Test
	public void testZeroBlockSanity() throws IOException, IllegalAccessException, InvocationTargetException {

		File file = new File("temp");
		FileInputStream fis;
		FileOutputStream fos;

		int r = 10;
		int s = 4;

		int numBlocks = 10000;
		int blockSize = 1;
		int len = numBlocks * blockSize;

		int[] inData = new int[len];
		int[] outData = new int[len];

		Random rand = new Random();
		for (int i = 0; i < len; i++) {
			int x = rand.nextInt() & 0xff;
			inData[i] = (x == 0) ? 1 : 0;
			outData[i] = ~inData[i];
		}

		fos = new FileOutputStream(file);
		BlockAdaptiveCoder coder = new BlockAdaptiveCoder(new BitOutputStream(fos), blockSize, 1, false, r, s);
		coder.code(inData);
		fos.close();

		fis = new FileInputStream(file);
		BlockAdaptiveDecoder decoder = new BlockAdaptiveDecoder(new BitInputStream(fis), blockSize, 1, false, r, s);
		decoder.decode(outData);
		fis.close();

		assertArrayEquals(inData, outData);

		file.delete();
	}


	@Test
	public void testDecider() {
		// how?
	}


	@Test
	public void testCompression() throws IOException {

		File file = new File("temp");
		FileOutputStream fos;

		int blockSize = 16;
		int numBlocks = 16;

		int r = 256;
		int s = 64;

		int len = numBlocks * blockSize;
		int[] inData = new int[len];

		Random rand = new Random();
		for (int i = 0; i < len; i++) {
			inData[i] = rand.nextInt();
		}

		for (int d = 1; d <= 32; d++) {
			int idBits;
			if (d <= 8) {
				idBits = 3;
			}
			else if (d <= 16) {
				idBits = 4;
			}
			else {
				idBits = 5;
			}

			fos = new FileOutputStream(file);
			BlockAdaptiveCoder coder = new BlockAdaptiveCoder(new BitOutputStream(fos), blockSize, d, false, r, s);
			coder.code(inData);
			fos.close();

			assertTrue(file.length() <= (len * d + numBlocks * idBits + 7) / 8);
		}

		file.delete();
	}


	@Test
	public void testSanity() throws IOException {

		File file = new File("temp");
		FileInputStream fis;
		FileOutputStream fos;

		int blockSize = 16;
		int len = 1024;
		int[] inData = new int[len];
		int[] outData = new int[len];

		int r = 256;
		int s = 64;

		Random rand = new Random();

		for (int d = 1; d <= 32; d++) {
			for (int i = 0; i < len; i++) {
				inData[i] = rand.nextInt() & (int) ~(0xffffffffL << d);
				outData[i] = ~inData[i];
			}

			fos = new FileOutputStream(file);
			BlockAdaptiveCoder coder = new BlockAdaptiveCoder(new BitOutputStream(fos), blockSize, d, false, r, s);
			coder.code(inData);
			fos.close();

			fis = new FileInputStream(file);
			BlockAdaptiveDecoder decoder = new BlockAdaptiveDecoder(new BitInputStream(fis), blockSize, d, false, r, s);
			decoder.decode(outData);
			fis.close();

			assertArrayEquals(inData, outData);
		}

		file.delete();
	}
	*/

}
