
package GiciEntropyCoder.Interface;

import java.io.IOException;


/**
 * This is the interface for classes that implement image encoding 
 * functionality.
 */
public interface ImageCoder {

	/**
	 * Encodes an image.
	 *
	 * @param img An array containing the image to be encoded.
	 * Generaly, the first dimension of the array corresponds to bands, the
	 * second to height and the third to width.
	 *
	 * @throws IOException if an IO error prevents the process from completing.
	 */
	void codeImage(int[][][] img) throws IOException;

}
