package GiciEntropyCoder.ArithmeticCoder;

import java.io.DataInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;

import GiciEntropyCoder.EntropyDecoder;
import GiciEntropyCoder.ProbabilityTable;

public class ArithmeticDecoder implements EntropyDecoder {
	final BinaryProbabilityMapping binaryProbabilityMapping;
	final DumbMQDecoder dumbMQDecoder;
	
	final int bitCount;
	final boolean[] bits;
	
	class LimitedInputStream extends FilterInputStream {
		long sizeLimit;
		long sizeCount;

	    protected LimitedInputStream(InputStream arg0) {
			super(arg0);
			DataInputStream ds = new DataInputStream(arg0);
			try {
				this.sizeLimit = ds.readLong();
				//	ds.close();
			} catch (IOException e) {
				e.printStackTrace();		
			}
			
			this.sizeCount = 0;
		}
		
		public int read() throws IOException {
			if (sizeCount < sizeLimit) {
				sizeCount++;
				return super.read();
			} else {
				return -1;
			}
		}
	}
	
	public ArithmeticDecoder(ProbabilityTable probabilityTable, InputStream inputStream) {
		this.binaryProbabilityMapping = new BinaryProbabilityMapping(probabilityTable);
		this.dumbMQDecoder = new DumbMQDecoder(new LimitedInputStream(inputStream));
		
		bitCount = binaryProbabilityMapping.getBitLength();
		bits = new boolean[bitCount];
	}
	
	public BigInteger decodeSymbol() throws IOException {
		for (int i = 0; i < bitCount; i++) {
			int probability = binaryProbabilityMapping.getPartialProbability(bits, i);
			bits[i] = dumbMQDecoder.decodeBit(probability);
		}

		return binaryProbabilityMapping.bitsToSymbol(bits);
	}
}
