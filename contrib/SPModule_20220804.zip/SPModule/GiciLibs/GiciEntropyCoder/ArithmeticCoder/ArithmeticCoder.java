package GiciEntropyCoder.ArithmeticCoder;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;

import GiciEntropyCoder.EntropyCoder;
import GiciEntropyCoder.ProbabilityTable;

/**
 * write
 *
 */

public class ArithmeticCoder implements EntropyCoder {
	final BinaryProbabilityMapping binaryProbabilityMapping;
	final OutputStream outputStream;
	
	final ByteArrayOutputStream outputByteStream;
	final DumbMQCoder dumbMQCoder;
	
	public ArithmeticCoder(ProbabilityTable probabilityTable, OutputStream outputStream) {
		this.binaryProbabilityMapping = new BinaryProbabilityMapping(probabilityTable);
		this.outputStream = outputStream;
		
		this.outputByteStream = new ByteArrayOutputStream();
		this.dumbMQCoder = new DumbMQCoder(outputByteStream);
	}
		
	public void codeSymbol (BigInteger symbol) throws IOException {		
		boolean [] bits = binaryProbabilityMapping.getBits(symbol);
		int [] probabilities = binaryProbabilityMapping.getProbabilities(bits);
		
		for (int i = 0; i < bits.length; i++) {
			dumbMQCoder.codeBit(bits[i], probabilities[i]);
		}
	}

	boolean terminated = false;
	
	public void terminate() throws IOException {
		assert (!terminated);
		terminated = true;
		
		dumbMQCoder.terminate();
		
		DataOutputStream dos = new DataOutputStream(outputStream);
		dos.writeLong(outputByteStream.size());
		dos.flush();
		
		outputByteStream.writeTo(outputStream);
	}
}
