package GiciEntropyCoder;

import java.io.IOException;
import java.math.BigInteger;

public interface EntropyDecoder {
	public abstract BigInteger decodeSymbol() throws IOException;
}