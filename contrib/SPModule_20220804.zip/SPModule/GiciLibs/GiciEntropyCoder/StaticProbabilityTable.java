package GiciEntropyCoder;

import java.math.BigInteger;
import java.util.Arrays;

/**
 * Represents a compressed-range probability table (ideal for arithmetic coding).
 * It is intended to provide support to very large symbol tables, and several-bytes
 * symbols. 
 * @author ian
 *
 */
public class StaticProbabilityTable implements ProbabilityTable {
		
	// Initial probability for each bound
	// S1 = [rangeBounds[0], rangeBounds[1]),
	// S2 = [rangeBounds[1], rangeBounds[2]),
	// SN = [rangeBounds[N-2], totalRange);
	final private BigInteger[] rangeBounds;
	final private BigInteger totalRange;
	
	protected StaticProbabilityTable(final BigInteger[] rangeBounds) {
		// Assert at least two elements and a power-of-two total count.
		assert (rangeBounds.length > 2);
		assert(rangeBounds[rangeBounds.length - 1].bitLength() == rangeBounds[rangeBounds.length - 1].getLowestSetBit() + 1);
		
		// Copy to our table (perhaps not required)
		this.rangeBounds = new BigInteger[rangeBounds.length];
		
		for (int i = 0; i < rangeBounds.length; i++) {
			assert(rangeBounds[i] != null);
			this.rangeBounds[i] = rangeBounds[i];
		}
		
		totalRange = rangeBounds[rangeBounds.length - 1];
	}

	public BigInteger getSymbolCount() {
		return BigInteger.valueOf(rangeBounds.length - 1);
	}
	
	public BigInteger getObservationCount() {
		return totalRange;
	}
	
	private int bigIntegerToIndex (BigInteger symbol) {
		int index = symbol.intValue();
		// symbol is allowed to be = rangeBounds.length - 1 to get the total cumulative frequency
		assert(index >= 0 && index < rangeBounds.length);
		
		return index;
	}
	
	public BigInteger getCumulativeFrequency(BigInteger symbol) {
		return rangeBounds[bigIntegerToIndex(symbol)];
	}

	public BigInteger getFrequency(BigInteger symbol) {
		int index = bigIntegerToIndex(symbol);
		
		return rangeBounds[index + 1].subtract(rangeBounds[index]);
	}

	public BigInteger findSymbolFromFrequency(BigInteger cumulativeFrequency) {
		assert (cumulativeFrequency.compareTo(BigInteger.ZERO) >= 0);
		assert (cumulativeFrequency.compareTo(totalRange) < 0);
		
		int result = Arrays.binarySearch(rangeBounds, cumulativeFrequency);
				
		if (result < 0) {
			int insertionPoint = -result - 1;
			result = insertionPoint - 1;
		}
		
		assert (result >= 0 && result < rangeBounds.length - 1);
		
		return BigInteger.valueOf(result);
	}
	
	final public int getSymbolByteSize() {
		int v = totalRange.bitLength() - 1;
		
		return (v) / 8 + (v % 8 != 0 ? 1 : 0);
	}
	
	final public void updateState(final BigInteger symbol) {
		// Not dynamic, so do nothing.
	}
}
