package GiciEntropyCoder;

import java.io.ByteArrayOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.math.BigInteger;

public class EntropyDecoderStream extends FilterInputStream {

	boolean open = true;
	EntropyDecoder decoder;
	ByteArrayOutputStream os = new ByteArrayOutputStream();
	
	protected EntropyDecoderStream(EntropyDecoder decoder) {
		super(null);
		this.decoder = decoder;
		
		// Does not work
		assert (false);
	}

	public int available() throws IOException {
		return 0;
	}

	public void close() throws IOException {
		super.close();
		open = false;
	}

	// No mark/reset support
	public synchronized void mark(int readlimit) {
	}

	public boolean markSupported() {
		return false;
	}

	public synchronized void reset() throws IOException {
		//super.reset();
		throw new IOException("Unsupported operation");
	}
	
	// Three fake functions for compatibility
	public int read() throws IOException {
		byte b[] = new byte[1];
		
		if (this.read(b) < 0)
			return -1;
		
		return (int) b[0];
	}

	public int read(byte[] b) throws IOException {
		return this.read(b, 0, b.length);
	}

	public long skip(final long n) throws IOException {
		if (n < 0)
			return 0;
		
		long remaining = n;
		int bufferSize;
		int result = 0;
			
		do {
			bufferSize = (int)(remaining % 65536);
			byte[] b = new byte[bufferSize];

			result = this.read(b);

			if (result < 0) {
				return n - remaining;
			}
			
			remaining -= result;
		} while (remaining >= 0 && result == bufferSize);
		
		return n - remaining;
	}
	
	private byte[] myToByteArray(BigInteger v, int length) {
		byte[] lowByteArray = v.toByteArray();
		
		byte[] result = new byte[length];
		
		int bytesFromV = v.bitLength();
		
		bytesFromV = bytesFromV / 8 + (bytesFromV % 8 != 0 ? 1 : 0);
		
		if (bytesFromV > length)
			bytesFromV = length;
		
		System.arraycopy(lowByteArray, lowByteArray.length - bytesFromV, result, length - bytesFromV, bytesFromV);
		
		return result;
	}
	
	public int read(byte[] b, int off, int len) throws IOException {
		if (! open)
			throw new IOException("Stream is closed");
		if (b == null)
			throw new NullPointerException();
		if (off < 0 || len < 0 || len > b.length - off)
			throw new IndexOutOfBoundsException();
		
		while (len - os.size() > 0) {
			BigInteger symbol = decoder.decodeSymbol();
		//	byte[] output = myToByteArray(symbol, getSymbolByteSize());
			//os.write(output);
		}
		
		byte[] osb = os.toByteArray();
		System.arraycopy(osb, 0, b, off, len);
		
		// Keep the remaining data in the buffer
		os.reset();
		os.write(osb, len, osb.length - len);
		
		return len;
	}
}
