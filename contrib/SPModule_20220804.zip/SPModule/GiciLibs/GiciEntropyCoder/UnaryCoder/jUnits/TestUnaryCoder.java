
package GiciEntropyCoder.UnaryCoder.jUnits;

import org.junit.*;
import static org.junit.Assert.*;

import GiciEntropyCoder.UnaryCoder.*;
import GiciStream.*;

import java.io.*;
import java.util.*;


public class TestUnaryCoder {

	@Test
	public void writeTest() throws IOException {

		File file = new File("temp");
		FileOutputStream fos;

		UnaryCoder coder;

		fos = new FileOutputStream(file);
		coder = new UnaryCoder(new BitOutputStream(fos));
		coder.codeSample(0);
		coder.finish();
		fos.close();
		assertTrue(file.length() == 1);

		fos = new FileOutputStream(file);
		coder = new UnaryCoder(new BitOutputStream(fos));
		coder.codeSample(7);
		coder.finish();
		fos.close();
		assertTrue(file.length() == 1);

		fos = new FileOutputStream(file);
		coder = new UnaryCoder(new BitOutputStream(fos));
		coder.codeSample(8);
		coder.finish();
		fos.close();
		assertTrue(file.length() == 2);

		fos = new FileOutputStream(file);
		coder = new UnaryCoder(new BitOutputStream(fos));
		coder.codeSample(15);
		coder.finish();
		fos.close();
		assertTrue(file.length() == 2);

		fos = new FileOutputStream(file);
		coder = new UnaryCoder(new BitOutputStream(fos));
		coder.codeSample(16);
		coder.finish();
		fos.close();
		assertTrue(file.length() == 3);

		// Writes a couple hundred megabytes bit by bit.
		// Takes too long.
		//fos = new FileOutputStream(file);
		//coder = new UnaryCoder(new BitOutputStream(fos));
		//coder.codeSample(0x80000000);
		//coder.finish();
		//fos.close();
		//assertTrue(file.length() == 2147483649L);

		file.delete();
	}


	@Test
	public void readTest() throws IOException {

		File file = new File("temp");
		FileInputStream fis;
		FileOutputStream fos;

		UnaryDecoder decoder;

		fos = new FileOutputStream(file);
		fos.write(0x80);
		fos.close();
		fis = new FileInputStream(file);
		decoder = new UnaryDecoder(new BitInputStream(fis));
		assertTrue(decoder.decodeSample() == 0);
		fis.close();

		fos = new FileOutputStream(file);
		fos.write(0x01);
		fos.close();
		fis = new FileInputStream(file);
		decoder = new UnaryDecoder(new BitInputStream(fis));
		assertTrue(decoder.decodeSample() == 7);
		fis.close();

		fos = new FileOutputStream(file);
		fos.write(0x00);
		fos.write(0x80);
		fos.close();
		fis = new FileInputStream(file);
		decoder = new UnaryDecoder(new BitInputStream(fis));
		assertTrue(decoder.decodeSample() == 8);
		fis.close();

		file.delete();
	}


	@Test
	public void sanityTest() throws IOException {

		int len = 1024;
		int[] inData = new int[len];
		int[] outData = new int[len];

		Random rand = new Random();
		for (int i = 0; i < len; i++) {
			inData[i] = rand.nextInt() & 0xff;
			outData[i] = ~inData[i];
		}

		File file = new File("temp");
		FileInputStream fis;
		FileOutputStream fos;

		fos = new FileOutputStream(file);
		UnaryCoder coder = new UnaryCoder(new BitOutputStream(fos));
		coder.code(inData);
		fos.close();

		fis = new FileInputStream(file);
		UnaryDecoder decoder = new UnaryDecoder(new BitInputStream(fis));
		decoder.decode(outData);
		fis.close();

		assertArrayEquals(inData, outData);

		file.delete();
	}

}
