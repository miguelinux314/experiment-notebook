package GiciEntropyCoder;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Arrays;

/* This is a _very_ high precision arithmetic coder */ 
public class EntropyCoderStream extends FilterOutputStream {

	boolean open = true;
	EntropyCoder coder;
	
	protected EntropyCoderStream(EntropyCoder coder) {
		super(null);
		this.coder = coder;
		
		// Does not work
		assert(false);
	}

	public void close() throws IOException {
		coder.terminate();
		open = false;
	}

	public void flush() throws IOException {
		// Nothing to see here, move along...
	}
	
	public void write(byte[] b) throws IOException {
		this.write(b,0,b.length);
	}

	public void write(int b) throws IOException {
		byte[] t = {(byte) b};
		this.write(t);
	}
	
	public void write(byte[] b, int off, int len) throws IOException {
		if (! open)
			throw new IOException("Stream is closed");
		if (b == null)
			throw new NullPointerException();
		if (off < 0 || len < 0 || len > b.length - off)
			throw new IndexOutOfBoundsException();
		
		byte[] b2 = Arrays.copyOfRange(b, off, off + len);
		
		//coder.codeSymbol(b2);
	}
	
	private BigInteger myToBigInt(byte[] b) {		
		if ((new BigInteger(b)).compareTo(BigInteger.ZERO) != 0) {
			return new BigInteger(1, b);
		} else {
			return BigInteger.ZERO;
		}
	}
}
