
package GiciEntropyCoder.EntropyBlockCoder.jUnits;

import java.io.IOException;

import org.junit.Test;


public class TestEntropyBlockCoder {

	// Takes too long

	// 2014/05/16: this code is dead
	
	@Test
	public void testSanity() throws IOException {
/*
		File file = new File("temp");
		FileInputStream fis;
		FileOutputStream fos;

		int bands = 16;
		int height = 17;
		int width = 18;

		int[][][] inImage = new int[bands][height][width];
		int[][][] outImage = new int[bands][height][width];

		Random rand = new Random();

		// band sequential
		for (int b = 1; b <= 2; b++) {
			for (int d = 1; d <= 16; d++) {
				for (int i = 0; i < bands; i++) {
					for (int j = 0; j < height; j++) {
						for (int k = 0; k < width; k++) {
							inImage[i][j][k] = rand.nextInt() & (int) ~(0xffffffff << d);
							outImage[i][j][k] = ~inImage[i][j][k];
						}
					}
				}

				fos = new FileOutputStream(file);
				EntropyBlockCoder coder = new EntropyBlockCoder(
					new BitOutputStream(fos),
					b*8,  // block size
					d,    // dynamic range
					256,  // reference sample interval
					true, // band sequential
					3,    // interleaving depth
					false // verbose
					);
				coder.codeImage(inImage);
				fos.close();

				fis = new FileInputStream(file);
				EntropyBlockDecoder decoder = new EntropyBlockDecoder(
					new BitInputStream(fis),
					b*8,  // block size
					d,    // dynamic range
					256,  // reference sample interval
					true, // band sequential
					3,    // interleaving depth
					false // verbose
					);
				decoder.decodeImage(outImage);
				fis.close();

				for (int i = 0; i < bands; i++) {
					for (int j = 0; j < height; j++) {
						for (int k = 0; k < width; k++) {
							assertTrue(inImage[i][j][k] == outImage[i][j][k]);
						}
					}
				}
			}
		}

		// band interleaved
		for (int b = 1; b <= 2; b++) {
			for (int d = 1; d <= 16; d++) {
				for (int m = 1; m <= bands; m++) {

					for (int i = 0; i < bands; i++) {
						for (int j = 0; j < height; j++) {
							for (int k = 0; k < width; k++) {
								inImage[i][j][k] = rand.nextInt() & (int) ~(0xffffffff << d);
								outImage[i][j][k] = ~inImage[i][j][k];
							}
						}
					}

					fos = new FileOutputStream(file);
					EntropyBlockCoder coder = new EntropyBlockCoder(
						new BitOutputStream(fos),
						b*8,  // block size
						d,    // dynamic range
						256,  // reference sample interval
						false, // band sequential
						m,    // interleaving depth
						false // verbose
						);
					coder.codeImage(inImage);
					fos.close();

					fis = new FileInputStream(file);
					EntropyBlockDecoder decoder = new EntropyBlockDecoder(
						new BitInputStream(fis),
						b*8,  // block size
						d,    // dynamic range
						256,  // reference sample interval
						false, // band sequential
						m,    // interleaving depth
						false // verbose
						);
					decoder.decodeImage(outImage);
					fis.close();

					for (int i = 0; i < bands; i++) {
						for (int j = 0; j < height; j++) {
							for (int k = 0; k < width; k++) {
								assertTrue(inImage[i][j][k] == outImage[i][j][k]);
							}
						}
					}

				}
			}
		}

		file.delete();*/
	}

}
