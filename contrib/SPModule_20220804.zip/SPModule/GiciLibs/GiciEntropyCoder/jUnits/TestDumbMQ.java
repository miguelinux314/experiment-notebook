package GiciEntropyCoder.jUnits;

import java.io.*;
import java.util.Random;

import GiciEntropyCoder.ArithmeticCoder.DumbMQCoder;
import GiciEntropyCoder.ArithmeticCoder.DumbMQDecoder;

import junit.framework.TestCase;

public class TestDumbMQ extends TestCase {

	public void testDumbMQ() throws IOException {
		
		ByteArrayOutputStream bo = new ByteArrayOutputStream();
		
		DumbMQCoder dmqc = new DumbMQCoder(bo);
		
		dmqc.codeBit(true, 0x5005);
		dmqc.codeBit(false, 0x5005);
		
		dmqc.terminate();
		
		dmqc = null;
		
		ByteArrayInputStream bi = new ByteArrayInputStream(bo.toByteArray());
		bo = null;
		
		DumbMQDecoder dmqd = new DumbMQDecoder(bi);
		
		boolean bit1 = dmqd.decodeBit(0x5005);
		boolean bit2 = dmqd.decodeBit(0x5005);
		
		assertTrue(bit1 == true);
		assertTrue(bit2 == false);
	}
	
	public void testDumbLong() throws IOException {
		
		final int testLength = 20240;
		
		Random ra = new Random(15);
		boolean[] bits = new boolean[testLength];
		int[] probs = new int[testLength];
		
		for (int i = 0; i < testLength; i++) {
			bits[i] = ra.nextBoolean();
			probs[i] = ra.nextInt(0xAC01 / 100) + 1;
		}
		
		ByteArrayOutputStream bo = new ByteArrayOutputStream();		
		DumbMQCoder dmqc = new DumbMQCoder(bo);
		
		for (int i = 0; i < testLength; i++) {
			dmqc.codeBit(bits[i], probs[i]);
		}
		
		dmqc.terminate();
		
		dmqc = null;
		
		ByteArrayInputStream bi = new ByteArrayInputStream(bo.toByteArray());
		bo = null;
		
		DumbMQDecoder dmqd = new DumbMQDecoder(bi);
		
		for (int i = 0; i < testLength; i++) {
			assertTrue(bits[i] == dmqd.decodeBit(probs[i]));
		}
	}
	
	public void testEntropy() throws IOException {
		
		final int testLength = 2024;
		
		Random ra = new Random(15);
		boolean[] bits = new boolean[testLength];
		int[] probs = new int[testLength];
		
		for (int i = 0; i < testLength; i++) {
			bits[i] = ra.nextInt(1000) > 300;
			//probs[i] = ra.nextInt(0xAC01 * 7 / 10) + 1;
			probs[i] = 0xAC01 * 7 / 10;
		}
		
		bits[10] = false;
		
		ByteArrayOutputStream bo = new ByteArrayOutputStream();		
		DumbMQCoder dmqc = new DumbMQCoder(bo);
		
		for (int i = 0; i < testLength; i++) {
			dmqc.codeBit(bits[i], probs[i]);
		}
		
		dmqc.terminate();
		
		dmqc = null;
		
		ByteArrayInputStream bi = new ByteArrayInputStream(bo.toByteArray());
		
		//System.out.println(bo.toByteArray().length * 8);
		//System.out.println(-testLength * (0.7 * Math.log(0.7) / Math.log(2) + 0.3 * Math.log(0.3) / Math.log(2)));
		
		// 0.98% Efficiency
		// It seems that it works
		
		bo = null;
		
		DumbMQDecoder dmqd = new DumbMQDecoder(bi);
		
		for (int i = 0; i < testLength; i++) {
			assertTrue(bits[i] == dmqd.decodeBit(probs[i]));
		}
	}
}
