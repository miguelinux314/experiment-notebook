package GiciEntropyCoder.jUnits;

import java.math.BigInteger;

import GiciEntropyCoder.StaticProbabilityTable;

class DiffProbabilityTables extends StaticProbabilityTable {
	
	private static BigInteger[] newBounds (BigInteger[] rangeBounds) {
		BigInteger[] result = new BigInteger[rangeBounds.length];
		
		for (int i = 0; i < rangeBounds.length; i++) {
			result[i] = rangeBounds[i].multiply(BigInteger.valueOf(2 << 20)).divide(rangeBounds[rangeBounds.length - 1]);
		}
		
		assert(result[rangeBounds.length - 1].bitLength() == result[rangeBounds.length - 1].getLowestSetBit() + 1);
		
		return result;
	}
	
	public DiffProbabilityTables(BigInteger[] rangeBounds) {
		
		// Assert at least two elements and a power-of-two total count.
		
		super(newBounds(rangeBounds));
		
		
	}	
	
};