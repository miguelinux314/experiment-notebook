package GiciEntropyCoder.jUnits;

import java.io.*;
import java.math.BigInteger;
import java.util.Random;

import GiciEntropyCoder.*;
import GiciEntropyCoder.ArithmeticCoder.ArithmeticCoder;
import GiciEntropyCoder.ArithmeticCoder.ArithmeticDecoder;
import junit.framework.TestCase;

public class TestArithmeticCoder extends TestCase {
	
	public void testFour() throws Exception {
		Random ra1 = new Random(15);
		
		xtestEntropy(1462297475);
		
		for (int i = 0; i < 1280 * 100; i++) {
			int seed = ra1.nextInt();
			xtestEntropy(seed);
		}
	}
	
	public void testRare() throws Exception {
		final int symbolCount = 13;
		ProbabilityTable pt = SimpleProbabilityTables.getEquiprobableTable(symbolCount);
		
		BigInteger[] v1 = {BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),
				BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),
				BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),
				BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),
				BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),
				BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),
				BigInteger.valueOf(1),BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),
				BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),
				BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),
				BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),
				BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),
				BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(0),BigInteger.valueOf(1)};
		
		xtestVector(v1, pt, symbolCount);
	}
	
	public void testOne() throws Exception {
		Random ra1 = new Random(15);
		
		final int symbolCount = 1 << 20;
		ProbabilityTable pt = SimpleProbabilityTables.getEquiprobableTable(symbolCount);
		
		for (int i = 0; i < 4800; i++) {
			int seed = ra1.nextInt();
			xtestSeed(seed, pt, symbolCount);
		}
	}
	
//	public void testTwo() throws Exception {
//		Random ra = new Random(15);
//		
//		final int symbolCount = 1 << 16;
//		ByteArrayOutputStream os = new ByteArrayOutputStream();
//		ProbabilityTable pt = SimpleProbabilityTables.getEquiprobableTable(symbolCount);
//		
//		EntropyCoderStream acs = new EntropyCoderStream(new RangeCoder(pt, os));
//		
//		byte[] b = new byte[2 * 1024];
//		ra.nextBytes(b);
//		
//		acs.write(b);
//		
//		acs.close();
//		
////		System.out.println("***************** codeword  *************************************");
////		showArray(os.toByteArray());
////		System.out.println("***************** decoding *************************************");
//		
//		InputStream is = new ByteArrayInputStream(os.toByteArray()); 
//		os = null;
//		
//		EntropyDecoderStream ads = new EntropyDecoderStream(new RangeDecoder(pt, is));
//		
//		byte[] b2 = new byte[b.length];
//		
//		ads.read(b2);
//		
//		for (int i = 0; i < b.length; i++) {
//			assertTrue(b[i] == b2[i]);
//		}
//	}
	
	public void testThree() throws Exception {
		Random ra1 = new Random(15);
		
		ProbabilityTable pt = SimpleProbabilityTables.getBinaryProbabilityTable(0.3f);

		for (int i = 0; i < 1280; i++) {
			int seed = ra1.nextInt();
			xtestBin(seed, pt);
		}
	}
	
//	private void showArray(byte[] b) {
//		for (int i = 0; i < b.length; i++) {
//			int x = b[i];
//			if (x < 0) x = 256 + x;
//			System.out.print(x + " ");
//		}
//		System.out.println("");
//	}
	
	public void xtestBin(int seed, ProbabilityTable pt) throws Exception {
//		System.out.println("***************** coding ( " + seed + " ) *******************************");
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		ArithmeticCoder ac = new ArithmeticCoder(pt, os);
	
		BigInteger[] v = new BigInteger[320];
		
		Random ra = new Random(seed);
		
		for (int i = 0; i < v.length; i++) {
			v[i] = BigInteger.valueOf(ra.nextInt(2));
			
			ac.codeSymbol(v[i]);
		}
		
		ac.terminate();
		
//		System.out.println("***************** codeword  *************************************");
//		showArray(os.toByteArray());
//		System.out.println("***************** decoding *************************************");
		
		InputStream is = new ByteArrayInputStream(os.toByteArray()); 
		os = null;
		
		ArithmeticDecoder ad = new ArithmeticDecoder(pt, is);
		
		for (int i = 0; i < v.length; i++) {
			assertTrue(ad.decodeSymbol().compareTo(v[i]) == 0);
		}
	}
	
	
	public void xtestEntropy(int seed) throws Exception {

		final boolean showDebug = true;
		
		Random ra = new Random(seed);
		if (showDebug) {
			System.out.println("***************** coding ( " + seed + " ) *******************************");
		}
		
		int zeroCount = 0;
		BigInteger[] v = new BigInteger[2048];
		
		int threshold = ra.nextInt(4000);
		
		for (int i = 0; i < v.length; i++) {
			v[i] = BigInteger.valueOf(ra.nextInt(4000) < threshold ? 0 : 1);
			if (v[i].compareTo(BigInteger.ZERO) == 0) {
				zeroCount++;
			}
		}
		
		if (zeroCount == 0)
			return;
		
		ProbabilityTable pt = SimpleProbabilityTables.getBinaryProbabilityTable(zeroCount / (float) v.length);
		
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		ArithmeticCoder ac = new ArithmeticCoder(pt, os);
		
		for (int i = 0; i < v.length; i++) {
			ac.codeSymbol(v[i]);
		}
		
		ac.terminate();
		
//		System.out.println("***************** codeword  *************************************");
//		showArray(os.toByteArray());
//		System.out.println("***************** decoding *************************************");
		
		int codeWordLength = os.toByteArray().length;
		
		InputStream is = new ByteArrayInputStream(os.toByteArray()); 
		os = null;
		
		ArithmeticDecoder ad = new ArithmeticDecoder(pt, is);
		
		for (int i = 0; i < v.length; i++) {
			assertTrue(ad.decodeSymbol().compareTo(v[i]) == 0);
		}
		
		float p0 = zeroCount / (float) v.length;
		float p1 = 1 - p0;
		double e = v.length * (-p0 * Math.log(p0) - p1 * Math.log(p1)) / Math.log(2);
		double er = (codeWordLength * 8);

		assertTrue(Double.isNaN(e) || e <= v.length);
		assertTrue(Double.isNaN(e) || er < 70 + 64 + 7 || er < e * 2);
		
//		System.out.println("***************** entropy *************************************");
		if (showDebug) {
			System.out.println("Original " + v.length);
			System.out.println("Estimated " + e );
			System.out.println("Real " +  er + "(" + ((er - e) * 100 / e) + ")");
		}
	}
	
	public void xtestVector(BigInteger[] v, ProbabilityTable pt, int symbolCount) throws Exception {
		
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		ArithmeticCoder ac = new ArithmeticCoder(pt, os);
	
		for (int i = 0; i < v.length; i++) {
			ac.codeSymbol(v[i]);
		//	System.out.println("coding symbol " + i + " (" + v[i].intValue() + ")");
		}
		
		ac.terminate();
		
//		System.out.println("***************** codeword  *************************************");
//		showArray(os.toByteArray());
//		System.out.println("***************** decoding *************************************");
		
		InputStream is = new ByteArrayInputStream(os.toByteArray()); 
		os = null;
		
		ArithmeticDecoder ad = new ArithmeticDecoder(pt, is);
		
		for (int i = 0; i < v.length; i++) {
		//	System.out.println("decoding symbol " + i + " (" + v[i].intValue() + ")");
			assertTrue(ad.decodeSymbol().compareTo(v[i]) == 0);
		}
	}
	
	public void xtestSeed(int seed, ProbabilityTable pt, int symbolCount) throws Exception {
		BigInteger[] v = new BigInteger[65];
		
		Random ra = new Random(seed);
		
		for (int i = 0; i < v.length; i++) {
			v[i] = BigInteger.valueOf(ra.nextInt(symbolCount));
		}
		
		xtestVector(v, pt, symbolCount);
	}
	
}

