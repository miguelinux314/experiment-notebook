package GiciEntropyCoder;

import java.math.BigInteger;

public class SimpleProbabilityTables extends StaticProbabilityTable {

	protected SimpleProbabilityTables(BigInteger rangeBounds) {
		super(null);
	}
	
	static public StaticProbabilityTable getProbabilityTableByRange (BigInteger[] rangeBounds) {
		BigInteger[] result = new BigInteger[rangeBounds.length];	
		for (int i = 0; i < rangeBounds.length; i++) {
			result[i] = rangeBounds[i].multiply(BigInteger.valueOf(2 << 
					20)).divide(rangeBounds[rangeBounds.length - 1]);
		}
		
		assert(result[rangeBounds.length - 1].bitLength() == 
			result[rangeBounds.length - 1].getLowestSetBit() + 1);
			
		return new StaticProbabilityTable(result);
	}

	static public StaticProbabilityTable getBinaryProbabilityTable(final float zeroFrequency) {
		BigInteger[] rangeBounds = new BigInteger[3];
		
		final int shift = 2 << 20;
	
		rangeBounds[0] = BigInteger.ZERO;
		rangeBounds[1] = BigInteger.valueOf((int) (zeroFrequency * shift));
		rangeBounds[2] = BigInteger.valueOf(shift);
		
		if (rangeBounds[1].compareTo(rangeBounds[0]) <= 0) {
			rangeBounds[1] = BigInteger.ONE;
		} else if (rangeBounds[1].compareTo(rangeBounds[2]) >= 0) {
			rangeBounds[1] = rangeBounds[2].subtract(BigInteger.ONE);
		}
		
		return new StaticProbabilityTable(rangeBounds);
	}

	
	static public StaticProbabilityTable getEquiprobableTable(final int elementCount) {
		
		assert (elementCount > 1);
		
		final BigInteger[] rangeBounds = new BigInteger[elementCount + 1];
		
		final BigInteger elementCountBig = BigInteger.valueOf(elementCount);
		BigInteger totalBound = BigInteger.ONE;
		
		while (totalBound.compareTo(elementCountBig) < 0) {
			totalBound = totalBound.shiftLeft(1);
		}
		
		for (int i = 0; i < elementCount; i++) {
			rangeBounds[i] = BigInteger.valueOf(i).multiply(totalBound).divide(elementCountBig);
		}
		
		rangeBounds[elementCount] = totalBound;
		
		return new StaticProbabilityTable(rangeBounds);
	}
}
