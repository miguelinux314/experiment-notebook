
package GiciEntropyCoder.RiceCoder.jUnits;

import org.junit.*;

import static org.junit.Assert.*;

import java.lang.reflect.*;

import GiciEntropyCoder.RiceCoder.*;
import GiciStream.*;

import java.io.*;
import java.util.*;

@SuppressWarnings({"rawtypes","unchecked"})
public class TestRiceCoder {

	private final Class cRiceCoder;

	private final Field coderIdBits;
	private final Field coderNumOptions;
	private final Field coderBackupOption;
	private final Field coderBitMask;

	private final Method maskBlockBits;
	private final Method backupBlock;
	private final Method riceCodeBlock;
	private final Method code;
	private final Method finish;

	private final Class cRiceDecoder;

	private final Field decoderIdBits;
	private final Field decoderNumOptions;
	private final Field decoderBackupOption;

	private final Method restoreBlock;
	private final Method riceDecodeBlock;
	private final Method decode;


	public TestRiceCoder() throws NoSuchFieldException, NoSuchMethodException, SecurityException {

		cRiceCoder = RiceCoder.class;

		coderIdBits = cRiceCoder.getDeclaredField("idBits");
		coderIdBits.setAccessible(true);

		coderNumOptions = cRiceCoder.getDeclaredField("numOptions");
		coderNumOptions.setAccessible(true);

		coderBackupOption = cRiceCoder.getDeclaredField("backupOption");
		coderBackupOption.setAccessible(true);

		coderBitMask = cRiceCoder.getDeclaredField("bitMask");
		coderBitMask.setAccessible(true);

		maskBlockBits = cRiceCoder.getDeclaredMethod("maskBlockBits", int[].class);
		maskBlockBits.setAccessible(true);

		backupBlock = cRiceCoder.getDeclaredMethod("backupBlock", int[].class);
		backupBlock.setAccessible(true);

		riceCodeBlock = cRiceCoder.getDeclaredMethod("riceCodeBlock", int[].class, int.class);
		riceCodeBlock.setAccessible(true);

		code = cRiceCoder.getDeclaredMethod("code", int[].class);
		code.setAccessible(true);

		finish = cRiceCoder.getDeclaredMethod("finish");
		finish.setAccessible(true);


		cRiceDecoder = RiceDecoder.class;

		decoderIdBits = cRiceDecoder.getDeclaredField("idBits");
		decoderIdBits.setAccessible(true);

		decoderNumOptions = cRiceDecoder.getDeclaredField("numOptions");
		decoderNumOptions.setAccessible(true);

		decoderBackupOption = cRiceDecoder.getDeclaredField("backupOption");
		decoderBackupOption.setAccessible(true);

		restoreBlock = cRiceDecoder.getDeclaredMethod("restoreBlock", int[].class);
		restoreBlock.setAccessible(true);

		riceDecodeBlock = cRiceDecoder.getDeclaredMethod("riceDecodeBlock", int[].class, int.class);
		riceDecodeBlock.setAccessible(true);

		decode = cRiceDecoder.getDeclaredMethod("decode", int[].class);
		decode.setAccessible(true);
	}


	@Test
	public void testIdBits() throws IllegalAccessException {

		RiceCoder coder;

		for (int i = 1; i <= 8; i++) {
			coder = new RiceCoder(null, 1, i, false);
			assertTrue(coderIdBits.getInt(coder) == 3);
			assertTrue(coderNumOptions.getInt(coder) == 0x08);
			assertTrue(coderBackupOption.getInt(coder) == 0x07);
		}

		for (int i = 9; i <= 16; i++) {
			coder = new RiceCoder(null, 1, i, false);
			assertTrue(coderIdBits.getInt(coder) == 4);
			assertTrue(coderNumOptions.getInt(coder) == 0x10);
			assertTrue(coderBackupOption.getInt(coder) == 0x0f);
		}

		for (int i = 17; i <= 32; i++) {
			coder = new RiceCoder(null, 1, i, false);
			assertTrue(coderIdBits.getInt(coder) == 5);
			assertTrue(coderNumOptions.getInt(coder) == 0x20);
			assertTrue(coderBackupOption.getInt(coder) == 0x1f);
		}

		RiceDecoder decoder;

		for (int i = 1; i <= 8; i++) {
			decoder = new RiceDecoder(null, 1, i, false);
			assertTrue(decoderIdBits.getInt(decoder) == 3);
			assertTrue(decoderNumOptions.getInt(decoder) == 0x08);
			assertTrue(decoderBackupOption.getInt(decoder) == 0x07);
		}

		for (int i = 9; i <= 16; i++) {
			decoder = new RiceDecoder(null, 1, i, false);
			assertTrue(decoderIdBits.getInt(decoder) == 4);
			assertTrue(decoderNumOptions.getInt(decoder) == 0x10);
			assertTrue(decoderBackupOption.getInt(decoder) == 0x0f);
		}

		for (int i = 17; i <= 32; i++) {
			decoder = new RiceDecoder(null, 1, i, false);
			assertTrue(decoderIdBits.getInt(decoder) == 5);
			assertTrue(decoderNumOptions.getInt(decoder) == 0x20);
			assertTrue(decoderBackupOption.getInt(decoder) == 0x1f);
		}
	}


	@Test
	public void testRestrictedIdBits() throws IllegalAccessException {

		RiceCoder coder;

		for (int i = 1; i <= 2; i++) {
			coder = new RiceCoder(null, 1, i, true);
			assertTrue(coderIdBits.getInt(coder) == 1);
			assertTrue(coderNumOptions.getInt(coder) == 0x02);
			assertTrue(coderBackupOption.getInt(coder) == 0x01);
		}

		for (int i = 3; i <= 4; i++) {
			coder = new RiceCoder(null, 1, i, true);
			assertTrue(coderIdBits.getInt(coder) == 2);
			assertTrue(coderNumOptions.getInt(coder) == 0x04);
			assertTrue(coderBackupOption.getInt(coder) == 0x03);
		}

		for (int i = 5; i <= 8; i++) {
			coder = new RiceCoder(null, 1, i, true);
			assertTrue(coderIdBits.getInt(coder) == 3);
			assertTrue(coderNumOptions.getInt(coder) == 0x08);
			assertTrue(coderBackupOption.getInt(coder) == 0x07);
		}

		for (int i = 9; i <= 16; i++) {
			coder = new RiceCoder(null, 1, i, true);
			assertTrue(coderIdBits.getInt(coder) == 4);
			assertTrue(coderNumOptions.getInt(coder) == 0x10);
			assertTrue(coderBackupOption.getInt(coder) == 0x0f);
		}

		for (int i = 17; i <= 32; i++) {
			coder = new RiceCoder(null, 1, i, true);
			assertTrue(coderIdBits.getInt(coder) == 5);
			assertTrue(coderNumOptions.getInt(coder) == 0x20);
			assertTrue(coderBackupOption.getInt(coder) == 0x1f);
		}

		RiceDecoder decoder;

		for (int i = 1; i <= 2; i++) {
			decoder = new RiceDecoder(null, 1, i, true);
			assertTrue(decoderIdBits.getInt(decoder) == 1);
			assertTrue(decoderNumOptions.getInt(decoder) == 0x02);
			assertTrue(decoderBackupOption.getInt(decoder) == 0x01);
		}

		for (int i = 3; i <= 4; i++) {
			decoder = new RiceDecoder(null, 1, i, true);
			assertTrue(decoderIdBits.getInt(decoder) == 2);
			assertTrue(decoderNumOptions.getInt(decoder) == 0x04);
			assertTrue(decoderBackupOption.getInt(decoder) == 0x03);
		}

		for (int i = 5; i <= 8; i++) {
			decoder = new RiceDecoder(null, 1, i, true);
			assertTrue(decoderIdBits.getInt(decoder) == 3);
			assertTrue(decoderNumOptions.getInt(decoder) == 0x08);
			assertTrue(decoderBackupOption.getInt(decoder) == 0x07);
		}

		for (int i = 9; i <= 16; i++) {
			decoder = new RiceDecoder(null, 1, i, true);
			assertTrue(decoderIdBits.getInt(decoder) == 4);
			assertTrue(decoderNumOptions.getInt(decoder) == 0x10);
			assertTrue(decoderBackupOption.getInt(decoder) == 0x0f);
		}

		for (int i = 17; i <= 32; i++) {
			decoder = new RiceDecoder(null, 1, i, true);
			assertTrue(decoderIdBits.getInt(decoder) == 5);
			assertTrue(decoderNumOptions.getInt(decoder) == 0x20);
			assertTrue(decoderBackupOption.getInt(decoder) == 0x1f);
		}
	}


	@Test
	public void testBitMask() throws IllegalAccessException {

		RiceCoder coder;

		for (int d = 1; d <= 32; d++) {
			coder = new RiceCoder(null, 1, d, true);
			assertTrue(coderBitMask.getInt(coder) == (int) ~(0xffffffffffffffffL << d));
		}
	}


	@Test
	public void testBlockMasking() throws IllegalAccessException, InvocationTargetException {

		int len = 32;
		int[] block = new int[len];

		RiceCoder coder;

		Random rand = new Random();

		for (int d = 1; d <= 32; d++) {
			for (int i = 0; i < len; i++) {
				block[i] = rand.nextInt();
			}
			coder = new RiceCoder(null, 1, d, true);
			block = (int[]) maskBlockBits.invoke(coder, block);
			for (int i = 0; i < len; i++) {
				assertTrue((block[i] & 0xffffffffL) <= (coderBitMask.getInt(coder) & 0xffffffffL));
			}
		}
	}


	@Test
	public void testBackupSanity() throws IOException, IllegalAccessException, InvocationTargetException {

		File file = new File("temp");
		FileInputStream fis;
		FileOutputStream fos;

		for (int j = 1; j <= 32; j++) {

			int[] inData = new int[j];
			int[] outData = new int[j];

			for (int d = 1; d <= 32; d++) {

				Random rand = new Random();
				for (int i = 0; i < j; i++) {
					inData[i] = rand.nextInt();
					outData[i] = ~inData[i];
				}

				fos = new FileOutputStream(file);
				RiceCoder coder = new RiceCoder(new BitOutputStream(fos), 1, d, true);
				inData = (int[]) maskBlockBits.invoke(coder, inData);
				backupBlock.invoke(coder, inData);
				finish.invoke(coder);
				fos.close();

				fis = new FileInputStream(file);
				RiceDecoder decoder = new RiceDecoder(new BitInputStream(fis), 1, d, true);
				restoreBlock.invoke(decoder, outData);
				fis.close();

				assertArrayEquals(inData, outData);

			}
		}

		file.delete();
	}


	@Test
	public void testRiceSanity() throws IOException, IllegalAccessException, InvocationTargetException {

		File file = new File("temp");
		FileInputStream fis;
		FileOutputStream fos;

		int len = 32;
		int[] inData = new int[len];
		int[] outData = new int[len];

		for (int k = 0; k <= 31; k++) {

			Random rand = new Random();
			for (int i = 0; i < len; i++) {
				inData[i] = rand.nextInt() & 0xff;
				outData[i] = ~inData[i];
			}

			fos = new FileOutputStream(file);
			RiceCoder coder = new RiceCoder(new BitOutputStream(fos), 1, 1, true);
			riceCodeBlock.invoke(coder, inData, k);
			finish.invoke(coder);
			fos.close();

			fis = new FileInputStream(file);
			RiceDecoder decoder = new RiceDecoder(new BitInputStream(fis), 1, 1, true);
			riceDecodeBlock.invoke(decoder, outData, k);
			fis.close();

			assertArrayEquals(inData, outData);

		}

		file.delete();
	}


	@Test
	public void testDecider() {
		// how?
	}


	@Test
	public void testCompression() throws IOException, IllegalAccessException, InvocationTargetException {

		File file = new File("temp");
		FileOutputStream fos;

		int blockSize = 16;
		int numBlocks = 16;
		int len = numBlocks * blockSize;
		int[] inData = new int[len];

		Random rand = new Random();
		for (int i = 0; i < len; i++) {
			inData[i] = rand.nextInt();
		}

		// restrict
		for (int d = 1; d <= 32; d++) {
			fos = new FileOutputStream(file);
			RiceCoder coder = new RiceCoder(new BitOutputStream(fos), blockSize, d, true);
			code.invoke(coder, inData);
			fos.close();

			assertTrue(file.length() <= (len * d + numBlocks * coderIdBits.getInt(coder) + 7) / 8);
		}

		// don't restrict
		for (int d = 1; d <= 32; d++) {
			fos = new FileOutputStream(file);
			RiceCoder coder = new RiceCoder(new BitOutputStream(fos), blockSize, d, false);
			code.invoke(coder, inData);
			fos.close();

			assertTrue(file.length() <= (len * d + numBlocks * coderIdBits.getInt(coder) + 7) / 8);
		}

		file.delete();
	}


	@Test
	public void testSanity() throws IOException, IllegalAccessException, InvocationTargetException {

		File file = new File("temp");
		FileInputStream fis;
		FileOutputStream fos;

		int blockSize = 15;
		int len = 256;
		int[] inData = new int[len];
		int[] outData = new int[len];

		Random rand = new Random();

		// restrict
		for (int d = 1; d <= 32; d++) {

			fos = new FileOutputStream(file);
			RiceCoder coder = new RiceCoder(new BitOutputStream(fos), blockSize, d, true);

			for (int i = 0; i < len; i++) {
				inData[i] = rand.nextInt() & coderBitMask.getInt(coder);
				outData[i] = ~inData[i];
			}

			code.invoke(coder, inData);
			fos.close();

			fis = new FileInputStream(file);
			RiceDecoder decoder = new RiceDecoder(new BitInputStream(fis), blockSize, d, true);
			decode.invoke(decoder, outData);
			fis.close();

			assertArrayEquals(inData, outData);
		}

		// don't restrict
		for (int d = 1; d <= 32; d++) {
			fos = new FileOutputStream(file);
			RiceCoder coder = new RiceCoder(new BitOutputStream(fos), blockSize, d, false);

			for (int i = 0; i < len; i++) {
				inData[i] = rand.nextInt() & coderBitMask.getInt(coder);
				outData[i] = ~inData[i];
			}

			code.invoke(coder, inData);
			fos.close();

			fis = new FileInputStream(file);
			RiceDecoder decoder = new RiceDecoder(new BitInputStream(fis), blockSize, d, false);
			decode.invoke(decoder, outData);
			fis.close();

			assertArrayEquals(inData, outData);
		}

		file.delete();
	}

}
