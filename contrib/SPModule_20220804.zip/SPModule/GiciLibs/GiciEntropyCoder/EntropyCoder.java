package GiciEntropyCoder;

import java.io.IOException;
import java.math.BigInteger;

public interface EntropyCoder {
	public abstract void codeSymbol(BigInteger symbol) throws IOException;
	public abstract void terminate() throws IOException;
}