package GiciEntropyCoder.RangeCoder;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.nio.ByteBuffer;

import GiciEntropyCoder.EntropyDecoder;
import GiciEntropyCoder.ProbabilityTable;

public class RangeDecoder implements EntropyDecoder {
	final ProbabilityTable probabilityTable;
	final InputStream inputStream;
	
	final boolean countIsPowerOfTwo;
	final int equivalentShift;
	
	public RangeDecoder(ProbabilityTable probabilityTable, InputStream inputStream) {
		this.probabilityTable = probabilityTable;
		this.inputStream = new BufferedInputStream(inputStream);
		
		countIsPowerOfTwo = probabilityTable.getObservationCount().bitCount() == 1;
		equivalentShift = probabilityTable.getObservationCount().getLowestSetBit();
	}

	BigInteger low = BigInteger.ZERO;
	BigInteger range = BigInteger.ONE;
	int count = 0;
	
	public BigInteger decodeSymbol() throws IOException {
		
		BigInteger F  = probabilityTable.getObservationCount();
		
		if (count == 0) {
			byte[] c = new byte[10];
			
			if (inputStream.read(c) < c.length) {
				throw new IOException("Invalid header received");
			}
						
			ByteBuffer byteBuffer = ByteBuffer.wrap(c);
			count = byteBuffer.getShort();
			assert (count >= 0);
			
			int padding = byteBuffer.getInt();
			assert (padding >= 0);
			
			int l = byteBuffer.getInt();
			assert (l >= 0);
			
			byte[] b = new byte[l];
			
			if (inputStream.read(b) < b.length) {
				throw new IOException("Partial codeword received");
			}
			
			low = new BigInteger(b);
			low = low.shiftLeft(padding);
			
			if (! countIsPowerOfTwo) {
				range = F.pow(count);
			}
		}
		
		BigInteger frequency;
		
		if (countIsPowerOfTwo) {
			frequency = low.shiftRight((count - 1) * equivalentShift);
		} else {
			range = range.divide(F);
			frequency = low.divide(range);
		}
		
		BigInteger symbol = probabilityTable.findSymbolFromFrequency(frequency);
		
		BigInteger Ci = probabilityTable.getCumulativeFrequency(symbol);
		BigInteger fi = probabilityTable.getFrequency(symbol);
		
		if (countIsPowerOfTwo) {
			low = low.subtract(Ci.shiftLeft((count - 1) * equivalentShift)).divide(fi);
		} else {
			low = low.subtract(range.multiply(Ci)).divide(fi);
		}
		
		count--;
		
		return symbol;
	}

	protected byte[] myToByteArray(BigInteger v, int length) {
		byte[] lowByteArray = v.toByteArray();
		
		byte[] result = new byte[length];
		
		int bytesFromV = v.bitLength();
		
		bytesFromV = bytesFromV / 8 + (bytesFromV % 8 != 0 ? 1 : 0);
		
		if (bytesFromV > length)
			bytesFromV = length;
		
		System.arraycopy(lowByteArray, lowByteArray.length - bytesFromV, result, length - bytesFromV, bytesFromV);
		
		return result;
	}
	
	/* (non-Javadoc)
	 * @see GiciEntropyCoder.RangeCoder.EntropyDecoder#decodeSymbolBytes()
	 */
	public byte[] decodeSymbolBytes() throws IOException {
		return myToByteArray(decodeSymbol(), probabilityTable.getSymbolByteSize()); 
	}
}
