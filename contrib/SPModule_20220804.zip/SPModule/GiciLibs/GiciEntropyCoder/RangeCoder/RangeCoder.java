package GiciEntropyCoder.RangeCoder;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.Arrays;

import GiciEntropyCoder.EntropyCoder;
import GiciEntropyCoder.ProbabilityTable;

/**
 * This is a very tough range coder with support for arbitrary alphabet length and
 * fine grained frequency tables with non-power-of-two totals.
 * 
 * DO NOT expect good speed (This is for research only).
 * 
 * @author Ian
 *
 */

public class RangeCoder implements EntropyCoder {
	final ProbabilityTable probabilityTable;
	final OutputStream outputStream;
	final ByteArrayOutputStream os = new ByteArrayOutputStream();
	
	final boolean countIsPowerOfTwo;
	final int equivalentShift;
	
	public RangeCoder(ProbabilityTable probabilityTable, OutputStream outputStream) {
		this.probabilityTable = probabilityTable;
		this.outputStream = new BufferedOutputStream(outputStream);

		countIsPowerOfTwo = probabilityTable.getObservationCount().bitCount() == 1;
		equivalentShift = probabilityTable.getObservationCount().getLowestSetBit();
	}
	
	BigInteger low = BigInteger.ZERO;
	BigInteger range = BigInteger.ONE;
	int count = 0;
	
	public void codeSymbol (BigInteger symbol) throws IOException {		
		BigInteger Ci = probabilityTable.getCumulativeFrequency(symbol);
		BigInteger fi = probabilityTable.getFrequency(symbol);
		BigInteger F  = probabilityTable.getObservationCount();
		
		if (countIsPowerOfTwo) {
			low = low.shiftLeft(equivalentShift).add(Ci.multiply(range));
		} else {
			low = low.multiply(F).add(Ci.multiply(range));
		}
		
		range = range.multiply(fi);
		
		count++;
		
		if (count == Short.MAX_VALUE) { // Expected average penalization of 0.2%  
			terminate();
		}
	}

	/* (non-Javadoc)
	 * @see GiciEntropyCoder.RangeCoder.EntropyCoder#terminate()
	 */
	public void terminate() throws IOException {				
		// find shortest value between [low, low + range)			
		assert(range.compareTo(BigInteger.ZERO) != 0);
		
		int padding = range.bitLength() - 2;
		
		while (padding >= 0 && low.testBit(padding) == true) {
			padding--;
		}
		
		BigInteger prefix;
		if (padding < 0) {
			padding = 0;
			prefix = low;
		} else {
			prefix = low.setBit(padding).shiftRight(padding);
		}
		
		// One bit can be further squeezed in the prefix
		// (if low.shift(prefix) ends in 0 and range != 1.shift(prefix)) <- check notation.
			
		//System.out.println ("Padding = " + padding + " first one " + (range.bitLength() - 2));
		
		assert(prefix.shiftLeft(padding).compareTo(low) >= 0);
		assert(prefix.shiftLeft(padding).compareTo(low.add(range)) < 0);
		
		byte[] result = prefix.toByteArray();
		
		// write count
		ByteBuffer byteBuffer = ByteBuffer.allocate(10);
		byteBuffer.putShort((short)count);
		byteBuffer.putInt(padding);
		byteBuffer.putInt(result.length);
		outputStream.write(byteBuffer.array());
		
		// write encoded message
		outputStream.write(result);
		outputStream.flush();
		
		// Reset the encoder for more input
		low = BigInteger.ZERO;
		range = BigInteger.ONE;
		count = 0;
	}
	
	protected BigInteger myToBigInt(byte[] b) {		
		if ((new BigInteger(b)).compareTo(BigInteger.ZERO) != 0) {
			return new BigInteger(1, b);
		} else {
			return BigInteger.ZERO;
		}
	}
	
	/* (non-Javadoc)
	 * @see GiciEntropyCoder.RangeCoder.EntropyCoder#codeSymbol(byte[])
	 */
	public void codeSymbol (byte[] symbol) throws IOException {
		
		os.write(symbol);
		
		byte[] b = os.toByteArray();
		int symbolSize = probabilityTable.getSymbolByteSize();
		
		for (int i = 0; i < b.length; i += symbolSize) {
			byte[] b2 = Arrays.copyOfRange(b, i, i + symbolSize);
			codeSymbol(myToBigInt(b2));
		}

		os.reset();
		
		int remainder = b.length % symbolSize;
		os.write(b, b.length - remainder, remainder);
	}
}
