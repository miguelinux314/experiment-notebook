/*
 * GICI Library -
 * Copyright (C) 2007  Group on Interactive Coding of Images (GICI)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Group on Interactive Coding of Images (GICI)
 * Department of Information and Communication Engineering
 * Autonomous University of Barcelona
 * 08193 - Bellaterra - Cerdanyola del Valles (Barcelona)
 * Spain
 *
 * http://gici.uab.es
 * gici-info@deic.uab.es
 */
package GiciTransform;
import GiciException.*;

/**
 * This class receives an image and return a mask indicating which coefficients are involucred in the inverse wavelet transform. Usage example:<br>
 * &nbsp; construct<br>
 * &nbsp; setParameters<br>
 * &nbsp; run<br>
 * &nbsp; get functions<br>
 *
 * @author Group on Interactive Coding of Images (GICI)
 * @version 1.0
 */

public class MaskWaveletDomainByteMap{
	
	/**
	 * Contains a bitmap that indicates if is a ROI coefficient. First dimensions indicates de ROIvalue, second dimension indicates if the coeffients is a ROI coefficients for the ROIvalue.
	 */
	byte[][][] bitMap = null;
	
	/**
	 * Contains a bitmap that indicates if a coefficient is marked to be checked in the next ressolution level. (index meaning [z][rLevel][x,y] one bit bit simulates an x,y position).
	 */
	byte[][][] nextRlevelBitMap = null;
	
	/**
	 * Definition in Coder
	 */
	long[][][] imageSamples = null;
	
	/**
	 * Definition in Coder
	 */
	byte[][][] maskSamples = null;
	
	/**
	 * Definition in Coder
	 */
	int zSize;

	/**
	 * Definition in Coder
	 */
	int ySize;

	/**
	 * Definition in Coder
	 */
	int xSize;
	
	 /**
	 * DWT levels to apply for each component.
	 * <p>
	 * Negative values not allowed.
	 */
	int[] WTLevels = null;
	
	/**
	 * Discrete wavelet transform to be applied for each component.
	 * <p>
	 * Valid values are:<br>
	 *   <ul>
	 *     <li> 0 - None
	 *     <li> 1 - Reversible 5/3 DWT (JPEG2000)
	 *     <li> 2 - Real Isorange (Irreversible) 9/7 DWT (JPEG2000 standard)
	 *     <li> 3 - Real Isonorm (Irreversible) 9/7 DWT (CCSDS-Recommended)
	 *     <li> 4 - Integer (Reversible) 9/7M DWT (CCSDS-Recommended)
	 *     <li> 5 - Integer 5/3 DWT (Classic construction)
	 *     <li> 6 - Integer 9/7 DWT (Classic construction)
	 *   </ul>
	 */
	int[] WTTypes = null;
	
	/**
	 * Define which value of the maskSample will be considered Roi
	 */
	int []RroiValues;
		
	/**
	 * To know if parameters are set.
	 * <p>
	 * True indicates that they are set otherwise false.
	 */
	boolean parametersSet = false;

	//INTERNAL VARIABLES
	
	/**
	 * <ul>
	 *   <li> 1 - rLevel
	 *   <li> 2 - subband where 0-HL, 1-LH, 2-HH
	 *   <li> 3 - coordenates where 0-yBegin, 1-xBegin, 2-yEnd, 3-xEnd
	 * </ul>
	 * 
	 * Containst the subband sizes by component and rLevel
	 */
	int[][][] subbandSizes = null;
	
	/**
	 * Position correspondence for filter 5/3 if the coefficient position in a normal domain is in a Even-Even position (2n,2m).
	 * <p>
	 * First array index represents the x position in the next resolution level and the second one y position(p.e. if x=6 and y=4, in the next resolution level for HL subband will have correspondence with (x=3,y=1) and (x=3,y=2).
	 * <ul>
	 *   <li> 0 - x position
	 *   <li> 1 - y position
	 *   <li> 2 - subband where 0-HL, 1-LH, 2-HH, 3-LL
	 * </ul>
	 */
	private final int[][] filter_5_3_EvenEven = {
		{0,   0,	0},
		{-1,  0,	0},
		{0,   0,	1},
		{0,  -1,	1}, 	
		{0,   0,	2},
		{0,  -1,	2},
		{-1,  0,	2},
		{-1, -1,	2},
		{0,   0,	3},
	};
	
	/**
	 * Position correspondence for filter 5/3 if the coefficient position in a normal domain is in a Even-Odd position (2n,2m).
	 * <p>
	 * First array index represents the x position in the next resolution level and the second one y position.
	 * <ul>
	 *   <li> 0 - x position
	 *   <li> 1 - y position
	 *   <li> 2 - subband where 0-HL, 1-LH, 2-HH, 3-LL
	 * </ul>
	 */
	private final int[][] filter_5_3_EvenOdd = {
		{-1,  1,	0},
		{0,   1,	0},
		{0,   1,	1},
		{-1,  1,	2},
		{0,   1,	2}, 
		{0,   1,	3},
	};
	
	/**
	 * Position correspondence for filter 5/3 if the coefficient position in a normal domain is in a Odd-Even position (2n,2m).
	 * <p>
	 * First array index represents the x position in the next resolution level and the second one y position.
	 * <ul>
	 *   <li> 0 - x position
	 *   <li> 1 - y position
	 *   <li> 2 - subband where 0-HL, 1-LH, 2-HH, 3-LL
	 * </ul>
	 */
	private final int[][] filter_5_3_OddEven = {
		{1,   0,	0},
		{1,   0,	1},
		{1,  -1,	1},
		{1,  -1,	2},
		{1,   0,	2},
		{1,   0,	3},
	};
	
	/**
	 * Position correspondence for filter 5/3 if the coefficient position in a normal domain is in a Odd-Odd position (2n,2m).
	 * <p>
	 * First array index represents the x position in the next resolution level and the second one y position.
	 * <ul>
	 *   <li> 0 - x position
	 *   <li> 1 - y position
	 *   <li> 2 - subband where 0-HL, 1-LH, 2-HH, 3-LL
	 * </ul>
	 */
	private final int[][] filter_5_3_OddOdd = {
		{1,   1,	0},
		{1,   1,	1},
		{1,   0,	2},
		{0,   1,	2},
		{1,   1,	2},
		{1,   1,	3},
	};
	
	/**
	 * Position correspondence for filter 9/7 if the coefficient position in a normal domain is in a any-any position.
	 * <p>
	 * First array index represents the x position in the next resolution level and the second one y position.
	 * <ul>
	 *   <li> 0 - x position
	 *   <li> 1 - y position
	 *   <li> 2 - subband where 0-HL, 1-LH, 2-HH, 3-LL
	 * </ul>
	 */
	private final int[][] filter_9_7_AnyAny = {
		{-2,  -1,	0},
		{-2,   0,	0},
		{-2,   1,	0},
		{-2,   2,	0},
		{-1,  -1,	0},
		{-1,   0,	0},
		{-1,   1,	0},
		{-1,   2,	0},
		{0,   -1,	0},
		{0,    0,	0},
		{0,    1,	0},
		{0,    2,	0},
		{1,   -1,	0},
		{1,    0,	0},
		{1,    1,	0},
		{1,    2,	0},
		{2,   -1,	0},
		{2,    0,	0},
		{2,    1,	0},
		{2,    2,	0},
		{-1,  -2,	1},
		{-1,  -1,	1},
		{-1,   0,	1},
		{-1,   1,	1},
		{-1,   2,	1},
		{0,   -2,	1},
		{0,   -1,	1},
		{0,    0,	1},
		{0,    1,	1},
		{0,    2,	1},
		{1,   -2,	1},
		{1,   -1,	1},
		{1,    0,	1},
		{1,    1,	1},
		{1,    2,	1},
		{2,   -2,	1},
		{2,   -1,	1},
		{2,    0,	1},
		{2,    1,	1},
		{2,    2,	1},
		{-2,  -2,	2},
		{-2,  -1,	2},
		{-2,   0,	2},
		{-2,   1,	2},
		{-2,   2,	2},
		{-1,  -2,	2},
		{-1,  -1,	2},
		{-1,   0,	2},
		{-1,   1,	2},
		{-1,   2,	2},
		{0,   -2,	2},
		{0,   -1,	2},
		{0,    0,	2},
		{0,    1,	2},
		{0,    2,	2},
		{1,   -2,	2},
		{1,   -1,	2},
		{1,    0,	2},
		{1,    1,	2},
		{1,    2,	2},
		{2,   -2,	2},
		{2,   -1,	2},
		{2,    0,	2},
		{2,    1,	2},
		{2,    2,	2},
		{-1,  -1,	3},
		{-1,   0,	3},
		{-1,   1,	3},
		{-1,   2,	3},
		{0,   -1,	3},
		{0,    0,	3},
		{0,    1,	3},
		{0,    2,	3},
		{1,   -1,	3},
		{1,    0,	3},
		{1,    1,	3},
		{1,    2,	3},
		{2,   -1,	3},
		{2,    0,	3},
		{2,    1,	3},
		{2,    2,	3},
	};

	/**
	 * Position correspondence for filter 9/7 if the coefficient position in a normal domain is in a any-any position.
	 * <p>
	 * First array index represents the x position in the next resolution level and the second one y position.
	 * <ul>
	 *   <li> 0 - x position
	 *   <li> 1 - y position
	 *   <li> 2 - subband where 0-HL, 1-LH, 2-HH, 3-LL
	 * </ul>
	 */
	private final int[][] filter_9_7_AnyAny_dist_0_1_2 = {
		{-2,  -1,	0,   1},
		{-2,   0,	0,   1},
		{-2,   1,	0,   1},
		{-2,   2,	0,   1},
		{-1,  -1,	0,   3},
		{-1,   0,	0,   3},
		{-1,   1,	0,   3},
		{-1,   2,	0,   1},
		{0,   -1,	0,   3},
		{0,    0,	0,   5},
		{0,    1,	0,   3},
		{0,    2,	0,   1},
		{1,   -1,	0,   3},
		{1,    0,	0,   3},
		{1,    1,	0,   3},
		{1,    2,	0,   1},
		{2,   -1,	0,   1},
		{2,    0,	0,   1},
		{2,    1,	0,   1},
		{2,    2,	0,   1},
		{-1,  -2,	1,   1},
		{-1,  -1,	1,   3},
		{-1,   0,	1,   3},
		{-1,   1,	1,   3},
		{-1,   2,	1,   1},
		{0,   -2,	1,   1},
		{0,   -1,	1,   3},
		{0,    0,	1,   5},
		{0,    1,	1,   3},
		{0,    2,	1,   1},
		{1,   -2,	1,   1},
		{1,   -1,	1,   3},
		{1,    0,	1,   3},
		{1,    1,	1,   3},
		{1,    2,	1,   1},
		{2,   -2,	1,   1},
		{2,   -1,	1,   1},
		{2,    0,	1,   1},
		{2,    1,	1,   1},
		{2,    2,	1,   1},
		{-2,  -2,	2,   1},
		{-2,  -1,	2,   1},
		{-2,   0,	2,   1},
		{-2,   1,	2,   1},
		{-2,   2,	2,   1},
		{-1,  -2,	2,   1},
		{-1,  -1,	2,   3},
		{-1,   0,	2,   3},
		{-1,   1,	2,   3},
		{-1,   2,	2,   1},
		{0,   -2,	2,   1},
		{0,   -1,	2,   3},
		{0,    0,	2,   5},
		{0,    1,	2,   3},
		{0,    2,	2,   1},
		{1,   -2,	2,   1},
		{1,   -1,	2,   3},
		{1,    0,	2,   3},
		{1,    1,	2,   3},
		{1,    2,	2,   1},
		{2,   -2,	2,   1},
		{2,   -1,	2,   1},
		{2,    0,	2,   1},
		{2,    1,	2,   1},
		{2,    2,	2,   1},
		{-1,  -1,	3,   3},
		{-1,   0,	3,   3},
		{-1,   1,	3,   3},
		{-1,   2,	3,   1},
		{0,   -1,	3,   3},
		{0,    0,	3,   5},
		{0,    1,	3,   3},
		{0,    2,	3,   1},
		{1,   -1,	3,   3},
		{1,    0,	3,   3},
		{1,    1,	3,   3},
		{1,    2,	3,   1},
		{2,   -1,	3,   1},
		{2,    0,	3,   1},
		{2,    1,	3,   1},
		{2,    2,	3,   1},
	};
	/**
	 * Position correspondence for filter 9/7 if the coefficient position in a normal domain is in a any-any position. Only mark ROI coeffcients located at distance equal to 0.
	 * <p>
	 * First array index represents the x position in the next resolution level and the second one y position.
	 * <ul>
	 *   <li> 0 - x position
	 *   <li> 1 - y position
	 *   <li> 2 - subband where 0-HL, 1-LH, 2-HH, 3-LL
	 *   <li> 3 - weight to apply at distance equal to 0
	 * </ul>
	 */
	private final int[][] filter_9_7_AnyAny_dist_0 = {
		{0,    0,    0,    5},
		{0,    0,	 1,	   5},
		{0,    0,	 2,    5},
		{0,    0,	 3,    5},
	};
	
	/**
	 * Position correspondence for filter 9/7 if the coefficient position in a normal domain is in a any-any position. Only mark ROI coeffcients located at distance equal to 0 and 1.
	 * <p>
	 * First array index represents the x position in the next resolution level and the second one y position.
	 * <ul>
	 *   <li> 0 - x position
	 *   <li> 1 - y position
	 *   <li> 2 - subband where 0-HL, 1-LH, 2-HH, 3-LL
	 *   <li> 3 - weight to apply at distance equal to 0 and 1
	 * </ul>
	 */
	private final int[][] filter_9_7_AnyAny_dist_0_1 = {
		{-1,  -1,	0,   3},
		{-1,   0,	0,   3},
		{-1,   1,	0,   3},
		{0,   -1,	0,   3},
		{0,    0,	0,   3},
		{0,    1,	0,   3},
		{1,   -1,	0,   3},
		{1,    0,	0,   3},
		{1,    1,	0,   3},
		{-1,  -1,	1,   3},
		{-1,   0,	1,   3},
		{-1,   1,	1,   3},
		{0,   -1,	1,   3},
		{0,    0,	1,   3},
		{0,    1,	1,   3},
		{1,   -1,	1,   3},
		{1,    0,	1,   3},
		{1,    1,	1,   3},
		{-1,  -1,	2,   3},
		{-1,   0,	2,   3},
		{-1,   1,	2,   3},
		{0,   -1,	2,   3},
		{0,    0,	2,   3},
		{0,    1,	2,   3},
		{1,   -1,	2,   3},
		{1,    0,	2,   3},
		{1,    1,	2,   3},
		{-1,  -1,	3,   3},
		{-1,   0,	3,   3},
		{-1,   1,	3,   3},
		{0,   -1,	3,   3},
		{0,    0,	3,   3},
		{0,    1,	3,   3},
		{1,   -1,	3,   3},
		{1,    0,	3,   3},
		{1,    1,	3,   3},
	};
	
	/**
	 * Position correspondence for filter 9/7 if the coefficient position in a normal domain is in a any-any position, to mark the coefficients in the 2 next columns, special cases for optimization.
	 * <p>
	 * First array index represents the x position in the next resolution level and the second one y position.
	 * <ul>
	 *   <li> 0 - x position
	 *   <li> 1 - y position
	 *   <li> 2 - subband where 0-HL, 1-LH, 2-HH, 3-LL
	 * </ul>
	 */
	private final int[][] filter_9_7_AnyAny_x = {
		{2,   -1,	0},
		{2,    0,	0},
		{2,    1,	0},
		{2,    2,	0},
		{2,   -2,	1},
		{2,   -1,	1},
		{2,    0,	1},
		{2,    1,	1},
		{2,    2,	1},
		{2,   -2,	2},
		{2,   -1,	2},
		{2,    0,	2},
		{2,    1,	2},
		{2,    2,	2},
		{2,   -1,	3},
		{2,    0,	3},
		{2,    1,	3},
		{2,    2,	3},
		};
	
	/**
	 * Position correspondence for filter 9/7 if the coefficient position in a normal domain is in a any-any position, to mark the coefficients in the 2 next rows, special cases for optimization.
	 * <p>
	 * First array index represents the x position in the next resolution level and the second one y position.
	 * <ul>
	 *   <li> 0 - x position
	 *   <li> 1 - y position
	 *   <li> 2 - subband where 0-HL, 1-LH, 2-HH, 3-LL
	 * </ul>
	 */
	private final int[][] filter_9_7_AnyAny_y = {
		{-2,   2,	0},
		{-1,   2,	0},
		{0,    2,	0},
		{1,    2,	0},
		{2,    2,	0},
		{-1,   2,	1},
		{0,    2,	1},
		{1,    2,	1},
		{2,    2,	1},
		{-2,   2,	2},
		{-1,   2,	2},
		{0,    2,	2},
		{1,    2,	2},
		{2,    2,	2},
		{-1,   2,	3},
		{0,    2,	3},
		{1,    2,	3},
		{2,    2,	3},
		};
	
	/**
	 * Component to calculate the Mask in wavelet domain, at the first time is calculated for the firts component z=0.
	 */
	int z = 0;
	
	/**
	 * Maximum numbers of ressolution levels.
	 */
	int maxRLevel;
	
	/**
	 * Indicates the maximum distance where the coefficients ara considered coefficients needed to recover the data correctly.
	 * <p>
	 * First array index represents the z compoenents in the next resolution level and the follwing the subband.
	 * <ul>
	 *   <li> 0 - z component
	 *   <li> 1 - rLevel
	 *   <li> 2 - subband where 0-HL, 1-LH, 2-HH, 3-LL
	 * </ul>
	 */
	int involvedCoeffs[][][] = null;
	
	int roiValue = 0;
	/**
	 * Constructor that receives the original image samples in a wavelet domain, and a mask which contain the Roi definition.
	 *
	 * @param imageSamples definition in {@link Pyrenees.Coder.Coder#imageSamplesFloat}
	 */
	public MaskWaveletDomainByteMap(long[][][] imageSamples){
		//Image data copy
		this.imageSamples = imageSamples;

		//Parameters copy
		this.zSize = imageSamples.length;
		this.ySize = imageSamples[0].length;
		this.xSize = imageSamples[0][0].length;
	
	}
	
	/**
	 * Set the parameters used to do the quantization.
	 *
	 * @param maskSamples definition in {@link Pyrenees.Coder.Coder#maskSamples}
	 * @param WTLevels definition in {@link GiciTransform.ForwardWaveletTransform#WTLevels}
	 * @param WTTypes definition in {@link GiciTransform.ForwardWaveletTransform#WTTypes}
	 * @param RroiValues definition in {@link Pyrenees.Coder.Transform.Rois#RroiValues}
	 */
	public void setParameters(byte[][][] maskSamples, int[] WTLevels, int[] WTTypes, int []RroiValues){
		parametersSet = true;
		//Parameters copy
		this.maskSamples = maskSamples;
		this.WTLevels = WTLevels;
		this.WTTypes = WTTypes;
		this.RroiValues = RroiValues;
		
		//begin tmp initialization
		if(involvedCoeffs != null){
			involvedCoeffs = new int [zSize][][];
			for(int z = 0; z < zSize; z++){
				involvedCoeffs[z] = new int[WTLevels[z]][3];
			}
			this.involvedCoeffs = involvedCoeffs;
		}
		//end tmp initialization
		
		
	}
	
	/**
	 * Performs the mask calculation in the wavelet domain.
	 *
	 *
	 * @throws ErrorException when parameters are not set or unrecognized roi type is passed
	 */
	public void run() throws ErrorException{
		//memory allocation for subband sizes
		//bitMap = new byte[RroiValues.length][(int)Math.ceil((double)(xSize*ySize)/8)];
		bitMap = new byte[RroiValues.length][ySize][xSize];
		for(roiValue = 0; roiValue < RroiValues.length; roiValue++){
			subbandSizes = new int[WTLevels[z]][3][4];
			SubbandSizesCalculation(z, subbandSizes);
			//nextRlevelBitMap = new byte[WTLevels[z]][];
			nextRlevelBitMap = new byte[WTLevels[z]][][];
			for(int rLevel = 0; rLevel < WTLevels[z]; rLevel++){
				//nextRlevelBitMap[rLevel] = new byte[(int)Math.ceil((double)(subbandSizes[rLevel][1][0]*subbandSizes[rLevel][0][1])/8)];
				nextRlevelBitMap[rLevel] = new byte[subbandSizes[rLevel][1][0]][subbandSizes[rLevel][0][1]];
				for(int y = 0; y < subbandSizes[rLevel][1][0]; y++){
				for(int x = 0; x < subbandSizes[rLevel][0][1]; x++){		
					nextRlevelBitMap[rLevel][y][x] = -1;
				}}
			}
			for(int y = 0; y < ySize; y++){
			for(int x = 0; x < xSize; x++){
				bitMap[roiValue][y][x] = -1;
			}}
			
			if(WTLevels[z] == 0){
				for(int y = 0; y < ySize; y++){
				for(int x = 0; x < xSize; x++){
					if(isRoi(z,y,x)){
						//bitMap[roiValue][((y * xSize) + x) / 8] |= (byte)(1 << (7-(((y * xSize) + x) % 8)));
						bitMap[roiValue][y][x] = 1;
					}
				}}
				
			}else{
				maxRLevel = WTLevels[z]-1;
				//select the raster depending on the wavelet filter
				switch(WTTypes[z]){
				case 1:
					rasterWavelet5_3(z);
					break;
				case 2:
					rasterWavelet9_7(z);
					break;
				}
			}
		}
			
	}
	
	/**
	 * Performs the raster for a roi if the wavelet transform is 5/3 (-wt 1)
	 *
	 */
	protected void rasterWavelet5_3(int z){
		//Raster the image to set the no-data values
		for(int rLevel = 0; rLevel < WTLevels[z]; rLevel++){
		for(int y = 0; y < subbandSizes[rLevel][1][2]; y++){
		for(int x = 0; x < subbandSizes[rLevel][0][3]; x++){	
			if(rLevel == 0){
				if(isRoi(z,y,x)){
					if((x % 2 == 0) && (y % 2 == 0)){ //even even
						evenEven(z, rLevel, y, x);
					}else if((x % 2 == 0) && (y % 2 == 1)){ //even odd
						if(y > 1 && x < xSize-1){
							if(isRoi(z,y-1,x) || isRoi(z,y-1,x+1)){
								evenOdd(z, rLevel, y, x);
							}else{
								evenEven(z, rLevel, y, x);
								evenOdd(z, rLevel, y, x);
							}
						}else{
							evenEven(z, rLevel, y, x);
							evenOdd(z, rLevel, y, x);
						}
					}else if((x % 2 == 1) && (y % 2 == 0)){ //odd even
						if(y > 1 && x < xSize-1){
							if(isRoi(z,y,x-1)){
								oddEven(z, rLevel, y, x);
							}else{
								evenEven(z, rLevel, y, x);
								oddEven(z, rLevel, y, x);
							}
						}else{
							evenEven(z, rLevel, y, x);
							oddEven(z, rLevel, y, x);
						}
					}else if((x % 2 == 1) && (y % 2 == 1)){ //odd odd
						if(y > 1 && x < xSize-1){
							if(isRoi(z,y,x-1) && isRoi(z,y-1,x)){
								oddOdd(z, rLevel, y, x);
							}else{
								evenEven(z, rLevel, y, x);
								oddEven(z, rLevel, y, x);
								evenOdd(z, rLevel, y, x);
								oddOdd(z, rLevel, y, x);
							}
						}else{
							evenEven(z, rLevel, y, x);
							oddEven(z, rLevel, y, x);
							evenOdd(z, rLevel, y, x);
							oddOdd(z, rLevel, y, x);
						}
					}
				}
			}else{
				if(isMarked(z, rLevel, y, x)){
					if((x % 2 == 0) && (y % 2 == 0)){ //even even
						evenEven(z, rLevel, y, x);
					}else if((x % 2 == 0) && (y % 2 == 1)){ //even odd
						if(y > 1 && x < xSize-1){
							if(isMarked(z,rLevel,y-1,x) || isMarked(z,rLevel,y-1,x+1)){
								evenOdd(z, rLevel, y, x);
							}else{
								evenEven(z, rLevel, y, x);
								evenOdd(z, rLevel, y, x);
							}
						}else{
							evenEven(z, rLevel, y, x);
							evenOdd(z, rLevel, y, x);
						}
					}else if((x % 2 == 1) && (y % 2 == 0)){ //odd even
						if(y > 1 && x < xSize-1){
							if(isMarked(z,rLevel,y,x-1)){
								oddEven(z, rLevel, y, x);
							}else{
								evenEven(z, rLevel, y, x);
								oddEven(z, rLevel, y, x);
							}
						}else{
							evenEven(z, rLevel, y, x);
							oddEven(z, rLevel, y, x);
						}
					}else if((x % 2 == 1) && (y % 2 == 1)){ //odd odd
						if(y > 1 && x < xSize-1){
							if(isMarked(z,rLevel,y,x-1) && isMarked(z,rLevel,y-1,x)){
								oddOdd(z, rLevel, y, x);
							}else{
								evenEven(z, rLevel, y, x);
								oddEven(z, rLevel, y, x);
								evenOdd(z, rLevel, y, x);
								oddOdd(z, rLevel, y, x);
							}
						}else{
							evenEven(z, rLevel, y, x);
							oddEven(z, rLevel, y, x);
							evenOdd(z, rLevel, y, x);
							oddOdd(z, rLevel, y, x);
						}
					}
				}
			}
			
		}}}
	}
	
	/**
	 * Performs the raster for a roi if the wavelet transform is 9/7 (-wt 2)
	 *
	 */
	protected void rasterWavelet9_7(int z){
		//Raster the image to set the no-data values
		for(int rLevel = 0; rLevel < WTLevels[z]; rLevel++){
		for(int y = 0; y < subbandSizes[rLevel][1][2]; y++){
		for(int x = 0; x < subbandSizes[rLevel][0][3]; x++){	
			if(rLevel == 0){
				if(isRoi(z,y,x)){
					if((x % 2 == 0) && (y % 2 == 0)){ //even even
						if(y > 1 && x > 0 && x < xSize-1){
							if(isRoi(z,y-2,x) || isRoi(z,y-1,x) || isRoi(z,y-2,x+1) || isRoi(z,y-1,x+1)){
								anyAny_y(z, rLevel, y, x);
							}else{
								if(isRoi(z,y,x-2) || isRoi(z,y,x-1)){
									anyAny_x(z, rLevel, y, x);
								}else{
									anyAny(z, rLevel, y, x);
								}
							}
						}else{
							anyAny(z, rLevel, y, x);
						}
						
					}else if((x % 2 == 0) && (y % 2 == 1)){ //even odd
						if(y > 2 && x > 2 && x < xSize-1){
							if(isRoi(z,y-3,x) || isRoi(z,y-2,x) || isRoi(z,y-3,x+1) || isRoi(z,y-2,x+1)){
								if(!isRoi(z,y-1,x) || !isRoi(z,y-1,x+1)){
									anyAny_y(z, rLevel, y, x);
								}
							}else{
								if(isRoi(z,y,x-2) || isRoi(z,y,x-1) || isRoi(z,y-1,x-2) || isRoi(z,y-1,x-1)){
									anyAny_x(z, rLevel, y, x);
								}else{
									anyAny(z, rLevel, y, x);
								}
							}
						}else{
							anyAny(z, rLevel, y, x);
						}
						
					}else if((x % 2 == 1) && (y % 2 == 0)){ //odd even	
						if(y > 2 && x > 1 && x < xSize-1){
							if(isRoi(z,y-2,x) || isRoi(z,y-1,x) || isRoi(z,y-2,x-1) || isRoi(z,y-1,x-1)){
								if(!isRoi(z,y,x-1)){
									anyAny_y(z, rLevel, y, x);
								}
							}else{
								if(isRoi(z,y,x-2) || isRoi(z,y,x-1)){
									anyAny_x(z, rLevel, y, x);
								}else{
									anyAny(z, rLevel, y, x);
								}
							}
						}else{
							anyAny(z, rLevel, y, x);
						}
					}else if((x % 2 == 1) && (y % 2 == 1)){ //odd odd
						if(y > 1 && x > 1){
							if(isRoi(z,y-2,x) || isRoi(z,y-1,x) || isRoi(z,y-2,x-1) || isRoi(z,y-1,x-1)){
								if(!isRoi(z,y-1,x) || !isRoi(z,y-1,x-1) || !isRoi(z,y,x-1)){
									anyAny_y(z, rLevel, y, x);
								}
							}else{
								if(isRoi(z,y-1,x-2) || isRoi(z,y-1,x-1) || isRoi(z,y,x-2) || isRoi(z,y,x-1)){
									anyAny_x(z, rLevel, y, x);
								}else{
									anyAny(z, rLevel, y, x);
								}
							}
						}else{
							if(!isRoi(z,y-1,x) || !isRoi(z,y-1,x-1) || !isRoi(z,y,x-1)){
								anyAny(z, rLevel, y, x);
							}
						}
					}	
				}
			}else{
				if(isMarked(z, rLevel,y,x)){
					if((x % 2 == 0) && (y % 2 == 0)){ //even even
						if(y > 1 && x > 0 && x < xSize-1){
							if(isMarked(z, rLevel,y-2,x) || isMarked(z, rLevel,y-1,x) || isMarked(z, rLevel,y-2,x+1) || isMarked(z, rLevel,y-1,x+1)){
								anyAny_y(z, rLevel, y, x);
							}else{
								if(isMarked(z, rLevel,y,x-2) || isMarked(z, rLevel,y,x-1)){
									anyAny_x(z, rLevel, y, x);
								}else{
									anyAny(z, rLevel, y, x);
								}
							}
						}else{
							anyAny(z, rLevel, y, x);
						}
						
					}else if((x % 2 == 0) && (y % 2 == 1)){ //even odd
						if(y > 2 && x > 2 && x < xSize-1){
							if(isMarked(z, rLevel,y-3,x) || isMarked(z, rLevel,y-2,x) || isMarked(z, rLevel,y-3,x+1) || isMarked(z, rLevel,y-2,x+1)){
								if(!isMarked(z, rLevel,y-1,x) || !isMarked(z, rLevel,y-1,x+1)){
									anyAny_y(z, rLevel, y, x);
								}
							}else{
								if(isMarked(z, rLevel,y,x-2) || isMarked(z, rLevel,y,x-1) || isMarked(z, rLevel,y-1,x-2) || isMarked(z, rLevel,y-1,x-1)){
									anyAny_x(z, rLevel, y, x);
								}else{
									anyAny(z, rLevel, y, x);
								}
							}
						}else{
							anyAny(z, rLevel, y, x);
						}
						
					}else if((x % 2 == 1) && (y % 2 == 0)){ //odd even	
						if(y > 2 && x > 1 && x < xSize-1){
							if(isMarked(z, rLevel,y-2,x) || isMarked(z, rLevel,y-1,x) || isMarked(z, rLevel,y-2,x-1) || isMarked(z, rLevel,y-1,x-1)){
								if(!isMarked(z, rLevel,y,x-1)){
									anyAny_y(z, rLevel, y, x);
								}
							}else{
								if(isMarked(z, rLevel,y,x-2) || isMarked(z, rLevel,y,x-1)){
									anyAny_x(z, rLevel, y, x);
								}else{
									anyAny(z, rLevel, y, x);
								}
							}
						}else{
							anyAny(z, rLevel, y, x);
						}
					}else if((x % 2 == 1) && (y % 2 == 1)){ //odd odd
						if(y > 1 && x > 1){
							if(isMarked(z, rLevel,y-2,x) || isMarked(z, rLevel,y-1,x) || isMarked(z, rLevel,y-2,x-1) || isMarked(z, rLevel,y-1,x-1)){
								if(!isMarked(z, rLevel,y-1,x) || !isMarked(z, rLevel,y-1,x-1) || !isMarked(z, rLevel,y,x-1)){
									anyAny_y(z, rLevel, y, x);
								}
							}else{
								if(isMarked(z, rLevel,y-1,x-2) || isMarked(z, rLevel,y-1,x-1) || isMarked(z, rLevel,y,x-2) || isMarked(z, rLevel,y,x-1)){
									anyAny_x(z, rLevel, y, x);
								}else{
									anyAny(z, rLevel, y, x);
								}
							}
						}else{
							if(!isMarked(z, rLevel,y-1,x) || !isMarked(z, rLevel,y-1,x-1) || !isMarked(z, rLevel,y,x-1)){
								anyAny(z, rLevel, y, x);
							}
						}
					}
				}
			}	
		}}}
	}
	
	/**
	 * Mark a coefficient in the bitMap.
	 *
	 * @param z component to shift.
	 * @param rLevel ressolution level where belong the x and y postion.
	 * @param y position of the subband and rlevel.
	 * @param x position of the subband and rlevel.
	 * @param subband where belong the x and y postion.
	 * @param weight depending on the distance from the ROI foreign
	 * 
	 */
	protected void shift(int z, int rLevel, int y, int x, int subband, int weight){
		boolean inRange = false;
		//mirror efect
		if(x < 0){
			x = -x;
		}
		if(y < 0){
			y = -y;
		}
		//checking if the x y position belong to the subband domain
		if((rLevel != maxRLevel)){//[z][rLevel][{LH,HL,HH}][{yBegin,xBegin,yEnd,xEnd}]
			if((y < ySize) && (y + subbandSizes[rLevel][subband][0] < subbandSizes[rLevel][subband][2]) && (x < xSize) && (x + subbandSizes[rLevel][subband][1] < subbandSizes[rLevel][subband][3])){
				inRange = true;
			}
		}else{//LL
			if((y < ySize) && (y < subbandSizes[rLevel][1][0]) && (x < xSize) && (x < subbandSizes[rLevel][0][1])){
				inRange = true;
			}
		}
		if(inRange){
			
			
			//mark the coefficient as shifted in the bitMap
			if((subband != 3) && (rLevel < WTLevels[z])){
				y += subbandSizes[rLevel][subband][0];
				x += subbandSizes[rLevel][subband][1];	
			}
			//mirror efect
			if(y > ySize){
				y = y - (y - ySize);
			}
			if(y == ySize){
				y--;
			}
			if(x > xSize){
				x = x - (x - xSize);
			}
			if(x == xSize){
				x--;
			}
				
			if((y >= 0) && (y <= ySize) && (x >= 0) && (x <= xSize)){
				//bitMap[roiValue][((y * xSize) + x) / 8] |= (byte)(1 << (7-(((y * xSize) + x) % 8)));
				if(bitMap[roiValue][y][x] == -1){
							//bitMap[roiValue][y][x] = (byte)(rLevel+1);
							//bitMap[roiValue][y][x] = (byte)1;
							bitMap[roiValue][y][x] = (byte)weight;
							//System.out.println("y: "+y+" x: "+x+" rLevel: "+rLevel+ " bitMap[roiValue][y][x]: "+bitMap[roiValue][y][x]);
					
				}
			}
			//////////////////////////////////////////////////////////////////////
			/*if(rLevel != 0 && nextRlevelBitMap[rLevel-1][y][x] == rLevel){
				bitMap[roiValue][y][x] = (byte)rLevel;
				//System.out.println("----------y: "+y+" x: "+x+" rLevel: "+rLevel+ " bitMap[roiValue][y][x]: "+bitMap[roiValue][y][x]);
			}*/
			//////////////////////////////////////////////////////////////////////

		}	
	}

	/**
	 * Mark a coefficient, this allow to know if the coefficient has to be shifted in the next ressolution level.
	 *
	 * @param z component to shift.
	 * @param rLevel ressolution level where belong the x and y position.
	 * @param y position of the subband and rlevel.
	 * @param x position of the subband and rlevel. 
	 */
	protected void mark(int z, int rLevel, int y, int x){
		//mirror efect
		if(x < 0){
			x = -x;
		}
		if(y < 0){
			y = -y;
		}
		if((y < subbandSizes[rLevel][1][0]) && (x < subbandSizes[rLevel][0][1])){
					
			if((nextRlevelBitMap[rLevel][y][x]) == -1){
				nextRlevelBitMap[rLevel][y][x] = (byte)(rLevel+1);
				//bitMap[rLevel][y][x] = (byte)(rLevel+1);
				//System.out.println("y: "+y+" x: "+x+" rLevel: "+rLevel+ " nextRlevelBitMap[roiValue][y][x]: "+nextRlevelBitMap[roiValue][y][x]+"  bitMap[roiValue][y][x]: "+bitMap[roiValue][y][x]);
			}
		}
	}
	
	
	/**
	 * Check if a coefficient has to be checked to be shifted
	 *
	 * @param z component to shift.
	 * @param rLevel ressolution level where belong the x and y postion.
	 * @param y position of the subband and rlevel.
	 * @param x position of the subband and rlevel.
	 * 
	 * @return a boolean, true is marked to be checked or false if not
	 * 
	 */
	protected boolean isMarked(int z, int rLevel, int y, int x){
		rLevel--;
		if(rLevel == -1) rLevel = 0;
		boolean isMarked = false;
		//mirror efect
		if(x < 0){
			x = -x;
		}
		if(y < 0){
			y = -y;
		}
		if((y >= 0) && (y < subbandSizes[rLevel][1][0]) && (x >= 0) && (x < subbandSizes[rLevel][0][1])){
			if(nextRlevelBitMap[rLevel][y][x] != -1){
				isMarked = true;
			}
		}
		return(isMarked);
	}
	/**
	 * Mark the required coefficients if the coefficient is in a position (any,any) only for wavelet filter 9/7.
	 *
	 * @param z is the component index
	 * @param rLevel is the ressolution level
	 * @param y position
	 * @param x position
	 * 
	 */
	protected void anyAny(int z, int rLevel, int y, int x){
		if((x % 2 == 0) && (y % 2 == 0)){ //even even
			x = x/2;
			y = y/2;
		}else if((x % 2 == 0) && (y % 2 == 1)){ //even odd
			y = (y--)/2;
			x = x/2;
		}else if((x % 2 == 1) && (y % 2 == 0)){ //odd even
			x = (x--)/2;
			y = y/2;
		}else if((x % 2 == 1) && (y % 2 == 1)){ //odd odd
			x = (x--)/2;
			y = (y--)/2;
		}
		for(int i = 0; i < filter_9_7_AnyAny.length - 16; i++){
			shift(z, rLevel, y + filter_9_7_AnyAny[i][1], x + filter_9_7_AnyAny[i][0], filter_9_7_AnyAny[i][2], filter_9_7_AnyAny_dist_0_1_2[i][3]);
		}
		for(int i = filter_9_7_AnyAny.length - 16; i < filter_9_7_AnyAny.length; i++){
			if(rLevel == maxRLevel){
				shift(z, rLevel, y + filter_9_7_AnyAny[i][1], x + filter_9_7_AnyAny[i][0], filter_9_7_AnyAny[i][2], filter_9_7_AnyAny_dist_0_1_2[i][3]);
			}else{
				mark(z, rLevel, y + filter_9_7_AnyAny[i][1], x + filter_9_7_AnyAny[i][0]);
			}
		}		
	}
	
	/**
	 * Mark the required coefficients if the coefficient is in a position (any,any) and the (any,any-2) has been marked before, only for wavelet filter 9/7.
	 *
	 * @param z is the component index
	 * @param rLevel is the ressolution level
	 * @param y position
	 * @param x position
	 * 
	 */
	protected void anyAny_y(int z, int rLevel, int y, int x){
		if((x % 2 == 0) && (y % 2 == 0)){ //even even
			x = x/2;
			y = y/2;
		}else if((x % 2 == 0) && (y % 2 == 1)){ //even odd
			y = (y--)/2;
			x = x/2;
		}else if((x % 2 == 1) && (y % 2 == 0)){ //odd even
			x = (x--)/2;
			y = y/2;
		}else if((x % 2 == 1) && (y % 2 == 1)){ //odd odd
			x = (x--)/2;
			y = (y--)/2;
		}
		for(int i = 0; i < filter_9_7_AnyAny_y.length - 4; i++){
			shift(z, rLevel, y + filter_9_7_AnyAny_y[i][1], x + filter_9_7_AnyAny_y[i][0], filter_9_7_AnyAny_y[i][2], filter_9_7_AnyAny_dist_0_1_2[i][3]);
		}
		for(int i = filter_9_7_AnyAny_y.length - 4; i < filter_9_7_AnyAny_y.length; i++){
			if(rLevel == maxRLevel){
				shift(z, rLevel, y + filter_9_7_AnyAny_y[i][1], x + filter_9_7_AnyAny_y[i][0], filter_9_7_AnyAny_y[i][2], filter_9_7_AnyAny_dist_0_1_2[i][3]);
			}else{
				mark(z, rLevel, y + filter_9_7_AnyAny_y[i][1], x + filter_9_7_AnyAny_y[i][0]);
			}
		}		
	}
	
	/**
	 * Mark the required coefficients if the coefficient is in a position (any,any) and if (any-2,any) has been marked before, only for wavelet filter 9/7.
	 *
	 * @param z is the component index
	 * @param rLevel is the ressolution level
	 * @param y position
	 * @param x position
	 * 
	 */
	protected void anyAny_x(int z, int rLevel, int y, int x){
		if((x % 2 == 0) && (y % 2 == 0)){ //even even
			x = x/2;
			y = y/2;
		}else if((x % 2 == 0) && (y % 2 == 1)){ //even odd
			y = (y--)/2;
			x = x/2;
		}else if((x % 2 == 1) && (y % 2 == 0)){ //odd even
			x = (x--)/2;
			y = y/2;
		}else if((x % 2 == 1) && (y % 2 == 1)){ //odd odd
			x = (x--)/2;
			y = (y--)/2;
		}
		for(int i = 0; i < filter_9_7_AnyAny_x.length - 4; i++){
			shift(z, rLevel, y + filter_9_7_AnyAny_x[i][1], x + filter_9_7_AnyAny_x[i][0], filter_9_7_AnyAny_x[i][2], filter_9_7_AnyAny_dist_0_1_2[i][3]);
		}
		for(int i = filter_9_7_AnyAny_x.length - 4; i < filter_9_7_AnyAny_x.length; i++){
			if(rLevel == maxRLevel){
				shift(z, rLevel, y + filter_9_7_AnyAny_x[i][1], x + filter_9_7_AnyAny_x[i][0], filter_9_7_AnyAny_x[i][2], filter_9_7_AnyAny_dist_0_1_2[i][3]);
			}else{
				mark(z, rLevel, y + filter_9_7_AnyAny_x[i][1], x + filter_9_7_AnyAny_x[i][0]);
			}
		}		
	}
	/**
	 * Mark the required coefficients if the coefficient is in a position (2n,2n).
	 *
	 * @param z is the component index
	 * @param rLevel is the ressolution level
	 * @param y position
	 * @param x position
	 * 
	 */
	protected void evenEven(int z, int rLevel, int y, int x){
		x = x/2;
		y = y/2;
		for(int i = 0; i < filter_5_3_EvenEven.length - 1; i++){
			shift(z, rLevel, y + filter_5_3_EvenEven[i][1], x + filter_5_3_EvenEven[i][0], filter_5_3_EvenEven[i][2], 1);
		}
		for(int i = filter_5_3_EvenEven.length - 1; i < filter_5_3_EvenEven.length; i++){
			if(rLevel == maxRLevel){
				shift(z, rLevel, y + filter_5_3_EvenEven[i][1], x + filter_5_3_EvenEven[i][0], filter_5_3_EvenEven[i][2], 1);
			}else{	
				mark(z, rLevel, y + filter_5_3_EvenEven[i][1], x + filter_5_3_EvenEven[i][0]);
			}
		}
		
	}
	
	/**
	 * Mark the required coefficients if the coefficient is in a position (2n,2n+1).
	 *
	 * @param z is the component index
	 * @param rLevel is the ressolution level
	 * @param y position
	 * @param x position
	 * 
	 */
	protected void evenOdd(int z, int rLevel, int y, int x){
		x = x/2;
		y = (y--)/2;
		for(int i = 0; i < filter_5_3_EvenOdd.length - 1; i++){
			shift(z, rLevel, y + filter_5_3_EvenOdd[i][1], x + filter_5_3_EvenOdd[i][0],  filter_5_3_EvenOdd[i][2], 1);
		}
		for(int i = filter_5_3_EvenOdd.length - 1; i < filter_5_3_EvenOdd.length; i++){
			if(rLevel == maxRLevel){
				shift(z, rLevel, y + filter_5_3_EvenOdd[i][1], x + filter_5_3_EvenOdd[i][0], filter_5_3_EvenOdd[i][2], 1);
			}else{	
				mark(z, rLevel, y + filter_5_3_EvenOdd[i][1], x + filter_5_3_EvenOdd[i][0]);
			}
		}
		
	}
	
	/**
	 * Mark the required coefficients if the coefficient is in a position (2n+1,2n).
	 *
	 * @param z is the component index
	 * @param rLevel is the ressolution level
	 * @param y position
	 * @param x position
	 */
	protected void oddEven(int z, int rLevel, int y, int x){
		x = (x--)/2;
		y = y/2;
		for(int i = 0; i < filter_5_3_OddEven.length - 1; i++){
			shift(z, rLevel, y + filter_5_3_OddEven[i][1], x + filter_5_3_OddEven[i][0], filter_5_3_OddEven[i][2], 1);
		}
		for(int i = filter_5_3_OddEven.length - 1; i < filter_5_3_OddEven.length; i++){
			if(rLevel == maxRLevel){
				shift(z, rLevel, y + filter_5_3_OddEven[i][1], x + filter_5_3_OddEven[i][0], filter_5_3_OddEven[i][2], 1);
			}else{	
				mark(z, rLevel, y + filter_5_3_OddEven[i][1], x + filter_5_3_OddEven[i][0]);
			}
		}
		
	}
	
	/**
	 * Mark the required coefficients if the coefficient is in a position (2n+1,2n+1).
	 *
	 * @param z is the component index
	 * @param rLevel is the ressolution level
	 * @param y position
	 * @param x position
	 * 
	 */
	protected void oddOdd(int z, int rLevel, int y, int x){
		x = (x--)/2;
		y = (y--)/2;
		for(int i = 0; i < filter_5_3_OddOdd.length - 1; i++){
			shift(z, rLevel, y + filter_5_3_OddOdd[i][1], x + filter_5_3_OddOdd[i][0], filter_5_3_OddOdd[i][2], 1);
		}
		for(int i = filter_5_3_OddOdd.length - 1; i < filter_5_3_OddOdd.length; i++){
			if(rLevel == maxRLevel){
				shift(z, rLevel, y + filter_5_3_OddOdd[i][1], x + filter_5_3_OddOdd[i][0], filter_5_3_OddOdd[i][2], 1);
			}else{	
				mark(z, rLevel, y + filter_5_3_OddOdd[i][1], x + filter_5_3_OddOdd[i][0]);
			}
		}
		
	}


		
	/**
	 * Check if a coefficient of the image belong to Roi.
	 *
	 * @param z is the component index
	 * @param y position
	 * @param x position
	 * 
	 * @return a boolean, true if the coefficient (z,y,x) belongs to the roi, and false if (z,y,x) not belogns to the roi.  
	 *
	 */
	protected boolean isRoi(int z, int y, int x){
		boolean isRoi = false;
		if(maskSamples[z][y][x] == RroiValues[roiValue]){
			isRoi = true;
		}
		return(isRoi);
	}
	
	/**
	 * Calculate the subband sizes for an image.
	 *
	 * @param subbandSizes is the memory structure to fill.
	 *
	 */
	protected void SubbandSizesCalculation(int z, int[][][] subbandSizes){
		
		int xSubbandSize;
		int ySubbandSize;

		xSubbandSize = xSize;
		ySubbandSize = ySize;
		for(int rLevel = 0; rLevel < WTLevels[z]; rLevel++){

			//Size setting for the level
			int xOdd = xSubbandSize % 2;
			int yOdd = ySubbandSize % 2;
			xSubbandSize = xSubbandSize / 2 + xOdd;
			ySubbandSize = ySubbandSize / 2 + yOdd;
						
			//[z][rLevel][{LH,HL,HH}][{yBegin,xBegin,yEnd,xEnd}]
			subbandSizes[rLevel][0][0] = 0;
			subbandSizes[rLevel][0][1] = xSubbandSize;
			subbandSizes[rLevel][0][2] = ySubbandSize;
			subbandSizes[rLevel][0][3] = xSubbandSize*2 - xOdd;
			
			subbandSizes[rLevel][1][0] = ySubbandSize;
			subbandSizes[rLevel][1][1] = 0;
			subbandSizes[rLevel][1][2] = ySubbandSize*2 - yOdd;
			subbandSizes[rLevel][1][3] = xSubbandSize;
			
			subbandSizes[rLevel][2][0] = ySubbandSize;
			subbandSizes[rLevel][2][1] = xSubbandSize;
			subbandSizes[rLevel][2][2] = ySubbandSize*2 - yOdd;
			subbandSizes[rLevel][2][3] = xSubbandSize*2 - xOdd;	
		}
	}
	
	/**
	 * @param z is the component index
	 * @return bitMap definition in {@link #bitMap}
	 */
	public byte[][][] getMaskWaveletDomain(int z){
		this.z = z;
		//this.roiValue
		//initializing the bitMap
			for(int roiValue = 0; roiValue < bitMap.length; roiValue++){
				this.roiValue = roiValue;
				for(int y = 0; y < bitMap[roiValue].length; y++){
				for(int x = 0; x < bitMap[roiValue][y].length; x++){
					bitMap[roiValue][y][x] = -1;
				}}
			}
				
			try{
				run();
			}catch(Exception e){
				
			}
		return(bitMap);
	}
	
	/**
	 * @return bitMap definition in {@link #bitMap}
	 */
	public byte[][][] getMaskWaveletDomain(){
		return(bitMap);
	}
}
		

	
	