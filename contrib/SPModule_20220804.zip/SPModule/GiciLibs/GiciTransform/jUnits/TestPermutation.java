package GiciTransform.jUnits;

import java.util.ArrayList;
import java.util.List;

import GiciTransform.Permutation;
import junit.framework.TestCase;

public class TestPermutation extends TestCase {

	public void xtestInterleaving() {
		
		Permutation p = new Permutation(12);
		p.permutationInterleaveRange(0, 12, true);
		p.scream(); p.setToIdentity();
		p.permutationInterleaveRange(0, 5, true);
		p.scream(); p.setToIdentity();
		p.permutationInterleaveRange(0, 5, false);
		p.scream(); p.setToIdentity();
		p.permutationInterleaveRange(1, 5, false);
		p.scream(); p.setToIdentity();
	}
	
	public void testBringList() {
		
		Permutation p = new Permutation(12);
		
		List<Integer> list = new ArrayList<Integer>();
		
		list.add(3);
		list.add(6);
		list.add(10);
		
		p.permutationBringListTo(list, 3);
		
		p.scream();
	}
	
}
