package GiciTransform.jUnits;

import java.util.Random;

import junit.framework.TestCase;

import GiciMatrix.MatrixAlgebra;
import GiciTransform.SingleRowElementaryReversibleMatrix;
import GiciTransform.SingleRowElementaryReversibleTransform;
import GiciTransform.KarhunenLoeveTransform;

public class TestSERM extends TestCase {
	public void xtestExample() {
		float[][] a = {
				{-23, 10, -14, 90},
				{-63, 22, 60, 80},
				{-26, 12, -35, 19},
				{30, 45, 21, 88},
		};
		
		float norm = (float) Math.pow(MatrixAlgebra.determinant(a),1/4f);
		
		// Potser que la normalitzi no?
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				a[i][j] /= norm;
			}
		}
		
		try {
			SingleRowElementaryReversibleMatrix erm = (new SingleRowElementaryReversibleMatrix(a)).call();
			
			int[] perm = erm.getPermutation();
			float[][] serms = erm.getSingleRowElementarySteps();
			float[][] pmat = erm.getPermutationMatrix();
			
			assertTrue(perm.length == 4
					&& perm[0] == 0
					&& perm[1] == 1
					&& perm[2] == 2
					&& perm[3] == 3);
			
			assertTrue(pmat.length == 4
					&& pmat[0].length == 4 && pmat[0][0] == 1
						&& pmat[0][1] == 0 && pmat[0][2] == 0 && pmat[0][3] == 0
					&& pmat[1].length == 4 && pmat[1][0] == 0
						&& pmat[1][1] == 1 && pmat[1][2] == 0 && pmat[1][3] == 0
					&& pmat[2].length == 4 && pmat[2][0] == 0
						&& pmat[2][1] == 0 && pmat[2][2] == 1 && pmat[2][3] == 0
					&& pmat[3].length == 4 && pmat[3][0] == 0
						&& pmat[3][1] == 0 && pmat[3][2] == 0 && pmat[3][3] == 1
			);
			
			float[][] r = {
					{-0.94699f,   -0.68695f,     40.054f,     1.0000f},
					{  1.0000f,     1.1542f,    -58.154f,     1.4463f},
					{ 0.20504f,     1.0000f,    -38.605f,    0.98904f},
					{-0.24167f,    0.55109f,     1.0000f,  -0.053631f},
					{  10.092f,    -19.077f,     33.876f,     1.0000f},
			};
			
			float[][] err = MatrixAlgebra.relativeError(serms, r);
			
			for (int i = 0; i < 4; i++) {
				for (int j = 0; j < 4; j++) {
					assertTrue(err[i][j] < 0.0001);
				}
			}
			
			float[][][] timage = {
					{{214f}}, {{122f}}, {{193f}}, {{243f}},
					//{{122f}}, {{0f}}, {{3f}}, {{4f}},
			};
			
			float[][][] iimage = (new SingleRowElementaryReversibleTransform(erm, timage, true)).call();
			float[][][] rimage = (new SingleRowElementaryReversibleTransform(erm, iimage, false)).call();
			
			for (int i = 0; i < 4; i++) {
				assertTrue(timage[i][0][0] == rimage[i][0][0]);
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false);
		}
	}
	
	public void testGeneric() {		
		Random ra = new Random(23493);
		int N = 6; //(int)(ra.nextFloat() * 8 + 1);;
		
		float[][] a = new float[N][N];
		
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				a[i][j] = ra.nextFloat() * 80;
			}
		}
		
		a = KarhunenLoeveTransform.generateTransform(
				MatrixAlgebra.cutUHUT(MatrixAlgebra.cutCUH(a))
				)[0];
		
		float[][] b = {
				{0.437423f , 0.364451f , 0.372798f , -0.00379347f , 0.568771f , -0.461934f },
				{-0.761645f , 0.532900f , -0.150810f , -0.00419887f , 0.0772084f , -0.327429f },
				{-0.454828f , -0.652465f , 0.366705f , 0.00287468f , 0.478965f , -0.0598177f },
				{-0.143547f , 0.378030f , 0.654179f , 0.00327011f , -0.0426062f , 0.637753f },
				{0.0328104f , 0.120995f , -0.525249f , 0.0104177f , 0.662817f , 0.518615f },
				{0.000101558f , -0.00300033f , -0.00306069f , -0.999930f , 0.00567771f , 0.0104509f},
		};
		
		a = MatrixAlgebra.transposeC(b);
		
		float norm = MatrixAlgebra.determinant(a, N);
		
		System.out.println ("norm: " + norm);
		
		if (Math.abs(norm) < Float.MIN_VALUE) {
			return;
		}
		
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				a[i][j] /= norm;
			}
		}
		
		try {
			SingleRowElementaryReversibleMatrix erm = (new SingleRowElementaryReversibleMatrix(a)).call();
		
			MatrixAlgebra.printMatrix(erm.getSingleRowElementarySteps());
			
			MatrixAlgebra.printMatrix(erm.getPermutationMatrix());
			
			// Iterate multiple times over the image
			for (int l = 0; l < 1; l++) {
				// Generate some tests
				int x = 15;
				int y = 15;

				float[][][] timage = new float[N][y][x];

				for (int k = 0; k < N; k++) {
					for (int j = 0; j < y; j++) {
						for (int i = 0; i < x; i++) {		
							timage[k][j][i] = ra.nextInt(65536);
						}
					}
				}

				float[][][] iimage = (new SingleRowElementaryReversibleTransform(erm, timage, true)).call();
				float[][][] rimage = (new SingleRowElementaryReversibleTransform(erm, iimage, false)).call();

				for (int j = 0; j < y; j++) {
					for (int i = 0; i < x; i++) {
						boolean result = true;

						for (int k = 0; k < N; k++) {
							// System.out.print(timage[k][j][i] + "x" + rimage[k][j][i] + " ");

							result = result && timage[k][j][i] == rimage[k][j][i];

						}
						// System.out.println();
						assertTrue(result);
						
//						 Mostar-ho en el domini transformat
						if (false) {
						float[][] v = new float[N][1]; 
						float[][] t = new float[1][N];
						
						System.out.print("rev: ");
						for (int k = 0; k < N; k++) {
							t[0][k] = iimage[k][j][i];
							v[k][0] = timage[k][j][i];
						}
						MatrixAlgebra.printMatrix(t);
						
						System.out.print("klt: ");
						MatrixAlgebra.printMatrix(
								MatrixAlgebra.transposeC(
										MatrixAlgebra.multiplicationCC(a, v)
										)
						);
						}
					}
				}			
			}
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false);
		}
	}
}
