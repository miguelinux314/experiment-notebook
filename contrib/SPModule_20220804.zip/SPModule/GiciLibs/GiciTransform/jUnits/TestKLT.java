package GiciTransform.jUnits;

import java.util.Random;
import GiciMatrix.MatrixAlgebra;
import GiciTransform.KarhunenLoeveTransform;
import GiciTransform.LinearTransform;
import junit.framework.TestCase;

public class TestKLT extends TestCase {

	float[][] buildTestMatrix1() {
		float[][] r = MatrixAlgebra.identityUT(8);

		for (int i = 0; i < r.length; i++) {
			for (int j = 0; j < r[i].length; j++) {
				int v = (i + 1) + (j + i + 1);
				r[i][j] = (float) ((v * v * v * v * v * v * v) % 256);
			}
		}

		return r;
	}

	public void xtestMeFirst () {
		MatrixAlgebra.printMatrix(KarhunenLoeveTransform.generateTransform(buildTestMatrix1())[0]);
	}
	
	public void testMeSecond () {
		float[][] m1 = buildTestMatrix1();
		float[][][] t = KarhunenLoeveTransform.generateTransform(m1);
		
		//MatrixAlgebra.printMatrix(t[1]);
		
		float[][] r = MatrixAlgebra.multiplicationCC(t[0], MatrixAlgebra.transposeC(t[0]));
		//MatrixAlgebra.printMatrix(r);
		//MatrixAlgebra.printMatrix(MatrixAlgebra.identityC(8));
		assertTrue(MatrixAlgebra.compare(r, MatrixAlgebra.identityC(8), 0.000001f));
		
		float[][] tp = MatrixAlgebra.transposeC(t[0]);
		float[][] r2 = MatrixAlgebra.multiplicationCC(t[0], MatrixAlgebra.multiplicationCC(t[1],tp));
		
		assertTrue(MatrixAlgebra.compare(r2, KarhunenLoeveTransform.toCompleteMirrorFill(m1), 0.1f));
	}

	float[][][] buildRandomImage(long seed) {
		Random ra = new Random(seed);

		int size1 = (int)(ra.nextFloat() * 100 + 1);
		int size2 = (int)(ra.nextFloat() * 100 + 1);
		int size3 = (int)(ra.nextFloat() * 100 + 1);

		//System.out.println(size1 + " x " + size2 + " x " + size3);

		float[][][] r = new float[size1][size2][size3];

		for (int i = 0; i < r.length; i++) {
			for (int j = 0; j < r[i].length; j++) {
				for (int k = 0; k < r[i][j].length; k++) {
					r[i][j][k] = (ra.nextFloat() - 0.5f) * 256.0f;
				}
			}
		}

		return r;
	}

	boolean compare(float[][][] a, float[][][] b) {

		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				for (int k = 0; k < a[i][j].length; k++) {
					if (Math.abs(a[i][j][k] - b[i][j][k]) > 0.01) {
						return false;
					}
				}
			}
		}

		return true;
	}

	public void testExtensive() {
		float[][][] imageSamples = buildRandomImage(32);
		float[][] t = KarhunenLoeveTransform.run(imageSamples);
		
		LinearTransform lt = new LinearTransform(t, 0);
		LinearTransform ltr = new LinearTransform(MatrixAlgebra.transposeC(t), 0);

		//MatrixAlgebra.printMatrix(t);
		//MatrixAlgebra.printMatrix(imageSamples[0]);
		//MatrixAlgebra.printMatrix(ltr.transform(lt.transform(imageSamples))[0]);
		
		assertTrue(compare(ltr.transform(lt.transform(imageSamples)), imageSamples));
	}
}
