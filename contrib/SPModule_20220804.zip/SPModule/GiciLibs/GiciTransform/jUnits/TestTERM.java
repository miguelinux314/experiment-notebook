package GiciTransform.jUnits;

import java.util.Random;

import junit.framework.TestCase;

import GiciMatrix.MatrixAlgebra;
import GiciTransform.TriangularElementaryReversibleMatrix;
import GiciTransform.TriangularElementaryReversibleTransform;

public class TestTERM extends TestCase {
	public void testGeneric() {		
		Random ra = new Random(234);
		int N = 256; //(int)(ra.nextFloat() * 8 + 1);;
		
		float[][] a = new float[N][N];
		
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				a[i][j] = ra.nextFloat() * 80;
			}
		}
		
//		a = KarhunenLoeveTransform.generateTransform(
//				MatrixAlgebra.cutUHUT(MatrixAlgebra.cutCUH(a))
//				)[0];

		N = 6;
		
		float[][] b = {
				{0.437423f , 0.364451f , 0.372798f , -0.00379347f , 0.568771f , -0.461934f },
				{-0.761645f , 0.532900f , -0.150810f , -0.00419887f , 0.0772084f , -0.327429f },
				{-0.454828f , -0.652465f , 0.366705f , 0.00287468f , 0.478965f , -0.0598177f },
				{-0.143547f , 0.378030f , 0.654179f , 0.00327011f , -0.0426062f , 0.637753f },
				{0.0328104f , 0.120995f , -0.525249f , 0.0104177f , 0.662817f , 0.518615f },
				{0.000101558f , -0.00300033f , -0.00306069f , -0.999930f , 0.00567771f , 0.0104509f},
		};
		
		a = MatrixAlgebra.transposeC(b);
		
		float norm = MatrixAlgebra.determinant(a, N);
		
		System.out.println ("norm: " + norm);
		
		if (Math.abs(norm) < Float.MIN_VALUE) {
			return;
		}
		
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				a[i][j] /= norm;
			}
		}
		
		try {
			TriangularElementaryReversibleMatrix term = (new TriangularElementaryReversibleMatrix(a)).call();
			
			System.out.println ("decomposition done");
			
			MatrixAlgebra.printMatrix(term.getPermutationMatrix());
			MatrixAlgebra.printMatrix(term.getElementaryMatrixL());
			MatrixAlgebra.printMatrix(term.getElementaryMatrixU());
			MatrixAlgebra.printMatrix(term.getElementaryMatrixS());
//			
//			MatrixAlgebra.printMatrix(a);
//			
//			MatrixAlgebra.printMatrix(
//					MatrixAlgebra.multiplicationCC(term.getPermutationMatrix(),
//							MatrixAlgebra.multiplicationCC(term.getElementaryMatrixL(),
//									MatrixAlgebra.multiplicationCC(
//											term.getElementaryMatrixU(),
//											term.getElementaryMatrixS()
//											)))
//					);
			
			// Iterate multiple times over the image
			for (int l = 0; l < 100; l++) {
				// Generate some tests
				int x = 10;
				int y = 50;

				float[][][] timage = new float[N][y][x];

				for (int k = 0; k < N; k++) {
					for (int j = 0; j < y; j++) {
						for (int i = 0; i < x; i++) {		
							timage[k][j][i] = ra.nextInt(65536);
						}
					}
				}

				float[][][] iimage = (new TriangularElementaryReversibleTransform(term, timage, true)).call();
				float[][][] rimage = (new TriangularElementaryReversibleTransform(term, iimage, false)).call();

				for (int j = 0; j < y; j++) {
					for (int i = 0; i < x; i++) {
						boolean result = true;

						for (int k = 0; k < N; k++) {
//							System.out.print(timage[k][j][i] + "x" + rimage[k][j][i] + " ");

							result = result && timage[k][j][i] == rimage[k][j][i];

						}
						//System.out.println();
						assertTrue(result);
						
						// Mostar-ho en el domini transformat
//						float[][] v = new float[N][1]; 
//						float[][] t = new float[1][N];
//						
//						System.out.print("rev: ");
//						for (int k = 0; k < N; k++) {
//							t[0][k] = iimage[k][j][i];
//							v[k][0] = timage[k][j][i];
//						}
//						MatrixAlgebra.printMatrix(t);
//						
//						System.out.print("klt: ");
//						MatrixAlgebra.printMatrix(
//								MatrixAlgebra.transposeC(
//										MatrixAlgebra.multiplicationCC(a, v)
//										)
//						);
					}
				}			
			}
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false);
		}
	}
}
