/*
 * GICI Library -
 * Copyright (C) 2007  Group on Interactive Coding of Images (GICI)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Group on Interactive Coding of Images (GICI)
 * Department of Information and Communication Engineering
 * Autonomous University of Barcelona
 * 08193 - Bellaterra - Cerdanyola del Valles (Barcelona)
 * Spain
 *
 * http://gici.uab.es
 * gici-info@deic.uab.es
 */
package GiciTransform;
import GiciException.*;

public class ColourTransform {
	
	/**
	 * Definition in {@link Pyrenees.Coder.Coder#imageSamplesFloat}
	 */
	float[][][] imageSamples = null;
	
	/**
	 * Definition in {@link Pyrenees.Coder.Coder#zSize}
	 */
	int zSize;

	/**
	 * Definition in {@link Pyrenees.Coder.Coder#ySize}
	 */
	int ySize;

	/**
	 * Definition in {@link Pyrenees.Coder.Coder#xSize}
	 */
	int xSize;
	
	/**
	 * Coulour Tranform Type defined by the International Colour Consortium
	 */
	int ICCType;
	
	/**
	 * Colour transform direction (forward/reverse).
	 * <p>
	 * Valid values are:<br>
	 *   <ul>
	 *     <li> 1 - Forward Colour Transform
	 *     <li> 0 - Reverse Colour Transform
	 *   </ul>
	 */
	int ICCforward;
	
	/**
	 * Matrix of forward SRGB
	 * <p>
	 * The values are static.
	 */
	 static float[][] SRGB_for =
	{
		{  3.2406F , -1.5372F , -0.4986F  },
		{  -0.9689F, 1.8758F , 0.0415F  },
		{  0.0557F  , -0.2040F , 1.0570F },
	};
	 
	/**
	 * Matrix of forward SRGB
	 * <p>
	 * The values are static.
	 */
	 static float[][] SRGB_inv =
	{
		{  0.4124F , 0.3576F , 0.1805F },
		{  0.2126F , 0.7152F , 0.0722F },
		{  0.0193F , 0.1192F , 0.9505F },
	};
		 
	 /**
	 * To know if parameters are set.
	 * <p>
	 * True indicates that they are set otherwise false.
	 */
	boolean parametersSet = false;
		
	 /**
	 * Constructor that receives the original image samples.
	 *
	 * @param imageSamples definition in {@link Pyrenees.Coder.Coder#imageSamplesFloat}
	 */
	public ColourTransform(float[][][] imageSamples){
		//Image data copy
		this.imageSamples = imageSamples;

		//Size set
		zSize = imageSamples.length;
		ySize = imageSamples[0].length;
		xSize = imageSamples[0][0].length;
	}
	
	/**
	 * Set the parameters used to do the colour transform operation.
	 *
	 * @param ICCType definition in {@link #ICCType}
	 * @param ICCforward definition in {@link #ICCforward}
	 */
	public void setParameters(int ICCType, int ICCforward){
		parametersSet = true;

		//Parameters copy
		this.ICCType = ICCType;
		this.ICCforward = ICCforward;
	}
	
	public float[][][] run() throws ErrorException{
	//If parameters are not set run cannot be executed
		if(!parametersSet){
			throw new ErrorException("Parameters not set.");
		}
		
		if(ICCType != 0){
			switch(ICCType){
			case 1:
				if(ICCforward == 1){
					ICCforwardTransformSRGB();
				}else{
					ICCinverseTransformSRGB();
				}
				break;
			default:
				throw new ErrorException("Unrecognized colour transform type.");
			
			}
		}else{
			throw new ErrorException("Unrecognized colour transform type.");
		}
		return(imageSamples);
	}
	
	/**
	 * Performs the ICC SRGB forward colour transform
	 *
	 */
	public void ICCforwardTransformSRGB(){
		for(int y = 0; y < ySize; y++){
		for(int x = 0; x < xSize; x++){
			float c1 = imageSamples[0][y][x];
			float c2 = imageSamples[1][y][x];
			float c3 = imageSamples[2][y][x];
			for(int z = 0; z < 3; z++){
				imageSamples[z][y][x] = c1 * SRGB_for[z][0] + c2 * SRGB_for[z][1] + c3 * SRGB_for[z][2];
			}
		}}
		int WDC = 0; //white digital count
		int KDC = 0; //black digital count
		for(int y = 0; y < ySize; y++){
		for(int x = 0; x < xSize; x++){
			if(imageSamples[0][y][x] == 255 && imageSamples[1][y][x] == 255 && imageSamples[2][y][x] == 255){
				WDC++;
			}
			if(imageSamples[0][y][x] == 0 && imageSamples[1][y][x] == 0 && imageSamples[2][y][x] == 0){
				KDC++;
			}
			for(int z = 0; z < zSize; z++){
				if(imageSamples[z][y][x] <= 0.0031308){
					imageSamples[z][y][x] *= 12.92;
				}else{
					imageSamples[z][y][x] = (float)(1.055 * Math.pow(imageSamples[z][y][x],(1.0D/2.4D))-0.055);
				}
			}
		}}
		int diff = WDC - KDC;
		for(int y = 0; y < ySize; y++){
		for(int x = 0; x < xSize; x++){
		for(int z = 0; z < zSize; z++){
			imageSamples[z][y][x] = ((diff * imageSamples[z][y][x]) + KDC)*255;
		}}}		
	}
	
	/**
	 * Performs the ICC SRGB inverse colour transform
	 *
	 */
	public void ICCinverseTransformSRGB(){
		
		for(int y = 0; y < 5; y++){
		for(int x = 0; x < 5; x++){
			System.out.println("("+imageSamples[0][y][x]+","+imageSamples[1][y][x]+","+imageSamples[2][y][x]+")");
		}}
		
		
		for(int y = 0; y < ySize; y++){
		for(int x = 0; x < xSize; x++){
		for(int z = 0; z < zSize; z++){
			imageSamples[z][y][x] /= 255;
		}}}
	
		for(int y = 0; y < ySize; y++){
		for(int x = 0; x < xSize; x++){
			for(int z = 0; z < zSize; z++){
				if(imageSamples[z][y][x] <= 0.04045){
					imageSamples[z][y][x] /= 12.92;
				}else{
					imageSamples[z][y][x] = (float)Math.pow(((imageSamples[z][y][x] + 0.055)/1.055),2.4); 
				}
			}
		}}
		
		
		for(int y = 0; y < ySize; y++){
		for(int x = 0; x < xSize; x++){
			float c1 = imageSamples[0][y][x];
			float c2 = imageSamples[1][y][x];
			float c3 = imageSamples[2][y][x];
			for(int z = 0; z < 3; z++){
				imageSamples[z][y][x] = c1 * SRGB_inv[z][0] + c2 * SRGB_inv[z][1] + c3 * SRGB_inv[z][2];
			}
		}}
		
		for(int y = 0; y < ySize; y++){
			for(int x = 0; x < xSize; x++){
			for(int z = 0; z < zSize; z++){
				imageSamples[z][y][x] /= 255;
			}}}
		
		/*
		for(int y = 0; y < 5; y++){
		for(int x = 0; x < 5; x++){
			System.out.println("("+imageSamples[0][y][x]+","+imageSamples[1][y][x]+","+imageSamples[2][y][x]+")");
		}}
		*/
	}
	
	
}
