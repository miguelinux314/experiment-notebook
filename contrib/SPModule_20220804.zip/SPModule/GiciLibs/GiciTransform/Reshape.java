package GiciTransform;

/**
 * Library of matrix reshaping tools
 * @author ian
 *
 */

public class Reshape {	
	
	public static final int[] DIM_TRANSP_BIL_TO_BSQ = {1, 0, 2};
	public static final int[] DIM_TRANSP_BSQ_TO_BIL = DIM_TRANSP_BIL_TO_BSQ;
	
	public static final int[] DIM_TRANSP_BIL_TO_BIP = {0, 2, 1};
	public static final int[] DIM_TRANSP_BIP_TO_BIL = DIM_TRANSP_BIL_TO_BIP;
	
	public static final int[] DIM_TRANSP_BIP_TO_BSQ = {2, 0, 1};
	public static final int[] DIM_TRANSP_BSQ_TO_BIP = {1, 2, 0};
	
	public static final int[] DIM_TRANSP_SPATIAL = {0, 2, 1};
	
	interface GenericReshape {
		public void dimensionTranspose(final int[] permutation);
		void reshapeMatlabLike(final int resultSizeZ, final int resultSizeY, final int resultSizeX);
	};
	
	GenericReshape instance;
	
	public void dimensionTranspose(final int[] permutation) {
		instance.dimensionTranspose(permutation);
	}
	
	public void reshapeMatlabLike(final int resultSizeZ, final int resultSizeY, final int resultSizeX) {
		instance.reshapeMatlabLike(resultSizeZ, resultSizeY, resultSizeX);
	}
	
	class FloatReshape implements GenericReshape {
		float[][][] image;
		
		public FloatReshape(float[][][] image) {
			assert (image.length > 0 && image[0].length > 0 && image[0][0].length > 0);
			this.image = image;
		}
		
		public void dimensionTranspose(final int[] permutation) {
			final Permutation p = new Permutation(permutation);
			
			int[] resultSize = {image.length, image[0].length, image[0][0].length};
			resultSize = p.applyToVector(resultSize);
			
			final float[][][] result = new float[resultSize[0]][resultSize[1]][resultSize[2]];
			
			p.reversePermutation();
			
			for (int i = 0; i < resultSize[0]; i++) {
				for (int j = 0; j < resultSize[1]; j++) {
					for (int k = 0; k < resultSize[2]; k++) {
						int[] c = {i,j,k};
						c = p.applyToVector(c);
						
						result[i][j][k] = image[c[0]][c[1]][c[2]];
					}
				}
			}
			
			image = result;
		}
		
		// Matlab-like function for dimension collapsing.
		public void reshapeMatlabLike(final int resultSizeZ, final int resultSizeY, final int resultSizeX) {
			final int sizeZ = image.length;
			final int sizeY = image[0].length;
			final int sizeX = image[0][0].length;
			
			assert (sizeZ * sizeY * sizeX == resultSizeZ * resultSizeY * resultSizeX);
			
			assert (sizeZ > 0);
			assert (sizeY > 0);
			assert (sizeX > 0);
			assert (resultSizeZ > 0);
			assert (resultSizeY > 0);
			assert (resultSizeX > 0);
			
			final float[][][] result = new float[resultSizeZ][resultSizeY][resultSizeX];
			
			int i = 0, j = 0, k = 0;
			int l = 0, m = 0, n = 0;
			
			do {
				result[l][m][n] = image[i][j][k]; 
				
				// Increase counters
				
				k = (k + 1) % sizeX;
				
				if (k == 0) {			
					j = (j + 1) % sizeY;
				
					if (j == 0)
						i = (i + 1) % sizeZ;
				}

				n = (n + 1) % resultSizeX;
				
				if (n == 0) {			
					m = (m + 1) % resultSizeY;
				
					if (m == 0) {
						l = (l + 1) % resultSizeZ;
						
						if (l == 0) {
							assert (i == 0 && j == 0 && k == 0);
							break;
						}
					}
				}
			} while (true);
			
			image = result;
		}
		
		public float[][][] getImage() {
			return image;
		}
	};
	
	class IntegerReshape implements GenericReshape {
		int[][][] image;
		
		public IntegerReshape(int[][][] image) {
			assert (image.length > 0 && image[0].length > 0 && image[0][0].length > 0);
			this.image = image;
		}
		
		public void dimensionTranspose(final int[] permutation) {
			final Permutation p = new Permutation(permutation);
			
			int[] resultSize = {image.length, image[0].length, image[0][0].length};
			resultSize = p.applyToVector(resultSize);
			
			final int[][][] result = new int[resultSize[0]][resultSize[1]][resultSize[2]];
			
			p.reversePermutation();
			
			for (int i = 0; i < resultSize[0]; i++) {
				for (int j = 0; j < resultSize[1]; j++) {
					for (int k = 0; k < resultSize[2]; k++) {
						int[] c = {i,j,k};
						c = p.applyToVector(c);
						
						result[i][j][k] = image[c[0]][c[1]][c[2]];
					}
				}
			}
			
			image = result;
		}
		
		// Matlab-like function for dimension collapsing.
		public void reshapeMatlabLike(final int resultSizeZ, final int resultSizeY, final int resultSizeX) {
			final int sizeZ = image.length;
			final int sizeY = image[0].length;
			final int sizeX = image[0][0].length;
			
			assert (sizeZ * sizeY * sizeX == resultSizeZ * resultSizeY * resultSizeX);
			
			assert (sizeZ > 0);
			assert (sizeY > 0);
			assert (sizeX > 0);
			assert (resultSizeZ > 0);
			assert (resultSizeY > 0);
			assert (resultSizeX > 0);
			
			final int[][][] result = new int[resultSizeZ][resultSizeY][resultSizeX];
			
			int i = 0, j = 0, k = 0;
			int l = 0, m = 0, n = 0;
			
			do {
				result[l][m][n] = image[i][j][k]; 
				
				// Increase counters
				
				k = (k + 1) % sizeX;
				
				if (k == 0) {			
					j = (j + 1) % sizeY;
				
					if (j == 0)
						i = (i + 1) % sizeZ;
				}

				n = (n + 1) % resultSizeX;
				
				if (n == 0) {			
					m = (m + 1) % resultSizeY;
				
					if (m == 0) {
						l = (l + 1) % resultSizeZ;
						
						if (l == 0) {
							assert (i == 0 && j == 0 && k == 0);
							break;
						}
					}
				}
			} while (true);
			
			image = result;
		}
		
		public int[][][] getImage() {
			return image;
		}
	};
	
	public Reshape(float[][][] image) {
		instance = new FloatReshape(image);
	}
	
	public Reshape(int[][][] image) {
		instance = new IntegerReshape(image);
	}

	public float[][][] getImageFloat() {
		return ((FloatReshape)instance).getImage();
	}
	
	public int[][][] getImageInteger() {
		return ((IntegerReshape)instance).getImage();
	}
}
