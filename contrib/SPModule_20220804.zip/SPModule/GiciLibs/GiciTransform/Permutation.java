package GiciTransform;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import GiciMatrix.MatrixAlgebra;

/**
 * A permutation defined as: "2, 0, 1", means that if applied, the resulting vector will have first the 3rd (2) component, and so on. 
 */
public class Permutation {
	int [] permutation;

	/**
	 * Creates an identity permutation.
	 * @param size
	 */
	public Permutation(final int size) {
		permutation = new int[size];
		this.setToIdentity();
	}
	
	/**
	 * Initializes this object with an arbritrary permutation.
	 * @param p
	 */
	public Permutation(final int[] p) {
		permutation = new int[p.length];
		this.setPermutation(p);
	}
	
	/**
	 * Clones one permutation
	 * @param p
	 */
	public Permutation(final Permutation p) {
		this(p.getPermutation());
	}
	
	public void setToIdentity () {
		for (int i = 0; i < permutation.length; i++) {
			permutation[i] = i;
		}
	}
	
	public boolean isIdentity () {
		for (int i = 0; i < permutation.length; i++) {
			if (permutation[i] != i)
				return false;
		}
		
		return true;
	}
	
	/**
	 * Appends a permutation to the current one that does this.
	 * @param from
	 * @param size
	 * @param secondHalfIsLonger means that if size is odd then the intervals interleaved are [from, from + size / 2),
	 * and [from + size / 2, from + size) instead of [from, from + size / 2 + 1), [from + size / 2 + 1, from + size).
	 */
	public void permutationInterleaveRange(final int from, final int size, boolean secondHalfIsLonger) {
		int v[] = new int[size];
	
		int startA, startB;
		boolean nowA; 
		
		if (secondHalfIsLonger) { // First element is from second half
			nowA = false;
			startA = from;
			startB = from + size / 2;
		} else { // First element is from first half
			nowA = true;
			startA = from;
			startB = from + size / 2 + size % 2; 
		}

		for (int i = 0; i < v.length; i++) {
			if (nowA) {
				v[i] = permutation[startA++];
			} else {
				v[i] = permutation[startB++];
			}
			
			nowA = ! nowA;
		}
		
		System.arraycopy(v, 0, permutation, from, size);
		
		verify();
	}
	
	public void permutationBringListTo(final List<Integer> list, final int to) {
		
		final List<Integer> listOutsideDestination = new ArrayList<Integer>();
		final Set<Integer> setInsideDestination = new TreeSet<Integer>();
		int[] values = new int[list.size()];
		
		// Copy values that go to the destination
		for (int i = 0; i < list.size(); i++) {
			int pos = list.get(i);
			values[i] = permutation[pos];
		}
		
		// Check locations inside and outside destination
		for (int i = 0; i < list.size(); i++) {
			int pos = list.get(i);
			
			if (pos < to || pos >= to + list.size()) {
				listOutsideDestination.add(pos);
			} else {
				setInsideDestination.add(pos);
			}	
		}
		
		assert(listOutsideDestination.size() + setInsideDestination.size() == list.size());
		
		// Move values from destination that have to go outside
		int usedOutside = 0;
		
		for (int i = 0; i < list.size(); i++) {
			int pos = to + i;
			
			if (! setInsideDestination.contains(pos)) {
				// This value goes out
				int dest = listOutsideDestination.get(usedOutside++);
				permutation[dest] = permutation[pos];
			}
		}
		
		System.arraycopy(values, 0, permutation, to, list.size());
		
		verify();
	}
	
	/**
	 * Appends a permutation to the current one that does this.
	 * @param from
	 * @param to
	 * @param size
	 */
	public void permutationBringTo(final int from, final int to, final int size) {
		assert (permutation.length >= to + size);
		assert (permutation.length >= from + size);
		assert (from >= 0 && to >= 0 && size >= 0);
	
		if (to == from)
			return;
		
		// Calculate the zone to be vacated and its destination
		final int vacateFrom, vacateTo, vacateSize;

		if (to + size <= from || from + size <= to) {
			// No overlap (just swap the zones)
			vacateFrom = to;
			vacateTo = from;
			vacateSize = size;
		} else if (to < from) {
			vacateFrom = to;
			vacateTo = to + size;
			vacateSize = from - to;
		} else { //if (to > from) {
			vacateFrom = from + size;
			vacateTo = from;
			vacateSize = to - from;
		}
	
		assert(vacateFrom + vacateSize <= permutation.length);
		assert(vacateSize >= 0);
		
		int[] vacate = Arrays.copyOfRange(permutation, vacateFrom, vacateFrom + vacateSize);
		
		System.arraycopy(permutation, from, permutation, to, size);
		System.arraycopy(vacate, 0, permutation, vacateTo, vacateSize);
		
		verify();
	}
	
	public void appendPermutation(Permutation p) {
		Permutation t = new Permutation(p.getPermutation());
		permutation = t.applyToVector(permutation);
	}
	
	/**
	 * Check permutation for correctness
	 **/
	private void verify() {
		int[] permTest = new int[permutation.length];
		System.arraycopy(permutation, 0, permTest, 0, permutation.length);
		Arrays.sort(permTest);
		for (int i = 0; i < permTest.length; i++) {
			assert(permTest[i] == i);
		}	
	}
	
	public void setPermutation(final int[] permutation) {
		assert(this.permutation.length == permutation.length);
		System.arraycopy(permutation, 0, this.permutation, 0, permutation.length);
		
		verify();
	}
	
	public int[] getPermutation() {
		return permutation;
	}
	
	public float[][] getPermutationAsMatrix() {
		return applyToMatrixRows(MatrixAlgebra.identityC(permutation.length));
	}
	
	/**
	 * This permutation is modified in a way that applying it before and
	 * after modification would result in no permutation performed.
	 */
	public void reversePermutation() {
		int[] newPermutation = new int[permutation.length];
		
		for (int i = 0; i < permutation.length; i++) {
			newPermutation[permutation[i]] = i;
		}
		
		// Check for reversibility
		Permutation test = new Permutation(newPermutation); 
		test.appendPermutation(this);
		assert(test.isIdentity());
		
		permutation = newPermutation;
	}

	public void permuteInPlace(final float[][][] image, final int dimension){
		int zSize;
		int ySize;
		int xSize;
		
		final float newImage[][][];
			
		zSize = image.length;
		ySize = image[0].length;
		xSize = image[0][0].length;
		
		assert (dimension >= 0 && dimension <= 2);
		assert((dimension == 0 && image.length == permutation.length)
				|| (dimension == 1 && image[0].length == permutation.length)
				|| (dimension == 2 && image[0][0].length == permutation.length));		
		
		switch(dimension) {
		case 0:
			assert(permutation.length == zSize);
			
			newImage = new float[zSize][][];
			
			// Careful with trying to do it in place here
			// as overlaps may yield unexpected results
			for (int z = 0; z < zSize; z++) {
				newImage[z] = image[permutation[z]];
			}
			
			break;
		case 1:
			assert(permutation.length == ySize);
			
			newImage = new float[zSize][ySize][];
			
			for (int z = 0; z < zSize; z++) {
				for (int y = 0; y < ySize; y++) {
					newImage[z][y] = image[z][permutation[y]];
				}
			}
			
			break;
		case 2:
			assert(permutation.length == xSize);
			
			newImage = new float[zSize][ySize][xSize];
			
			for (int z = 0; z < zSize; z++) {
				for (int y = 0; y < ySize; y++) {
					for (int x = 0; y < ySize; y++) {
						newImage[z][y][x] = image[z][y][permutation[x]];
					}
				}
			}
			
			break;
			
			default:
				throw new IndexOutOfBoundsException();
		}
		
		//image = newImage;
		System.arraycopy(newImage, 0, image, 0, newImage.length);
	}
	
	public float[][] applyToMatrixRows(final float[][] a) {
		float[][][] b = {MatrixAlgebra.copy(a)};
		
		assert(permutation.length == a.length);
		
		Permutation p = new Permutation(permutation);
		p.permuteInPlace(b, 1);
		
		return b[0];
	}
	
	public void applyToMatrixRowsInPlace(final float[][] a) {
		assert(permutation.length == a.length);

		float[][] r = new float[a.length][];
		
		for (int z = 0; z < r.length; z++) {
			r[z] = a[permutation[z]];
		}
		
		System.arraycopy(r, 0, a, 0, a.length);
	}
	
	public void applyToMatrixRowsInPlace(final double[][] a) {
		assert(permutation.length == a.length);

		double[][] r = new double[a.length][];
		
		for (int z = 0; z < r.length; z++) {
			r[z] = a[permutation[z]];
		}
		
		System.arraycopy(r, 0, a, 0, a.length);
	}
	
	
	public float[][] applyToMatrixCols(final float[][] a) {
		float[][][] b = {MatrixAlgebra.copy(a)};
		
		assert(permutation.length == a[0].length);
		
		Permutation p = new Permutation(permutation);
		p.permuteInPlace(b, 2);
		
		return b[0];
	}
	
	/**
	 * Not in place!!!
	 * @param v
	 * @return
	 */
	public int[] applyToVector(final int[] v) {
		int[] r = new int[v.length];
		
		for (int z = 0; z < r.length; z++) {
			r[z] = v[permutation[z]];
		}
		
		return r;
	}
	
	/**
	 * Not in place!!!
	 * @param v
	 * @return
	 */
	public float[] applyToVector(final float[] v) {
		float[] r = new float[v.length];
		
		for (int z = 0; z < r.length; z++) {
			r[z] = v[permutation[z]];
		}
		
		return r;
	}
	
	/**
	 * Not in place!!!
	 * @param v
	 * @return
	 */
	public double[] applyToVector(final double[] v) {
		double[] r = new double[v.length];
		
		for (int z = 0; z < r.length; z++) {
			r[z] = v[permutation[z]];
		}
		
		return r;
	}
	
	public String toString () {
		String result = "";
		int last = 0;
		boolean skip = false;
		
		for (int i = 0; i < permutation.length; i++) {
			if (i == 0) {
				result += permutation[0];
			} else {
				if (last + 1 == permutation[i]) {
					// skip
					skip = true;
				} else {
					// show
					if (skip) {
						result += ".." + last;
						skip = false;
					}
					
					result += ", " + permutation[i];
				}
			}
			
			last = permutation[i];
		}
		
		// show
		if (skip) {
			result += ".." + last;
		}
		
		return result;
	}
	
	/* debug */
	public void scream() {
		System.out.print("Permutation " + this + " ");
		MatrixAlgebra.printVector(permutation);
		
		(new Exception()).printStackTrace(System.out);
	}
}
