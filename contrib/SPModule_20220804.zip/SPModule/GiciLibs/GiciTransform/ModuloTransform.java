package GiciTransform;

import java.util.ArrayList;
import java.util.List;

/**
 * Based on "Modulo Transforms - an Alternative to Lifting"
 * by Sridhar Srinivasan <sridhsri@microsoft.com>, Microsoft Digital Media Division.
 * 
 * @author ian
 *
 */

public class ModuloTransform {
	
	/**
	 * Pythagorean triples satisfying the conditions of Theorem 6
	 */
	private int[] getPythagoreanTriple (final int index) {
		assert (index > 0);
		
		final int s = (index * 2 + 1);
		final int c = (s * s - 1) / 2;
		
		final int r [] = {s, c, c + 1};
		
		return r;
	}
	
	private double getAngleFromTriple(final int[] triple) {
		final int s = triple[0];
		return Math.atan2(2 * s, s * s - 1);
	}
	
	private List<int[]> recursiveSequence(final int start, final int end, final int levels) {
		//assert(levels >= 0);
		
		if (levels < 1) {
			return new ArrayList<int[]>();
		} else {
			List<int[]> list = recursiveSequence(start, end, levels - 1);
			List<int[]> newList = new ArrayList<int[]>();
			for (int[] e: list) {
				for (int i = start; i < end; i++) {
					int[] e1 = new int[e.length + 1];
					System.arraycopy(e, 0, e1, 0, e.length);
					e1[e.length] = i;
					newList.add(e1);
				}
			}
			
			for (int i = start; i < end; i++) {
				int[] e1 = new int[1];
				e1[0] = i;
				newList.add(e1);
			}
			
			return newList;
		}
	}
	
	public int[] suggestTriplesSequence(double angle) {
		assert (angle > 0);
		//double tolerance
		// With a precision of 8 bits a 0.5 rounding error might be equivalent to asin(2 / 256) = 0.002 rad
		// Lets use 0.005 to have some margin
		
		// Conclusion: for each transform concatenation, we require a 0.002 rad increase of accuracy or else
		// What we got was better
		
		List<int[]> seq = recursiveSequence(1,13,5);
		
		int[] best = null;
		double bestAngle = Double.NEGATIVE_INFINITY;
		int bestLevels = 1;
		
		for (int[] s: seq) {
			double a = 0;
			
			for (int i = 0; i < s.length; i++) {
				a += getAngleFromTriple(getPythagoreanTriple(s[i]));
			}
			
			if (Math.abs(angle - a) + (0.005 * (s.length - bestLevels)) < Math.abs(angle - bestAngle)) {
				best = s;
				bestAngle = a;
				bestLevels = s.length;
			}
		}
		
		return best;
	}
	
	/**
	 * Definition 6.
	 */
	private int sdiv (final int a, final int n) {
		assert (n > 0);
		
		// Rounded towards -inf.
		int an2 = a + (n / 2);
		
		int r = an2 / n;
		
		if (an2 < 0 && an2 % n != 0) {
			r--;
		}
		
		return r;
	}
	
	/**
	 * Definition 7.
	 */
	
	private int smod (final int a, final int n) {
		return a - n * sdiv(a,n);
	}
	
	
	int index = 0;
	
	public void setTransform(int index) {
		assert (index > 0);
		this.index = index;
	}
	
	private int[] butterfly (final int[] a, final int[] triple) {
		final int s = triple[0], c = triple[1], c1 = triple[2];
		
		final int[] r = {a[0] * c, a[1] * c};
		
		r[1] += a[0] * s; 
		r[0] -= a[1] * s;
		
		r[0] = sdiv(r[0], c1);
		r[1] = sdiv(r[1], c1);
		
		return r;
	}
	
	/**
	 * in-place
	 * @param vectors
	 */
	public void applyForward (final int[][] vectors) {
		final int[] triple = getPythagoreanTriple(index);
		
		for (int i = 0; i < vectors.length; i++) {
			vectors[i] = butterfly(vectors[i], triple);
		}
	}
	
	/**
	 * in-place
	 * @param vectors
	 */
	public void applyInverse (final int[][] vectors) {
		final int[] triple = getPythagoreanTriple(index);
	
		triple[0] = -triple[0];
		
		for (int i = 0; i < vectors.length; i++) {
			vectors[i] = butterfly(vectors[i], triple);
		}
	}
}
