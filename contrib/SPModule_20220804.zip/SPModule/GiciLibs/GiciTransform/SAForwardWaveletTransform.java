/*
 * GICI Library -
 * Copyright (C) 2007  Group on Interactive Coding of Images (GICI)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Group on Interactive Coding of Images (GICI)
 * Department of Information and Communication Engineering
 * Autonomous University of Barcelona
 * 08193 - Bellaterra - Cerdanyola del Valles (Barcelona)
 * Spain
 *
 * http://gici.uab.es
 * gici-info@deic.uab.es
 */
package GiciTransform;

import GiciException.*;

public class SAForwardWaveletTransform {
	
	/**
	 * Image samples (index meaning [z][y][x]).
	 */
	float[][][] imageSamples = null;
	
	/**
	 * Mask for no-data values in the image (index meaning [z][y][x]).
	 * <p>
	 * Only byte values are allowed. False if the position in the image is no-data, true otherwise. This mask is also used to Roi definition.
	 */
	byte[][][] maskSamples = null;

	/**
	 * Number of image components.
	 * <p>
	 * Negative values are not allowed for this field.
	 */
	int zSize;
	
	/**
	 * Image height.
	 * <p>
	 * Negative values are not allowed for this field.
	 */
	int ySize;
	
	/**
	 * Image width.
	 * <p>
	 * Negative values are not allowed for this field.
	 */
	int xSize;

		
	/**
	 * Discrete wavelet transform to be applied for each component.
	 * <p>
	 * Valid values are:<br>
	 *   <ul>
	 *     <li> 0 - None
	 *     <li> 1 - Reversible 5/3 DWT (JPEG2000)
	 *     <li> 2 - Real Isorange (Irreversible) 9/7 DWT
	 *     <li> 3 - Real Isonorm (Irreversible) 9/7 DWT
	 *     <li> 4 - Integer (Reversible) 9/7M DWT (CCSDS-Recommended)
	 *     <li> 5 - Integer 5/3 DWT (Classic construction)
	 *     <li> 6 - Integer 9/7 DWT (Classic construction)
	 *   </ul>
	 */
	int[] WTTypes = null;

   /**
	 * DWT levels to apply for each component.
	 * <p>
	 * Negative values not allowed.
	 */
	int[] WTLevels = null;
	 
	/**
	 * To know the order of the transform in the spatial dimentions for each component
	 * <p>
	 * Valid values are:<br>
	 *   <ul>
	 *     <li> 0 - Horizontal - Verical
	 *     <li> 1 - Vertical - Horizontal
	 *     <li> 2 - Only horizontal
	 *   </ul>
	 * 
	 */
	int[] WTOrder;

	/**
	 * To know if parameters are set.
	 * <p>
	 * True indicates that they are set otherwise false.
	 */
	boolean parametersSet = false;
	


	/**
	 * Constructor that receives the original image samples and shape defined by a byte mask
	 * 
	 * @param imageSamples definition in {@link #imageSamples}
	 * @param maskSamples definition in {@link #maskSamples}
	 */
	public SAForwardWaveletTransform(float[][][] imageSamples, byte[][][] maskSamples) throws ErrorException{
		if(maskSamples == null){
			throw new ErrorException("You must specify a mask.");
		}
		if(imageSamples == null){
			throw new ErrorException("You must specify a input image.");
		}
		if(imageSamples[0].length != maskSamples[0].length || imageSamples[0][0].length != maskSamples[0][0].length){
			throw new ErrorException("The dimensions of the mask and the input image must be the same.");
		}
		
		//Image data copy
		this.imageSamples = imageSamples;
		this.maskSamples = maskSamples;
		
		//Size set
		zSize = imageSamples.length;
	}

	/**
	 * Set the parameters used to apply the discrete wavelet transform, the order is set and cannot be selected..
	 *
	 * @param WTTypes definition in {@link #WTTypes}
	 * @param WTLevels definition in {@link #WTLevels}
	 */
	public void setParameters(int[] WTTypes, int[] WTLevels){
		parametersSet = true;

		//Parameters copy
		this.WTTypes = WTTypes;
		this.WTLevels = WTLevels;
		this.WTOrder = new int[zSize];
		
		for (int z = 0 ; z < zSize; z++){ //if order is not specified vertical-horizontal is set.
			// default order is the one designed for the JPEG2000 standard
			WTOrder[z] = 1; 
		}
	}

	/**
	 * Set the parameters used to apply the discrete wavelet transform when the order of the spatial dimentions can be chosen.
	 *
	 * @param WTTypes definition in {@link #WTTypes}
	 * @param WTLevels definition in {@link #WTLevels}
	 * @param WTOrder definition in {@link #WTOrder} 
	 */
	public void setParameters(int[] WTTypes, int[] WTLevels, int[] WTOrder){
		parametersSet = true;

		//Parameters copy
		this.WTTypes = WTTypes;
		this.WTLevels = WTLevels;
		this.WTOrder = WTOrder;
	}
	

	
	/**
	 * Performs the discrete wavelete transform and returns the result image.
	 *
	 * @throws ErrorException when parameters are not set or wavelet type is unrecognized
	 */
	public void run() throws ErrorException{
		//If parameters are not set run cannot be executed
		if(!parametersSet){
			throw new ErrorException("Discrete wavelet transform cannot run if parameters are not set.");
		}

		//Ensures the validity of the mask
		/*int componentsToTransform = 0;
		for(int z = 0; z < zSize; z++){
			if(WTTypes[z] != 0){
				componentsToTransform++;
			}
		}
		if(componentsToTransform != maskSamples.length){
			throw new ErrorException("The mask has different components than the input image to transform.");
		}*/
		
		//Apply DWT for each component
		for(int z = 0; z < zSize; z++){
			ySize = imageSamples[z].length;
			xSize = imageSamples[z][0].length;
			//Apply DWT only if is specified
			if((WTTypes[z] != 0) && (WTLevels[z] > 0)){

				//Level size
				int xSubBandSize = xSize;
				int ySubBandSize = ySize;
				
				//Apply DWT for each level
				for(int currentLevel = 0; currentLevel < WTLevels[z]; currentLevel++){

					if( WTOrder[z] == 0 || WTOrder[z] ==2 ){
						//HOR_SD
						for(int y = 0; y < ySubBandSize; y++){
							float currentRow[] = new float[xSubBandSize];
							byte currentRowMask[] = new byte[xSubBandSize];
							for(int x = 0; x < xSubBandSize; x++){
								currentRow[x] = imageSamples[z][y][x];
								currentRowMask[x] = maskSamples[z][y][x];
							}
							//mask + coefficients filtering!
							//Subband row = new Subband(currentRow,currentRowMask);
							//row = filtering(row,z);
							currentRowMask = filtering(currentRow,currentRowMask,z);
							
							for(int x = 0; x < xSubBandSize; x++){
								imageSamples[z][y][x] = currentRow[x];
								maskSamples[z][y][x] = currentRowMask[x];
							}
						}
						
					}
					
					if( WTOrder[z] !=2 ){		
						//VER_SD
						for(int x = 0; x < xSubBandSize; x++){
							float currentColumn[] = new float[ySubBandSize];
							byte currentColumnMask[] = new byte[ySubBandSize];							
							for(int y = 0; y < ySubBandSize; y++){
								currentColumn[y] = imageSamples[z][y][x];
								currentColumnMask[y] = maskSamples[z][y][x];
							}
							//mask + coefficients filtering!
							//Subband column = new Subband(currentColumn,currentColumnMask);
							//column = filtering(column,z);
							currentColumnMask = filtering(currentColumn,currentColumnMask,z);							
							
							for(int y = 0; y < ySubBandSize; y++){
								imageSamples[z][y][x] = currentColumn[y];
								maskSamples[z][y][x] = currentColumnMask[y];
							}
						}

					}
					
					
					if( WTOrder[z] == 1 ){
						//HOR_SD
						for(int y = 0; y < ySubBandSize; y++){
							float currentRow[] = new float[xSubBandSize];
							byte currentRowMask[] = new byte[xSubBandSize];							
							for(int x = 0; x < xSubBandSize; x++){
								currentRow[x] = imageSamples[z][y][x];
								currentRowMask[x] = maskSamples[z][y][x];								
							}
							//mask + coefficients filtering!
							//Subband row = new Subband(currentRow,currentRowMask);
							//row = filtering(row,z);
							currentRowMask = filtering(currentRow,currentRowMask,z);
							
							//currentRow = filtering(currentRow, z);
							
							for(int x = 0; x < xSubBandSize; x++){
								imageSamples[z][y][x] = currentRow[x];
								maskSamples[z][y][x] = currentRowMask[x];
							}
						}
						
					}

					//Size setting for the next level
					xSubBandSize = xSubBandSize / 2 + xSubBandSize % 2;
					if ( WTOrder[z] !=2 ) {
						ySubBandSize = ySubBandSize / 2 + ySubBandSize % 2;
					}
				}
			}
		}

	}

	
	/**
	 * Given a initial position, selects the first ocurrence that is a true n an boolean vector.
	 * 
	 * @param srcMask the boolean vector to be examined
	 * @param index the initial position where we begin the search.
	 * @return index the position of the first ocurrence of true. Or length+1 if not any.
	 */
	private int jumpFalse(float[] src, byte[] srcMask, int index)
	{
		//jump false coefficients from mask
		while (( index < srcMask.length) && (srcMask[index] == 0) ){
			src[index] = 0f;
			index++;
		}
		return index;
	}	
	
	/**
	 * Given a initial position, selects the first ocurrence that is a false in an boolean vector.
	 * 
	 * @param srcMask the boolean vector to be examined
	 * @param index the initial position where we begin the search.
	 * @return index the position of the first ocurrence of false. Or length+1 if not any.
	 */
	private int jumpTrue(byte[] srcMask, int index)
	{
		//jump true coefficients from mask
		while  ( ( index < srcMask.length) && (srcMask[index] != 0))	{
			index++;
		}
		return index;
	}	
	
	/**
	 * This function selects the way to apply the filter
	 * selected depending on the size of the source.
	 * Other consideration is Phase: even or odd.
	 * The function divides the src in different segments
	 * according to the given mask.
	 * The float array source is modified and mask array returned  
	 *
	 * @param src a float array of the image samples
	 * @param srcMask a boolean array of the mask samples
	 * @param z the component determines the filter to apply
	 * @return a boolean array that contains the interleave mask
	 *
	 * @throws ErrorException when wavelet type is unrecognized
	 */	
	private byte[] filtering(float[] src, byte[] srcMask, int z) throws ErrorException{
	
		float[] segI;	
		byte [] temp = new byte[srcMask.length];
		int x=0;
		int y;

		//check length 1
		if(src.length!=1) {		
		
			//check region to filter
			while ( x < srcMask.length){		
				x = jumpFalse(src, srcMask, x);
				//select odd/even start				
				y=x; //select the start of the new segment			
				if (y<srcMask.length)
				{
					if (x%2 == 0)//even phase
					{
						y = jumpTrue(srcMask,y);
						segI = new float[y-x];
						segI = selectSegment(x,y,src);
						switch((segI.length)%2)
						{
						case 0: //even length signal	
							//the first even/odd pair refers to signal length
							//the second refers to phase start: even - low, odd - high
							evenEvenFiltering(segI,z);
							replaceSegment(segI,x,src);
							break;
						case 1: //odd length signal						
							oddEvenFiltering(segI,z);	
							replaceSegment(segI,x,src);
							break;				
						}				
					}//end even phase
					else //odd phase
					{
						y = jumpTrue(srcMask,y);
						segI = new float[y-x];
						segI = selectSegment(x,y,src);
						switch((segI.length)%2)
						{
						case 0: //even length signal				
							evenOddFiltering(segI,z);
							replaceSegment(segI,x,src);
							break;
						case 1: //odd length							
							oddOddFiltering(segI,z);
							replaceSegment(segI,x,src);
							break; //odd length signal				
						}	
					}//end odd phase
					x=y;//select new start of FALSE position	
				}
			}
		
		//interleave process
		switch((src.length)%2)
		{
		case 0: //even interleaving						
			replaceSegment(evenInterleavingSrc(src),0,src);
			temp = evenInterleavingMask(srcMask);			
			break;
		case 1:	//odd interleaving			
			replaceSegment(oddInterleavingSrc(src),0,src);			
			temp = oddInterleavingMask(srcMask);
			break; //odd length signal				
		}
		return temp;
	}//end not length 1 src
	return srcMask;
}
	

	/**
	 * Selects a portion of a given float array
	 * 
	 * @param ini start from the segment
	 * @param end end from the segment
	 * @param src source where we extract the segment
	 * @return the segment of the source defined by ini/end
	 * @throws ErrorException
	 */
	private float[] selectSegment( int ini, int end, float[] src) throws ErrorException
	{			
		float[] seg = new float[end-ini];
		int j=0;
		for (int i=ini;i<end;i++)
		{			
			seg[j] = src[i];
			j++;
		}
		return (seg);
	}
	
	//replace segment of a subband in its place
	/**
	 * Puts back in its place a segment that have been filtered
	 * 
	 * @param seg float array that needs to be placed back in the source
	 * @param ini starting index in the source that corresponds with the start of the segment
	 * @param src source array where the segment must be placed
	 * 
	 * @throws ErrorException
	 */
	private void replaceSegment(float[] seg, int ini, float[] src) throws ErrorException
	{
		int j=0;	
		while (j<seg.length)		
		{			
			src[ini] = seg[j];
			j++;
			ini++;
		}
	}


	//odd length signal interleaving
	private float[] oddInterleavingSrc(float[] src) throws ErrorException
	{
		
		int subbandSize = src.length;
		//DE_INTERLEAVE source odd length
		float dst[]=new float[subbandSize];		
		for(int k=0;k<(subbandSize/2);k++){
			dst[k]=src[2*k];
			dst[k+(subbandSize/2)+1]=src[2*k+1];
		}
		dst[subbandSize/2]=src[subbandSize-1];			
		return (dst);
	}
	private byte[] oddInterleavingMask(byte[] srcMask) throws ErrorException
	{
		
		int subbandSize = srcMask.length;
		//DE_INTERLEAVE mask odd length		
		byte m[] = new byte[subbandSize];				
		for(int k=0;k<(subbandSize/2);k++){			
			m[k]=srcMask[2*k];
			m[k+(subbandSize/2)+1]=srcMask[2*k+1];			
		}	
		m[subbandSize/2]=srcMask[subbandSize-1];	
		return (m);
	}
	//even length signal interleaving
	private float[] evenInterleavingSrc(float[] src) throws ErrorException	
	{		
		int subbandSize = src.length;
		
		//DE_INTERLEAVE even length
		int half = subbandSize / 2;
		float dst[] = new float[subbandSize];		
		for(int k = 0; k < half; k++){
			dst[k] = src[2*k];
			dst[k+half] = src[2*k+1];
		}
		return (dst);
	}
//	even length signal interleaving
	private byte[] evenInterleavingMask(byte[] srcMask) throws ErrorException	
	{		
		int subbandSize = srcMask.length;
		
		//DE_INTERLEAVE even length
		int half = subbandSize / 2;	
		byte m[] = new byte[subbandSize];		
		for(int k = 0; k < half; k++){			
			m[k] = srcMask[2*k];
			m[k+half] = srcMask[2*k+1];	
		}
		return (m);
	}
	
	/**
	 * This function applies the DWT filter to a source with even length.
	 *
	 * @param src a float array of the image samples
	 * @param z the component determines the filter to apply
	 *
	 * @return a float array that contains the tranformed sources
	 *
	 * @throws ErrorException when wavelet type is unrecognized or size is not proper
	 */
	private float[] evenOddFiltering(float[] src, int z) throws ErrorException{
		//Subband size
		int subbandSize = src.length;
		
		//check length 1
		if(subbandSize==1) {
			return(src);
		}
		
		//Appling the filter
		if( WTTypes[z] == 1 ){
			// Integer 5/3 DWT JPEG200
			// H L H L H L	
			//H
//			 (H)1st coef. extension.
			src[0] = src[0] - (float) (Math.floor(((src[1]+src[1])/2)));
			for (int k = 2; k < subbandSize-1; k += 2){			
				src[k] = src[k] - (float) (Math.floor(((src[k-1]+src[k+1])/2)));
			}
//			 (L)last coef. extension.	
			src[subbandSize-1] = src[subbandSize-1] + (float) (Math.floor((src[subbandSize-2]+src[subbandSize-2]+2)/4));
			//L
			for(int k = 1; k < subbandSize-1; k += 2){
				src[k] = src[k] + (float) (Math.floor(((src[k-1]+src[k+1]+2)/4)));
			}	
		} else if ( WTTypes[z] == 2 || WTTypes[z] == 3 )  {
			// 9/7 DWT
			final float alfa_97 = -1.586134342059924F;
			final float beta_97 = -0.052980118572961F;
			final float gamma_97 = 0.882911075530934F;
			final float delta_97 = 0.443506852043971F;
			final float nh_97, nl_97;
			if ( WTTypes[z] == 2 ){// Isorange
				nh_97 = 1.230174104914001F; //with this weights the range is mantained
				nl_97 = 1F / nh_97;
			} else {// Isonorm
				nl_97 = 1.14960430535816F; //with this weights the norm is nearly mantained
				nh_97 = 1F / nl_97;
			}
			// H L H L H L	
			//H
			src[0] = src[0] + alfa_97 * (src[1]+src[1]);
			for(int k = 2; k < subbandSize-1; k += 2){
				src[k] = src[k] + alfa_97 * (src[k-1]+src[k+1]);
			}			

			//L			
			for(int k = 1; k < subbandSize-1; k += 2){			
				src[k] = src[k] + beta_97 * (src[k-1]+src[k+1]);
			}
			src[subbandSize-1] = src[subbandSize-1] + beta_97 * (src[subbandSize-2]+src[subbandSize-2]);

			//H
			src[0] = src[0] + gamma_97 * (src[1]+src[1]);
			for(int k = 2; k < subbandSize-1; k += 2){
				src[k] = src[k] + gamma_97 * (src[k-1]+src[k+1]);
			}			

			//L
			src[subbandSize-1] = src[subbandSize-1] + delta_97 * (src[subbandSize-2]+src[subbandSize-2]);			
			for(int k = 1; k < subbandSize-1; k += 2){
				src[k] = src[k] + delta_97 * (src[k-1]+src[k+1]);
			}

			//odd start
			for(int k = 0; k < subbandSize; k+= 2){
				src[k] = src[k] * nh_97;
				src[k+1] = src[k+1] * nl_97;
			}
		} else if( WTTypes[z] == 4 ){
			// Integer 9/7 M (CCSDS Recommended )
			if ( subbandSize >=6 ){
				final float alfa1 = (9F/16F);
				final float alfa2 = (1F/16F);
				final float beta = (1F/4F);
						
				src[1]=src[1] - (float) (Math.floor( alfa1*(src[0]+src[2])-alfa2*(src[2]+src[4])+0.5 ) );
				for (int k=3; k<subbandSize-3; k+=2){
					src[k]=src[k] - (float) (Math.floor( alfa1*(src[k-1]+src[k+1])-alfa2*(src[k-3]+src[k+3])+0.5 ) );
				}
				src[subbandSize-3]=src[subbandSize-3] - (float) (Math.floor( alfa1*(src[subbandSize-4]+src[subbandSize-2]) 
																								- alfa2*(src[subbandSize-6]+src[subbandSize-2]) + 0.5 ) );
				src[subbandSize-1]=src[subbandSize-1] - (float) (Math.floor( alfa1*(src[subbandSize-2]+src[subbandSize-2]) 
																								- alfa2*(src[subbandSize-4]+src[subbandSize-4]) + 0.5 ) );
				
				src[0]=src[0] -  (float) ( Math.floor(-beta*(src[1]+src[1])+0.5) );
				for (int k=2; k<subbandSize; k+=2){
					src[k]=src[k] - (float) (Math.floor(-beta*(src[k-1]+src[k+1])+0.5) );
				}
			} else {
				throw new ErrorException("Size should be greater or equal than 6 in order to perform 9/7M");
			}
		} else if ( WTTypes[z] == 5 || WTTypes[z] == 6 ){
			// Classical Integer to Integer DWT
			final float alfa, beta, gamma, delta;
			if( WTTypes[z] == 6 ){ // 9/7 integer version has been chosen
				alfa=-1.58615986717275F;
				beta=-0.05297864003258F;
				gamma=0.88293362717904F;
				delta=0.44350482244527F;
			} else {//it is supposed the 5/3 Le Gall filter has been chosen
				alfa=-0.5F;
				beta=0.25F;
				gamma=0.F;
				delta=0.F;
			}
			//H
			src[0]=src[0]+  (float) Math.floor(alfa*(src[1]+src[1])+0.5);
			for (int k=2; k<subbandSize-1; k+=2){
				src[k]=src[k]+ (float) Math.floor(alfa*(src[k-1]+src[k+1])+0.5);
			}
			//L
			for (int k=1; k<subbandSize-2; k+=2){
				src[k]=src[k]+ (float) Math.floor(beta*(src[k-1]+src[k+1])+0.5);
			}
			src[subbandSize-1]=src[subbandSize-1]+ (float) Math.floor(beta*(src[subbandSize-2]+src[subbandSize-2])+0.5);
			
			if( WTTypes[z] == 6 ){
				//H
				src[0]=src[0]+ (float) Math.floor(gamma*(src[1]+src[1])+0.5);
				for (int k=2; k<subbandSize-1; k+=2){
					src[k]=src[k]+ (float) Math.floor(gamma*(src[k-1]+src[k+1])+0.5);
				}				
				//L
				src[subbandSize-1]=src[subbandSize-1]+ (float) Math.floor(delta*(src[subbandSize-2]+src[subbandSize-2])+0.5);
				for (int k=1; k<subbandSize-2; k+=2){
					src[k]=src[k]+ (float) Math.floor(delta*(src[k-1]+src[k+1])+0.5);
				}
			}
		} else {
			throw new ErrorException("Unrecognized wavelet transform type.");
		}
		return (src);
	}

	/**
	 * This function applies the DWT filter to a source with odd length.
	 *
	 * @param src a float array of the image samples
	 * @param z the component determines the filter to apply
	 *
	 * @return a float array that contains the tranformed sources
	 *
	 * @throws ErrorException when wavelet type is unrecognized or size is not proper
	 */
	private float[] oddOddFiltering(float[] src, int z) throws ErrorException{

		int subbandSize = src.length;
		//check length 1
		if(subbandSize==1) {
			return(src);
		}

		//Appling the filter
		if( WTTypes[z] == 1 ){
			// Integer 5/3 DWT JPEG2000
			// H L H L H L H
			// H filterting
			for (int k = 2; k < subbandSize-1; k += 2){			
				src[k] = src[k] - (float) (Math.floor(((src[k-1]+src[k+1])/2)));
			}
//			 (H)1st coef. extension.
			src[0] = src[0] - (float) (Math.floor(((src[1]+src[1])/2)));
//			 (H)last coef. extension.			
			src[subbandSize-1] = src[subbandSize-1] - (float) (Math.floor(((src[subbandSize-2]+src[subbandSize-2])/2)));
			//L filtering
			for(int k = 1; k < subbandSize-1; k += 2){			
				src[k] = src[k] + (float) (Math.floor(((src[k-1]+src[k+1]+2)/4)));
			}	
	
		} else if ( WTTypes[z] == 2 || WTTypes[z] == 3 )  {
			// 9/7 DWT
			final float alfa_97 = -1.586134342059924F;
			final float beta_97 = -0.052980118572961F;
			final float gamma_97 = 0.882911075530934F;
			final float delta_97 = 0.443506852043971F;
			final float nh_97, nl_97;
			if ( WTTypes[z] == 2 ){// Isorange
				nh_97 = 1.230174104914001F; //with this weights the range is mantained
				nl_97 = 1F / nh_97;
			} else {// Isonorm
				nh_97 = 1.14960430535816F; //with this weights the norm is nearly mantained
				nl_97 = 1F / nh_97;
			}
			//H(0) L(1) H(2) L(3) H(4) L(5) H(6)
			//H
			for(int k = 2; k < subbandSize-1; k += 2){
				src[k] = src[k] + alfa_97 * (src[k-1]+src[k+1]);
			}
			src[subbandSize-1] = src[subbandSize-1] + alfa_97 * (src[subbandSize-2]+src[subbandSize-2]);
			src[0] = src[0] + alfa_97 * (src[1]+src[1]);

			//L
			for(int k = 1; k < subbandSize-1 ; k += 2){
				src[k] = src[k] + beta_97 * (src[k-1]+src[k+1]);
			}			

			//H
			for(int k = 2; k < subbandSize-1; k += 2){
				src[k] = src[k] + gamma_97 * (src[k-1]+src[k+1]);
			}
			src[subbandSize-1] = src[subbandSize-1] + gamma_97 * (src[subbandSize-2]+src[subbandSize-2]);
			src[0] = src[0] + gamma_97 * (src[1]+src[1]);

			//L
			for(int k = 1; k < subbandSize-1; k += 2){
				src[k] = src[k] + delta_97 * (src[k-1]+src[k+1]);
			}			

			for(int k = 0; k < subbandSize-1; k+= 2){
				src[k] = src[k] * nh_97;
				src[k+1] = src[k+1] * nl_97;
			}
			src[subbandSize-1]=src[subbandSize-1]*nh_97;
		} else if( WTTypes[z] == 4 ){
			// Integer 9/7 M (CCSDS Recommended )
			throw new ErrorException("Integer 9/7M CCSDS Recommended is not implemented for odd signals.!!!");
		} else if ( WTTypes[z] == 5 || WTTypes[z] == 6 ){
			// Classical Integer to Integer DWT
			final float alfa, beta, gamma, delta;
			if( WTTypes[z] == 6 ){ // 9/7 integer version has been chosen
				alfa=-1.58615986717275F;
				beta=-0.05297864003258F;
				gamma=0.88293362717904F;
				delta=0.44350482244527F;
			} else {//it is supposed the 5/3 Le Gall filter has been chosen
				alfa=-0.5F;
				beta=0.25F;
				gamma=0.F;
				delta=0.F;
			}
			//H
			src[0]=src[0]+  (float) Math.floor(alfa*(src[1]+src[1])+0.5);
			for (int k=2; k<subbandSize-1; k+=2){
				src[k]=src[k]+ (float) Math.floor(alfa*(src[k-1]+src[k+1])+0.5);
			}
			src[subbandSize-1]=src[subbandSize-1]+ (float) Math.floor(alfa*(src[subbandSize-2]+src[subbandSize-2])+0.5);
			//L
			for (int k=1; k<subbandSize-1; k+=2){
				src[k]=src[k]+ (float) Math.floor(beta*(src[k-1]+src[k+1])+0.5);
			}			
			
			if( WTTypes[z] == 6 ){
				//H
				src[0]=src[0]+ (float) Math.floor(gamma*(src[1]+src[1])+0.5);
				for (int k=2; k<subbandSize-1; k+=2){
					src[k]=src[k]+ (float) Math.floor(gamma*(src[k-1]+src[k+1])+0.5);
				}
				src[subbandSize-1]=src[subbandSize-1]+ (float) Math.floor(gamma*(src[subbandSize-2]+src[subbandSize-2])+0.5);
				//L			
				for (int k=1; k<subbandSize-1; k+=2){
					src[k]=src[k]+ (float) Math.floor(delta*(src[k-1]+src[k+1])+0.5);
				}
			}
		} else {
			throw new ErrorException("Unrecognized wavelet transform type.");
		}
		return(src);
	}
	
	private float[] evenEvenFiltering(float[] src, int z) throws ErrorException{
		//Subband size
		int subbandSize = src.length;
		//check length 1
		if(subbandSize==1) {
			return(src);
		}
		
		//Appling the filter
		if( WTTypes[z] == 1 ){
			// Integer 5/3 DWT JPEG200
			for(int k = 1; k < subbandSize-1; k += 2){
				src[k] = src[k] - (float) (Math.floor(((src[k-1]+src[k+1])/2)));
			}
			// L H L H L H
//			 (H)last coef. extension.	
			src[subbandSize-1] = src[subbandSize-1] - (float) (Math.floor((src[subbandSize-2]+src[subbandSize-2])/2));
//			 (L)1st coef. extension.				
			src[0] = src[0] + (float) (Math.floor(((src[1]+src[1]+2)/4)));
			for (int k = 2; k < subbandSize-1; k += 2){
				src[k] = src[k] + (float) (Math.floor(((src[k-1]+src[k+1]+2)/4)));
			}	
		} else if ( WTTypes[z] == 2 || WTTypes[z] == 3 )  {
			// 9/7 DWT
			final float alfa_97 = -1.586134342059924F;
			final float beta_97 = -0.052980118572961F;
			final float gamma_97 = 0.882911075530934F;
			final float delta_97 = 0.443506852043971F;
			final float nh_97, nl_97;
			if ( WTTypes[z] == 2 ){// Isorange
				nh_97 = 1.230174104914001F; //with this weights the range is mantained
				nl_97 = 1F / nh_97;
			} else {// Isonorm
				nl_97 = 1.14960430535816F; //with this weights the norm is nearly mantained
				nh_97 = 1F / nl_97;
			}
			// L H L H L H
			//H
			for(int k = 1; k < subbandSize-2; k += 2){
				src[k] = src[k] + alfa_97 * (src[k-1]+src[k+1]);
			}
			src[subbandSize-1] = src[subbandSize-1] + alfa_97 * (src[subbandSize-2]+src[subbandSize-2]);

			src[0] = src[0] + beta_97 * (src[1]+src[1]);
			for(int k = 2; k < subbandSize; k += 2){
				src[k] = src[k] + beta_97 * (src[k-1]+src[k+1]);
			}

			for(int k = 1; k < subbandSize-2; k += 2){
				src[k] = src[k] + gamma_97 * (src[k-1]+src[k+1]);
			}
			src[subbandSize-1] = src[subbandSize-1] + gamma_97 * (src[subbandSize-2]+src[subbandSize-2]);

			src[0] = src[0] + delta_97 * (src[1]+src[1]);
			for(int k = 2; k < subbandSize; k += 2){
				src[k] = src[k] + delta_97 * (src[k-1]+src[k+1]);
			}

			for(int k = 0; k < subbandSize; k+= 2){
				src[k] = src[k] * nl_97;
				src[k+1] = src[k+1] * nh_97;
			}
		} else if( WTTypes[z] == 4 ){
			// Integer 9/7 M (CCSDS Recommended )
			if ( subbandSize >=6 ){
				final float alfa1 = (9F/16F);
				final float alfa2 = (1F/16F);
				final float beta = (1F/4F);
						
				src[1]=src[1] - (float) (Math.floor( alfa1*(src[0]+src[2])-alfa2*(src[2]+src[4])+0.5 ) );
				for (int k=3; k<subbandSize-3; k+=2){
					src[k]=src[k] - (float) (Math.floor( alfa1*(src[k-1]+src[k+1])-alfa2*(src[k-3]+src[k+3])+0.5 ) );
				}
				src[subbandSize-3]=src[subbandSize-3] - (float) (Math.floor( alfa1*(src[subbandSize-4]+src[subbandSize-2]) 
																								- alfa2*(src[subbandSize-6]+src[subbandSize-2]) + 0.5 ) );
				src[subbandSize-1]=src[subbandSize-1] - (float) (Math.floor( alfa1*(src[subbandSize-2]+src[subbandSize-2]) 
																								- alfa2*(src[subbandSize-4]+src[subbandSize-4]) + 0.5 ) );
				
				src[0]=src[0] -  (float) ( Math.floor(-beta*(src[1]+src[1])+0.5) );
				for (int k=2; k<subbandSize; k+=2){
					src[k]=src[k] - (float) (Math.floor(-beta*(src[k-1]+src[k+1])+0.5) );
				}
			} else {
				throw new ErrorException("Size should be greater or equal than 6 in order to perform 9/7M");
			}
		} else if ( WTTypes[z] == 5 || WTTypes[z] == 6 ){
			// Classical Integer to Integer DWT
			final float alfa, beta, gamma, delta;
			if( WTTypes[z] == 6 ){ // 9/7 integer version has been chosen
				alfa=-1.58615986717275F;
				beta=-0.05297864003258F;
				gamma=0.88293362717904F;
				delta=0.44350482244527F;
			} else {//it is supposed the 5/3 Le Gall filter has been chosen
				alfa=-0.5F;
				beta=0.25F;
				gamma=0.F;
				delta=0.F;
			}

			src[subbandSize-1]=src[subbandSize-1]+ (float) Math.floor(alfa*(src[subbandSize-2]+src[subbandSize-2])+0.5);
			for (int k=1; k<subbandSize-1; k+=2){
				src[k]=src[k]+ (float) Math.floor(alfa*(src[k-1]+src[k+1])+0.5);
			}			

			src[0]=src[0]+  (float) Math.floor(beta*(src[1]+src[1])+0.5);
			for (int k=2; k<subbandSize; k+=2){
				src[k]=src[k]+ (float) Math.floor(beta*(src[k-1]+src[k+1])+0.5);
			}
			
			if( WTTypes[z] == 6 ){
				src[subbandSize-1]=src[subbandSize-1]+ (float) Math.floor(gamma*(src[subbandSize-2]+src[subbandSize-2])+0.5);
				for (int k=1; k<subbandSize-1; k+=2){
					src[k]=src[k]+ (float) Math.floor(gamma*(src[k-1]+src[k+1])+0.5);
				}				

				src[0]=src[0]+ (float) Math.floor(delta*(src[1]+src[1])+0.5);
				for (int k=2; k<subbandSize; k+=2){
					src[k]=src[k]+ (float) Math.floor(delta*(src[k-1]+src[k+1])+0.5);
				}
			}
		} else {
			throw new ErrorException("Unrecognized wavelet transform type.");
		}

		return(src);
	}

	/**
	 * This function applies the DWT filter to a source with odd length.
	 *
	 * @param src a float array of the image samples
	 * @param z the component determines the filter to apply
	 *
	 * @return a float array that contains the tranformed sources
	 *
	 * @throws ErrorException when wavelet type is unrecognized or size is not proper
	 */
	private float[] oddEvenFiltering(float[] src, int z) throws ErrorException{
		
		int subbandSize = src.length;
		//check length 1
		if(subbandSize==1) {
			return(src);
		}

		//Appling the filter
		if( WTTypes[z] == 1 ){
			// Integer 5/3 DWT JPEG2000
			// L H L H L H L
			for(int k = 1; k < subbandSize-1; k += 2){
				src[k] = src[k] - (float) (Math.floor(((src[k-1]+src[k+1])/2)));
			}
//			 (L)1st coef. extension.
			src[0] = src[0] + (float) (Math.floor(((src[1]+src[1]+2)/4)));
//			 (L)last coef. extension.			
			src[subbandSize-1] = src[subbandSize-1] + (float) (Math.floor(((src[subbandSize-2]+src[subbandSize-2]+2)/4)));
			for (int k = 2; k < subbandSize-1; k += 2){
				src[k] = src[k] + (float) (Math.floor(((src[k-1]+src[k+1]+2)/4)));
			}			
	
		} else if ( WTTypes[z] == 2 || WTTypes[z] == 3 )  {
			// 9/7 DWT
			final float alfa_97 = -1.586134342059924F;
			final float beta_97 = -0.052980118572961F;
			final float gamma_97 = 0.882911075530934F;
			final float delta_97 = 0.443506852043971F;
			final float nh_97, nl_97;
			if ( WTTypes[z] == 2 ){// Isorange
				nh_97 = 1.230174104914001F; //with this weights the range is mantained
				nl_97 = 1F / nh_97;
			} else {// Isonorm
				nh_97 = 1.14960430535816F; //with this weights the norm is nearly mantained
				nl_97 = 1F / nh_97;
			}
			// L H L H L H L
			for(int k = 1; k < subbandSize-1; k += 2){
				src[k] = src[k] + alfa_97 * (src[k-1]+src[k+1]);
			}			

			src[0] = src[0] + beta_97 * (src[1]+src[1]);
			for(int k = 2; k < subbandSize-1 ; k += 2){
				src[k] = src[k] + beta_97 * (src[k-1]+src[k+1]);
			}
			src[subbandSize-1] = src[subbandSize-1] + beta_97 * (src[subbandSize-2]+src[subbandSize-2]);

			for(int k = 1; k < subbandSize-1; k += 2){
				src[k] = src[k] + gamma_97 * (src[k-1]+src[k+1]);
			}			

			src[0] = src[0] + delta_97 * (src[1]+src[1]);
			for(int k = 2; k < subbandSize-1; k += 2){
				src[k] = src[k] + delta_97 * (src[k-1]+src[k+1]);
			}
			src[subbandSize-1] = src[subbandSize-1] + delta_97 * (src[subbandSize-2]+src[subbandSize-2]);

			for(int k = 0; k < subbandSize-1; k+= 2){
				src[k] = src[k] * nl_97;
				src[k+1] = src[k+1] * nh_97;
			}
			src[subbandSize-1]=src[subbandSize-1]*nl_97;
		} else if( WTTypes[z] == 4 ){
			// Integer 9/7 M (CCSDS Recommended )
			throw new ErrorException("Integer 9/7M CCSDS Recommended is not implemented for odd signals.!!!");
		} else if ( WTTypes[z] == 5 || WTTypes[z] == 6 ){
			// Classical Integer to Integer DWT
			final float alfa, beta, gamma, delta;
			if( WTTypes[z] == 6 ){ // 9/7 integer version has been chosen
				alfa=-1.58615986717275F;
				beta=-0.05297864003258F;
				gamma=0.88293362717904F;
				delta=0.44350482244527F;
			} else {//it is supposed the 5/3 Le Gall filter has been chosen
				alfa=-0.5F;
				beta=0.25F;
				gamma=0.F;
				delta=0.F;
			}
			//H
			for (int k=1; k<subbandSize-1; k+=2){
				src[k]=src[k]+ (float) Math.floor(alfa*(src[k-1]+src[k+1])+0.5);
			}
			//L
			src[subbandSize-1]=src[subbandSize-1]+ (float) Math.floor(beta*(src[subbandSize-2]+src[subbandSize-2])+0.5);
			src[0]=src[0]+  (float) Math.floor(beta*(src[1]+src[1])+0.5);
			for (int k=2; k<subbandSize-1; k+=2){
				src[k]=src[k]+ (float) Math.floor(beta*(src[k-1]+src[k+1])+0.5);
			}
			
			if( WTTypes[z] == 6 ){
				//H				
				for (int k=1; k<subbandSize-1; k+=2){
					src[k]=src[k]+ (float) Math.floor(gamma*(src[k-1]+src[k+1])+0.5);
				}
				//L
				src[subbandSize-1]=src[subbandSize-1]+ (float) Math.floor(delta*(src[subbandSize-2]+src[subbandSize-2])+0.5);
				src[0]=src[0]+ (float) Math.floor(delta*(src[1]+src[1])+0.5);
				for (int k=2; k<subbandSize-1; k+=2){
					src[k]=src[k]+ (float) Math.floor(delta*(src[k-1]+src[k+1])+0.5);
				}
			}
		} else {
			throw new ErrorException("Unrecognized wavelet transform type.");
		}

		return(src);
	}
	
}
