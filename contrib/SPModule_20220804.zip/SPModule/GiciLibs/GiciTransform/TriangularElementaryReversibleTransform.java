package GiciTransform;

import java.util.concurrent.Callable;
import GiciParallel.ParallelMap;

public strictfp class TriangularElementaryReversibleTransform implements Callable<float[][][]> {

	private final int[] memberPermutation;
	private final float[][] memberTermL;
	private final float[][] memberTermU;
	private final float[][] memberTermS;
	
	private float[][][] image;
	private boolean forward;
	
	public TriangularElementaryReversibleTransform(final int[] permutation,
			final float[][] termL, final float[][] termU, final float[][] termS,
			final float[][][] inputImage, final boolean isForward) {

		this.memberPermutation = permutation; 
		this.memberTermL = termL;
		this.memberTermU = termU;
		this.memberTermS = termS;
		this.forward = isForward;
		
		// Asserts 
		assert (termL.length == inputImage.length
				&& termU.length == inputImage.length
				&& termS.length == inputImage.length
				&& termL.length == termL[0].length 
				&& termU.length == termU[0].length
				&& termS.length == termS[0].length);
		
		assert (permutation.length == inputImage.length);
		
		this.image = inputImage;
	}

	public TriangularElementaryReversibleTransform(final TriangularElementaryReversibleMatrix term,
			final float[][][] inputImage, final boolean isForward) {

		memberPermutation = term.getPermutation();
		memberTermL = term.getElementaryMatrixL();
		memberTermU = term.getElementaryMatrixU();
		memberTermS = term.getElementaryMatrixS();
		this.forward = isForward;
		
		// Asserts 
		assert (memberTermL.length == inputImage.length
				&& memberTermU.length == inputImage.length
				&& memberTermS.length == inputImage.length
				&& memberTermL.length == memberTermL[0].length 
				&& memberTermU.length == memberTermU[0].length
				&& memberTermS.length == memberTermS[0].length);
		
		assert (memberPermutation.length == inputImage.length);
		
		this.image = inputImage;
	}

	private long[] applyLowerTerm(final float[][] term, final long[] data) {
		int n = data.length;		
		assert (term.length == n && term[0].length == n);
		
		// Careful with the possible sign change in the last component!
		if (term[n - 1][n - 1] < 0) {
			data[n - 1] = -data[n - 1];
		}
		
		// Bottom-up application
		for (int i = n - 1; i >= 0; i--) {
			double acc = 0;
			
			for (int j = 0; j < i; j++) {
				acc += (double) term[i][j] * (double) data[j];
			}
			
			data[i] += Math.rint(acc);
		}
		
		return data;
	}
	
	private long[] applyUpperTerm(final float[][] term, final long[] data) {
		int n = data.length;		
		assert (term.length == n && term[0].length == n);
		
		// Top-down application
		for (int i = 0; i < n; i++) {
			double acc = 0;
			
			for (int j = i + 1; j < n; j++) {
				acc += (double) term[i][j] * (double) data[j];
			}
			
			data[i] += Math.rint(acc);
		}
		
		// Careful with the possible sign change in the last component!
		if (term[n - 1][n - 1] < 0) {
			data[n - 1] = -data[n - 1];
		}
		
		return data;	
	}
	
	private long[] applyPermutation(final int[] originalPermutation, final long[] data) {
		// Apply the permutation
		long[] t = new long[data.length];
		
		for (int z = 0; z < data.length; z++) {
			t[z] = data[originalPermutation[z]];
		}
		
		return t;
	}
	
	private long[] removeLowerTerm(final float[][] term, final long[] data) {
		int n = data.length;		
		assert (term.length == n && term[0].length == n);
		
		for (int i = 0; i < n; i++) {
			double acc = 0;
			
			for (int j = 0; j < i; j++) {
				acc += (double) term[i][j] * (double) data[j];
			}

			data[i] -= Math.rint(acc);
		}

		// Careful with the possible sign change in the last component!
		if (term[n - 1][n - 1] < 0) {
			data[n - 1] = -data[n - 1];
		}
		
		return data;
	}
	
	private long[] removeUpperTerm(final float[][] term, final long[] data) {
		int n = data.length;		
		assert (term.length == n && term[0].length == n);
		
		// Careful with the possible sign change in the last component!
		if (term[n - 1][n - 1] < 0) {
			data[n - 1] = -data[n - 1];
		}
		
		for (int i = n - 1; i >= 0; i--) {
			double acc = 0;
			
			for (int j = i + 1; j < n; j++) {
				acc += (double) term[i][j] * (double) data[j];
			}
			
			data[i] -= Math.rint(acc);
		}
		
		return data;	
	}
	
	private int[] inversePermutation(final int[] originalPermutation) {
		int[] inversePermutation = new int[originalPermutation.length];
		
		for (int i = 0; i < originalPermutation.length; i++) {
			inversePermutation[originalPermutation[i]] = i;
		}
		
		return inversePermutation;
	}
	
	public final float[][][] call() {	
		final float[][][] t = new float[image.length][image[0].length][image[0][0].length];		
		
		final int d0 = image.length;
		final int d1 = image[0].length;
		final int d2 = image[0][0].length;
				
		if (forward) {
			ParallelMap.map(new ParallelMap.MultidimensionalIterator(d1, d2), new ParallelMap.MapInterface<int[]>() {
				public void apply(final int[] p) {
					long[] tl = new long[d0];

					for (int k = 0; k < d0; k++) {
						tl[k] = (int) image[k][p[0]][p[1]];
					}

					tl = applyLowerTerm(memberTermS, tl);
					tl = applyUpperTerm(memberTermU, tl);
					tl = applyLowerTerm(memberTermL, tl);
					tl = applyPermutation(memberPermutation, tl);

					for (int k = 0; k < d0; k++) {
						// Anything outside this boundary is not lossless
						assert (tl[k] < (1 << 23) && tl[k] > -(1 << 23));
						t[k][p[0]][p[1]] = tl[k];
					}
				}
			});

//			for (int y = 0; y < image[0].length; y++) {
//				for (int x = 0; x < image[0][0].length; x++) {
//
//					long[] tl = new long[d0];
//
//					for (int z = 0; z < d0; z++) {
//						tl[z] = (int) image[z][y][x];
//					}
//
//					tl = applyLowerTerm(memberTermS, tl);
//					tl = applyUpperTerm(memberTermU, tl);
//					tl = applyLowerTerm(memberTermL, tl);
//					tl = applyPermutation(memberPermutation, tl);
//
//					for (int z = 0; z < d0; z++) {
//						t[z][y][x] = tl[z];
//					}
//				}
//			}
		} else {
			// Reverse
			final int[] ipermutation = inversePermutation(memberPermutation);

			ParallelMap.map(new ParallelMap.MultidimensionalIterator(d1, d2), new ParallelMap.MapInterface<int[]>() {
				public void apply(final int[] p) {
					long[] tl = new long[d0];

					for (int k = 0; k < d0; k++) {
						tl[k] = (int) image[k][p[0]][p[1]];
					}

					tl = applyPermutation(ipermutation, tl);
					tl = removeLowerTerm(memberTermL, tl);
					tl = removeUpperTerm(memberTermU, tl);
					tl = removeLowerTerm(memberTermS, tl);

					for (int k = 0; k < d0; k++) {
						// Anything outside this boundary is not lossless
						assert (tl[k] < (1 << 23) && tl[k] > -(1 << 23));
						t[k][p[0]][p[1]] = tl[k];
					}
				}
			});

//			for (int y = 0; y < image[0].length; y++) {
//				for (int x = 0; x < image[0][0].length; x++) {
//
//					long[] tl = new long[d0];
//
//					for (int z = 0; z < d0; z++) {
//						tl[z] = (int) image[z][y][x];
//					}
//
//					tl = applyPermutation(ipermutation, tl);
//					tl = removeLowerTerm(memberTermL, tl);
//					tl = removeUpperTerm(memberTermU, tl);
//					tl = removeLowerTerm(memberTermS, tl);
//
//					for (int z = 0; z < d0; z++) {
//						t[z][y][x] = tl[z];
//					}
//				}
//			}
			
		}
		
		return t;
	}


}
