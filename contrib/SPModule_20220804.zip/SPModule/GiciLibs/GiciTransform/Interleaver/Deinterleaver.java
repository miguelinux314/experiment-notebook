
package GiciTransform.Interleaver;


/**
 * This class reverses the interleaving of an image's samples.
 * The sequence of the images samples, is again arranged as a three-dimensional array representing the image.
 *
 * There are two interleaving orders: band sequential and band interleaved.
 * Each mode of interleaving is implemented as a class implementing the <code>GenericDeinterleaver</code> interface.
 * An instance of <code>GenericDeinterleaver</code> is created based on the constructor's parameters.
 * Any calls to <code>setNextSamples</code> are delegated to that instance.
 */
public class Deinterleaver {

	/**
	 * This is the interface implemented by the two Deinterleaver implementations.
	 */
	interface GenericDeinterleaver {

		/**
		 * Attempts to arrange the next <code>data.length</code> samples from the sequence to the image.
		 * It will use fewer samples if the image is completed.
		 *
		 * The whole image can be reconstructed in one go, or incrementaly.
		 * This is especially usefull when the whole sample sequence is not immediately available.
		 *
		 * @param data The array that contains the samples.
		 *
		 * @return How many saples were used.
		 */
		int setNextSamples(int[] data);

	}

	private final GenericDeinterleaver instance;


	/**
	 * Implementation of the Band Sequential deinterleaving mode.
	 */
	private class BandSequential implements GenericDeinterleaver {
		int[][][] img;
		int x_max, x = 0;
		int y_max, y = 0;
		int z_max, z = 0;

		/**
		 * Constructor
		 *
		 * @param img The image to receive the samples.
		 */
		public BandSequential(int[][][] img) {
			this.img = img;
			this.x_max = img[0][0].length;
			this.y_max = img[0].length;
			this.z_max = img.length;
		}

		/**
		 * See the general contract for the <code>setNextSamples</code> method of the
		 * <code>GenericDeinterleaver</code> * interface.
		 *
		 * @param data The array that contains the samples.
		 *
		 * @return How many saples were used.
		 */
		public int setNextSamples(int[] data) {
			int i = 0;
			loop:
			for (; z < z_max; z++) {
				for (; y < y_max; y++) {
					for (; x < x_max; x++) {
						if (i > data.length) {
							break loop;
						}
						img[z][y][x] = data[i++];
					}
					x = 0;
				}
				y = 0;
			}
			return i;
		}
	}


	/**
	 * Implementation of the Band Interleaved deinterleaving mode.
	 */
	private class BandInterleaved implements GenericDeinterleaver {
		int[][][] img;
		int x_max, x = 0;
		int y_max, y = 0;
		int z_max, z = 0;
		int M, aux, m = 0;

		/**
		 * Constructor
		 *
		 * @param img The image to receive the samples.
		 * @param M The sub-frame interleaving depth.
		 */
		public BandInterleaved(int[][][] img, int M) {
			this.img = img;
			this.x_max = img[0][0].length;
			this.y_max = img[0].length;
			this.z_max = img.length;

			if (M < 1 || M > img.length) {
				throw new RuntimeException("Subframe interleaving depth must be between 1 and the number of bands.");
			}

			this.M = M;
			this.aux = (z_max % M == 0) ?
				z_max/M :
				z_max/M + 1;
		}

		/**
		 * See the general contract for the <code>setNextSamples</code> method of the
		 * <code>GenericDeinterleaver</code> * interface.
		 *
		 * @param data The array that contains the samples.
		 *
		 * @return How many saples were used.
		 */
		public int setNextSamples(int[] data) {
			int i = 0;
			loop:
			for (; y < y_max; y++) {
				for (; m < aux; m++) {
					for (; x < x_max; x++) {
						for (; z < Math.min((m + 1) * M, z_max); z++) {
							if (i >= data.length) {
								break loop;
							}
							img[z][y][x] = data[i++];
						}
						z = m * M;
					}
					z = (m + 1) * M;
					x = 0;
				}
				m = 0;
				z = 0;
			}
			return i;
		}
	}


	/**
	 * Constructor
	 * Creates a delegate based on the input arguments.
	 *
	 * @param img The image to receive the samples.
	 * @param order The interleaving order to be used.
	 * @param M When the selected order is Band Interleaved, this is the sub-frame interleaving depth.
	 */
	public Deinterleaver(int[][][] img, SampleOrder order, int M) {

		switch (order) {

			case BSQ:
				this.instance = new BandSequential(img);
			break;

			case BIL:
				this.instance = new BandInterleaved(img, M);
			break;

			default:
				this.instance = null;
			break;

		}
	}


	/**
	 * Delegates the call to the instance.
	 *
	 * @param data The array that contains the samples.
	 *
	 * @return How many saples were used.
	 */
	public int setNextSamples(int[] data) {
		return instance.setNextSamples(data);
	}

}