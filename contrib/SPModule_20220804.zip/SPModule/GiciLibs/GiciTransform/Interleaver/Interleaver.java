
package GiciTransform.Interleaver;


/**
 * This class implements the interleaving of an image's samples.
 * The result of interleaving an image, is a sequence of the images samples in some specific order.
 *
 * There are two interleaving orders: band sequential and band interleaved.
 * Each mode of interleaving is implemented as a class implementing the <code>GenericInterleaver</code> interface.
 * An instance of <code>GenericInterleaver</code> is created based on the constructor's parameters.
 * Any calls to <code>getNextSamples</code> are delegated to that instance.
 */
public class Interleaver {

	/**
	 * This is the interface implemented by the two Interleaver implementations.
	 */
	interface GenericInterleaver
	{

		/**
		 * Attempts to return the next <code>data.length</code> samples from the sequence.
		 * It will return fewer samples if no more are available.
		 *
		 * The whole image can be interleaved in one go, or incrementally.
		 * This is especially useful when the whole image is not immediately available.
		 *
		 * @param data The array that will receive the samples.
		 *
		 * @return How many samples were retrieved.
		 */
		int getNextSamples(int[] data);

	}

	private final GenericInterleaver instance;


	/**
	 * Implementation of the Band Sequential interleaving mode.
	 */
	private class BandSequential implements GenericInterleaver {
		int[][][] img;
		int x_max, x = 0;
		int y_max, y = 0;
		int z_max, z = 0;

		/**
		 * Constructor
		 *
		 * @param img The image from which samples are taken.
		 */
		public BandSequential(int[][][] img) {
			this.img = img;
			this.x_max = img[0][0].length;
			this.y_max = img[0].length;
			this.z_max = img.length;
		}

		/**
		 * See the general contract for the <code>getNextSamples</code> method of the <code>GenericInterleaver</code>
		 * interface.
		 *
		 * @param data The array that will receive the samples.
		 *
		 * @return How many samples were retreived.
		 */
		public int getNextSamples(int[] data) {
			int i = 0;
			loop:
			for (; z < z_max; z++) {
				for (; y < y_max; y++) {
					for (; x < x_max; x++) {
						if (i >= data.length) {
							break loop;
						}
						data[i++] = img[z][y][x];
					}
					x = 0;
				}
				y = 0;
			}
			return i;
		}
	}


	/**
	 * Implementation of the Band Interleaved interleaving mode.
	 */
	private class BandInterleaved implements GenericInterleaver {

		int[][][] img;
		int x_max, x = 0;
		int y_max, y = 0;
		int z_max, z = 0;
		int M, aux, m = 0;

		/**
		 * Constructor
		 *
		 * @param img The image from which samples are taken.
		 * @param M The sub-frame interleaving depth.
		 */
		public BandInterleaved(int[][][] img, int M) {
			this.img = img;
			this.x_max = img[0][0].length;
			this.y_max = img[0].length;
			this.z_max = img.length;

			if (M < 1 || M > img.length) {
				throw new RuntimeException("Subframe interleaving depth must be between 1 and the number of bands.");
			}

			this.M = M;
			this.aux = (z_max % M == 0) ?
				z_max/M :
				z_max/M + 1;
		}

		/**
		 * See the general contract for the <code>getNextSamples</code> method of the <code>GenericInterleaver</code>
		 * interface.
		 *
		 * @param data The array that will receive the samples.
		 *
		 * @return How many samples were retrieved.
		 */
		public int getNextSamples(int[] data) {
			int i = 0;
			loop:
			for (; y < y_max; y++) {
				for (; m < aux; m++) {
					for (; x < x_max; x++) {
						for (; z < Math.min((m + 1) * M, z_max); z++) {
							if (i >= data.length) {
								break loop;
							}
							data[i++] = img[z][y][x];
						}
						z = m * M;
					}
					z = (m + 1) * M;
					x = 0;
				}
				m = 0;
				z = 0;
			}
			return i;
		}
	}


	/**
	 * Constructor
	 * Creates a delegate based on the input arguments.
	 *
	 * @param img The image from which samples will be taken.
	 * @param order The interleaving order to be used.
	 * @param M When the selected order is Band Interleaved, this is the sub-frame interleaving depth.
	 */
	public Interleaver(int[][][] img, SampleOrder order, int M) {

		switch (order) {

			case BSQ:
				this.instance = new BandSequential(img);
			break;

			case BIL:
				this.instance = new BandInterleaved(img, M);
			break;

			default:
				this.instance = null;
			break;

		}
	}


	/**
	 * Delegates the call to the instance.
	 *
	 * @param data The array that will receive the samples.
	 *
	 * @return How many samples were retrieved.
	 */
	public int getNextSamples(int[] data) {
		return instance.getNextSamples(data);
	}

}
