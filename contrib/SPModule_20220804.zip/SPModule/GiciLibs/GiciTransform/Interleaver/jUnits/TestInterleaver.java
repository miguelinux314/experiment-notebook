
package GiciTransform.Interleaver.jUnits;

import java.util.Random;

import org.junit.Test;
import static org.junit.Assert.*;
import GiciTransform.Interleaver.Deinterleaver;
import GiciTransform.Interleaver.Interleaver;
import GiciTransform.Interleaver.SampleOrder;


public class TestInterleaver {

	@Test
	public void testBandSequential() {

		int bands = 10;
		int height = 11;
		int width = 12;
		int len = bands * height * width;

		int[] inData = new int[len];
		int[] outData = new int[len];
		int[][][] img = new int[bands][height][width];

		Random rand = new Random();
		for (int i = 0; i < len; i++) {
			inData[i] = rand.nextInt();
			outData[i] = ~inData[i];
		}

		Deinterleaver deinterleaver = new Deinterleaver(img, SampleOrder.BSQ, 0);
		deinterleaver.setNextSamples(inData);

		Interleaver interleaver = new Interleaver(img, SampleOrder.BSQ, 0);
		interleaver.getNextSamples(outData);

		assertArrayEquals(inData, outData);
	}


	@Test
	public void testBandInterleaved() {

		int bands = 10;
		int height = 11;
		int width = 12;
		int len = bands * height * width;

		int[] inData = new int[len];
		int[] outData = new int[len];
		int[][][] img = new int[bands][height][width];

		Random rand = new Random();

		for (int m = 1; m <= bands; m++) {
			for (int i = 0; i < len; i++) {
				inData[i] = rand.nextInt();
				outData[i] = ~inData[i];
			}

			Deinterleaver deinterleaver = new Deinterleaver(img, SampleOrder.BIL, m);
			deinterleaver.setNextSamples(inData);

			Interleaver interleaver = new Interleaver(img, SampleOrder.BIL, m);
			interleaver.getNextSamples(outData);

			assertArrayEquals(inData, outData);
		}
	}

}
