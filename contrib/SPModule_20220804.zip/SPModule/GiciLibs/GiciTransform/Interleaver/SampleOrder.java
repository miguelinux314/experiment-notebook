
package GiciTransform.Interleaver;


/**
 * The two sample orders available to the Interleaver and Deinterleaver.
 */
public enum SampleOrder {BIL, BSQ};
