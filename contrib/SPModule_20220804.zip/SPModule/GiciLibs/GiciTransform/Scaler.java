/*
 * GICI Library -
 * Copyright (C) 2007  Group on Interactive Coding of Images (GICI)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Group on Interactive Coding of Images (GICI)
 * Department of Information and Communication Engineering
 * Autonomous University of Barcelona
 * 08193 - Bellaterra - Cerdanyola del Valles (Barcelona)
 * Spain
 *
 * http://gici.uab.es
 * gici-info@deic.uab.es
 */
package GiciTransform;

import GiciException.*;


public class Scaler {
		
		/**
		 * Definition in Coder
		 */
		float  [][]imageSamples = null;
		
	   	public static final int NEAREST = 1;
	    public static final int BILINEAR = 2;

	    /**
		 * Interpolation type
		 * <ul>
		 *   <li> 1 - Nearest
		 *   <li> 2 - Bilinear
		 * </ul>
		 */
	    int interpolType;
	    
	    /**
	     * Vertical scale
	     */
	    double scaleVertical;
	    
	    /**
	     * Horitzontal scale
	     */
	    double scaleHorizontal;
	    
	    //INTERNAL VARIABLES
	    boolean parametersSet = false;
	    
	    /**
	     * Constructor for an ImageScaler. The parameter interpolType may be either NEAREST or BILINEAR.
	     *
	     * @param imageSamples 
	     */
	    public Scaler(float[][] imageSamples)
	    {
	    	this.imageSamples = imageSamples;
	    }
	    
	    public void setParamaters(double scaleVertical, double scaleHorizontal, int interpolType){
	    	parametersSet = true;
	    	this.scaleVertical = scaleVertical;
	        this.scaleHorizontal = scaleHorizontal;
	        this.interpolType = interpolType;
	    }
	   
	   
	    /**
	     * Scale a matrix using bilinear interpolation.
	     */
	    float[][] getScaleNN() throws ErrorException{
	    	//If parameters are not set run cannot be executed
			if(!parametersSet){
				throw new ErrorException("Parameters not set.");
			}
	        int height = imageSamples.length;
	        int width = imageSamples[0].length;

	        double EPS = 1e-10;

	        // The size of the scaled image
	        int pheight = (int)(height * scaleVertical + EPS);
	        int pwidth = (int)(width * scaleHorizontal + EPS);

	        float[][] newMatrix = new float[pheight][pwidth];

			double sv = (pheight-1.0) / (height-1.0);
			double sh = (pwidth-1.0) / (width-1.0);
	
			int i, j;

	        // Fills in the pMatrix using nearest neighbour interpolation
	        for (int x = 0; x < pheight; x++)
	        {
		    i = (int)Math.round(x/sv);

	            for (int y = 0; y < pwidth; y++){
					j = (int)Math.round(y/sh);
					newMatrix[x][y] = imageSamples[i][j];
	            }

	        }
	        
	        return newMatrix;
	    }
	    
	    /**
	     * Scale a matrix using bilinear interpolation
	     */
	    float[][] getScaleMatrixBL()throws ErrorException{
	    	//If parameters are not set run cannot be executed
			if(!parametersSet){
				throw new ErrorException("Parameters not set.");
			}

	        int height = imageSamples.length;
	        int width = imageSamples[0].length;

	        double EPS = 1e-10;

	        // The size of the scaled image
	        int pheight = (int)(height * scaleVertical + EPS);
	        int pwidth = (int)(width * scaleHorizontal + EPS);

	        float[][] newMatrix = new float[pheight][pwidth];

			double is, im;
			double js, jm;
			int i0, i0p1, j0, j0p1;
		    float p1, p2, p3, p4;
			short bilinValue;
	
			double sv = (pheight-1.0) / (height-1.0);
			double sh = (pwidth-1.0) / (width-1.0);

	        // Fills in the pMatrix using bilinear interpolation
	        for (int x = 0; x < pheight; x++){
			    is = x / sv;
			    i0 = (int)is;
			    i0p1 = Math.min(i0 + 1, height - 1);
			    im = is - i0;
	
	            for (int y = 0; y < pwidth; y++){
					js = y / sh;
					j0 = (int)js;
					j0p1 = Math.min(j0 + 1, width - 1);
					jm = js - j0;
		
					p1 = imageSamples[i0][j0];
		            p2 = imageSamples[i0p1][j0];
		            p3 = imageSamples[i0p1][j0p1];
		            p4 = imageSamples[i0][j0p1];
			
		            bilinValue = (short) ((1-im) * (1-jm) * p1
					      + im * (1-jm) * p2
					      + im * jm * p3
					      + (1-im) * jm * p4);
		
		            newMatrix[x][y] = bilinValue;
	            }

	        }
	        return newMatrix;
	    }

}
