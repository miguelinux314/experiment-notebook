package GiciParallel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Creates one single executor service as a singleton class.
 * 
 * NOTE: when using this class one should exit applications with system.exit(), and not by returning from main().
 * Otherwise, thread pools do not get released and threads awaiting for a job block the virtual machine destruction.
 * An "Angel" Thread will try to watch for this condition. 
 * 
 * @author Ian
 * @param <T>
 *
 */

public class BatchExecutorService<T> {
	// Singleton element of this class
	private static ThreadPoolExecutor tpe = null;
	
	// Thread that monitors this service in case of an unexpected program termination that
	// does not execute the shutdown hooks.
	private static Thread angelThreadInstance = null;
	
	private class AngelThread extends Thread {
		public void run() {
			int iHaveSeenItCount = 0;

			while (tpe != null) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// This is normal, relax.
				}

				boolean doThings = false;

				Map<Thread,StackTraceElement[]> threads = Thread.getAllStackTraces();
				for (Thread t : threads.keySet()) {
					if (t.getName().equals("DestroyJavaVM")) {
						doThings = true;
					}
				}

				if (doThings) {
					synchronized (BatchExecutorService.class) {
						if (tpe != null) {
							iHaveSeenItCount++;
						}

						if (iHaveSeenItCount > 2) {
							System.err.println("Is your application not exiting with System.exit()?");
							System.err.println("ShutDownHooks required by a BatchExecutorService are not getting called because of that.");
							System.err.println("Trying to shutdown a ThreadPoolExecutor forcefully.");
							System.err.println("Trutly yours, your angel thread.");
							tpe.shutdown();
							tpe = null;
						}
					}
				}
			}
		}
	};
	
	private Queue<Future<T>> localTasks = new ConcurrentLinkedQueue<Future<T>>();
	
	final private static ThreadLocal<Boolean> sonOfABES = new ThreadLocal<Boolean>() {
		protected Boolean initialValue() {
            return false;
		}
	};
	
	public BatchExecutorService() {
		synchronized (BatchExecutorService.class) {
			if (tpe == null) {
				// Create the ThreadPoolExecutor if not created already
				BatchExecutorService.tpe = new ThreadPoolExecutor(Runtime.getRuntime().availableProcessors(),
						Runtime.getRuntime().availableProcessors(), 1,
						TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());

				// Angel thread that will watch for a virtual machine destruction without sucessfully calling
				// shutdown hooks.
				angelThreadInstance = new AngelThread();
				angelThreadInstance.start();

				// Register a shutdown hook that will destroy the Thread Pool Executor. 
				Runtime.getRuntime().addShutdownHook(new Thread() {
					public void run() {
						synchronized (BatchExecutorService.class) {
							if (BatchExecutorService.tpe != null) {
								BatchExecutorService.tpe.shutdown();
								BatchExecutorService.tpe = null;
							}
						}

						// wake the angel so that it dies
						angelThreadInstance.interrupt();
					}
				});
			}
		}
	}
	
	public final void submitAndRememberFuture(final Callable<T> task) {
		localTasks.add(tpe.submit(
				new Callable<T>() {
					public T call() throws Exception {
						// Mark this child thread for future reference.
						// Save and restore old value in case this thread is reused.
						Boolean oldSonOfABESValue = sonOfABES.get();
						sonOfABES.set(true);
						T r = task.call();
						sonOfABES.set(oldSonOfABESValue);
						return r;
					}
					
				}		
		));
	}
	
	public final List<T> awaitAllLocalTasks() {
		List<T> o = new ArrayList<T>();
		
		try {
			// If we are a child of a BES, allocate one more thread to the executor service, since we are stalling
			// one thread for ourselves.

			Boolean sonOfABESValue = sonOfABES.get();
			
			if (sonOfABESValue) {
				System.out.println("increase");
				synchronized (BatchExecutorService.class) {
					tpe.setCorePoolSize(tpe.getMaximumPoolSize() + 1);
					tpe.setMaximumPoolSize(tpe.getMaximumPoolSize() + 1);
				}
			}
			
			Future<T> f;
			
			while ((f = localTasks.poll()) != null) {
				o.add(f.get());
			}
			
			if (sonOfABESValue) {
				synchronized (BatchExecutorService.class) {
					tpe.setCorePoolSize(tpe.getMaximumPoolSize() - 1);
					tpe.setMaximumPoolSize(tpe.getMaximumPoolSize() - 1);
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
			throw new Error("Error in parallel execution handler (Thread Interrupted)");
		} catch (ExecutionException e) {
			e.printStackTrace();
			e.getCause().printStackTrace();
			throw new Error("Error in parallel execution handler (thread threw interruption)");
		} finally {
			localTasks.clear();
		}
		
		return o;
	}
}
