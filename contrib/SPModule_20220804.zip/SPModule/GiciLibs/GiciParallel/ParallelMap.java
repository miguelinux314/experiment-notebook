package GiciParallel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.Callable;

/**
 * Apply operations in parallel in a "functional map" style.
 * @author Ian
 *
 */
public final class ParallelMap {
	
	private ParallelMap() {
		// This class shall not be constructed.
	}
	
	public interface MapInterface<E> {
		// input can be modified by apply
		void apply(E position);
	}
	
	public interface MapIterator<E> {
		Iterator<E> getPackageIterator(int currentPackage, final int totalPackages);
	}
	
	private static final int DEFAULT_CONCURRENCY = Runtime.getRuntime().availableProcessors();
	
	public static final class ListIterator implements MapIterator<Integer> {
		private final List<Integer> memberList;
		
		public ListIterator(final List<Integer> list) {
			memberList = list;
		}
		
		public ListIterator(final Set<Integer> list) {
			memberList = new ArrayList<Integer>(list);
		}
		
		public Iterator<Integer> getPackageIterator(final int currentPackage, final int totalPackages) {
			int fromIndex = memberList.size() * currentPackage / totalPackages;
			int toIndex = memberList.size() * (currentPackage + 1) / totalPackages;
			
			List<Integer> subList = memberList.subList(fromIndex, toIndex);
			
			return subList.iterator();
		}	
	}
	
	public static final class MultidimensionalIterator implements MapIterator<int[]> {
		private final int[] dimensionSizes;
		private final int elementCount;

		public MultidimensionalIterator(final int... sizes) {
			this.dimensionSizes = sizes;
			
			int a = 1;
			
			double overflowTest = 1;

			for (int b : dimensionSizes) {
				a *= b;
				overflowTest *= b;
			}
			
			assert(overflowTest < Integer.MAX_VALUE);

			elementCount = a;
		}
		
		public Iterator<int[]> getPackageIterator(final int currentPackage, final int totalPackages) {
			final int[] position = new int[dimensionSizes.length];
			
			final int fromIndex = elementCount * currentPackage / totalPackages;
			final int toIndex = elementCount * (currentPackage + 1) / totalPackages;
			
			int offset = fromIndex;
			
			for (int i = position.length - 1; i > 0; i--) {
				position[i] = offset % dimensionSizes[i];
				offset /= dimensionSizes[i];
			}
			
			position[0] = offset;
			
			if (dimensionSizes.length != 2) {
				// return a generic iterator
				return new Iterator<int[]>() {
					private int localFromIndex = fromIndex;
					private final int localToIndex = toIndex; 

					public boolean hasNext() {
						return localFromIndex < localToIndex;
					}

					public int[] next() {
						if (!hasNext()) {
							throw new NoSuchElementException();
						}

						int[] result = Arrays.copyOf(position, position.length);

						for (int i = position.length - 1; i >= 0; i--) {
							position[i] = (position[i] + 1) % dimensionSizes[i];

							if (position[i] != 0) {
								break;
							}
						}

						localFromIndex++;

						return result;
					}

					public void remove() {
						throw new UnsupportedOperationException();
					}

				};
			} else {
				// Return an optimized iterator for this particular case
				position[1]--;
				
				if (position[1] == -1) {
					position[0]--;
				}
				
				return new Iterator<int[]>() {
					private int localFromIndex = fromIndex;
					private final int localToIndex = toIndex; 
					
					final int[] nextValue = position;
					final int modulo = dimensionSizes[1];
					
					public boolean hasNext() {
						return localFromIndex < localToIndex;
					}

					public int[] next() {
						/*if (localFromIndex >= localToIndex) {
							throw new NoSuchElementException();
						}*/
						
						nextValue[1] = (nextValue[1] + 1) % modulo;
						
						if (nextValue[1] == 0) {
							nextValue[0]++;
						}
						
						localFromIndex++;
						
						final int[] nextValue = position;
						
						return nextValue;
					}

					public void remove() {
						throw new UnsupportedOperationException();
					}

				};
			}
		}
	};
	
	
	// FIXME: this one is currently not working
	public static final class UpperDiagonalIterator implements MapIterator<int[]> {
		private final int matrixSize;

		public UpperDiagonalIterator(final int size) {
			this.matrixSize = size;
		}
		
		private int[] startPosition(final int currentPackage, final int totalPackages) {
			int[] r = new int[2];
			
			if (currentPackage == totalPackages) {
				r[0] = matrixSize;
				r[1] = matrixSize;
				
				return r;
			}
			
			final int n = matrixSize;
			final int tnp1 = (2 * n + 1);
			
			final int unitPosition = (((1 + n) * n) / 2) * currentPackage / totalPackages;
			
			// Approximate the largest number of rows with less that unitPosition elements overall.
			// TODO fix this for proper accuracy
			int approximation = (-tnp1 + (int) Math.sqrt(tnp1 * tnp1 + 8 * unitPosition)) / 2 - 3;
			
			while (unitPosition >= (tnp1 * approximation - approximation * approximation) / 2) {
				approximation++;
			}
			
			approximation--;
			
			r[0] = approximation;
			r[1] = approximation + unitPosition - (tnp1 * approximation - approximation * approximation) / 2;
			
			return r;
		}

		public Iterator<int[]> getPackageIterator(final int currentPackage, final int totalPackages) {
			
			return new Iterator<int[]>() {
				private int[] position = startPosition(currentPackage, totalPackages);
				private int[] endPosition = startPosition(currentPackage + 1, totalPackages);
				
				public boolean hasNext() {
					return !(position[0] == endPosition[0] && position[1] == endPosition[1]);
				}

				public int[] next() {
					if (!hasNext()) {
						throw new NoSuchElementException();
					}
					
					int[] result = Arrays.copyOf(position, position.length);
					
					//System.out.println("p:" + position[0] + " " + position[1] + " " + matrixSize);
					
					position[1]++;
					
					if (position[1] >= matrixSize) {
						position[0]++;
						position[1] = position[0];
					}
					
					return result;
				}

				public void remove() {
					throw new UnsupportedOperationException();
				}
			};
		}
	};
	
	/**
	 * 
	 * @param inputArray (assumed to be rectangular and equal in size to the preallocated outputArray)
	 * @param operation
	 * @param numberOfPackages
	 */
	public static <E> void map(final MapIterator<E> dimensionMap, final MapInterface<E> operation, final int numberOfPackages) {
		
		BatchExecutorService<Object> bes = new BatchExecutorService<Object>();
		
		for (int p = 0; p < numberOfPackages; p++) {
			final int currentPackage = p;

			bes.submitAndRememberFuture(new Callable<Object>() {
				public Object call() {
					Iterator<E> position = dimensionMap.getPackageIterator(currentPackage, numberOfPackages);

					//System.out.println("child starting " + currentPackage + "/" + numberOfPackages);

					while (position.hasNext()) {
						operation.apply(position.next());
					}

					return null;
				} }
			);
		}
		
		bes.awaitAllLocalTasks();
	}
	
	public static <E> void map(final MapIterator<E> dimensionMap, final MapInterface<E> operation) {
		map(dimensionMap, operation, DEFAULT_CONCURRENCY);
	}
}
