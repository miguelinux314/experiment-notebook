package GiciParallel.jUnits;

import java.util.Random;

import GiciParallel.ParallelMap;
import junit.framework.TestCase;

public class TestParallelMap extends TestCase {
	public void testExhaustiveness() {
		
		Random r = new Random(13);
		
		for (int i = 0; i < 100; i++) {
			int d0 = r.nextInt(10) + 1;
			int d1 = r.nextInt(10) + 1;
			int d2 = r.nextInt(10) + 1;
			int d3 = r.nextInt(10) + 1;
			
			final int[][][][] src = new int[d0][d1][d2][d3];
			final int[][][][] dst = new int[d0][d1][d2][d3];
			
			ParallelMap.map(new ParallelMap.MultidimensionalIterator(d0, d1, d2, d3), new ParallelMap.MapInterface<int[]>() {
				public void apply(final int[] p) {
					src[p[0]][p[1]][p[2]][p[3]]++;
				}
			});
			
			// Check for repeated ops
			for (int id0 = 0; id0 < d0; id0++) {
				for (int id1 = 0; id1 < d1; id1++) {
					for (int id2 = 0; id2 < d2; id2++) {
						for (int id3 = 0; id3 < d3; id3++) {
							assertTrue(src[id0][id1][id2][id3] < 2);
						}
					}
				}
			}
			
			// Check for missing oops
			for (int id0 = 0; id0 < d0; id0++) {
				for (int id1 = 0; id1 < d1; id1++) {
					for (int id2 = 0; id2 < d2; id2++) {
						for (int id3 = 0; id3 < d3; id3++) {
							assertTrue(src[id0][id1][id2][id3] > 0);
						}
					}
				}
			}
			
			ParallelMap.map(new ParallelMap.MultidimensionalIterator(d0, d1, d2, d3), new ParallelMap.MapInterface<int[]>() {
				public void apply(final int[] p) {
					src[p[0]][p[1]][p[2]][p[3]] = p[0] * p[1] * p[2] * p[3] + 1;
				}
			});

			ParallelMap.map(new ParallelMap.MultidimensionalIterator(d0, d1, d2, d3), new ParallelMap.MapInterface<int[]>() {
				public void apply(final int[] p) {
					dst[p[0]][p[1]][p[2]][p[3]] = src[p[0]][p[1]][p[2]][p[3]];
				}
			});
			
			ParallelMap.map(new ParallelMap.MultidimensionalIterator(d0, d1, d2, d3), new ParallelMap.MapInterface<int[]>() {
				public void apply(final int[] p) {
					assertTrue(dst[p[0]][p[1]][p[2]][p[3]] == p[0] * p[1] * p[2] * p[3] + 1);
				}
			});
			
			for (int id0 = 0; id0 < d0; id0++) {
				for (int id1 = 0; id1 < d1; id1++) {
					for (int id2 = 0; id2 < d2; id2++) {
						for (int id3 = 0; id3 < d3; id3++) {
							assertTrue(src[id0][id1][id2][id3] > 0);
							assertTrue(dst[id0][id1][id2][id3] > 0);
							assertTrue(dst[id0][id1][id2][id3] == id0 * id1 * id2 * id3 + 1);
						}
					}
				}
			}
		}
		
	}
	
	public void testExhaustiveness2() {
		
		Random r = new Random(13);
		
		for (int i = 0; i < 100; i++) {
			int d0 = r.nextInt(10) + 1;
			int d1 = r.nextInt(10) + 1;
				
			final int[][] src = new int[d0][d1];
			final int[][] dst = new int[d0][d1];
			
			ParallelMap.map(new ParallelMap.MultidimensionalIterator(d0, d1), new ParallelMap.MapInterface<int[]>() {
				public void apply(final int[] p) {
					src[p[0]][p[1]]++;
				}
			});
			
			// Check for repeated ops and for missing oops
			for (int id0 = 0; id0 < d0; id0++) {
				for (int id1 = 0; id1 < d1; id1++) {
					assertTrue(src[id0][id1] < 2);
					assertTrue(src[id0][id1] > 0);
				}
			}
			
			ParallelMap.map(new ParallelMap.MultidimensionalIterator(d0, d1), new ParallelMap.MapInterface<int[]>() {
				public void apply(final int[] p) {
					src[p[0]][p[1]] = p[0] * p[1] + 1;
				}
			});

			ParallelMap.map(new ParallelMap.MultidimensionalIterator(d0, d1), new ParallelMap.MapInterface<int[]>() {
				public void apply(final int[] p) {
					dst[p[0]][p[1]] = src[p[0]][p[1]];
				}
			});
			
			ParallelMap.map(new ParallelMap.MultidimensionalIterator(d0, d1), new ParallelMap.MapInterface<int[]>() {
				public void apply(final int[] p) {
					assertTrue(dst[p[0]][p[1]] == p[0] * p[1] + 1);
				}
			});
			
			for (int id0 = 0; id0 < d0; id0++) {
				for (int id1 = 0; id1 < d1; id1++) {
					assertTrue(src[id0][id1] > 0);
					assertTrue(dst[id0][id1] > 0);
					assertTrue(dst[id0][id1] == id0 * id1 + 1);
				}
			}
		}
		
	}
}
