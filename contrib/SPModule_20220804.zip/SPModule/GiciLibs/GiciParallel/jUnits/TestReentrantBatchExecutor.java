package GiciParallel.jUnits;

import java.util.concurrent.Callable;

import junit.framework.TestCase;
import GiciParallel.BatchExecutorService;

public class TestReentrantBatchExecutor extends TestCase {

	
	public void testReentrantCode() {
		System.out.println("parent start");
		BatchExecutorService<Boolean> bes = new BatchExecutorService<Boolean>();
		
		for (int i = 0; i < 7; i++) {
			final int fi = i;
			
			bes.submitAndRememberFuture(new Callable<Boolean>() {
				public Boolean call() throws Exception {
					System.out.println("child start " + fi);
					
					BatchExecutorService<Integer> chileBes = new BatchExecutorService<Integer>();
					Thread.sleep(1000);
					for (int i = 0; i < 7; i++) {
						final int fi2 = i;
						
						chileBes.submitAndRememberFuture(new Callable<Integer>() {
							public Integer call() throws Exception {
								System.out.println("grand child start " + fi + " " + fi2);
								Thread.sleep(100);
								System.out.println("grand child stop " + fi + " " + fi2);
								return 0;
							}
						});
					}
					
					System.out.println("child wait " + fi);
					chileBes.awaitAllLocalTasks();
					
					System.out.println("child stop " + fi);
					
					return true;
				}
			});
		}
		
		System.out.println("parent wait");
		
		bes.awaitAllLocalTasks();
		System.out.println("parent done");
	}
	
	public static void main(String[] args) {
		BatchExecutorService<Object> bes = new BatchExecutorService<Object>();
	}
}
