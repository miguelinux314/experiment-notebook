package GiciMask;

import GiciException.ErrorException;
import GiciException.WarningException;
import GiciStream.BitStream;

/**
 * Main class of the ArithmeticDecodingMask object. This class implements the decoding
 * algorithm of the adaptive arithmetic encoding to find the mask passed in the bit stream.
 * Usage example:<br>
 * &nbsp; construct<br>
 * &nbsp; setParameters<br>
 * &nbsp; run<br>
 * &nbsp; get methods<br>
 *
 * @author Group on Interactive Coding of Images (GICI)
 * @version 1.0
 */
public class ArithmeticDecoding {
	/**
	 * Marks if the parameters are set in the class.
	 * <p>
	 * Only boolean values are allowed; false if the parameters are not set; otherwise true
	 */
	protected boolean parameters = false;

	/**
	 * Number of symbols in the alphabet.
	 * <p>
	 * Only natural values are allowed. 
	 */
	protected int numberOfSymbols = 0;
	
	/**
	 * Number of bits needed to represent each symbol of the alphabet.
	 * <p>
	 * log_2(numberOfSymbols)
	 */
	protected int bitsSymbol = 0;
	
	/**
	 * The window size to adapt the probabilities table.
	 * <p>
	 * Only positive values are allowed; the value 0 marks that the table is never adapted.
	 */
	protected int windowSize = 0;
	
	/**
	 * Stored the number of aparitions in the message for each symbol in the alphabet in scale factor (index meaning [symbol]).
	 * <p>
	 * Only positive values are allowed.
	 */
	protected int[] cumFrequencies = null;
	
	/**
	 * The input bit stream to encode in the arithemtic encoding way.
	 * <p>
	 * Only a bit stream is allowed.
	 */
	protected BitStream inputBS = null;

	/**
	 * The output bit stream dencoded in the arithemtic decoding way.
	 * <p>
	 * Only a bit stream is allowed.
	 */
	protected BitStream outputBS = null;

	/**
	 * The resulting bit stream from the arithmetic decoding algorithm.
	 * <p>
	 * Only a bit stream is allowed.
	 */
	protected BitStream arithmeticDecodedBS = null;

	//INTERNAL VARIABLES
	/**
	 * Marks if the bit stream to decode is finished.
	 * <p>
	 * Only boolean values are allowed.
	 */
	protected boolean endBitStream = false;
	
	/**
	 * Defines the low position in the interval [low, high) in the arithmetic encoding algorithm.
	 * <p>
	 * Only positive values are allowed.
	 */
	protected int low = 0;
	
	/**
	 * Defines the high position in the interval [low, high) in the arithmetic encoding algorithm.
	 * <p>
	 * Only positive values are allowed.
	 */
	protected int high = 0;

	/**
	 * Used to find the encoded symbol in the input bit stream.
	 * <p>
	 * Only values from the bit stream are allowed.
	 */
	protected int code = 0;
	
	/**
	 * Stores the scale to construct the probabilities.
	 * <p>
	 * Only natural values are allowed.
	 */
	protected int scale = 0;
	/**
	 * Stores the number of occurrences for each symbol int the adaptive process.
	 * <p>
	 * Only positive values are allowed.
	 */
	 protected int[] symbolOcurrences = null;

	/**
	 * Constructor of the class; copies the object basic attributes,
	 * 
	 * @param numberOfSymbols number of symbols in the alphabet.
	 * @param inputBS bit stream to decode.
	 * @throws WarningException when some problem occurs in the bit stream read process.
	 */
	public ArithmeticDecoding(int numberOfSymbols, BitStream inputBS) throws WarningException {
		//Initialize some attributes
		low = 0;
		high = 0xffff;
		code = inputBS.getBits(16);
		
		//Copies the parameters
		this.numberOfSymbols = numberOfSymbols;
		this.inputBS = inputBS;
	}
	
	/**
	 * Copies the parameters of the decoding algorithm and ensures his validity.
	 * 
	 * @param windowSize how many symbols the decoder reads to recalculate the table of probabilities.
	 * @param frequencies the starting frequencies
	 * @throws ErrorException when a flimsy is detected in the given parameters.
	 */
	public void setParameters(int windowSize, int[] frequencies) throws ErrorException{
		parameters = true;
		
		//Window size
		if(windowSize < 0){
			throw new ErrorException("The window size specified for the arithmetic encoding of the mask is not correct.");
		}
		this.windowSize = windowSize;
		
		//Memory allocation for the cumulated frequencies
		cumFrequencies = new int[numberOfSymbols];

		//Vector of probabilities
		if(frequencies == null){
			//Sets the scale to construct the probabilities
			scale = 1001;
			//Sets the default probabilities (equiprobable)
			frequencies = new int[numberOfSymbols];
			
			for(int p = 0; p < frequencies.length; p++){
				frequencies[p] = (scale - 1) / numberOfSymbols;
			}
		}
		
		//Finds the cumulated vector of probabilities
		cumFrequencies[0] = frequencies[0];
		for(int p = 1; p < frequencies.length; p++){
			cumFrequencies[p] = frequencies[p] + cumFrequencies[p - 1];
		}
		//We work in the interval [0, 1) so prob[0]+prob[1]+...+prob[numberOfSymbols - 1] / scale < 1
		scale = cumFrequencies[cumFrequencies.length - 1] + 1;
		//The number of occurrence for each symbol in the adaptive process
		symbolOcurrences = new int[numberOfSymbols];
		
		if(frequencies.length != numberOfSymbols){
			throw new ErrorException("The probabilities vector is not complete. You must specify a probability for each symbol.");
		}
	}

	/**
	 * Runs the decoder algorithm of the arithmetic encoding.
	 * 
	 * @throws ErrorException when some error occurs in the process.
	 */
	public void run() throws ErrorException{
		//Ensure the parameters setting
		if(!parameters){
			throw new ErrorException("You must specify the parameters.");
		}
		//Ensure the necessary attributes in the class
		if(numberOfSymbols <= 0){
			throw new ErrorException("The number of symbols in the class is negative.");
		}
		if(inputBS == null){
			throw new ErrorException("The input bit stream is empty.");
		}
		
		int counter = windowSize;
		int symbol = 0;
		bitsSymbol = (int) Math.ceil((Math.log( (float) numberOfSymbols) / Math.log(2.0D)));
		outputBS = new BitStream();
		
		do{
			symbol = decodeSymbol();
			outputBS.addBits(symbol, bitsSymbol);
			if(windowSize != 0){
				counter--;
				symbolOcurrences[symbol]++;
			}
			
			if(windowSize != 0 && counter == 0){
				//Updates the probabilities table
				updateTableProbabilities();
				counter = windowSize;
			}			
		}while(!endBitStream);
	}
	
	/**
	 * Decodes one symbol from the input bit stream.
	 * 
	 * @return the decoded symbol.
	 */
	protected int decodeSymbol(){
		int symbol = 0;
		long range = (long) (high - low) + 1;
		long count = ((long) (code - low + 1) * scale - 1);
		
		while(cumFrequencies[symbol] * range <= count){
			symbol++;
		}
		
		high = low + (int) ((range * cumFrequencies[symbol]) / scale - 1);
		if(symbol != 0){
			low = low + (int) ((range * cumFrequencies[symbol - 1]) / scale);
		}
		recalculateHLC();
		
		return(symbol);
	}
	
	/**
	 * Recalculates the high and low and code.
	 * 
	 */
	protected void recalculateHLC(){
		for(;;){
			if( (high & 0x8000) == (low & 0x8000) ){
			}else if( ((low & 0x4000) == 0x4000) && ((high & 0x4000) == 0) ){
				low &= 0x3fff;
				high |= 0x4000;
				code ^=0x4000;
			}else{
				return;
			}
				
			low <<= 1;
			low &= 0xffff;
			high <<= 1;
			high &= 0xffff;
			high |= 1;
			code <<= 1;
			code &= 0xffff;

			try{
				code |= inputBS.getBits(1);
			}catch(WarningException e){
				code &= 0;
				endBitStream = true;
			}
		}
	}
	
	/**
	 * Updates the table of probabilities.
	 *
	 */
	protected void updateTableProbabilities(){
		int[] frequencies = new int[cumFrequencies.length];
		
		frequencies[0] = cumFrequencies[0] + symbolOcurrences[0];
		symbolOcurrences[0] = 0;
		for(int f = frequencies.length - 1; f > 0; f--){
			frequencies[f] = cumFrequencies[f] - cumFrequencies[f - 1];
			frequencies[f] += symbolOcurrences[f];
			symbolOcurrences[f] = 0;
		}
		
		cumFrequencies[0] = frequencies[0];
		for(int f = 1; f < frequencies.length; f++){
			cumFrequencies[f] = frequencies[f] + cumFrequencies[f - 1];
			
		}
		
		if(cumFrequencies[cumFrequencies.length - 1] > 0x3fff){
			for(int f = frequencies.length - 1; f >= 0; f--){
				frequencies[f] /= 2;
				if(frequencies[f] == 0){
					frequencies[f] = 1;
				}
			}
			
			cumFrequencies[0] = frequencies[0];
			for(int f = 1; f < frequencies.length; f++){
				cumFrequencies[f] = frequencies[f] + cumFrequencies[f - 1];
			}
		}
		scale = cumFrequencies[cumFrequencies.length - 1] + 1;
	}
	
	/**
	 * Returns the decode bit stream.
	 * 
	 * @return the decoded bit stream.
	 */
	public BitStream getOutputBS(){
		return(outputBS);
	}

}
