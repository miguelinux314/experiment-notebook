package GiciMask;

import GiciStream.BitStream;
import GiciException.ErrorException;
import GiciException.WarningException;

/**
 * Main class of the ArithmeticEncodingMask object. This class implements an adaptive arithmetic encoding to the
 * enconded bit stream resulting from the EncodeMask object
 * Usage example:<br>
 * &nbsp; construct<br>
 * &nbsp; setParameters<br>
 * &nbsp; run<br>
 * &nbsp; get methods<br>
 *
 * @author Group on Interactive Coding of Images (GICI)
 * @version 1.0
 */
public class ArithmeticEncoding {
	/**
	 * Marks if the parameters are set in the class.
	 * <p>
	 * Only boolean values are allowed; false if the parameters are not set; otherwise true
	 */
	protected boolean parameters = false;
	
	/**
	 * Number of symbols in the alphabet.
	 * <p>
	 * Only natural values are allowed. 
	 */
	protected int numberOfSymbols = 0;
	
	/**
	 * The window size to adapt the probabilities table.
	 * <p>
	 * Only positive values are allowed; the value 0 marks that the table is never adapted.
	 */
	protected int windowSize = 0;
	
	/**
	 * Stored the number of aparitions in the message for each symbol in the alphabet in scale factor (index meaning [symbol]).
	 * <p>
	 * Only positive values are allowed.
	 */
	protected int[] cumFrequencies = null;
	
	/**
	 * The input bit stream to encode in the arithemtic encoding way.
	 * <p>
	 * Only a bit stream is allowed.
	 */
	protected BitStream inputBS = null;
	
	/**
	 * The resulting bit stream from the arithmetic encoding algorithm.
	 * <p>
	 * Only a bit stream is allowed.
	 */
	protected BitStream arithmeticEncodedBS = null;
	
	//INTERNAL VARIABLES
	
	/**
	 * Defines the low position in the interval [low, high) in the arithmetic encoding algorithm.
	 * <p>
	 * Only positive values are allowed.
	 */
	protected int low = 0;
	
	/**
	 * Defines the high position in the interval [low, high) in the arithmetic encoding algorithm.
	 * <p>
	 * Only positive values are allowed.
	 */
	protected int high = 0;
	
	/**
	 * Marks if an underflow situation is ocurred in the algorithm process.
	 * <p>
	 * Only positive values are allowed.
	 */
	protected long underflow = 0;

	/**
	 * Stores the scale to construct the probabilities.
	 * <p>
	 * Only natural values are allowed.
	 */
	protected int scale = 0;
	/**
	 * Stores the number of occurrences for each symbol int the adaptive process.
	 * <p>
	 * Only positive values are allowed.
	 */
	protected int[] symbolOcurrences = null;
	
	/**
	 * Constructor, sets the number of symbols in the alphabet and the input bit stream.
	 * @param numberOfSimbols number of symbols in the alphabet.
	 * @param inputBS the input bit stream to encode in the arithmetic encoding algorithm way.
	 */
	public ArithmeticEncoding(int numberOfSimbols, BitStream inputBS){
		//Initialize some attributes
		low = 0;
		high = 0xffff;
		underflow = 0;
		
		//Copies the parameters
		this.numberOfSymbols = numberOfSimbols;
		this.inputBS = inputBS;
	}
	
	/**
	 * Sets the parameters given by parameters and ensures the validity.
	 * 
	 * @param windowSize marks the number of symbols between the probability table update.
	 * @param frequencies stores the probabilities for each symbol in the alphabet.
	 * 
	 * @throws ErrorException when one or more parameters have an invalid value.
	 */
	public void setParameters(int windowSize, int[] frequencies) throws ErrorException{
		parameters = true;
		
		//Window size
		if(windowSize < 0){
			throw new ErrorException("The window size specified for the arithmetic encoding must be positive.");
		}
		this.windowSize = windowSize;
		
		//Memory allocation for the cumulated frequencies
		cumFrequencies = new int[numberOfSymbols];
		
		//Vector of probabilities
		if(frequencies == null){
			//Sets the scale to construct the probabilities
			scale = 1001;
			//Sets the default probabilities (equiprobable)
			frequencies = new int[numberOfSymbols];
			
			for(int p = 0; p < frequencies.length; p++){
				frequencies[p] = (scale - 1) / numberOfSymbols;
			}
		}
		
		//Finds the cumulated vector of probabilities
		cumFrequencies[0] = frequencies[0];
		for(int p = 1; p < frequencies.length; p++){
			//cumFrequencies[p] = frequencies[p] + frequencies[p - 1];
			cumFrequencies[p] = frequencies[p] + cumFrequencies[p - 1];
		}
		//We work in the interval [0, 1) so prob[0]+prob[1]+...+prob[numberOfSymbols - 1] / scale < 1
		scale = cumFrequencies[cumFrequencies.length - 1] + 1;
		
		//The number of occurrence for each symbol in the adaptive process
		symbolOcurrences = new int[numberOfSymbols];
		
		if(frequencies.length != numberOfSymbols){
			throw new ErrorException("The probabilities vector is not complete. You must specify a probability for each symbol.");
		}
	}
	
	/**
	 * Runs the arithmetic encoding algorithm for the input bit stream.
	 * 
	 * @throws ErrorException when an error occurs in the encoding process.
	 */
	public void run() throws ErrorException{
		//Ensure the parameters setting
		if(!parameters){
			throw new ErrorException("You must specify the parameters.");
		}
		//Ensure the necessary attributes in the class
		if(numberOfSymbols <= 0){
			throw new ErrorException("The number of symbols in the class is negative.");
		}
		if(inputBS == null){
			throw new ErrorException("The input bitstream is empty.");
		}
		
		int counter = windowSize;
		int symbol = 0;
		int bitsSymbol = (int) Math.ceil((Math.log( (float) numberOfSymbols) / Math.log(2.0D)));
		arithmeticEncodedBS = new BitStream();		
		
		for(int s = 0; s < (inputBS.getNumBits() / bitsSymbol); s++){
			try{
				symbol = inputBS.getBits(bitsSymbol);
			}catch(WarningException e){
				throw new ErrorException("The bit stream is finished unexpectly.");
			}
			encodeSymbol(symbol);
			if(windowSize != 0){
				counter--;
				symbolOcurrences[symbol]++;
			}
			
			if(windowSize != 0 && counter == 0){
				//Updates the probabilities table
				updateTableProbabilities();
				counter = windowSize;
			}
		}
		
		//Ends the encoding process
		arithmeticEncodedBS.addBit((low & 0x4000) == 0x4000);
		underflow++;
		
		//Solves the underflow problems
		while(underflow > 0){
			arithmeticEncodedBS.addBit((~low & 0x4000) == 0x4000);
			underflow--;
		}
		//Final bit stream tag
		arithmeticEncodedBS.addBits(0, 16);
	}
	
	protected void encodeSymbol(int symbol){
		long range = (long) (high - low) + 1;
		high = low + (int) ((range * cumFrequencies[symbol]) / scale - 1);
		if(symbol != 0){
			low = low + (int) ((range * cumFrequencies[symbol - 1]) / scale);
		}
		
		//Recalculates High and Low
		for(;;){
			if((high & 0x8000) == (low & 0x8000)){
				//MSB of low and high coincides and we write it to the bit stream and handle the underflow
				arithmeticEncodedBS.addBit((high & 0x8000) == 0x8000);
				while(underflow > 0){
					arithmeticEncodedBS.addBit((~high & 0x8000) == 0x8000);
					underflow--;
				}
			}else if(((low & 0x4000) == 0x4000) && ((high & 0x4000) == 0)){
				//Underflow occurs h=10 l=01. We remove the second bit of high and low.
				underflow++;
				low &= 0x3fff;
				high |= 0x4000;
			}else{
				//Otherwise, continue.
				return;
			}
			low <<= 1;
			high <<= 1;
			//We only use 16 bits in the int data type, so we apply masks to erase the shifted bits to left
			low &= 0xffff;
			high &= 0xffff;
			high |= 1;
		}
	}
	
	/**
	 * Updates the table of probabilities.
	 *
	 */
	protected void updateTableProbabilities(){
		int[] frequencies = new int[cumFrequencies.length];
		
		frequencies[0] = cumFrequencies[0] + symbolOcurrences[0];
		symbolOcurrences[0] = 0;
		for(int f = frequencies.length - 1; f > 0; f--){
			frequencies[f] = cumFrequencies[f] - cumFrequencies[f - 1];
			frequencies[f] += symbolOcurrences[f];
			symbolOcurrences[f] = 0;
		}
		
		cumFrequencies[0] = frequencies[0];
		for(int f = 1; f < frequencies.length; f++){
			cumFrequencies[f] = frequencies[f] + cumFrequencies[f - 1];
			
		}
		
		if(cumFrequencies[cumFrequencies.length - 1] > 0x3fff){
			for(int f = frequencies.length - 1; f >= 0; f--){
				frequencies[f] /= 2;
				if(frequencies[f] == 0){
					frequencies[f] = 1;
				}
			}
			
			cumFrequencies[0] = frequencies[0];
			for(int f = 1; f < frequencies.length; f++){
				cumFrequencies[f] = frequencies[f] + cumFrequencies[f - 1];
			}
		}
		scale = cumFrequencies[cumFrequencies.length - 1] + 1;
	}

	/**
	 * Returns the bit stream resulting from the algorithm execution.
	 * 
	 * @return a reference to the bit stream generated in the class.
	 */
	public BitStream getArithmeticEncodedBS() {
		return(arithmeticEncodedBS);
	}
}
