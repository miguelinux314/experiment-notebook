package GiciMask;

import GiciException.*;
import GiciFile.SaveFile;

/**
 * Main class of SaveMask application.
 *
 * @author Group on Interactive Coding of Images (GICI)
 * @version 1.0
 */

public class SaveMask{
	
	/**
	 * Saves the mask in a visible format to see the shape of the image to encode.
	 *
	 * @param maskSamples a 3D array with the samples of the mask with boolean format
	 * @param maskFile the name of the file to save the mask in visible format
	 * @param format the format to store the mask in the disk. 0- PNM, 1- TIFF, 2- PNG, 3- JPEG, 4- BMP
	 */
	public static void SaveMaskFormat(byte[][][] maskSamples, String maskFile, int format) throws ErrorException{
		float dataValue = 255f;
		int zSize = maskSamples.length;
		int ySize = maskSamples[0].length;
		int xSize = maskSamples[0][0].length;
		float[][][] maskSamplesFloat;
		
		//Stores the mask in bi-level format
		if(maskFile.contains("_bin")){
			dataValue = 1F;
		}
		
		maskSamplesFloat = new float[zSize][ySize][xSize];
		
		for(int z = 0; z < zSize; z++){
		for(int y = 0; y < ySize; y++){
		for(int x = 0; x < xSize; x++){
			if(maskSamples[z][y][x] != 0){
				maskSamplesFloat[z][y][x] = dataValue;
			}else{
				maskSamplesFloat[z][y][x] = 0f;
			}
		}}}

		try{
			SaveFile.SaveFileFormat(maskSamplesFloat, maskFile, format);
		}catch (WarningException e){
			throw new ErrorException(e.getMessage());
		}
	}

	/**
	 * Saves the mask in a file.
	 *
	 * @param maskSamples a 3D array with the samples of the mask with boolean format
	 * @param maskFile the name of the file to save the mask in .pgm format
	 * @param byteOrder 0 if BIG_ENDIAN, 1 if LITTLE_ENDIAN
	 */
	public static void SaveMaskRaw(byte[][][] maskSamples, String maskFile, int byteOrder) throws WarningException{
		int zSize = maskSamples.length;
		int ySize = maskSamples[0].length;
		int xSize = maskSamples[0][0].length;
		float[][][] maskSamplesFloat;
		
		maskSamplesFloat = new float[zSize][ySize][xSize];
		
		for(int z = 0; z < zSize; z++){
			for(int y = 0; y < ySize; y++){
				for(int x = 0; x < xSize; x++){
					if(maskSamples[z][y][x] != 0){
						maskSamplesFloat[z][y][x] = 1f;
					}else{
						maskSamplesFloat[z][y][x] = 0f;
					}
				}
			}
		}

		SaveFile.SaveFileRaw(maskSamplesFloat, maskFile, 0, byteOrder);
	}

}
