/*
 * GICI Library -
 * Copyright (C) 2007  Group on Interactive Coding of Images (GICI)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Group on Interactive Coding of Images (GICI)
 * Department of Information and Communication Engineering
 * Autonomous University of Barcelona
 * 08193 - Bellaterra - Cerdanyola del Valles (Barcelona)
 * Spain
 *
 * http://gici.uab.es
 * gici-info@deic.uab.es
 */
package GiciAnalysis;
import java.util.Set;
import java.util.TreeSet;

import GiciException.WarningException;
import GiciParallel.ParallelMap;


/**
 * This class receives two images and calculates its difference information (MSE and PSNR).
 *
 * @author Group on Interactive Coding of Images (GICI)
 * @version 1.0
 */
public final class ImageCompareSA implements ImageCompareInterface {
	
	/**
	 * ssim for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] covariance = null;

	/**
	 * variance for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] variance = null;
	
	/**
	 * variance for each image2 component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] variance2 = null;
	
	/**
	 * total variance
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalVariance;
	
	/**
	 * energy for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] energy = null;
	
	/**
	 * Total energy.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalEnergy = 0;
	
	/**
	 * Mean Absolute Error (MAE) for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] mae = null;

	/**
	 * Global Mean Absolute Error (MSE) of the image.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalMAE = 0;
	
	/**
	 * Peak Absolute Error (MAE) for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] pae = null;

	/**
	 * Global Peak Absolute Error (PAE) of the image.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalPAE = 0;

	/**
	 * Mean Squared Error (MSE) for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] mse = null;

	/**
	 * Global Mean Squared Error (MSE) of the image.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalMSE = 0;

	/**
	 * Root Mean Squared Error (MSE) for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] rmse = null;

	/**
	 * Global Root Mean Squared Error (MSE) of the image.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalRMSE = 0;

	/**
	 * Mean Error (ME) for each image component.
	 * <p>
	 * All values allowed.
	 */
	private double[] me = null;

	/**
	 * Global Mean Error (MSE) of the image.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalME = 0;

	/**
	 * Signal to Noise Ratio (SNR) for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] snr = null;
	
	/**
	 * Signal to Noise Ratio (SNR) for each image component calculated with original image Variance.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] snrVar = null;

	/**
	 * Global Signal to Noise Ratio (SNR) of the image.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalSNR = 0;
	
	/**
	 * Global Signal to Noise Ratio calculated with original image variance (SNR) of the image.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalSNRVAR = 0;

	/**
	 * Peak Signal to Noise Ratio (PSNR) for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] psnr = null;
	private double[] psnrSalomon = null;

	/**
	 * Global Peak Signal to Noise Ratio (PSNR) of the image.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalPSNR;
	private double totalPSNRSALOMON;

	/**
	 * Equality for each image component.
	 * <p>
	 * True or false.
	 */
	private boolean[] equal;

	/**
	 * Global equality of the image.
	 * <p>
	 * True or false.
	 */
	private boolean totalEQUAL;

	/**
	 * ssim for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] ssim = null;
	
	/**
	 * Global SSIM of the image.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalSSIM = 0;
	
	/**
	 * Relative RMSE for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] rrmse = null;
	
	/**
	 * Global Relative RMSE of the image.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalRRMSE = 0;
	
	/**
	 * Normalized MSE for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] nmse = null;
	
	/**
	 * Global Normalized MSE of the image.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalNMSE = 0;
	
	/**
	 * PSNR-NC for each image component.
	 * <p>
	 * Only positive values allowed.
	 */
	private double[] psnrNc = null;
	
	/**
	 * Global PSNR-NC of the image.
	 * <p>
	 * Only positive values allowed.
	 */
	private double totalPSNRNC = 0;
	
	
	/**
	 * Number of pixels encoded for the current mask.
	 * <p>
	 * Only positive values allowed.
	 */
	private long[] imagePixels = null;
	
	/**
	 * Contains the relationship between mask values and weights to be applied during the distortion measure calculation.
	 * <p>
	 * Only positive values allowed
	 */
	private float[] regionOfInterest = null;

	/**
	 * Original Image.
	 */
	private float[][][] image1 = null;
	
	/**
	 * Recovered Image.
	 */
	private float[][][] image2 = null;
	
	/**
	 * Mask.
	 */
	private byte[][][] mask = null;
	
	/**
	 * Constructor that does all the operations to compare images.
	 *
	 * @param inputImage1 a 3D float array of image samples (index are [z][y][x])
	 * @param inputImage2 a 3D float array of image samples (index are [z][y][x])
	 * @param pixelBitDepth number of bits for the specified image sample type (for each component)
	 * @param variance_deprecated is no longer used because is cheap to compute and the aggregated 
	 * variance is not trivial to compute (although not impossible if you have the energy)
	 *
	 * @throws WarningException when image sizes are not the same
	 */
	public ImageCompareSA(final float[][][] inputImage1, final float[][][] inputImage2, final int[] pixelBitDepth,
			final byte[][][] inputMask, final  float[] inputROI, final int inverse, final Set<Integer> components)
				throws WarningException {
		
		this.image1 = inputImage1;
		this.image2 = inputImage2;
		this.mask = inputMask;
		
		//Size set
		int zSize1 = inputImage1.length;
		int ySize1 = inputImage1[0].length;
		int xSize1 = inputImage1[0][0].length;

		int zSize2 = inputImage2.length;
		int ySize2 = inputImage2[0].length;
		int xSize2 = inputImage2[0][0].length;
		
		// Check if images have the same size
		if ((ySize1 != ySize2) || (xSize1 != xSize2)) {
			throw new WarningException("Image sizes (ySize and xSize) must be the same on both images to perform"
					+ " comparisons for a specific components.");
		}

		// And that the components to compare exists in both images
		for (int z : components) {
			if (z >= zSize1 || z >= zSize2) {
				throw new WarningException("Component " + z + " (zero based offset) does not exists for one of the images.");
			}
		}		
		
		int maskZSize = 0;
		int maskYSize = 0;
		int maskXSize = 0;
		
		if (inputMask != null) {
			maskZSize = inputMask.length;
			maskYSize = inputMask[0].length;
			maskXSize = inputMask[0][0].length;
	
			//Check if the mask has the same size
			if ((maskZSize != zSize2) || (maskYSize != ySize2) || (maskXSize != xSize2)) {
				throw new WarningException("Mask size must match image size to perform the comparison.");
			}
		}
		
		// Check for overflows
		// We are using IEEE 754 binary64 doubles with 53 bits of mantissa 	
		// New strategy: check for the error after it occurs		
		int imprecisionBits = 0;
				
		// ROI
		this.regionOfInterest = inputROI;
		
		// Count the mask pixels		
		imagePixels = new long[zSize1];
		long totalImagePixels = 0;

		for (int z : components) {
			if (inputMask != null) {
				//Number of pixels in the foreground of the image
				for (int y = 0; y < ySize1; y++) {
					for (int x = 0; x < xSize1; x++) {
						if (inputMask[z][y][x] == 1) {
							imagePixels[z]++;
						}
					}
				}
			} else {
				imagePixels[z] = xSize1 * ySize1;
			}
			
			totalImagePixels += imagePixels[z];
		}
		
		// Do all the energy things before
		energy = new double[zSize1];
		variance = new double[zSize1];
		variance2 = new double[zSize2];
		covariance = new double[zSize1];
		totalEnergy = 0;
		totalVariance = 0;
		
		final double[] mean = new double[zSize1];
		final double[] mean2 = new double[zSize2];
		final double[] sum = new double[zSize1];
		final double[] sum2 = new double[zSize1];
		final double[] max = new double[zSize1];
		
		// Two iterations are need for numerical stability
		// It is _not_ possible to use the abbreviated formula
		ParallelMap.map(new ParallelMap.ListIterator(components), new ParallelMap.MapInterface<Integer>() {
			public void apply(final Integer z) {
				double squaredSum = 0;
				double squaredSum2 = 0;
				
				max[z] = Double.NEGATIVE_INFINITY;
				
				for (int y = 0; y < inputImage1[z].length; y++) {
					for (int x = 0; x < inputImage1[z][y].length; x++) {
						if (inputMask == null || inputMask[z][y][x] == 1) {
							double value = inputImage1[z][y][x];
							double value2 = inputImage2[z][y][x];
							sum[z] += value;
							sum2[z] += value2;
							squaredSum += value * value;
							squaredSum2 += value2 * value2;
							max[z] = Math.max(max[z], value);
						}
					}
				}

				mean[z] = sum[z] / imagePixels[z];
				mean2[z] = sum2[z] / imagePixels[z];

				energy[z] = squaredSum;
			}
		});
		
		// Accumulate parallel results
		double totalSum = 0;
		double totalSum2 = 0;
		double totalMax = Double.NEGATIVE_INFINITY;
		
		for (int z : components) {
			totalSum += sum[z];
			totalSum2 += sum2[z];
			totalEnergy += energy[z];
			totalMax = Math.max(totalMax, max[z]);
		}
		
		// Overflow check
		imprecisionBits = imprecisionBits(totalEnergy, imprecisionBits);
		imprecisionBits = imprecisionBits(totalSum, imprecisionBits);
		imprecisionBits = imprecisionBits(totalSum2, imprecisionBits);
		
		final double totalMean = totalSum / totalImagePixels;
		final double totalMean2 = totalSum2 / totalImagePixels;
		
		final double[] localSquaredDifferenceSum = new double[zSize1];
		final double[] localSquaredDifferenceSum2 = new double[zSize1];
		
		ParallelMap.map(new ParallelMap.ListIterator(components), new ParallelMap.MapInterface<Integer>() {
			public void apply(final Integer z) {

				double squaredDifferenceSum = 0;
				double squaredDifferenceSum2 = 0;
				double productDifference = 0;

				for (int y = 0; y < inputImage1[z].length; y++) {
					for (int x = 0; x < inputImage1[z][y].length; x++) {
						if (inputMask == null || inputMask[z][y][x] == 1) {
							double value = inputImage1[z][y][x] - mean[z];
							double value2 = inputImage2[z][y][x] - mean2[z];
							squaredDifferenceSum += value * value;
							squaredDifferenceSum2 += value2 * value2;
							productDifference += value * value2;

							double totalValue = inputImage1[z][y][x] - totalMean;
							double totalValue2 = inputImage2[z][y][x] - totalMean2;
							localSquaredDifferenceSum[z] += totalValue * totalValue;
							localSquaredDifferenceSum2[z] += totalValue2 * totalValue2;
						}
					}
				}

				variance[z] = squaredDifferenceSum / imagePixels[z];
				variance2[z] = squaredDifferenceSum2 / imagePixels[z];
				covariance[z] = productDifference / imagePixels[z];			
			}
		});
		
		// Accumulate parallel results
		double totalSquaredDifferenceSum = 0;
		double totalSquaredDifferenceSum2 = 0;
		
		for (int z : components) {
			totalSquaredDifferenceSum += localSquaredDifferenceSum[z];
			totalSquaredDifferenceSum2 += localSquaredDifferenceSum2[z];
		}
		
		// Overflow check
		imprecisionBits = imprecisionBits(totalSquaredDifferenceSum, imprecisionBits);
		
		totalVariance = totalSquaredDifferenceSum / totalImagePixels;
		
		// Memory allocation for the intermediate results
		final double[] absoluteErrorSum = new double[zSize1];
		final double[] absoluteErrorPeak = new double[zSize1];
		final double[] squaredErrorSum = new double[zSize1];
		final double[] errorSum = new double[zSize1];
		final double[] squaredRelativeErrorSum = new double[zSize1];
		
		//long[] squaredErrorSumInt = new long[zSize1];
		
		// Fill the intermediate results
		ParallelMap.map(new ParallelMap.ListIterator(components), new ParallelMap.MapInterface<Integer>() {
			public void apply(final Integer z) {
				// Initialize (all the others are properly initialized as 0)
				absoluteErrorPeak[z] = Double.NEGATIVE_INFINITY;
				
				// Main loop
				for (int y = 0; y < inputImage1[z].length; y++) {
					for (int x = 0; x < inputImage1[z][y].length; x++) {
						final double error = getDiff(z, y, x);
						final double value1 = (double) inputImage1[z][y][x];
						
						// Fill
						absoluteErrorSum[z] += Math.abs(error);
						absoluteErrorPeak[z] = Math.max(absoluteErrorPeak[z], Math.abs(error));
						squaredErrorSum[z] += error * error;
						errorSum[z] += error;
						
						final double relativeError;
						
						if (error == 0) {
							relativeError = 0; // When error is zero, relativeError is also zero regardless of value1.
						} else {
							relativeError = (error * error) / (value1 * value1);
						}
							
						squaredRelativeErrorSum[z] += relativeError;
					}
				}
			}
		});
		
		// Memory allocation for the results
		mae = new double[zSize1];
		pae = new double[zSize1];
		mse = new double[zSize1];
		rmse = new double[zSize1];
		me = new double[zSize1];
		snr = new double[zSize1];
		snrVar = new double[zSize1];
		psnr = new double[zSize1];
		psnrSalomon = new double[zSize1];
		equal = new boolean[zSize1];
		ssim = new double[zSize1];
		rrmse = new double[zSize1];
		nmse = new double[zSize1];
		psnrNc = new double[zSize1];
		
		// Generate final per component results
		for (int z : components) {
			double range = getRange(pixelBitDepth[z]);
			
			mae[z] = absoluteErrorSum[z] / imagePixels[z];
			pae[z] = absoluteErrorPeak[z];
			mse[z] = squaredErrorSum[z] / imagePixels[z];
			rmse[z] = Math.sqrt(mse[z]);
			me[z] = errorSum[z] / imagePixels[z];
			snr[z] = 10 * Math.log10(energy[z]  / (mse[z] * imagePixels[z]));
			snrVar[z] = 10 * Math.log10(variance[z] / mse[z]);
			psnr[z] = 10 * Math.log10(range * range / mse[z]);
			psnrSalomon[z] = 10 * Math.log10((range + 1) * (range + 1) / (4 * mse[z]));
			equal[z] = (absoluteErrorSum[z] == 0);
			
			// ssim
			final double c1 = (0.01 * range) * (0.01 * range);
			final double c2 = (0.03 * range) * (0.03 * range);
			ssim[z] = ((2 * mean[z] * mean2[z] + c1) * (2 * covariance[z] + c2))
				/ ((mean[z] * mean[z] + mean2[z] * mean2[z] + c1) * (variance[z] + variance2[z] + c2));
			
			// Alternative definition?
			// double C3 = C2/2;
			// ssim[z] = ((2*mean[z]*mean2[z]+C1)/(mean[z]*mean[z]+mean2[z]*mean2[z]+C1))
			// * ((2*Math.sqrt(variance[z])*Math.sqrt(variance2[z])+C2)/(variance[z]+variance2[z]+C2))
			// * ((sigmaxy[z]+C3)/(Math.sqrt(variance[z])*Math.sqrt(variance2[z])+C3));
			
			rrmse[z] = Math.sqrt(squaredRelativeErrorSum[z] / imagePixels[z]);
			nmse[z] = 100 * mse[z] / energy[z];
			psnrNc[z] = 10 * Math.log10(max[z] * max[z] / mse[z]);
		}
		
		// Calculus of Total Intermediate results
		double totalAbsoluteErrorSum = 0;
		double totalAbsoluteErrorPeak = Double.NEGATIVE_INFINITY;
		double totalSquaredErrorSum = 0;
		double totalErrorSum = 0;
		totalSSIM = 0;
		totalRRMSE = 0;
		
		for (int z : components) {
			totalAbsoluteErrorSum += absoluteErrorSum[z];
			totalAbsoluteErrorPeak = Math.max(totalAbsoluteErrorPeak, absoluteErrorPeak[z]);
			totalSquaredErrorSum += squaredErrorSum[z];
			totalErrorSum += errorSum[z];
			totalSSIM += ssim[z];
			totalRRMSE += squaredRelativeErrorSum[z];
		}
		
		// Overflow check
		imprecisionBits = imprecisionBits(totalAbsoluteErrorSum, imprecisionBits);
		imprecisionBits = imprecisionBits(totalAbsoluteErrorPeak, imprecisionBits);
		imprecisionBits = imprecisionBits(totalSquaredErrorSum, imprecisionBits);
				
		// Calculus of Total final results
		double totalRange = getRange(pixelBitDepth[0]);
		
		for (int bitDepth : pixelBitDepth) {
			if (getRange(bitDepth) != totalRange) {
				throw new WarningException("Totals may be undefined as bit depth varies across components.");
			}
		}
		
		totalMAE = totalAbsoluteErrorSum / totalImagePixels;
		totalPAE = totalAbsoluteErrorPeak;
		totalMSE = totalSquaredErrorSum / totalImagePixels;  
		totalRMSE = Math.sqrt(totalMSE);
		totalME = totalErrorSum / totalImagePixels;
		totalSNR = 10 * Math.log10(totalEnergy  / (totalMSE * totalImagePixels));
		totalSNRVAR = 10 * Math.log10(totalVariance / totalMSE);
		totalPSNR = 10 * Math.log10(totalRange * totalRange / totalMSE);
		totalPSNRSALOMON = 10 * Math.log10((totalRange + 1) * (totalRange + 1) / (4 * totalMSE));
		totalEQUAL = (totalAbsoluteErrorSum == 0);
		totalSSIM = totalSSIM / components.size();
		totalRRMSE = Math.sqrt(totalRRMSE / totalImagePixels);
		totalNMSE = 100 * totalMSE / totalEnergy;
		totalPSNRNC = 10 * Math.log10(totalMax * totalMax / totalMSE);
		
		// Report overflows in case they occur
		if (imprecisionBits > 0) {
			System.err.println("Inexact results may be produced due to insufficient mantissa bits (at least "
					+ imprecisionBits + " more bits required).");
			
			double voxels = components.size() * ySize1 * xSize1;

			double maxBitDepthRange = 0;

			for (int z : components) {
				if (pixelBitDepth[z] > 12) {
					maxBitDepthRange = Math.max(getRealRange(z), maxBitDepthRange);
				} else {
					maxBitDepthRange = Math.max(getRange(pixelBitDepth[z]), maxBitDepthRange);
				}
			}

			// requiredBits be inaccurate due to insufficient mantissa bits, but it shall work anyway
			// maxBitDepthRange is squared because it is also squared in the computation
			double requiredBits = Math.ceil(Math.log(voxels * maxBitDepthRange * maxBitDepthRange) / Math.log(2));
			double requiredBitsNoMSE = Math.ceil(Math.log(voxels * maxBitDepthRange) / Math.log(2));
			double requiredBitsNoMulti = Math.ceil(Math.log(ySize1 * xSize1 * maxBitDepthRange * maxBitDepthRange) / Math.log(2));
			double requiredBitsNoMultiMSE = Math.ceil(Math.log(ySize1 * xSize1 * maxBitDepthRange) / Math.log(2));

			final int maxMantisa = 52; 

			if (requiredBits > maxMantisa) {
				System.err.println("Image too large for exact computations. Required precision for this image is "
						+ requiredBits + " bits.");

				if (requiredBitsNoMSE <= maxMantisa) {
					System.err.println("* All but MSE related measures (MSE, PSNR, SNR) are still accurate.");
				}

				if (requiredBitsNoMulti <= maxMantisa) {
					System.err.println("* Individual component results are still accurate");
				}

				if (requiredBitsNoMultiMSE <= maxMantisa && requiredBitsNoMSE > maxMantisa && requiredBitsNoMulti > maxMantisa) {
					System.err.println("* Individual component results of all but MSE related measures (MSE, PSNR, SNR)"
							+ " are still accurate.");
				}
			}
		}
	}
	
	/**
	 * Returns a set with either one or zSize1 elements. If component is negative the set contains the elements
	 * from 0 to zSize-1 both included, in the other case the set contains the element component.
	 * @param component
	 * @param zSize1
	 * @return
	 */
	private static Set<Integer> buildSetOfComponentsFromIntegerParameter(final int component, final int zSize1) {
		Set<Integer> components = new TreeSet<Integer>();
			
		if (component < 0) {	
			for (int z = 0; z < zSize1; z++) {
				components.add(z);
			}
		} else {
			components.add(component);
		}
		
		return components;
	}
	
	/**
	 * See the other constructor for a definition. DEPRECATED.
	 */
	public ImageCompareSA(final float[][][] inputImage1, final float[][][] inputImage2, final int[] pixelBitDepth,
			final byte[][][] inputMask, final float[] inputROI, final int inverse, final int component,
			final int deprecatedMeasure, final double[] deprecatedEnergy, final double[] deprecatedVariance)
				throws WarningException {
		
		this(inputImage1, inputImage2, pixelBitDepth, inputMask, inputROI, inverse,
				buildSetOfComponentsFromIntegerParameter(component, inputImage1.length));
	}
	
	private int imprecisionBits(final double a, final int previousMax) {
		final double largestExactDouble = 0x1FFFFFFFFFFFFFL;
		int r = 0;
		
		if (a > largestExactDouble) {
			r = Math.max(previousMax, (int) Math.ceil(Math.log(a / largestExactDouble) / Math.log(2)));
		}
		
		return r;
	}
	
	/**
	 * @param z indicating the component
	 * @return range for an specific component
	 */
	public double getRealRange(final int z) {
		
		float min = Float.MAX_VALUE;
		float max = Float.MIN_VALUE;

		for (int y = 0; y < image1[z].length; y++) {
			for (int x = 0; x < image1[z][y].length; x++) {
				min = Math.min(Math.min(image1[z][y][x], image2[z][y][x]), min);
				max = Math.max(Math.max(image1[z][y][x], image2[z][y][x]), max);
			}
		}
		
		// assume signed
		int pixelBitDepth = (int) Math.max(Math.ceil(Math.log(max + 1) / Math.log(2)), Math.ceil(Math.log(Math.abs(min)) / Math.log(2))) + 1;
		// (int)Math.ceil(Math.log(max + 1) / Math.log(2));
		
		double range = 0;
		double maxFactor = 0;
		if (regionOfInterest != null) {
			for (int i = 0; i < regionOfInterest.length / 2; i++) {
				//first measure
				if (regionOfInterest[(i * 2) + 1] > maxFactor) {
					maxFactor = regionOfInterest[(i * 2) + 1];
				}
			}
			range = Math.pow(2D, (double) pixelBitDepth) * maxFactor - 1;
		} else {
			range = Math.pow(2D, (double) pixelBitDepth) - 1;
		}
		
		return range;
	}
	
	/**
	 * @param z indicating the component
	 * @param pixelBitDepth
	 * @return range for an specific component
	 */
	public double getRange(final int pixelBitDepth) {
		double range = 0;
		double maxFactor = 0;
		if (regionOfInterest != null) {
			for (int i = 0; i < regionOfInterest.length / 2; i++) {
				//first measure
				if (regionOfInterest[(i * 2) + 1] > maxFactor) {
					maxFactor = regionOfInterest[(i * 2) + 1];
				}
			}
			range = Math.pow(2D, (double) pixelBitDepth) * maxFactor - 1;
		} else {
			range = Math.pow(2D, (double) pixelBitDepth) - 1;
		}
		
		return range;
	}
	
	/**
	 * @param z indicating the component
	 * @param x 
	 * @param y
	 * @return difference between original and recovered, considering the factor used in prioritized distortion measures
	 */
	private double getDiff(final int z, final int y, final int x) {
		double factor = 1D;
		double diff = 0D;
		
		if (regionOfInterest != null) {
			//Difference for the P-MSE
			for (int i = 0; i < regionOfInterest.length / 2; i++) {
				if (regionOfInterest[i * 2] - 128 == mask[z][y][x]) {
					factor = regionOfInterest[(i * 2) + 1];
					i = regionOfInterest.length;
				}
			}
			diff = (image1[z][y][x] - image2[z][y][x]) * factor;
		} else {
			//Standard difference calculation
			if (mask == null || mask[z][y][x] == 1) {
				diff = (image1[z][y][x] - image2[z][y][x]);
			}
		}
		return diff;
	}

	/**
	 * @return mae definition in this class
	 */
	public double[] getMAE() {
		return mae;
	}

	/**
	 * @return totalMAE definition in this class
	 */
	public double getTotalMAE() {
		return totalMAE;
	}

	/**
	 * @return pae definition in this class
	 */
	public double[] getPAE() {
		return pae;
	}

	/**
	 * @return totalPAE definition in this class
	 */
	public double getTotalPAE() {
		return totalPAE;
	}

	/**
	 * @return mse definition in this class
	 */
	public double[] getMSE() {
		return mse;
	}

	/**
	 * @return totalMSE definition in this class
	 */
	public double getTotalMSE() {
		return totalMSE;
	}

	/**
	 * @return rmse definition in this class
	 */
	public double[] getRMSE() {
		return rmse;
	}

	/**
	 * @return totalRMSE definition in this class
	 */
	public double getTotalRMSE() {
		return totalRMSE;
	}

		/**
	 * @return me definition in this class
	 */
	public double[] getME() {
		return me;
	}

	/**
	 * @return totalME definition in this class
	 */
	public double getTotalME() {
		return totalME;
	}

	/**
	 * @return snr definition in this class
	 */
	public double[] getSNR() {
		return snr;
	}

	/**
	 * @return totalSNR definition in this class
	 */
	public double getTotalSNR()  {
		return totalSNR;
	}

	/**
	 * @return psnr definition in this class
	 */
	public double[] getPSNR() {
		return psnr;
	}

	/**
	 * @return totalPSNR definition in this class
	 */
	public double getTotalPSNR() {
		return totalPSNR;
	}
	
	/**
	 * @return psnr definition in this class
	 */
	public double[] getPSNRSALOMON() {
		return psnrSalomon;
	}

	/**
	 * @return totalPSNR definition in this class
	 */
	public double getTotalPSNRSALOMON() {
		return totalPSNRSALOMON;
	}

	/**
	 * @return equal definition in this class
	 */
	public boolean[] getEQUAL() {
		return equal;
	}

	/**
	 * @return totalEQUAL definition in this class
	 */
	public boolean getTotalEQUAL() {
		return totalEQUAL;
	}

	/**
	 * @return snr definition in this class
	 */
	public double[] getSNRVAR() {
		return snrVar;
	}

	/**
	 * @return totalSNR definition in this class
	 */
	public double getTotalSNRVAR() {
		return totalSNRVAR;
	}
	
	/**
	 * @return covariance definition in this class
	 */
	public double[] getCovariance() {
		return covariance;
	}
	
	/**
	 * @return ssim definition in this class
	 */
	public double[] getSSIM() {
		return ssim;
	}

	/**
	 * @return totalSSIM definition in this class
	 */
	public double getTotalSSIM() {
		return totalSSIM;
	}
	
	public double[] getRRMSE() {
		return rrmse;
	}

	public double getTotalRRMSE() {
		return totalRRMSE;
	}

	public double[] getNMSE() {
		return nmse;
	}

	public double getTotalNMSE() {
		return totalNMSE;
	}

	public double[] getPSNRNC() {
		return psnrNc;
	}

	public double getTotalPSNRNC() {
		return totalPSNRNC;
	}
}
