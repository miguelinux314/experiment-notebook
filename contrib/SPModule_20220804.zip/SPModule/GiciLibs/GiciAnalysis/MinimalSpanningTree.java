package GiciAnalysis;

import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Set;
import java.util.TreeSet;

import GiciTransform.Permutation;

public class MinimalSpanningTree implements Runnable {
	final float[][] adjacencyMatrix;
	
	final int N;
	
	final int[] parents;
	final float[] costs;
	final Set<Integer> remainingNodes = new TreeSet<Integer>();
	
	public MinimalSpanningTree(final float[][] adjacencyMatrix) {
		this.adjacencyMatrix = adjacencyMatrix;
		
		this.N = adjacencyMatrix.length;
		assert (N == adjacencyMatrix[0].length);
		assert (N > 0);
		
		parents = new int[N];
		costs = new float[N];
		
		for (int i = 0; i < N; i++) {
			remainingNodes.add(i);
			parents[i] = -1;
			costs[i] = Float.POSITIVE_INFINITY;
		}
	}
	
	private void updateCostsAndRemove(final int selectedNode) {
		remainingNodes.remove(selectedNode);
		
		for (int i : remainingNodes) {
			if (adjacencyMatrix[selectedNode][i] < costs[i]) {
				costs[i] = adjacencyMatrix[selectedNode][i];
				parents[i] = selectedNode;
			}
		}
		
	}
	
	private int getNearestNode() {
		float bestCost = Float.POSITIVE_INFINITY;
		int bestNode = -1;
		
		for (int i : remainingNodes) {
			if (costs[i] <= bestCost) {
				bestCost = costs[i];
				bestNode = i;
			}
		}

		return bestNode;
	}
	
	public int[] getPermutation(int mode) {
		/*final*/int[] permutation = new int[N];
		
		if (mode == 0 || mode == 1 || mode == 3) {
			int index = 0;

			final Queue<Integer> remainingParents = new ArrayDeque<Integer>();
			remainingParents.add(-1);

			while (remainingParents.size() != 0) {
				int currentParent = remainingParents.peek();

				float min = Float.POSITIVE_INFINITY;
				int pos = -1;

				for (int i = 0; i < N; i++) {
					if (parents[i] == currentParent && ! remainingParents.contains(i)) {
						if (adjacencyMatrix[i][i] < min) {
							min = adjacencyMatrix[i][i];
							pos = i;
						}
					}
				}

				if (pos != -1) {
					permutation[index++] = pos;
					remainingParents.add(pos);
				} else {
					remainingParents.remove(currentParent);
				}
			}
		}
		
		/* test: just sort them by variance */
		if(mode == 2) {
			final TreeSet<Integer> remaining = new TreeSet<Integer>();

			for (int i=0; i < N; i++) {
				float max = Float.NEGATIVE_INFINITY;
				int pos = -1;

				for (int j=0; j < N; j++) {
					if (! remaining.contains(j)) {
						if (adjacencyMatrix[j][j] > max) {
							pos = j;
							max = adjacencyMatrix[j][j];
						}
					}
				}

				remaining.add(pos);

				permutation[i] = pos;
			}
		}
		
		if (mode == 4) {
			// my custom permutation
			Permutation p = new Permutation(N);
			// interesting things
			p.permutationBringTo(7, 0, 50);
			p.permutationBringTo(76, 50, 45);
			p.permutationBringTo(134, 95, 32);
			
			permutation = p.getPermutation();
		}
		
		if (mode == 5) {
			// my custom permutation
			Permutation p = new Permutation(N);
			// interesting things
			p.permutationBringTo(7, 0, 50);
			p.permutationBringTo(76, 50, 148);
			
			permutation = p.getPermutation();
		}
		
		return permutation;
	}

	public int[] getParents() {
		return parents;
	}
	
	public void run() {
		while (remainingNodes.size() != 0) {
			final int selectedNode = getNearestNode();
			updateCostsAndRemove(selectedNode);
		}
	}
	
}
