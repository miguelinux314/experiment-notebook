package GiciAnalysis.jUnits;

import java.util.Random;

import GiciAnalysis.Epsilon;
import GiciAnalysis.HalfFloat;
import junit.framework.TestCase;

public class TestHalfFloat extends TestCase {
	public void testBasic() {

		assertTrue((new HalfFloat(HalfFloat.MIN_VALUE.floatValue())).equals(HalfFloat.MIN_VALUE));
		
		assertFalse((new HalfFloat(HalfFloat.MAX_VALUE.floatValue() - 1)).isInfinite());
		assertTrue((new HalfFloat(HalfFloat.MAX_VALUE.floatValue() + 1)).isInfinite());
		assertFalse(new HalfFloat(HalfFloat.MAX_VALUE.floatValue()).isInfinite());
		assertTrue((new HalfFloat(-HalfFloat.MAX_VALUE.floatValue() - 1)).isInfinite());
		assertTrue(HalfFloat.MIN_VALUE.floatValue() != 0);
				
		
		HalfFloat e = new HalfFloat(1);
		assertTrue(e.intValue() == 1);
		
		HalfFloat f = new HalfFloat(.5);
		assertTrue(f.floatValue() == .5);
		
		HalfFloat a = new HalfFloat(Float.NaN);
		HalfFloat b = new HalfFloat(Float.POSITIVE_INFINITY);
		HalfFloat c = new HalfFloat(Float.NEGATIVE_INFINITY);
		
		assertTrue(a.isNaN());
		assertFalse(a.isInfinite());
		
		assertTrue(b.isInfinite());
		assertFalse(b.isNaN());
		
		assertTrue(c.isInfinite());
		assertFalse(c.isNaN());
		
		assertTrue(Float.isInfinite(HalfFloat.POSITIVE_INFINITY.floatValue()));
		assertTrue(Float.isInfinite(HalfFloat.NEGATIVE_INFINITY.floatValue()));
		assertTrue(HalfFloat.POSITIVE_INFINITY.floatValue() > 0);
		assertTrue(HalfFloat.NEGATIVE_INFINITY.floatValue() < 0);
		assertTrue(Float.isNaN(HalfFloat.NaN.floatValue()));
	}
	
	public void testTable() {
		HalfFloat t1 = new HalfFloat(-3.199458E-8f);
		assertTrue(t1.floatValue() == -0f);
	}
	
	public void testRandomStorage() {
		
		Random r = new Random(13);
		
		for (int i = 0; i < 3000; i++) {
			float in = r.nextFloat() * (r.nextInt(3) - 1);
			
			HalfFloat t1 = new HalfFloat(in);
			
			if (! t1.isNormal()) continue;
			
			float out = t1.floatValue();
			
			if (in != 0) {
				assertTrue(in / out < 1.0 + Epsilon.getHalfFloatEpsilon().floatValue());
				assertTrue(in / out > 1.0 - Epsilon.getHalfFloatEpsilon().floatValue());
			} else {
				assertTrue(out == in);
			}
		}
		
		for (int i = 0; i < 3000; i++) {
			double in = r.nextDouble() * (r.nextInt(3) - 1);;
			
			HalfFloat t1 = new HalfFloat(in);
			
			if (! t1.isNormal()) continue;
			
			double out = t1.doubleValue();
			
			if (in != 0) {
				assertTrue(in / out < 1.0 + Epsilon.getHalfFloatEpsilon().floatValue());
				assertTrue(in / out > 1.0 - Epsilon.getHalfFloatEpsilon().floatValue());
			} else {
				assertTrue(out == in);
			}
		}
		
		for (int i = 0; i < 3000; i++) {
			float in = r.nextFloat() * (r.nextInt(9) - 4);
			
			HalfFloat t1 = new HalfFloat(in);
			HalfFloat t2 = new HalfFloat(t1.floatValue());
			HalfFloat t3 = new HalfFloat(t2.floatValue());
			HalfFloat t4 = new HalfFloat(t3.doubleValue());
			
			assertTrue(t1.equals(t4));
		}
		
		for (int i = 0; i < 3000; i++) {
			float in = r.nextFloat() * (r.nextInt(9) - 4) * 0.00001f;
			
			HalfFloat t1 = new HalfFloat(in);
			HalfFloat t2 = new HalfFloat(t1.floatValue());
			HalfFloat t3 = new HalfFloat(t2.floatValue());
			HalfFloat t4 = new HalfFloat(t3.doubleValue());
			
			assertTrue(t1.equals(t4));
		}
		
		for (int i = 0; i < 3000; i++) {
			float in = r.nextFloat() * (r.nextInt(9) - 4);
			
			HalfFloat t1 = new HalfFloat(in);			
			short value1 = HalfFloat.halfFloatToRawShortBits(t1);
			HalfFloat t2 = HalfFloat.shortBitsToFloat(value1);
			short value2 = HalfFloat.halfFloatToRawShortBits(t2);

			assertTrue(t1.equals(t2));
			assertTrue(value1 == value2);
		}
	}
}
