package GiciAnalysis.jUnits;

import java.util.Random;

import GiciAnalysis.IsoData;
import GiciAnalysis.VectorDistance;
import junit.framework.TestCase;

public class TestIsoData extends TestCase {

	static VectorDistance getSAM () {
		return new VectorDistance(){
			public float distance(float[] a, float[] b) {
				/* dot product */
				float acc1 = 0;
				float acc2 = 0;
				float acc3 = 0;

				for (int i = 0; i < a.length; i++) {
					acc1 += a[i] * b[i];
					acc2 += a[i] * a[i];
					acc3 += b[i] * b[i];
				}

				// FIXME!! a metric has to be defined for every point in space, and
				// this one is not!
				if (acc2 * acc3 < 0.000001f) {
					return 0;
				}
				
				double t = acc1 / (Math.sqrt(acc2) * Math.sqrt(acc3)); 
				
				// Check for slightly larger dot products that produce NaNs on acos.
				if (Math.abs(t) > 1) {
					return (float) Math.acos(Math.signum(t));
				}
				
				return (float) Math.acos(t);
				// This result is in degrees!
			}
		};
	}
	
	private VectorDistance createDot() {
		VectorDistance x = new VectorDistance(){
			public float distance(float[] a, float[] b) {
				/* dot product */
				float acc = 0;
				
				for (int i = 0; i < a.length; i++) {
					acc += a[i] * b[i];
				}
				
				return acc;
			}
		};
			
		return x;
	}
	
	public void testDotProduct () {
		VectorDistance x = createDot();
		
		float[] a = {1,1,1,0,0,0};
		float[] b = {1,1,1,0,0,0};
		float[] c = {1,0,1,0,1,0};
		float[] d = {.1f,.1f,.1f,0,0,0};
		float[] e = {.1f,.1f,.5f,0,0,0};
		
		assertTrue(x.distance(a, b) == 3);
		assertTrue(x.distance(a, a) == 3);
		assertTrue(x.distance(a, c) == 2);
		assertTrue(x.distance(a, d) == .3f);
		assertTrue(x.distance(a, e) == .7f);
		assertTrue(x.distance(e, d) == .07f);
	}
	
	private IsoData createIsoData(float[][] f, int c) {
		return new IsoData(f, getSAM(), c);
	}
	
	public void testMeFirst () {
		
		float[][] a = {
				{1,0,1,0},
				{0,1,1,1},
		};
		
		IsoData kmeans = createIsoData(a, 2);

		try {
			int[] x = kmeans.call();

			for (int i = 0; i < x.length; i++) {
				System.err.println(" " + x[i]);
			}
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false);
		}

	}
	
	public void testSpeed () {		
		float[][] a = new float[512*30/*vectors*/][150/*dimension*/];
		
		Random r = new Random(13);
		
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				a[i][j] = r.nextFloat() * 60000;
			}
		}
		
		IsoData kmeans = createIsoData(a, 10);

		try {
			int[] x = kmeans.call();
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false);
		}

	}
}
