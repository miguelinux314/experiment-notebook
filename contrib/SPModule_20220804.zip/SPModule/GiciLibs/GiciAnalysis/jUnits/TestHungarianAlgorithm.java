package GiciAnalysis.jUnits;

import GiciAnalysis.HungarianAlgorithm;
import GiciAnalysis.HungarianAlgorithm.WeightFunction;
import junit.framework.TestCase;

public class TestHungarianAlgorithm extends TestCase {

	public void testHungarianKnownExampleMinimize() {
		WeightFunction w = new HungarianAlgorithm.WeightFunction() {	
			float[][] c = {
					{7,2,1,9,4},
					{9,6,9,5,5},
					{3,8,3,1,8},
					{7,9,4,2,2},
					{8,4,7,4,8},
			};

			public float weight(int v, int u) {
				return c[v][u];
			}
		};

		HungarianAlgorithm h = new HungarianAlgorithm(5, w, false);
		h.solve();
		h.getMateStoT();
		h.getMateTtoS();
		double score = h.getScore();
		assertTrue (score == 15);
	}

	public void testHungarianKnownExampleMaximize() {

		WeightFunction w = new HungarianAlgorithm.WeightFunction() {	
			float[][] c = {
					{62, 75, 80, 93, 95, 97},
					{75, 80, 82, 85, 71, 97},
					{80, 75, 81, 98, 90, 97},
					{78, 82, 84, 80, 50, 98},
					{90, 85, 85, 80, 85, 99},
					{65, 75, 80, 75, 68, 96},
			};

			public float weight(int v, int u) {
				return c[v][u];
				//return -c[v][u];
			}
		};

		HungarianAlgorithm h = new HungarianAlgorithm(6, w);
		h.solve();
		h.getMateStoT();
		h.getMateTtoS();
		double score = h.getScore();
		assertTrue (score == 543);
	}

	public void testHungarianLarge() {
		HungarianAlgorithm.WeightFunction w = new HungarianAlgorithm.WeightFunction() {
			public float weight(int v, int u) {
				return v * ((8 * u + 5) % 512);
			}
		};
		
		HungarianAlgorithm h = new HungarianAlgorithm(600, w);
		h.solve();
		double score = h.getScore();
		assertTrue (score > 6E7);
	}

	public void testHungarianTryCrashWithMatrix() {
		int[] L = {32,1,2,54,33,11,17};

		for (int j : L) {
			final int size = j;

			float[][] w = new float[size][size];
			for (int v = 0; v < size; v++) {
				for (int u = 0; u < size; u++) {
					w[v][u] = (float) (v * ((8.321412341243124234 * u + 5.3214312341234123414) % 512));
					if (Math.abs(v-u) > 32) {
						w[v][u] = 100000000;
					}
				}	
			}

			HungarianAlgorithm h = new HungarianAlgorithm(size, w, true);
			h.solve();
			h.getMateStoT();
			h.getMateTtoS();
			h.getScore();
			// We are have not crashed
			assertTrue(true);
		}
	}

	public void testHungarianTryCrashWithFunction() {
		int[] L = {32,1,2,54,33,11,17};

		for (int j : L) {
			final int size = j;

			HungarianAlgorithm.WeightFunction w = new HungarianAlgorithm.WeightFunction() {
				public float weight(int v, int u) {
					if (Math.abs(v-u) > 32) {
						return 100000000;
					} else 
						return (float) (v * ((8.321412341243124234 * u + 5.3214312341234123414) % 512));
				}
			};

			HungarianAlgorithm h = new HungarianAlgorithm(size, w);
			h.solve();
			h.getMateStoT();
			h.getMateTtoS();
			h.getScore();
			// We are have not crashed
			assertTrue(true);
		}
	}
}
