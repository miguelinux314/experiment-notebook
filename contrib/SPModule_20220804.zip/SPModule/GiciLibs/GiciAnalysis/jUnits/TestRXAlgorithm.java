package GiciAnalysis.jUnits;

import java.util.Random;
import GiciAnalysis.RXAlgorithm;
import GiciMatrix.MatrixAlgebra;
import junit.framework.TestCase;

public class TestRXAlgorithm extends TestCase {

	float[][][] buildRandomImage(long seed) {
		Random ra = new Random(seed);

		int size1 = (int)(ra.nextFloat() * 15 + 1);
		int size2 = (int)(ra.nextFloat() * 15 + 1);
		// FIXME bug with 1 instead of 2
		int size3 = (int)(ra.nextFloat() * 15 + 2);

		System.out.println(size1 + " x " + size2 + " x " + size3);

		float[][][] r = new float[size1][size2][size3];
		
		for (int i = 0; i < r.length; i++) {
			for (int j = 0; j < r[i].length; j++) {
				for (int k = 0; k < r[i][j].length; k++) {
					r[i][j][k] = (ra.nextFloat() - 0.5f) * 256.0f;
				}
			}
		}

		return r;
	}
		
	float[][][] buildTestImage() {
		float[][][] r = {
				{{1, 2, 3, 4, 5, 6, 7, 8}},
				{{5, 3, 6, 8, 2, 6, 8, 8}},
				{{1, 3, 6, 8, 2, 6, 8, 8}},
		};
		
		/* Result shall be: 
		 * 2.4749f, 1.6303f, 1.2692f, 1.5395f, 2.0124f, 0.6572f, 1.1630f, 1.5499f
	 	 */
		
		return r;
	}
	
	public void testFirst () {
		final float[][][] img = buildTestImage();//buildRandomImage(23);
		RXAlgorithm rx = new RXAlgorithm(img);
		try {
			float[][] r = rx.call();
			float[][] rt1 = {{2.4749f, 1.6303f, 1.2692f, 1.5395f, 2.0124f, 0.6572f, 1.1630f, 1.5499f}};
			//float[][] rt2 = {{2.4583f, 0.5912f, 1.1541f, 1.5237f, 1.7578f, 0.6057f, 0.5891f, 0.8973f}};
			
			assertTrue(MatrixAlgebra.compare(r, rt1, 0.001f));// || MatrixAlgebra.compare(r, rt2, 0.001f));
			
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false);
		}
	}
}
