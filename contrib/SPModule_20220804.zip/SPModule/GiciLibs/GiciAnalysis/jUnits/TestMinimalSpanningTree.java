package GiciAnalysis.jUnits;

import GiciAnalysis.MinimalSpanningTree;
import GiciMatrix.MatrixAlgebra;
import junit.framework.TestCase;

public class TestMinimalSpanningTree extends TestCase {
	
	public void testOne() {
		final float[][] adjacencyMatrix = { {1,2,3,4,5}, {2,1,5,7,3}, {3,5,2,6,7}, {4,7,6,3,6}, {5,3,7,6,6} };
		MinimalSpanningTree mst = new MinimalSpanningTree(adjacencyMatrix);
	
		mst.run();
		
		int[] p = mst.getPermutation(0);
		
		MatrixAlgebra.printVector(p);
		
		p = mst.getParents();
		
		MatrixAlgebra.printVector(p);
	}

}
