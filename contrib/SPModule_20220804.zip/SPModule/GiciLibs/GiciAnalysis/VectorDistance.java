package GiciAnalysis;

public interface VectorDistance {
	public float distance(float[] a, float[] b);
}