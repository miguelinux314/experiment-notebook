
package GiciStream.jUnits;

import org.junit.*;
import static org.junit.Assert.*;

import GiciStream.*;

import java.io.*;
import java.util.*;


public class BitStreamTest {

	int len = 1024;
	byte[] data;

	DataInputStream in_data_stream;
	DataOutputStream out_data_stream;

	ByteArrayOutputStream byte_out;


	@Before
	public void randomData() {

		data = new byte[len];

		Random rand = new Random();
		rand.nextBytes(data);

		in_data_stream = new DataInputStream(new ByteArrayInputStream(data));

		byte_out = new ByteArrayOutputStream();
		out_data_stream = new DataOutputStream(byte_out);
	}


	@After
	public void countErrors() {

		byte[] buf = byte_out.toByteArray();

		int e = 0;
		for(int i = 0; i < len; i++) {
			if(data[i] != buf[i]) {
				e++;
			}
		}
		assertEquals("Errors", 0, e);
	}


	@Test
	public void testBytes() throws IOException {

		// write data
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		BitOutputStream bos = new BitOutputStream(out);

		for(int i = 0; i < len; i++) {
			bos.write(8, in_data_stream.read());
		}

		bos.close();

		// read data
		BitInputStream bis = new BitInputStream(new ByteArrayInputStream(out.toByteArray()));

		for(int i = 0; i < len; i++) {
			out_data_stream.write(bis.read(8));
		}

		bis.close();
	}


	@Test
	public void testInts() throws IOException {

		// write data
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		BitOutputStream bos = new BitOutputStream(out);

		for(int i = 0; i < len / 4; i++) {
			bos.write(32, in_data_stream.readInt());
		}

		bos.close();

		// read data
		BitInputStream bis = new BitInputStream(new ByteArrayInputStream(out.toByteArray()));

		for(int i = 0; i < len / 4; i++) {
			out_data_stream.writeInt(bis.read(32));
		}

		bis.close();
	}

}
