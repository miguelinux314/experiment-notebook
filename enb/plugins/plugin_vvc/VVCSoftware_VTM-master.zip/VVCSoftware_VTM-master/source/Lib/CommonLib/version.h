#if ! defined( VTM_VERSION )
#define VTM_VERSION "12.3"
#endif
