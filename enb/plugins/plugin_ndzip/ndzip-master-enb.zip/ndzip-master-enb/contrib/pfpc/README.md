# pFPC v1.0

pFPC is a parallel lossless compressor/decompressor by Martin Burtscher written in C for IEEE 754 64-bit double-precision floating-point data.

pFPC is included in this repository as third-party code for benchmarking purposes. See `pFPC.c` for licensing details. Small modifications have been made to the code to allow including it as a library.

Origin: https://userweb.cs.txstate.edu/~burtscher/research/pFPC/
