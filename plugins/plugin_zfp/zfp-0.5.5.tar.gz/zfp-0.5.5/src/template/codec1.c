/* order coefficients by polynomial degree/frequency */
cache_align_(static const uchar perm_1[4]) = {
  0, 1, 2, 3
};
